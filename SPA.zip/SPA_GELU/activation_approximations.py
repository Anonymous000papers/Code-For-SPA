"""Evaluators for every activation profile in the catalog.

One implementation serves three callers: the offline fitter
(``profile_math.py``, float64 numpy), the catalog audit, and the GPU
activation swap in ``eval_methods.py`` (float32 torch, optionally fused
by ``torch.compile``). Every function here is written against the
arithmetic that numpy arrays and torch tensors share (``+ - *`` with
Python-float constants), so the same code runs on both and the audit can
check the GPU path against the reference bit-for-bit up to dtype.

Profiles are plain dicts with a ``kind`` key. The four kinds:

``spa``
    Proposed method. ``x/2 + Q(2 x^2 / R^2 - 1)`` with ``Q`` a Chebyshev
    series; ``coefficients`` and ``operating_radius``.

``nexus``
    Reconstruction of the GELU shipped in NEXUS's open-source code
    (``src/gelu.cpp``): two CKK20 composite-polynomial signs at
    ``x = -shift`` and ``x = +shift`` select between 0, a degree-12
    ``x/2 + even`` polynomial, and ``x``. The published paper describes a
    four-segment PUMA-style piecewise polynomial instead; the code is what
    the comparison papers benchmark against and what carries exact
    coefficients, so it is what we reproduce.

``euston``
    Reconstruction of Euston's GELU (``Euston_func/gelu.cpp`` and
    ``func_main.cpp``): sigmoid form ``x * sigma(1.702 x)`` computed from a
    CKK20 sign, a squaring-based exponential and a Goldschmidt inverse.

``moai``
    Reconstruction of MOAI's GELU: ``x/2 * (1 + P(x))`` with ``P`` a
    degree-23 minimax fit of the tanh factor on a base interval, composed
    with Cheon-Kim-Park domain-extension stages for wider operating
    intervals.

Which parameters are range-dependent, and how they are chosen, is
documented in ``profile_math.py``.
"""

from __future__ import annotations

import math
from collections.abc import Sequence

# CKK20 composite-polynomial sign (Cheon, Kim, Kim, ASIACRYPT 2020), exactly
# as in NEXUS/Euston/MOAI: f_4 and g_4 are odd degree-9 polynomials; the
# composition is g^dg then f^df. The divisors are powers of two, so the
# coefficients are exact in binary floating point, and f_4(1) = 1 exactly.
F4_COEFFICIENTS = tuple(value / 128.0 for value in (315.0, -420.0, 378.0, -180.0, 35.0))
G4_COEFFICIENTS = tuple(value / 1024.0 for value in (5850.0, -34974.0, 97015.0, -113492.0, 46623.0))

SQRT_2_OVER_PI = math.sqrt(2.0 / math.pi)
GELU_TANH_CUBIC = 0.044715


def chebval(t, coefficients: Sequence[float]):
    """First-kind Chebyshev series by Clenshaw recurrence.

    ``coefficients`` are Python floats so the recurrence unrolls into
    constants under ``torch.compile`` instead of indexing a buffer.
    """
    n = len(coefficients)
    if n == 1:
        return t * 0.0 + float(coefficients[0])
    b1 = t * 0.0
    b2 = t * 0.0
    for c in coefficients[:0:-1]:
        b1, b2 = 2.0 * t * b1 - b2 + float(c), b1
    return t * b1 - b2 + float(coefficients[0])


def odd_polynomial(y, odd_coefficients: Sequence[float]):
    """``c[0] y + c[1] y^3 + c[2] y^5 + ...`` by Horner in ``y^2``."""
    y2 = y * y
    acc = y2 * 0.0 + float(odd_coefficients[-1])
    for c in odd_coefficients[-2::-1]:
        acc = acc * y2 + float(c)
    return y * acc


def ckk20_sign(y, dg: int, df: int, factor: float = 1.0):
    """Approximate ``factor * sign(y)`` for ``y`` in ``[-1, 1]``.

    ``dg`` applications of ``g_4`` then ``df`` of ``f_4``; the reference
    code folds ``factor`` into the last polynomial, which is arithmetically
    the same as multiplying afterwards, so we multiply afterwards.
    """
    for _ in range(dg):
        y = odd_polynomial(y, G4_COEFFICIENTS)
    for _ in range(df):
        y = odd_polynomial(y, F4_COEFFICIENTS)
    return y * float(factor) if factor != 1.0 else y


def cheon_kim_park_extension(x, base_radius: float, stages: int, factor: float = 1.5):
    """Map ``[-B L^s, B L^s]`` into ``[-B, B]`` while staying close to the
    identity near the origin (Cheon, Kim, Park, IEEE TIFS 2022).

    Each stage uses the cubic ``b(t) = t - 4 t^3 / 27``, which maps
    ``[-1.5, 1.5]`` onto ``[-1, 1]`` monotonically (``b(1.5) = 1``,
    ``b'(1.5) = 0``) and is ``t (1 - 4 t^2/27)``, hence near-identity for
    small ``t``. Stage ``r`` is ``S b(y/S)`` with ``S = B L^r``: it takes
    ``[-L S, L S]`` to ``[-S, S]``. Stages run from the outermost
    (``r = s-1``) inwards so the widest interval is handled first and the
    innermost stage, whose distortion dominates, acts only on the final
    ``[-B L, B L]``. ``factor`` must not exceed 1.5.
    """
    y = x
    for r in range(stages - 1, -1, -1):
        scale = base_radius * (factor**r)
        y = y - (4.0 / (27.0 * scale * scale)) * (y * y * y)
    return y


def evaluate_spa(spec: dict, x):
    radius = float(spec["operating_radius"])
    z = x * (1.0 / radius)
    t = 2.0 * (z * z) - 1.0
    return 0.5 * x + chebval(t, spec["coefficients"])


def evaluate_nexus(spec: dict, x):
    shift = float(spec["shift"])
    inverse_delta = 1.0 / float(spec["delta"])
    dg, df = int(spec["sign_dg"]), int(spec["sign_df"])
    b0 = ckk20_sign((x + shift) * inverse_delta, dg, df, 0.5)
    b1 = ckk20_sign((x - shift) * inverse_delta, dg, df, 0.5)
    middle_gate = b0 - b1  # 1 on (-shift, shift), else 0
    linear_gate = b1 + 0.5  # 1 above +shift, else 0
    # A[0] + A[1] x + A[2] x^2 + A[3] x^4 + ... + A[7] x^12, in the reference
    # code's own power-basis schedule.
    a = [float(value) for value in spec["middle_coefficients"]]
    x2 = x * x
    even = x2 * 0.0 + a[-1]
    for c in a[-2:1:-1]:
        even = even * x2 + c
    middle = a[0] + a[1] * x + even * x2
    power = int(spec.get("gate_power", 1))
    if power > 1:
        # Gate sharpening for wide intervals. The sign leaves a residual of
        # about one ulp in the working precision; multiplied by the x^12
        # polynomial that residual is not small. Raising the middle gate to
        # a power suppresses it (MOAI's copy of this code squares it). We
        # also raise the complement of the linear gate so that
        # middle_gate + linear_gate stays exactly 1 across the +shift band,
        # where the released construction blends the two branches;
        # squaring the middle gate alone leaves a dip of 0.875 at x = shift.
        sharpened_middle = middle_gate
        complement = 1.0 - linear_gate
        sharpened_complement = complement
        for _ in range(power - 1):
            sharpened_middle = sharpened_middle * middle_gate
            sharpened_complement = sharpened_complement * complement
        middle_gate = sharpened_middle
        linear_gate = 1.0 - sharpened_complement
    return middle * middle_gate + x * linear_gate


def evaluate_euston(spec: dict, x):
    inverse_delta = 1.0 / float(spec["delta"])
    dg, df = int(spec["sign_dg"]), int(spec["sign_df"])
    slope = float(spec.get("slope", 1.702))
    squarings = int(spec["exp_squarings"])
    iterations = int(spec["inverse_iterations"])
    exp_coefficients = [float(value) for value in spec["exp_coefficients"]]

    def exp_neg(y):
        # e^y for y <= 0: degree-7 polynomial of y / 2^r, then r squarings.
        z = y * (1.0 / float(2**squarings))
        p = z * 0.0 + exp_coefficients[-1]
        for c in exp_coefficients[-2::-1]:
            p = p * z + c
        for _ in range(squarings):
            p = p * p
        return p

    def inverse(v):
        # Goldschmidt as in the reference: y = 1 - v, res = 2 - v,
        # res *= 1 + y^(2^i) for i = 1..iterations.
        y = 1.0 - v
        res = 2.0 - v
        for _ in range(iterations):
            y = y * y
            res = res * (1.0 + y)
        return res

    s = ckk20_sign(x * inverse_delta, dg, df, 1.0)
    magnitude = x * s
    z = magnitude * inverse(1.0 + exp_neg(magnitude * (-slope)))
    rectifier = s * exp_neg(magnitude * (s - 1.0) * (0.5 * slope))
    return z * rectifier


def evaluate_moai(spec: dict, x):
    base = float(spec["base_radius"])
    y = cheon_kim_park_extension(
        x, base, int(spec["extension_stages"]), float(spec.get("extension_factor", 1.5))
    )
    tanh_factor = chebval(y * (1.0 / base), spec["coefficients"])
    return 0.5 * x * (1.0 + tanh_factor)


EVALUATORS = {
    "spa": evaluate_spa,
    "nexus": evaluate_nexus,
    "euston": evaluate_euston,
    "moai": evaluate_moai,
}


def evaluate_profile(spec: dict, x):
    """Evaluate a catalog profile at ``x`` (numpy array or torch tensor)."""
    try:
        evaluator = EVALUATORS[spec["kind"]]
    except KeyError as exc:
        raise ValueError(f"unknown profile kind: {spec.get('kind')!r}") from exc
    return evaluator(spec, x)


__all__ = [
    "F4_COEFFICIENTS",
    "G4_COEFFICIENTS",
    "GELU_TANH_CUBIC",
    "SQRT_2_OVER_PI",
    "chebval",
    "cheon_kim_park_extension",
    "ckk20_sign",
    "evaluate_profile",
    "odd_polynomial",
]
