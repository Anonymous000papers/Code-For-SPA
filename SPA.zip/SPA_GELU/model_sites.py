"""Locate the gated-MLP activation sites that the experiment swaps.

The SiLU harness found MLPs by attribute shape (``gate_proj``, ``up_proj``,
``down_proj``, ``act_fn``). Gemma 4 has a second module with exactly that
shape, ``Gemma4VisionMLP`` inside the vision tower, and it also applies
``gelu_pytorch_tanh`` in the per-layer-input gate of every decoder layer.
Only the text decoder MLPs are in scope, so calibration, evaluation and
the permutation check all go through this module. The vision and audio
towers are never run on text-only input, but a proxy installed there
would still be resolved against the text range plan by layer index, and
the calibration hooks would register on the wrong ``gate_proj`` if an
image were ever passed. The per-layer-input gate GELU
(``per_layer_input_gate``) stays native: the SiLU protocol approximated
the MLP activation only, and the comparison keeps that scope.

Works for ``Gemma4ForConditionalGeneration`` (text stack at
``model.language_model``), ``Gemma4ForCausalLM`` and the Llama family
(text stack at ``model``), with or without a PEFT wrapper.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import Any

EXCLUDED_TOWER_TAGS = ("vision", "audio", "image", "speech", "embedder")
GATED_MLP_ATTRIBUTES = ("gate_proj", "up_proj", "down_proj", "act_fn")


def _is_decoder_stack(module: Any) -> bool:
    layers = getattr(module, "layers", None)
    return layers is not None and hasattr(module, "embed_tokens") and hasattr(layers, "__len__")


def text_backbone(model: Any) -> tuple[str, Any]:
    """Return ``(qualified_name, module)`` of the text decoder stack."""
    candidates: list[tuple[str, Any]] = []
    for name, module in model.named_modules():
        lowered = name.lower()
        if any(tag in lowered for tag in EXCLUDED_TOWER_TAGS):
            continue
        if _is_decoder_stack(module):
            candidates.append((name, module))
    if not candidates:
        raise RuntimeError("no text decoder stack (module with .layers and .embed_tokens) found")
    preferred = [item for item in candidates if item[0].split(".")[-1] == "language_model"]
    if preferred:
        return preferred[0]
    if len(candidates) > 1:
        # Nested stacks (a wrapper that forwards to the real one) share a
        # prefix; keep the outermost so names stay resolvable.
        candidates.sort(key=lambda item: len(item[0]))
    return candidates[0]


def is_gated_mlp(module: Any) -> bool:
    return all(hasattr(module, attribute) for attribute in GATED_MLP_ATTRIBUTES)


def iter_gated_mlps(model: Any) -> Iterator[tuple[str, Any]]:
    """Yield ``(qualified_name, mlp_module)`` for every text decoder MLP,
    in layer order, with names qualified from the model root."""
    prefix, backbone = text_backbone(model)
    for name, module in backbone.named_modules():
        if is_gated_mlp(module):
            qualified = f"{prefix}.{name}" if prefix else name
            yield qualified, module


def activation_name(model: Any) -> str:
    """The configured hidden activation of the text stack."""
    config = getattr(model, "config", None)
    text_config = getattr(config, "text_config", None) or config
    return str(getattr(text_config, "hidden_activation", getattr(text_config, "hidden_act", "unknown")))


__all__ = ["activation_name", "is_gated_mlp", "iter_gated_mlps", "text_backbone"]
