"""Per-channel GELU pre-activation range calibration on a task's calibration split.

The quantity calibrated is the input of every text-decoder MLP's
``act_fn``, i.e. the ``gate_proj`` output (``act_fn(gate_proj(x)) *
up_proj(x)`` in Gemma 4's ``Gemma4TextMLP``). Sites are discovered through
``model_sites`` so the vision tower's identically shaped MLP is not
hooked. Calibration is zero-shot on the released weights.
The evaluation split is never opened by this script; the resulting
``channel_calibration.csv`` feeds ``build_range_plan.py`` unchanged.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path

import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from mcq_common import build_records, set_seed
from model_sites import activation_name, iter_gated_mlps
from tasks import get_task, set_source_override


class SubstitutedGelu(torch.nn.Module):
    """erf-GELU in place of the model's act_fn, on the same numerical path
    as the evaluation (activation dtype, cast back). Used so that the
    Exact-erf branch is calibrated on its own pre-activation distribution:
    swapping the activation in early layers changes the inputs of later
    layers, so the tanh calibration must not be assumed to carry over."""

    def __init__(self, approximate: str, dtype: torch.dtype):
        super().__init__()
        self.approximate = approximate
        self.dtype = dtype

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return torch.nn.functional.gelu(x.to(self.dtype), approximate=self.approximate).to(x.dtype)


def substitute_activation(model, target: str, dtype: torch.dtype) -> int:
    """Install the target GELU form at every text-decoder MLP; returns the count."""
    approximate = {"tanh": "tanh", "erf": "none"}[target]
    count = 0
    for _, mlp in iter_gated_mlps(model):
        mlp.act_fn = SubstitutedGelu(approximate, dtype)
        count += 1
    return count

LAYER_PATTERN = re.compile(r"(?:^|\.)layers\.(\d+)\.")


def layer_index(name: str) -> int:
    match = LAYER_PATTERN.search(name)
    return int(match.group(1)) if match else -1


def resolve_model_path(path: str) -> str:
    candidate = Path(path).expanduser()
    if candidate.exists():
        return str(candidate.resolve())
    fallback = Path("/root") / candidate
    if fallback.exists():
        return str(fallback.resolve())
    raise FileNotFoundError(f"model directory not found: {path!r} (also tried {fallback})")


class ChannelStats:
    def __init__(self, width: int, thresholds: tuple[float, ...]):
        self.width = width
        self.thresholds = thresholds
        self.max_abs = np.zeros(width, dtype=np.float32)
        self.count_gt = {value: np.zeros(width, dtype=np.uint64) for value in thresholds}
        self.sample_gt = {value: np.zeros(width, dtype=np.uint64) for value in thresholds}
        self.value_count = 0

    @torch.no_grad()
    def update(self, output: torch.Tensor, attention_mask: torch.Tensor) -> None:
        if output.ndim != 3:
            raise RuntimeError(f"expected [batch, time, channels], got {tuple(output.shape)}")
        magnitude = output.detach().float().abs()
        valid = attention_mask.bool().unsqueeze(-1)
        masked = magnitude.masked_fill(~valid, 0.0)

        self.max_abs = np.maximum(self.max_abs, masked.amax(dim=(0, 1)).cpu().numpy())
        self.value_count += int(attention_mask.sum().item()) * self.width

        for threshold in self.thresholds:
            over = (magnitude > threshold) & valid
            self.count_gt[threshold] += (
                over.sum(dim=(0, 1), dtype=torch.int64).cpu().numpy().astype(np.uint64)
            )
            self.sample_gt[threshold] += (
                over.any(dim=1).sum(dim=0, dtype=torch.int64).cpu().numpy().astype(np.uint64)
            )


class Collector:
    def __init__(self, thresholds: tuple[float, ...]):
        self.thresholds = thresholds
        self.current_mask: torch.Tensor | None = None
        self.stats: dict[str, ChannelStats] = {}
        self.handles: list = []

    def attach(self, model) -> None:
        # Hook the gate projection of each text MLP: its output is exactly
        # what act_fn receives, and the row name keeps the ".gate_proj"
        # suffix the range-plan builder and the evaluator resolve by layer
        # index.
        for mlp_name, mlp in iter_gated_mlps(model):
            module = mlp.gate_proj
            name = f"{mlp_name}.gate_proj"

            def hook(_module, _inputs, output, name=name):
                if self.current_mask is None:
                    raise RuntimeError("attention mask missing during calibration")
                if name not in self.stats:
                    self.stats[name] = ChannelStats(output.shape[-1], self.thresholds)
                self.stats[name].update(output, self.current_mask)

            self.handles.append(module.register_forward_hook(hook))
        if not self.handles:
            raise RuntimeError("no text-decoder gated MLPs found")

    def close(self) -> None:
        for handle in self.handles:
            handle.remove()
        self.handles.clear()


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Range calibration on a task's calibration split. The evaluation "
            "split is never read by this script."
        )
    )
    parser.add_argument("--task", default="hellaswag")
    parser.add_argument("--model-path", required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--split", default="", help="Defaults to the task's calibration split.")
    parser.add_argument(
        "--candidate-mode",
        default="all",
        choices=["all", "gold", "context"],
        help="Which sequences to run: every choice, the gold choice only, or the context alone.",
    )
    parser.add_argument("--prompt-style", default="plain", choices=["plain", "chat"])
    parser.add_argument("--max-length", type=int, default=1024)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--max-samples", type=int, default=0, help="0 uses the whole split.")
    parser.add_argument(
        "--target",
        default="tanh",
        choices=["tanh", "erf"],
        help=(
            "Activation actually executed while calibrating. 'tanh': the model's own act_fn. "
            "'erf': the exact erf-GELU is substituted at the text MLPs (activation dtype, cast "
            "back), so the Exact-erf branch is calibrated on its own distribution."
        ),
    )
    parser.add_argument("--activation-dtype", default="float32", choices=["float32", "float64"])
    parser.add_argument(
        "--thresholds",
        default="5,20,24,32,40,48,56,64,80,96,112,128,160,192,256,320,384,448,512",
        help="Exceedance counters; the range-plan wide candidates should be among them.",
    )
    parser.add_argument(
        "--hf-source",
        default="",
        help=(
            "Override the Hub repo for this task, as repo[:config], "
            "comma-separated for several candidates in order. Use when a "
            "canonical repo still ships a loading script or goes offline."
        ),
    )
    parser.add_argument("--seed", type=int, default=20260901)
    args = parser.parse_args()

    if not torch.cuda.is_available():
        raise RuntimeError("a CUDA GPU is required")

    set_seed(args.seed)
    if args.hf_source:
        set_source_override(args.task, args.hf_source)
    task = get_task(args.task)
    split = args.split or task.calibration_split

    thresholds = tuple(float(value) for value in args.thresholds.split(",") if value.strip())
    model_path = resolve_model_path(args.model_path)

    tokenizer = AutoTokenizer.from_pretrained(model_path, local_files_only=True)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "right"

    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        dtype=torch.bfloat16,
        local_files_only=True,
        attn_implementation="sdpa",
    )
    model.eval().cuda()
    model.config.use_cache = False
    model_activation = activation_name(model)
    print(f"model hidden activation: {model_activation}")
    substituted = 0
    if args.target == "erf":
        substituted = substitute_activation(
            model, "erf", {"float32": torch.float32, "float64": torch.float64}[args.activation_dtype]
        )
        print(f"target erf: exact erf-GELU substituted at {substituted} text MLPs for calibration")

    # Comma-separated splits let a task with a thin calibration split
    # combine several (MMLU validation,dev or ARC train,validation).
    examples = []
    for piece in [name.strip() for name in split.split(",") if name.strip()]:
        if piece == task.eval_split:
            raise RuntimeError(
                f"refusing to calibrate on the evaluation split ({piece!r}) "
                f"for task {task.name!r}"
            )
        examples.extend(task.loader(piece, args.max_samples, args.seed))
    records, truncated, _, _ = build_records(
        tokenizer,
        examples,
        choice_prefix=task.choice_prefix,
        max_length=args.max_length,
        prompt_style=args.prompt_style,
        system_prompt=task.chat_system_prompt,
    )

    if args.candidate_mode == "gold":
        records = [r for r in records if r.choice == examples[r.example].gold]
    elif args.candidate_mode == "context":
        seen: set[int] = set()
        kept = []
        for record in records:
            if record.example in seen:
                continue
            seen.add(record.example)
            prompt_length = record.length - record.scored_tokens
            record.input_ids = record.input_ids[:prompt_length]
            record.labels = record.labels[:prompt_length]
            record.length = prompt_length
            kept.append(record)
        records = kept

    print(
        f"task={task.name} split={split} examples={len(examples)} "
        f"sequences={len(records)} truncated[{truncated}]"
    )

    collector = Collector(thresholds)
    collector.attach(model)
    pad_id = tokenizer.pad_token_id
    order = sorted(range(len(records)), key=lambda index: records[index].length)

    @torch.inference_mode()
    def run_batch(chunk) -> None:
        width = max(record.length for record in chunk)
        input_ids = torch.full((len(chunk), width), pad_id, dtype=torch.long)
        attention = torch.zeros((len(chunk), width), dtype=torch.long)
        for row, record in enumerate(chunk):
            input_ids[row, : record.length] = torch.tensor(record.input_ids, dtype=torch.long)
            attention[row, : record.length] = 1
        input_ids = input_ids.cuda()
        attention = attention.cuda()
        collector.current_mask = attention
        with torch.autocast("cuda", dtype=torch.bfloat16):
            model(input_ids=input_ids, attention_mask=attention, use_cache=False)
        collector.current_mask = None

    for start in range(0, len(order), args.batch_size):
        run_batch([records[index] for index in order[start : start + args.batch_size]])
        done = min(start + args.batch_size, len(order))
        print(f"\rprocessed sequences {done}/{len(order)}", end="", flush=True)
    print()

    collector.close()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    channel_rows: list[dict] = []
    layer_rows: list[dict] = []
    global_max = 0.0

    for name in sorted(collector.stats, key=layer_index):
        stats = collector.stats[name]
        global_max = max(global_max, float(stats.max_abs.max()))
        for channel in range(stats.width):
            row = {
                "layer": name,
                "layer_index": layer_index(name),
                "channel": channel,
                "max_abs": float(stats.max_abs[channel]),
            }
            for threshold in thresholds:
                tag = f"{threshold:g}".replace(".", "_")
                row[f"count_gt_{tag}"] = int(stats.count_gt[threshold][channel])
                row[f"samples_or_sequences_gt_{tag}"] = int(stats.sample_gt[threshold][channel])
            channel_rows.append(row)

        layer_row = {
            "layer": name,
            "layer_index": layer_index(name),
            "channels": stats.width,
            "max_abs": float(stats.max_abs.max()),
            "value_count": stats.value_count,
        }
        for threshold in thresholds:
            tag = f"{threshold:g}".replace(".", "_")
            layer_row[f"channels_ever_gt_{tag}"] = int(np.count_nonzero(stats.count_gt[threshold]))
            layer_row[f"values_gt_{tag}"] = int(stats.count_gt[threshold].sum())
        layer_rows.append(layer_row)

    write_csv(output_dir / "channel_calibration.csv", channel_rows)
    write_csv(output_dir / "layer_calibration.csv", layer_rows)

    metadata = {
        "purpose": "range calibration only",
        "task": task.name,
        "split": split,
        "evaluation_split": task.eval_split,
        "validation_accessed": False,
        "examples": len(examples),
        "sequences": len(records),
        "candidate_mode": args.candidate_mode,
        "prompt_style": args.prompt_style,
        "model": model_path,
        "model_activation": model_activation,
        "calibrated_quantity": "act_fn input (gate_proj output) of text-decoder gated MLPs",
        "activation_target": args.target,
        "activation_executed": (
            f"model act_fn ({model_activation})" if args.target == "tanh"
            else f"exact erf-GELU substituted at {substituted} text MLPs ({args.activation_dtype}, cast back)"
        ),
        "activation_sites": len(collector.stats),
        "thresholds": list(thresholds),
        "global_max_abs": global_max,
        "truncated_prompts": truncated.prompts,
        "truncated_continuations": truncated.continuations,
        "seed": args.seed,
    }
    (output_dir / "metadata.json").write_text(json.dumps(metadata, indent=2))
    print(f"global calibration max |act_fn input| = {global_max}")
    print(f"saved: {output_dir / 'channel_calibration.csv'}")


if __name__ == "__main__":
    main()
