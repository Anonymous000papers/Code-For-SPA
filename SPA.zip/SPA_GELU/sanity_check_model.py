"""Sanity-check the model outside the harness.

A working 2B-class model scores about 2.5-3.5 nats/token on plain English
text; a value near 8-12 nats (uniform over the vocabulary is 12.5) means
the model is not being run correctly (missing BOS, wrong class, wrong
attention path), and no activation experiment on top of it is meaningful.
This script isolates such problems in a couple of minutes:

    python sanity_check_model.py --model-path <path-to-gemma-4-e2b-it>

It reports, in order:

1. loading info: any weights that were NOT found in the checkpoint
   (randomly initialised) or were unexpected;
2. the tokenizer's treatment of a short string (BOS present? ids?);
3. greedy generation from a chat-templated prompt and from raw text;
4. per-token NLL of a fixed English paragraph under the harness's exact
   settings (bf16 weights, autocast, sdpa, right padding with an
   attention mask, use_cache=False) and under each alternative:
   eager attention, no autocast, no padding, float32 weights, and the
   text-only ``ForCausalLM`` class if the library exposes one.

Read the NLL table: the setting whose NLL drops to a sane value names
the culprit. If every setting is ~10 nats, the checkpoint or the
library version is the problem (step 1 usually shows it).
"""

from __future__ import annotations

import argparse
import math
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from mcq_common import encode_with_bos

PARAGRAPH = (
    "The Nile is a major north-flowing river in northeastern Africa. It flows "
    "into the Mediterranean Sea. The Nile is the longest river in Africa and has "
    "historically been considered the longest river in the world, though this "
    "has been contested by research suggesting that the Amazon River is slightly "
    "longer. Of the world's major rivers, the Nile is one of the smallest, as "
    "measured by annual flow in cubic metres of water."
)


def resolve(path: str) -> str:
    candidate = Path(path).expanduser()
    if candidate.exists():
        return str(candidate.resolve())
    fallback = Path("/root") / candidate
    if fallback.exists():
        return str(fallback.resolve())
    raise FileNotFoundError(path)


def load(model_path: str, dtype, attn: str, cls=AutoModelForCausalLM):
    model, info = cls.from_pretrained(
        model_path,
        dtype=dtype,
        local_files_only=True,
        attn_implementation=attn,
        output_loading_info=True,
    )
    model.eval().cuda()
    return model, info


@torch.inference_mode()
def nll(model, tokenizer, text: str, autocast: bool, pad_to: int = 0, bos: bool = True) -> float:
    ids = encode_with_bos(tokenizer, text) if bos else list(tokenizer.encode(text, add_special_tokens=True))
    if not bos and ids and ids[0] == tokenizer.bos_token_id:
        ids = ids[1:]
    width = max(len(ids), pad_to)
    input_ids = torch.full((1, width), tokenizer.pad_token_id, dtype=torch.long)
    attention = torch.zeros((1, width), dtype=torch.long)
    input_ids[0, : len(ids)] = torch.tensor(ids)
    attention[0, : len(ids)] = 1
    input_ids, attention = input_ids.cuda(), attention.cuda()
    if autocast:
        with torch.autocast("cuda", dtype=torch.bfloat16):
            logits = model(input_ids=input_ids, attention_mask=attention, use_cache=False).logits
    else:
        logits = model(input_ids=input_ids, attention_mask=attention, use_cache=False).logits
    logp = torch.log_softmax(logits[0, : len(ids) - 1].float(), dim=-1)
    target = input_ids[0, 1 : len(ids)]
    token_logp = logp.gather(-1, target.unsqueeze(-1)).squeeze(-1)
    return float(-token_logp.mean())


@torch.inference_mode()
def generate(model, tokenizer, prompt_ids: list[int], new_tokens: int = 24) -> str:
    ids = torch.tensor([prompt_ids], device="cuda")
    out = model.generate(ids, max_new_tokens=new_tokens, do_sample=False)
    return tokenizer.decode(out[0, len(prompt_ids) :], skip_special_tokens=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument("--model-path", required=True)
    args = parser.parse_args()
    model_path = resolve(args.model_path)

    tokenizer = AutoTokenizer.from_pretrained(model_path, local_files_only=True)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    raw_ids = tokenizer.encode("The capital of France is", add_special_tokens=True)
    ids = encode_with_bos(tokenizer, "The capital of France is")
    print("tokenizer:", type(tokenizer).__name__)
    print(f"  tokenizer.encode(add_special_tokens=True) -> {raw_ids}")
    print(f"  bos_token_id={tokenizer.bos_token_id}; tokenizer adds BOS itself: {raw_ids[:1] == [tokenizer.bos_token_id]}")
    print(f"  harness encoding (encode_with_bos)         -> {ids}")
    print(f"  pad_token_id={tokenizer.pad_token_id} eos_token_id={tokenizer.eos_token_id}")

    print("\n[1] loading under the harness's settings (bf16, sdpa)")
    model, info = load(model_path, torch.bfloat16, "sdpa")
    print("  class:", type(model).__name__)
    for key in ("missing_keys", "unexpected_keys", "mismatched_keys"):
        values = info.get(key, [])
        print(f"  {key}: {len(values)}" + (f"  e.g. {list(values)[:5]}" if values else ""))
    config = getattr(model.config, "text_config", model.config)
    print(f"  text layers={config.num_hidden_layers} hidden={config.hidden_size} activation={config.hidden_activation}")

    print("\n[2] generation")
    try:
        chat = tokenizer.apply_chat_template(
            [{"role": "user", "content": "What is the capital of France? Answer in one word."}],
            tokenize=True,
            add_generation_prompt=True,
        )
        if hasattr(chat, "input_ids"):
            chat = list(chat["input_ids"])
        print("  chat template ->", repr(generate(model, tokenizer, list(chat))))
    except Exception as exc:  # noqa: BLE001
        print("  chat template failed:", exc)
    print("  raw text      ->", repr(generate(model, tokenizer, ids)))

    print("\n[3] per-token NLL of a fixed paragraph (sane: ~2-4 nats; broken: ~9-12)")
    print(f"  harness settings (bf16, sdpa, autocast, no padding):   {nll(model, tokenizer, PARAGRAPH, True):.3f}")
    print(f"  the same WITHOUT BOS (what the first sweep scored):     {nll(model, tokenizer, PARAGRAPH, True, bos=False):.3f}")
    print(f"  + right padding to 256 with attention mask:            {nll(model, tokenizer, PARAGRAPH, True, 256):.3f}")
    print(f"  without autocast:                                      {nll(model, tokenizer, PARAGRAPH, False):.3f}")
    del model
    torch.cuda.empty_cache()

    model, _ = load(model_path, torch.bfloat16, "eager")
    print(f"  eager attention:                                       {nll(model, tokenizer, PARAGRAPH, True):.3f}")
    del model
    torch.cuda.empty_cache()

    model, _ = load(model_path, torch.float32, "sdpa")
    print(f"  float32 weights, no autocast:                          {nll(model, tokenizer, PARAGRAPH, False):.3f}")
    del model
    torch.cuda.empty_cache()

    try:
        import transformers

        cls = getattr(transformers, "Gemma4ForCausalLM", None)
        if cls is not None:
            model, info = load(model_path, torch.bfloat16, "sdpa", cls=cls)
            print(
                f"  Gemma4ForCausalLM (text-only class), missing={len(info.get('missing_keys', []))}: "
                f"{nll(model, tokenizer, PARAGRAPH, True):.3f}"
            )
    except Exception as exc:  # noqa: BLE001
        print("  text-only class failed:", exc)

    print(f"\nuniform over the vocabulary would be {math.log(len(tokenizer)):.2f} nats")


if __name__ == "__main__":
    main()
