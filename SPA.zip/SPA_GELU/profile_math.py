"""Offline fitting and range adaptation for the GELU profile catalog.

Everything here runs in numpy; the evaluators themselves live in
``activation_approximations.py`` so that the fitter, the audit and the GPU
path share one implementation.

Target activation
-----------------
The model's activation is ``gelu_pytorch_tanh``::

    GELU(x) = x/2 * (1 + tanh(sqrt(2/pi) (x + 0.044715 x^3)))

It is complementary-gated (``GELU(x) - GELU(-x) = x``), so SPA fits only
the even residual ``GELU(x) - x/2`` on the squared domain.

Range adaptation of the comparison methods
------------------------------------------
Each published method fixes an operating interval. To evaluate them on the
calibrated radii used here they are extended along the axis each method
itself exposes, and nothing else:

NEXUS
    The released code normalises the two sign inputs by ``1/8.5`` with
    breakpoints at ``+-3.5``, i.e. it covers ``[-5, 5]``. The normaliser is
    the range knob: ``delta = R + 3.5`` reproduces 8.5 at ``R = 5``. The
    middle polynomial is not range dependent (the function is 0 or ``x``
    outside the breakpoints), so it is kept verbatim. Two consequences of
    a wider normaliser have to be handled with the method's own means:

    * The CKK20 sign's transition band has a fixed width in *normalised*
      units, so it widens in ``x`` with ``delta``. CKK20's remedy is more
      compositions; ``(dg, df)`` is chosen to preserve the released
      absolute band width (section "Sign depth").
    * The sign does not saturate exactly. The composition itself returns
      ``g_4(1) = 1022/1024`` at the interval end and needs several stages
      to close that gap (1.3e-11 remains after (3, 2)), and in the working
      precision a residual of about one ulp appears at a large fraction of
      points regardless of depth. The middle polynomial grows like
      ``7e-7 x^12`` (``3e9`` at 20, ``3e15`` at 64), so a residual gate
      leaks it at full size. MOAI's copy of this code (``gelu.hpp``,
      normaliser 1/60) squares the middle gate for exactly this reason;
      we generalise that to a power ``p`` chosen so that the worst-case
      leak ``max(|residual|, ulp)^p * |middle - selected branch|`` beyond
      the transition bands is at most ``1e-4`` (``p = 1`` at ``R = 5``, i.e. the released
      code), and apply the same power to the complement of the linear gate
      so the two branches still sum to one across the ``+3.5`` band
      (squaring the middle gate alone, as MOAI does, leaves a dip of 0.875
      at ``x = 3.5``). Each extra power is one multiplication per gate.

Euston
    The released code normalises the sign input by ``1/6`` for inputs in
    ``[-5, 5]`` (``delta = 1.2 R``), approximates ``e^y`` on ``y/2^r`` in
    ``[-5, 0]`` with a fixed degree-7 polynomial followed by ``r``
    squarings (``r = 1`` at ``R = 5``), and inverts ``1 + e^y`` with three
    Goldschmidt iterations. ``r`` is the exponential's range knob and is
    the smallest value keeping ``1.702 R / 2^r <= 5``; the inverse's input
    is in ``(1, 2]`` regardless of ``R`` so its iteration count is kept.
    The sign depth is chosen as for NEXUS. Note that Euston targets the
    sigmoid form ``x sigma(1.702 x)``, which differs from tanh-GELU by up
    to ``2.1e-2``; that gap is a property of the method and is reported,
    not corrected.

MOAI
    The paper approximates the tanh factor with a degree-23 minimax
    polynomial on its calibrated interval and names the Cheon-Kim-Park
    domain-extension polynomial as the way to reach larger intervals. Both
    knobs are used: the base radius ``B`` is chosen from a candidate list
    and ``s = ceil(log_L(R / B))`` extension stages (``L = 1.5``) are
    composed in front. Since the error of ``x/2 (1 + P)`` grows like
    ``R/2`` times the tanh-factor error, while extension distortion
    converges with stages, the best ``B`` depends on ``R``; the smallest
    error over the candidate list wins, ties going to fewer stages.

Sign depth
----------
The CKK20 sign ``s(y) = f^df(g^dg(y))`` is within ``1e-3`` of ``+-1`` for
``|y| >= w(dg, df)``; the transition band in ``x`` is ``delta * w``. The
released depths were chosen for the released normalisers, so widening
``delta`` alone widens the band in ``x`` by the same factor. The rule:
``(dg, df)`` is the cheapest depth (fewest compositions, then fewest
``g``) not below the released one whose band in ``x`` is no wider than
the released method's, ``delta * w(dg, df) <= delta_released *
w(dg_released, df_released)``. This is a statement about the sign alone,
so it is independent of the evaluation dtype and of the grid; each extra
composition costs four CKKS levels in the reference evaluators and the
count is recorded on the profile.
"""

from __future__ import annotations

import math
from collections.abc import Callable

import numpy as np
from numpy.polynomial.chebyshev import chebvander
from scipy.optimize import linprog
from scipy.special import erf

from activation_approximations import GELU_TANH_CUBIC, SQRT_2_OVER_PI, ckk20_sign, evaluate_profile

ArrayFunc = Callable[[np.ndarray], np.ndarray]

# --------------------------------------------------------------------------
# target functions
# --------------------------------------------------------------------------

# The GELU form every fit and error in this module refers to. "tanh" is the
# model's own activation (gelu_pytorch_tanh); "erf" is the exact erf-GELU,
# which MOAI's and NEXUS's released polynomials approximate. Selected once
# per process (generate_method_profiles --target, eval_methods --target, the
# audit from the catalog); SPA refits to whichever is selected, MOAI refits
# its factor polynomial to erf(x/sqrt 2) or the tanh factor, NEXUS's
# released graph and Euston's construction do not change.
ACTIVATION_TARGETS = {
    "tanh": {"id": "tanh-gelu", "name": "GELU (tanh approximation, gelu_pytorch_tanh)", "torch_approximate": "tanh"},
    "erf": {"id": "erf-gelu", "name": "GELU (exact erf)", "torch_approximate": "none"},
}
_ACTIVATION_TARGET = "tanh"
TARGET_NAME = ACTIVATION_TARGETS[_ACTIVATION_TARGET]["name"]


def set_activation_target(name: str) -> None:
    global _ACTIVATION_TARGET, TARGET_NAME
    if name not in ACTIVATION_TARGETS:
        raise ValueError(f"unknown activation target {name!r}; choose from {sorted(ACTIVATION_TARGETS)}")
    _ACTIVATION_TARGET = name
    TARGET_NAME = ACTIVATION_TARGETS[name]["name"]


def activation_target() -> str:
    return _ACTIVATION_TARGET


def target_name() -> str:
    return ACTIVATION_TARGETS[_ACTIVATION_TARGET]["name"]


def tanh_factor(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=np.float64)
    return np.tanh(SQRT_2_OVER_PI * (x + GELU_TANH_CUBIC * x**3))


def erf_factor(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=np.float64)
    return erf(x / math.sqrt(2.0))


def activation_factor(x: np.ndarray) -> np.ndarray:
    """``2 GELU(x)/x - 1`` for the selected target: the function MOAI's
    degree-23 polynomial approximates."""
    return tanh_factor(x) if _ACTIVATION_TARGET == "tanh" else erf_factor(x)


def gelu(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=np.float64)
    return 0.5 * x * (1.0 + activation_factor(x))


def sigmoid_gelu(x: np.ndarray, slope: float = 1.702) -> np.ndarray:
    """Euston's own target, ``x * sigma(slope x)``."""
    x = np.asarray(x, dtype=np.float64)
    return x / (1.0 + np.exp(-slope * x))


def spa_target(t: np.ndarray, radius: float) -> np.ndarray:
    """Even residual ``GELU(x) - x/2`` as a function of ``t = 2x^2/R^2 - 1``."""
    x = radius * np.sqrt(np.maximum(0.0, 0.5 * (t + 1.0)))
    return gelu(x) - 0.5 * x


# --------------------------------------------------------------------------
# minimax fitting (discrete Chebyshev-basis LP, as in the SiLU protocol)
# --------------------------------------------------------------------------


def map_t_to_x(t: np.ndarray, lo: float, hi: float) -> np.ndarray:
    return 0.5 * (hi - lo) * t + 0.5 * (hi + lo)


def solve_minimax_on_grid(target: np.ndarray, vandermonde: np.ndarray) -> tuple[np.ndarray, float]:
    rows = len(target)
    upper = np.hstack([vandermonde, -np.ones((rows, 1))])
    lower = np.hstack([-vandermonde, -np.ones((rows, 1))])
    constraints = np.vstack([upper, lower])
    bounds = np.concatenate([target, -target])
    objective = np.concatenate([np.zeros(vandermonde.shape[1]), [1.0]])
    variable_bounds = [(None, None)] * vandermonde.shape[1] + [(0.0, None)]
    result = linprog(
        objective,
        A_ub=constraints,
        b_ub=bounds,
        bounds=variable_bounds,
        method="highs",
    )
    if not result.success:
        raise RuntimeError(f"minimax LP failed: {result.message}")
    return np.asarray(result.x[:-1], dtype=np.float64), float(result.x[-1])


def fit_spa_minimax(radius: float, degree: int, grid_size: int = 3000) -> tuple[np.ndarray, float]:
    theta = np.linspace(0.0, np.pi, grid_size)
    t = np.sort(np.cos(theta))
    target = spa_target(t, radius)
    return solve_minimax_on_grid(target, chebvander(t, degree))


def fit_direct_minimax(
    func: ArrayFunc,
    degree: int,
    lo: float,
    hi: float,
    grid_size: int = 3001,
    validation_points: int = 200001,
    refinements: int = 6,
) -> tuple[np.ndarray, float]:
    """Minimax Chebyshev series of ``func`` on ``[lo, hi]`` with exchange
    refinement; returns coefficients in ``t = 2(x - lo)/(hi - lo) - 1``."""
    from numpy.polynomial.chebyshev import chebval as np_chebval

    uniform = np.linspace(-1.0, 1.0, grid_size)
    lobatto = np.cos(np.pi * np.arange(grid_size) / (grid_size - 1))
    grid = np.unique(np.concatenate([uniform, lobatto]))
    dense = np.linspace(-1.0, 1.0, validation_points)
    dense_target = func(map_t_to_x(dense, lo, hi))
    coefficients: np.ndarray | None = None
    max_error = float("nan")

    for _ in range(refinements):
        target = func(map_t_to_x(grid, lo, hi))
        coefficients, lp_error = solve_minimax_on_grid(target, chebvander(grid, degree))
        error = np_chebval(dense, coefficients) - dense_target
        absolute = np.abs(error)
        max_error = float(np.max(absolute))

        derivative_sign = np.sign(np.diff(error))
        for i in range(1, len(derivative_sign)):
            if derivative_sign[i] == 0:
                derivative_sign[i] = derivative_sign[i - 1]
        for i in range(len(derivative_sign) - 2, -1, -1):
            if derivative_sign[i] == 0:
                derivative_sign[i] = derivative_sign[i + 1]
        extrema = np.where(derivative_sign[:-1] * derivative_sign[1:] <= 0)[0] + 1
        extrema = np.unique(np.concatenate([[0], extrema, [len(dense) - 1]]))
        strong = extrema[absolute[extrema] >= 0.75 * max_error]
        additions = dense[np.unique(np.concatenate([strong, [int(np.argmax(absolute))]]))]
        old_size = len(grid)
        grid = np.unique(np.concatenate([grid, additions]))
        if len(grid) == old_size or max_error <= lp_error * (1.0 + 5e-7):
            break

    if coefficients is None:
        raise RuntimeError("minimax fit did not run")
    return coefficients, max_error


# --------------------------------------------------------------------------
# error evaluation
# --------------------------------------------------------------------------

DTYPES = {"float32": np.float32, "float64": np.float64}


def evaluate_spec(
    spec: dict,
    radius: float,
    points: int = 300001,
    dtype: str = "float64",
    target: ArrayFunc = gelu,
) -> dict[str, float]:
    """Maximum, mean and RMS error of ``spec`` against ``target`` on
    ``[-radius, radius]``, evaluating the profile in ``dtype``."""
    x = np.linspace(-radius, radius, points, dtype=np.float64)
    approximation = np.asarray(evaluate_profile(spec, x.astype(DTYPES[dtype])), dtype=np.float64)
    error = approximation - target(x)
    finite = np.isfinite(error)
    if not finite.all():
        return {
            "max_abs_error": float("inf"),
            "mean_abs_error": float("inf"),
            "rmse": float("inf"),
            "argmax_x": float("nan"),
            "nonfinite_points": int((~finite).sum()),
        }
    absolute = np.abs(error)
    index = int(np.argmax(absolute))
    return {
        "max_abs_error": float(absolute[index]),
        "mean_abs_error": float(np.mean(absolute)),
        "rmse": float(np.sqrt(np.mean(error * error))),
        "argmax_x": float(x[index]),
        "nonfinite_points": 0,
    }


def error_summary(spec: dict, radius: float, eval_dtype: str, points: int = 300001) -> dict:
    """The metrics stored on every profile: float64 reference plus the
    evaluation dtype the model run uses."""
    reference = evaluate_spec(spec, radius, points, "float64")
    summary = {
        "max_abs_error": reference["max_abs_error"],
        "mean_abs_error": reference["mean_abs_error"],
        "rmse": reference["rmse"],
        "argmax_x": reference["argmax_x"],
        "evaluation_dtype": eval_dtype,
    }
    if eval_dtype != "float64":
        in_dtype = evaluate_spec(spec, radius, points, eval_dtype)
        summary[f"max_abs_error_{eval_dtype}"] = in_dtype["max_abs_error"]
        summary[f"rmse_{eval_dtype}"] = in_dtype["rmse"]
        summary[f"nonfinite_points_{eval_dtype}"] = in_dtype["nonfinite_points"]
    return summary


# --------------------------------------------------------------------------
# SPA cost accounting (Theorem "Exact cost of the implemented Cheb-PS circuit")
# --------------------------------------------------------------------------


def spa_ps_cost(degree: int, split: int) -> dict[str, int]:
    blocks = -(-(degree + 1) // split)
    if blocks == 1:
        ct_ct = degree
        eta = math.ceil(math.log2(degree)) if degree > 1 else 0
    else:
        ct_ct = split + blocks + math.ceil(math.log2(blocks)) - 2
        eta = math.ceil(math.log2(split))
    depth_raw = 2 + eta + math.ceil(math.log2(blocks + 1))
    return {"ps_blocks": blocks, "ps_ctct_mults": ct_ct, "ps_depth_raw_input": depth_raw}


# --------------------------------------------------------------------------
# NEXUS
# --------------------------------------------------------------------------

NEXUS_SHIFT = 3.5
NEXUS_DELTA_MARGIN = 3.5  # delta = R + margin; 8.5 at R = 5 as released
NEXUS_SIGN = (2, 2)  # (dg, df) in the released code
NEXUS_RELEASED_DELTA = 8.5
NEXUS_MIDDLE_COEFFICIENTS = (
    2.25775755e-04,
    0.5,
    3.96880960e-01,
    -6.37042698e-02,
    8.38841647e-03,
    -7.17830961e-04,
    3.49617829e-05,
    -7.26059653e-07,
)


def nexus_spec(radius: float, dg: int, df: int, gate_power: int = 1) -> dict:
    return {
        "kind": "nexus",
        "shift": NEXUS_SHIFT,
        "delta": radius + NEXUS_DELTA_MARGIN,
        "sign_dg": int(dg),
        "sign_df": int(df),
        "gate_power": int(gate_power),
        "middle_coefficients": list(NEXUS_MIDDLE_COEFFICIENTS),
    }


# --------------------------------------------------------------------------
# Euston
# --------------------------------------------------------------------------

EUSTON_DELTA_RATIO = 6.0 / 5.0  # released: inputs in [-5, 5], sign normaliser 1/6
EUSTON_SIGN = (3, 3)
EUSTON_RELEASED_DELTA = 6.0
EUSTON_INVERSE_ITERATIONS = 3
EUSTON_SLOPE = 1.702
EUSTON_EXP_INTERVAL = 5.0  # degree-7 polynomial fitted for y/2^r in [-5, 0]
EUSTON_EXP_COEFFICIENTS = (
    0.9999176045120705,
    0.9987416303869157,
    0.4953285812872865,
    0.159281595830637,
    0.03551592614263832,
    0.00533666218566905,
    0.00048218432821377466,
    1.9546405829954175e-05,
)


def euston_squarings(radius: float) -> int:
    """Smallest ``r`` with ``slope * R / 2^r <= 5``; the released code uses
    ``r = 1`` for ``R = 5``."""
    return max(1, math.ceil(math.log2(EUSTON_SLOPE * radius / EUSTON_EXP_INTERVAL)))


def euston_spec(radius: float, dg: int, df: int) -> dict:
    return {
        "kind": "euston",
        "delta": EUSTON_DELTA_RATIO * radius,
        "sign_dg": int(dg),
        "sign_df": int(df),
        "slope": EUSTON_SLOPE,
        "exp_squarings": euston_squarings(radius),
        "inverse_iterations": EUSTON_INVERSE_ITERATIONS,
        "exp_coefficients": list(EUSTON_EXP_COEFFICIENTS),
    }


# --------------------------------------------------------------------------
# sign-depth rule shared by NEXUS and Euston, and NEXUS gate sharpening
# --------------------------------------------------------------------------

SIGN_BAND_TOLERANCE = 1e-3
_BAND_CACHE: dict[tuple[int, int], float] = {}


def sign_band_half_width(dg: int, df: int, tolerance: float = SIGN_BAND_TOLERANCE) -> float:
    """Smallest ``w`` such that ``|s(y) - 1| <= tolerance`` for all
    ``y`` in ``[w, 1]`` (float64, fine grid). The sign is odd, so the
    band is ``(-w, w)``."""
    key = (int(dg), int(df))
    if key not in _BAND_CACHE:
        y = np.linspace(0.0, 1.0, 400001)
        s = ckk20_sign(y, key[0], key[1], 1.0)
        bad = np.abs(s - 1.0) > tolerance
        _BAND_CACHE[key] = float(y[np.max(np.where(bad)[0])] if bad.any() else 0.0)
    return _BAND_CACHE[key]


def select_sign_depth(
    delta: float,
    released_delta: float,
    released_depth: tuple[int, int],
    max_compositions: int = 7,
) -> tuple[tuple[int, int], dict]:
    """Choose ``(dg, df)`` by the band-preservation rule of the module
    docstring; returns the depth and a record of the search."""
    budget = released_delta * sign_band_half_width(*released_depth)
    trials: list[dict] = []
    for dg in range(released_depth[0], max_compositions + 1):
        for df in range(released_depth[1], max_compositions + 1):
            width = delta * sign_band_half_width(dg, df)
            trials.append({"dg": dg, "df": df, "total": dg + df, "band_half_width_x": width})
    admissible = [t for t in trials if t["band_half_width_x"] <= budget * (1.0 + 1e-9)]
    if not admissible:
        chosen = min(trials, key=lambda t: t["band_half_width_x"])
        exhausted = True
    else:
        chosen = min(admissible, key=lambda t: (t["total"], t["dg"], t["df"]))
        exhausted = False
    record = {
        "rule": (
            "cheapest depth not below the released one whose transition band in x "
            f"(delta * w, |s-1| <= {SIGN_BAND_TOLERANCE:g}) is no wider than the released method's"
        ),
        "released_depth": list(released_depth),
        "released_delta": released_delta,
        "released_band_half_width_x": budget,
        "band_half_width_x": chosen["band_half_width_x"],
        "budget_exhausted": exhausted,
        "trials": trials,
    }
    return (chosen["dg"], chosen["df"]), record


ULP = {"float32": 2.0**-24, "float64": 2.0**-53}
NEXUS_LEAK_TOLERANCE = 1e-4


def nexus_middle(x: np.ndarray) -> np.ndarray:
    a = NEXUS_MIDDLE_COEFFICIENTS
    x = np.asarray(x, dtype=np.float64)
    return a[0] + a[1] * x + sum(c * x ** (2 * i) for i, c in enumerate(a[2:], start=1))


def nexus_leakage(radius: float, dg: int, df: int, eval_dtype: str, power: int, points: int = 200001) -> float:
    """Worst-case leak of the middle polynomial outside the breakpoints:
    ``max(|gate residual|, ulp)^power * |middle(x) - selected(x)|`` over
    ``[-R, R]`` beyond the two transition bands.

    The residual has two sources: the CKK20 composition itself, which at
    ``|y| = 1`` returns ``g_4(1) = 1022/1024`` and needs several stages to
    reach 1 (1.3e-11 after (3, 2)), and rounding in the working precision
    (one ulp). Both are multiplied by a polynomial that is ``3e9`` at 20.
    """
    delta = radius + NEXUS_DELTA_MARGIN
    band = delta * sign_band_half_width(dg, df)
    x = np.linspace(-radius, radius, points)
    b0 = ckk20_sign((x + NEXUS_SHIFT) / delta, dg, df, 0.5)
    b1 = ckk20_sign((x - NEXUS_SHIFT) / delta, dg, df, 0.5)
    middle_gate = b0 - b1
    # Between the breakpoints the two gates sum to one, so a residual there
    # blends two nearly equal branches and costs nothing; outside them the
    # cost is the residual times the difference between the middle
    # polynomial and the branch that should be selected (x above +shift,
    # 0 below -shift). Near +shift that difference is small; at the
    # interval end it is the whole x^12 polynomial.
    outside = np.abs(x) > NEXUS_SHIFT + band * (1.0 + 1e-6)
    residual = np.maximum(np.abs(middle_gate[outside]), ULP[eval_dtype])
    selected = np.where(x[outside] > 0, x[outside], 0.0)
    return float(np.max(residual**power * np.abs(nexus_middle(x[outside]) - selected)))


def nexus_gate_power(
    radius: float,
    eval_dtype: str,
    dg: int = NEXUS_SIGN[0],
    df: int = NEXUS_SIGN[1],
    tolerance: float = NEXUS_LEAK_TOLERANCE,
    max_power: int = 8,
) -> tuple[int, float]:
    """Smallest ``p >= 1`` whose worst-case leak is within ``tolerance``;
    returns ``(p, leak)``."""
    for power in range(1, max_power + 1):
        leak = nexus_leakage(radius, dg, df, eval_dtype, power)
        if leak <= tolerance:
            return power, leak
    raise RuntimeError(f"NEXUS gate power above {max_power} needed at R={radius:g}")


def build_nexus_profile(radius: float, eval_dtype: str, gate_power: int | None = None) -> dict:
    """NEXUS adapted to ``[-R, R]`` per the module docstring."""
    delta = radius + NEXUS_DELTA_MARGIN
    (dg, df), sign_record = select_sign_depth(delta, NEXUS_RELEASED_DELTA, NEXUS_SIGN)
    if gate_power is None:
        power, leak = nexus_gate_power(radius, eval_dtype, dg, df)
        rule = (
            f"smallest p with max(|gate residual|, ulp({eval_dtype}))^p * |middle - selected branch| "
            f"<= {NEXUS_LEAK_TOLERANCE:g} on [-R, R] beyond the transition bands"
        )
    else:
        power = int(gate_power)
        leak = nexus_leakage(radius, dg, df, eval_dtype, power)
        rule = "fixed by --nexus-gate-power"
    spec = nexus_spec(radius, dg, df, power)
    spec["sign_search"] = sign_record
    spec["gate_power_rule"] = {
        "rule": rule,
        "worst_case_leak": leak,
        "leak_without_sharpening": nexus_leakage(radius, dg, df, eval_dtype, 1),
        "ulp": ULP[eval_dtype],
    }
    return spec


def build_euston_profile(radius: float) -> dict:
    """Euston adapted to ``[-R, R]`` per the module docstring."""
    delta = EUSTON_DELTA_RATIO * radius
    (dg, df), sign_record = select_sign_depth(delta, EUSTON_RELEASED_DELTA, EUSTON_SIGN)
    spec = euston_spec(radius, dg, df)
    spec["sign_search"] = sign_record
    return spec


# --------------------------------------------------------------------------
# MOAI
# --------------------------------------------------------------------------

MOAI_DEGREE = 23
MOAI_EXTENSION_FACTOR = 1.5
MOAI_BASE_CANDIDATES = (4.0, 5.0, 6.0, 7.0, 8.0, 10.0, 12.0, 16.0, 20.0)


def moai_stages(radius: float, base: float, factor: float) -> int:
    if base >= radius * (1.0 - 1e-12):
        return 0
    return math.ceil(math.log(radius / base) / math.log(factor) - 1e-12)


def moai_spec(base: float, stages: int, coefficients: np.ndarray, factor: float) -> dict:
    return {
        "kind": "moai",
        "base_radius": float(base),
        "extension_stages": int(stages),
        "extension_factor": float(factor),
        "degree": MOAI_DEGREE,
        "coefficients": [float(value) for value in coefficients],
    }


def select_moai_profile(
    radius: float,
    eval_dtype: str,
    base_candidates: tuple[float, ...] = MOAI_BASE_CANDIDATES,
    factor: float = MOAI_EXTENSION_FACTOR,
    degree: int = MOAI_DEGREE,
    points: int = 200001,
) -> tuple[dict, list[dict]]:
    """Choose the base radius and stage count per the module docstring."""
    candidates = sorted({float(b) for b in base_candidates if b <= radius * (1 + 1e-9)} | {float(radius)})
    if radius > max(base_candidates):
        candidates = [b for b in candidates if b <= max(base_candidates)]
    trials: list[dict] = []
    fits: dict[float, tuple[np.ndarray, float]] = {}
    for base in candidates:
        coefficients, tanh_error = fit_direct_minimax(activation_factor, degree, -base, base)
        fits[base] = (coefficients, tanh_error)
        stages = moai_stages(radius, base, factor)
        spec = moai_spec(base, stages, coefficients, factor)
        metrics = evaluate_spec(spec, radius, points, eval_dtype)
        trials.append(
            {
                "base_radius": base,
                "extension_stages": stages,
                "covered_radius": base * factor**stages,
                "factor_minimax_error": tanh_error,
                "max_abs_error": metrics["max_abs_error"],
                "argmax_x": metrics["argmax_x"],
            }
        )
    chosen = min(trials, key=lambda t: (t["max_abs_error"], t["extension_stages"], -t["base_radius"]))
    coefficients, tanh_error = fits[chosen["base_radius"]]
    spec = moai_spec(chosen["base_radius"], chosen["extension_stages"], coefficients, factor)
    spec["factor_minimax_error"] = tanh_error
    spec["factor_target"] = "erf(x/sqrt(2))" if _ACTIVATION_TARGET == "erf" else "tanh(sqrt(2/pi)(x + 0.044715 x^3))"
    spec["covered_radius"] = chosen["covered_radius"]
    spec["base_search"] = {
        "rule": (
            "smallest max error over base radii "
            f"{[b for b in candidates]} with ceil(log_{factor:g}(R/B)) extension stages, "
            f"evaluated in {eval_dtype}; ties to fewer stages"
        ),
    }
    return spec, trials


__all__ = [
    "DTYPES",
    "EUSTON_SIGN",
    "MOAI_BASE_CANDIDATES",
    "MOAI_DEGREE",
    "MOAI_EXTENSION_FACTOR",
    "NEXUS_SIGN",
    "TARGET_NAME",
    "ACTIVATION_TARGETS",
    "activation_factor",
    "activation_target",
    "erf_factor",
    "set_activation_target",
    "target_name",
    "error_summary",
    "euston_spec",
    "euston_squarings",
    "evaluate_spec",
    "fit_direct_minimax",
    "fit_spa_minimax",
    "gelu",
    "moai_spec",
    "moai_stages",
    "nexus_spec",
    "spa_ps_cost",
    "spa_target",
    "select_moai_profile",
    "select_sign_depth",
    "sign_band_half_width",
    "nexus_gate_power",
    "nexus_leakage",
    "build_nexus_profile",
    "build_euston_profile",
    "sigmoid_gelu",
    "tanh_factor",
]
