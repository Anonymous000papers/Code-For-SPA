"""Pool the paired comparison across tasks, and tabulate the perplexity axis.

Each task is scored independently, but every method sees exactly the same
items within a task, so the per-task McNemar tests can be pooled into one
test with far more power than any single benchmark carries. On the four
zero-shot tasks that is about 26,500 paired items.

    python pool_results.py --results results/zeroshot \\
        --tasks wikitext2 c4_en hellaswag mmlu social_i_qa race_high

Reads each ``<results>/<task>/full/predictions.csv``. Reports per-task and
pooled accuracy deltas, discordant splits, exact McNemar p-values and the
minimum detectable effect at each observed count.

Language-modelling corpora are tabulated separately from their
``summary.csv``: they have no accuracy to pool, and per-token NLL with a
paired bootstrap resolves differences that the accuracy tables cannot.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np

from paired_stats import mcnemar, minimum_detectable_effect

REFERENCE = "native"


def canonical_names(task_dir: Path) -> dict[str, str]:
    """Map task-local method ids onto names comparable across tasks.

    SPA variants are specified by target error, and the degree needed to
    hit that target depends on the task's wide radius. So the same id can
    mean different things: spa-k47 is the 1e-3 variant on HellaSwag and
    the 1e-4 variant on ARC-Challenge. Pooling by raw id would silently
    mix tiers, so ids are rewritten to spa@<target> using the catalog
    that produced them.
    """
    catalog_path = task_dir / "profile_catalog.json"
    if not catalog_path.exists():
        return {}
    catalog = json.loads(catalog_path.read_text())
    mapping: dict[str, str] = {}
    for variant in catalog.get("methods", {}).get("spa", []):
        mapping[variant["id"]] = f"spa@{variant['target_max_error']:g}"
    return mapping


def load_predictions(path: Path) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    with path.open() as handle:
        rows = list(csv.DictReader(handle))
    if not rows:
        raise ValueError(f"{path} is empty")
    gold = np.array([int(row["gold"]) for row in rows], dtype=np.int64)
    methods = [
        name[: -len("_pred")]
        for name in rows[0]
        if name.endswith("_pred") and not name.endswith("_pred_raw")
    ]
    predictions = {
        method: np.array([int(row[f"{method}_pred"]) for row in rows], dtype=np.int64)
        for method in methods
    }
    return gold, predictions


def summarise(correct: dict[str, np.ndarray], label: str) -> list[dict]:
    reference = correct[REFERENCE]
    total = len(reference)
    rows: list[dict] = []
    for method, values in correct.items():
        if method == REFERENCE:
            continue
        result = mcnemar(reference, values)
        rows.append(
            {
                "scope": label,
                "method": method,
                "n": total,
                "reference_acc": float(reference.mean()),
                "method_acc": float(values.mean()),
                "delta_pp": 100.0 * float(values.mean() - reference.mean()),
                "discordant": result["mcnemar_discordant"],
                "to_wrong": result["mcnemar_to_wrong"],
                "to_right": result["mcnemar_to_right"],
                "mcnemar_p": result["mcnemar_p"],
                "mde_pp": minimum_detectable_effect(total, result["mcnemar_discordant"]),
            }
        )
    return rows


def perplexity_table(results: Path, tasks: list[str], subdir: str) -> list[dict]:
    """Tabulate the language-modelling corpora side by side."""
    rows: list[dict] = []
    for task in tasks:
        summary = results / task / subdir / "summary.csv"
        if not summary.exists():
            print(f"skipping {task}: {summary} not found")
            continue
        with summary.open() as handle:
            for entry in csv.DictReader(handle):
                rows.append(
                    {
                        "corpus": task,
                        "method": entry["method"],
                        "token_nll": float(entry.get("token_nll") or "nan"),
                        "perplexity": float(entry.get("perplexity") or "nan"),
                        "delta_nll": float(entry.get("delta_token_nll") or "nan"),
                        "ci_low": float(entry.get("delta_token_nll_ci_low") or "nan"),
                        "ci_high": float(entry.get("delta_token_nll_ci_high") or "nan"),
                        "p": float(entry.get("delta_token_nll_p") or "nan"),
                        "perplexity_delta_pct": float(
                            entry.get("perplexity_delta_pct") or "nan"
                        ),
                        "windows": entry.get("bootstrap_windows", ""),
                        "lost": entry.get("invalid_examples", "0"),
                    }
                )
    return rows


def print_perplexity(rows: list[dict], alpha: float) -> None:
    if not rows:
        return
    header = (
        f"{'corpus':<14}{'method':<14}{'token_nll':>11}{'perplexity':>12}"
        f"{'d_nll':>11}{'95% CI':>24}{'p':>9}{'ppl %':>9}  verdict"
    )
    print("\n" + header)
    print("-" * len(header))
    previous = None
    for row in rows:
        if previous is not None and row["corpus"] != previous:
            print("-" * len(header))
        previous = row["corpus"]
        interval = f"[{row['ci_low']:+.5f},{row['ci_high']:+.5f}]"
        if row["method"] in {"native", "exact"}:
            verdict = "reference"
        elif row["p"] < alpha and row["delta_nll"] > 0:
            verdict = "degraded"
        elif row["p"] < alpha:
            verdict = "improved"
        else:
            verdict = "null"
        note = f"  ({row['lost']} windows lost)" if row["lost"] not in ("0", "") else ""
        print(
            f"{row['corpus']:<14}{row['method']:<14}{row['token_nll']:>11.5f}"
            f"{row['perplexity']:>12.4f}{row['delta_nll']:>11.2e}{interval:>24}"
            f"{row['p']:>9.4f}{row['perplexity_delta_pct']:>+9.4f}  {verdict}{note}"
        )
    print(
        "\nPerplexity has no ceiling and does not quantise to whole examples, so "
        "it separates methods every accuracy table reports as identical. A "
        "method that lost windows is compared on the shared subset; see "
        "token_nll_shared in the summary."
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, required=True)
    parser.add_argument("--tasks", nargs="+", required=True)
    parser.add_argument("--subdir", default="full")
    parser.add_argument("--output", type=Path, default=None)
    parser.add_argument(
        "--alpha", type=float, default=0.05, help="Significance level for the verdict column."
    )
    parser.add_argument(
        "--raw-ids",
        action="store_true",
        help="Pool by task-local method id instead of resolving SPA target tiers.",
    )
    parser.add_argument(
        "--bonferroni",
        action="store_true",
        help=(
            "Judge per-task rows against alpha divided by the number of "
            "per-task comparisons. With 7 methods on 4 tasks the smallest "
            "attainable p at 6 discordant pairs is 0.031, so uncorrected "
            "per-task verdicts produce false positives."
        ),
    )
    args = parser.parse_args()

    per_task: dict[str, dict[str, np.ndarray]] = {}
    corpora: list[str] = []
    for task in args.tasks:
        path = args.results / task / args.subdir / "predictions.csv"
        if not path.exists():
            print(f"skipping {task}: {path} not found")
            continue
        metadata_path = args.results / task / args.subdir / "metadata.json"
        if metadata_path.exists():
            if json.loads(metadata_path.read_text()).get("task_kind") == "lm":
                corpora.append(task)
                continue
        gold, predictions = load_predictions(path)
        if REFERENCE not in predictions:
            raise ValueError(f"{path} has no {REFERENCE!r} column to compare against")
        rename = canonical_names(args.results / task) if not args.raw_ids else {}
        for source, target in rename.items():
            if source in predictions:
                print(f"  {task}: pooling {source} as {target}")
        per_task[task] = {
            rename.get(method, method): (values == gold)
            for method, values in predictions.items()
        }

    if corpora:
        print_perplexity(perplexity_table(args.results, corpora, args.subdir), args.alpha)

    if not per_task:
        if corpora:
            return
        raise SystemExit("no prediction files were found")

    print()

    shared = set.intersection(*(set(correct) for correct in per_task.values()))
    if len(shared) < 2:
        raise SystemExit("the tasks share no methods beyond the reference")

    rows: list[dict] = []
    for task, correct in per_task.items():
        rows.extend(summarise({m: correct[m] for m in sorted(shared)}, task))

    pooled = {
        method: np.concatenate([per_task[task][method] for task in per_task])
        for method in sorted(shared)
    }
    rows.extend(summarise(pooled, "POOLED"))

    comparisons = (len(shared) - 1) * len(per_task)
    if args.bonferroni:
        print(
            f"Bonferroni: {comparisons} per-task comparisons at "
            f"{args.alpha / max(1, comparisons):.5f}, "
            f"{len(shared) - 1} pooled comparisons at "
            f"{args.alpha / max(1, len(shared) - 1):.5f}\n"
        )
    header = f"{'scope':<16}{'method':<14}{'n':>7}{'delta pp':>10}{'discord':>8}{'b':>5}{'c':>5}{'McNemar p':>12}{'MDE pp':>8}  verdict"
    print(header)
    print("-" * len(header))
    previous_scope = None
    for row in rows:
        if row["scope"] != previous_scope and previous_scope is not None:
            print("-" * len(header))
        previous_scope = row["scope"]
        threshold = args.alpha
        if args.bonferroni:
            # The pooled row is one comparison per method, not one per
            # (task, method), so it gets its own divisor. Leaving it
            # uncorrected reported spa@0.001 as "improved" at p = 0.045
            # across seven simultaneous comparisons.
            divisor = len(shared) - 1 if row["scope"] == "POOLED" else comparisons
            threshold = args.alpha / max(1, divisor)
        verdict = "degraded" if row["mcnemar_p"] < threshold and row["delta_pp"] < 0 else (
            "improved" if row["mcnemar_p"] < threshold else "null"
        )
        print(
            f"{row['scope']:<16}{row['method']:<14}{row['n']:>7}{row['delta_pp']:>10.3f}"
            f"{row['discordant']:>8}{row['to_wrong']:>5}{row['to_right']:>5}"
            f"{row['mcnemar_p']:>12.3e}{row['mde_pp']:>8.3f}  {verdict}"
        )

    print(
        "\ndiscord = examples where exactly one of the two is correct, so b + c. "
        "It is smaller than the raw prediction-flip count, since a flip between "
        "two wrong answers is concordant.\n"
        "b = reference correct and method wrong, c = the reverse. "
        "A null verdict with a large MDE means the comparison lacks resolution, "
        "which is different from the methods being equivalent."
    )

    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        if args.output.suffix == ".json":
            args.output.write_text(json.dumps(rows, indent=2, default=float))
        else:
            with args.output.open("w", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
                writer.writeheader()
                writer.writerows(rows)
        print(f"saved: {args.output}")


if __name__ == "__main__":
    main()
