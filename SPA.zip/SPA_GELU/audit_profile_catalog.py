"""Audit a frozen profile catalog: hash chain to the range plan, recomputed errors, evaluator reflection identity."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from numpy.polynomial.chebyshev import chebval

import profile_math
from activation_approximations import evaluate_profile
from profile_math import gelu


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Validate a generated GELU profile catalog against its range plan and "
            "recompute every stored error from the stored parameters."
        )
    )
    parser.add_argument("--range-plan", type=Path, required=True)
    parser.add_argument("--profile-catalog", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    plan = json.loads(args.range_plan.read_text())
    catalog = json.loads(args.profile_catalog.read_text())
    errors: list[str] = []
    checks: dict[str, object] = {}

    if catalog.get("range_plan_sha256") != sha256(args.range_plan):
        errors.append("profile catalog does not match the range plan")

    labels = plan["labels"]
    radii = {label: float(plan["radii"][label]) for label in labels}
    checks["ranges"] = radii
    if labels[:2] != ["r5", "r20"]:
        errors.append(f"expected base labels r5,r20, found {labels[:2]}")

    variants = catalog["methods"]["spa"]
    if len(variants) != 3:
        errors.append(f"expected three SPA variants, found {len(variants)}")

    degrees_by_label = {label: [] for label in labels}
    spa_checks = []
    for variant in variants:
        target = float(variant["target_max_error"])
        wide_degree = int(variant["degrees"][labels[-1]])
        expected_id = f"spa-k{wide_degree}"
        if variant["id"] != expected_id:
            errors.append(f"{variant['id']} should be named {expected_id}")

        item = {
            "method": variant["id"],
            "target_max_error": target,
            "profiles": {},
        }
        for label in labels:
            profile_id = variant["profiles"][label]
            profile = catalog["profiles"][profile_id]
            degree = int(profile["degree_square"])
            degrees_by_label[label].append(degree)
            if abs(float(profile["operating_radius"]) - radii[label]) > 1e-12:
                errors.append(f"{profile_id} has the wrong radius")
            if float(profile["max_abs_error"]) > target * (1.0 + 1e-9):
                errors.append(f"{profile_id} exceeds its target error")
            coefficients = np.asarray(profile["coefficients"], dtype=np.float64)
            if len(coefficients) != degree + 1 or not np.isfinite(coefficients).all():
                errors.append(f"{profile_id} has an invalid coefficient vector")

            x = np.linspace(-radii[label], radii[label], 50001)
            t = 2.0 * (x / radii[label]) ** 2 - 1.0
            value = 0.5 * x + chebval(t, coefficients)
            reflected = 0.5 * (-x) + chebval(t, coefficients)
            identity_error = float(np.max(np.abs((value - reflected) - x)))
            if identity_error > 5e-12:
                errors.append(f"{profile_id} violates the SPA reflection identity")

            item["profiles"][label] = {
                "profile_id": profile_id,
                "degree": degree,
                "max_abs_error": profile["max_abs_error"],
                "reflection_identity_error": identity_error,
            }
        spa_checks.append(item)

    for label, degrees in degrees_by_label.items():
        # Tiers may share a degree at a small radius; they must be
        # non-decreasing everywhere and strictly increasing at the wide
        # radius, which names them.
        if not all(a <= b for a, b in zip(degrees, degrees[1:])):
            errors.append(f"SPA degrees are not non-decreasing for {label}: {degrees}")
        if label == labels[-1] and not all(a < b for a, b in zip(degrees, degrees[1:])):
            errors.append(f"SPA wide-range degrees are not strictly increasing: {degrees}")
    checks["spa_variants"] = spa_checks
    checks["spa_degrees_by_range"] = degrees_by_label

    # Every profile (SPA and baseline) is re-evaluated with the shared
    # evaluator so the stored errors are reproducible from the stored
    # parameters alone, in float64 and in the catalog's evaluation dtype.
    eval_dtype = catalog.get("evaluation_dtype", "float32")
    profile_math.set_activation_target(catalog.get("activation_target", "tanh"))
    checks["activation_target"] = catalog.get("activation_target", "tanh")
    np_dtype = {"float32": np.float32, "float64": np.float64}[eval_dtype]
    recomputed = {}
    for profile_id, profile in catalog["profiles"].items():
        radius = float(profile["operating_radius"])
        x = np.linspace(-radius, radius, 100001)
        exact = gelu(x)
        error64 = float(np.max(np.abs(np.asarray(evaluate_profile(profile, x), dtype=np.float64) - exact)))
        approx_eval = np.asarray(evaluate_profile(profile, x.astype(np_dtype)), dtype=np.float64)
        finite = np.isfinite(approx_eval)
        error_eval = float(np.max(np.abs(approx_eval[finite] - exact[finite]))) if finite.any() else float("inf")
        recomputed[profile_id] = {
            "kind": profile["kind"],
            "stored_max_abs_error": profile["max_abs_error"],
            "recomputed_max_abs_error_float64": error64,
            f"recomputed_max_abs_error_{eval_dtype}": error_eval,
            f"nonfinite_points_{eval_dtype}": int((~finite).sum()),
        }
        if not np.isfinite(error64) or error64 > float(profile["max_abs_error"]) * 1.05 + 1e-12:
            errors.append(
                f"{profile_id}: recomputed float64 error {error64:.3e} exceeds stored "
                f"{float(profile['max_abs_error']):.3e}"
            )
        if (~finite).any():
            errors.append(f"{profile_id} is non-finite on [-R, R] in {eval_dtype}")
    checks["recomputed_errors"] = recomputed

    baseline_checks = {}
    for method in ("nexus", "moai", "euston"):
        method_spec = catalog["methods"].get(method)
        if not method_spec:
            errors.append(f"missing method {method}")
            continue
        missing = [label for label in labels if label not in method_spec["profiles"]]
        if missing:
            errors.append(f"{method} is missing profiles {missing}")
        details = {}
        for label, profile_id in method_spec["profiles"].items():
            profile = catalog["profiles"][profile_id]
            if abs(float(profile["operating_radius"]) - radii.get(label, float("nan"))) > 1e-12:
                errors.append(f"{profile_id} has the wrong radius")
            detail = {"profile_id": profile_id, "max_abs_error": profile["max_abs_error"]}
            if method == "nexus":
                detail.update(
                    delta=profile["delta"],
                    sign=[profile["sign_dg"], profile["sign_df"]],
                    gate_power=profile["gate_power"],
                )
                if abs(float(profile["delta"]) - (radii[label] + 3.5)) > 1e-9:
                    errors.append(f"{profile_id}: delta is not R + 3.5")
            elif method == "euston":
                detail.update(
                    delta=profile["delta"],
                    sign=[profile["sign_dg"], profile["sign_df"]],
                    exp_squarings=profile["exp_squarings"],
                    max_abs_error_vs_own_target=profile.get("max_abs_error_vs_own_target"),
                )
                if abs(float(profile["delta"]) - 1.2 * radii[label]) > 1e-9:
                    errors.append(f"{profile_id}: delta is not 1.2 R")
                if 1.702 * radii[label] / 2 ** int(profile["exp_squarings"]) > 5.0 + 1e-9:
                    errors.append(f"{profile_id}: exp argument leaves the fitted interval")
            else:
                detail.update(
                    base_radius=profile["base_radius"],
                    extension_stages=profile["extension_stages"],
                    covered_radius=profile.get("covered_radius"),
                )
                covered = float(profile["base_radius"]) * float(profile["extension_factor"]) ** int(
                    profile["extension_stages"]
                )
                if covered < radii[label] * (1 - 1e-9):
                    errors.append(f"{profile_id}: extension stages do not cover R")
                if len(profile["coefficients"]) != int(profile["degree"]) + 1:
                    errors.append(f"{profile_id}: coefficient count does not match the degree")
            details[label] = detail
        baseline_checks[method] = details
    checks["baseline_profiles"] = baseline_checks

    result = {
        "status": "pass" if not errors else "fail",
        "errors": errors,
        "checks": checks,
        "range_plan_sha256": sha256(args.range_plan),
        "profile_catalog_sha256": sha256(args.profile_catalog),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
