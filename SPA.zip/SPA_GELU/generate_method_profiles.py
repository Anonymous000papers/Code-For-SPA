"""Generate the shared GELU profile catalog.

One catalog serves plaintext evaluation and the ciphertext implementation.
It holds, per calibrated range (r5, r20, wide):

* three SPA profiles chosen by maximum-error target, exactly as in the
  SiLU protocol (the tiers are named after the wide-range degree);
* one range-adapted reconstruction each of NEXUS, MOAI and Euston. The
  adaptation rules, and why they are the methods' own knobs, are in
  ``profile_math.py``; every search trial is recorded in the catalog.

Errors are measured against ``gelu_pytorch_tanh`` (the model's activation)
in float64 and in the dtype the GPU evaluation uses (``--eval-dtype``).
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import time
from pathlib import Path

from profile_math import (
    EUSTON_EXP_INTERVAL,
    EUSTON_RELEASED_DELTA,
    EUSTON_SIGN,
    MOAI_BASE_CANDIDATES,
    MOAI_DEGREE,
    MOAI_EXTENSION_FACTOR,
    NEXUS_RELEASED_DELTA,
    NEXUS_SIGN,
    ACTIVATION_TARGETS,
    build_euston_profile,
    build_nexus_profile,
    error_summary,
    evaluate_spec,
    fit_spa_minimax,
    spa_ps_cost,
    select_moai_profile,
    sigmoid_gelu,
)

BASELINES = ("nexus", "moai", "euston")
DISPLAY_NAMES = {"nexus": "NEXUS", "moai": "MOAI", "euston": "Euston"}


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def parse_targets(text: str) -> list[float]:
    targets = [float(value) for value in text.split(",") if value.strip()]
    if len(targets) != 3:
        raise ValueError("--spa-target-errors must contain exactly three values")
    if not (targets[0] > targets[1] > targets[2] > 0):
        raise ValueError("SPA target errors must be strictly decreasing")
    return targets


def parse_floats(text: str) -> tuple[float, ...]:
    values = tuple(float(value) for value in text.split(",") if value.strip())
    if not values:
        raise ValueError("expected a comma-separated list of numbers")
    return values


def range_split(label: str, small_label: str, small_split: int, other_split: int) -> int:
    return small_split if label == small_label else other_split


def spa_candidates(split: int, max_blocks: int) -> list[int]:
    return [blocks * split - 1 for blocks in range(1, max_blocks + 1)]


# --------------------------------------------------------------------------
# SPA
# --------------------------------------------------------------------------


def select_spa_profiles(
    ranges: list[dict],
    targets: list[float],
    small_label: str,
    small_split: int,
    other_split: int,
    max_blocks: int,
    lp_grid: int,
    validation_grid: int,
    eval_dtype: str,
) -> tuple[dict[str, dict], list[dict], list[dict]]:
    profiles: dict[str, dict] = {}
    search_trials: list[dict] = []
    selections: list[dict] = [
        {"tier": tier, "target_max_error": target, "profiles": {}, "degrees": {}}
        for tier, target in zip(("fast", "balanced", "accurate"), targets)
    ]

    for range_item in ranges:
        label = range_item["label"]
        radius = float(range_item["radius"])
        split = range_split(label, small_label, small_split, other_split)
        candidates = spa_candidates(split, max_blocks)
        selected_for_target: dict[float, str] = {}

        for degree in candidates:
            coefficients, lp_error = fit_spa_minimax(radius, degree, lp_grid)
            spec = {
                "kind": "spa",
                "operating_radius": radius,
                "coefficients": [float(value) for value in coefficients],
            }
            metrics = error_summary(spec, radius, eval_dtype, validation_grid)
            profile_id = f"spa-r{radius:g}-k{degree}"
            profile = {
                "id": profile_id,
                "family": "SPA",
                "range_label": label,
                "domain_lo": -radius,
                "domain_hi": radius,
                "degree_square": degree,
                "degree_x": 2 * degree,
                "ps_split": split,
                "fit_method": "discrete Chebyshev-basis minimax LP on the squared domain",
                "lp_error": lp_error,
                **spec,
                **spa_ps_cost(degree, split),
                **metrics,
            }
            profiles[profile_id] = profile
            search_trials.append(
                {
                    "range_label": label,
                    "radius": radius,
                    "degree_square": degree,
                    "ps_split": split,
                    "max_abs_error": metrics["max_abs_error"],
                    "rmse": metrics["rmse"],
                }
            )
            print(
                f"SPA {label:>4s} k={degree:>3d} PS{split} "
                f"max={metrics['max_abs_error']:.6e} "
                f"ct-ct={profile['ps_ctct_mults']} depth={profile['ps_depth_raw_input']}"
            )

            for target in targets:
                if target not in selected_for_target and metrics["max_abs_error"] <= target:
                    selected_for_target[target] = profile_id
            if len(selected_for_target) == len(targets):
                break

        missing = [target for target in targets if target not in selected_for_target]
        if missing:
            raise RuntimeError(
                f"no SPA degree for {label} met target errors {missing}; "
                "increase --spa-max-blocks"
            )

        chosen_degrees: list[int] = []
        for selection in selections:
            profile_id = selected_for_target[selection["target_max_error"]]
            degree = int(profiles[profile_id]["degree_square"])
            chosen_degrees.append(degree)
            selection["profiles"][label] = profile_id
            selection["degrees"][label] = degree

        if len(set(chosen_degrees)) != len(chosen_degrees):
            # Two tiers can legitimately land on the same degree at a small
            # radius (GELU's PS4 buckets at R = 5 jump from 1.3e-3 straight
            # to 9e-6). Tiers are named by the wide-range degree, which is
            # checked for uniqueness below.
            print(
                f"  note: SPA tiers share a degree for {label}: {chosen_degrees} "
                "(distinct wide-range degrees are still required)"
            )

    wide_label = ranges[-1]["label"]
    used_ids: set[str] = set()
    for selection in selections:
        wide_degree = selection["degrees"][wide_label]
        method_id = f"spa-k{wide_degree}"
        if method_id in used_ids:
            raise RuntimeError(f"duplicate SPA method ID: {method_id}")
        used_ids.add(method_id)
        selection["id"] = method_id
        selection["display_name"] = f"SPA-k{wide_degree}"
        selection["naming_rule"] = "suffix is the square-domain degree of the wide profile"
        selection["degree_schedule"] = ";".join(
            f"{item['label']}:k{selection['degrees'][item['label']]}" for item in ranges
        )

    selected_ids = {
        profile_id for selection in selections for profile_id in selection["profiles"].values()
    }
    selected_profiles = {
        profile_id: profile for profile_id, profile in profiles.items() if profile_id in selected_ids
    }
    return selected_profiles, selections, search_trials


# --------------------------------------------------------------------------
# baselines
# --------------------------------------------------------------------------


def common_fields(profile_id: str, family: str, label: str, radius: float) -> dict:
    return {
        "id": profile_id,
        "family": family,
        "range_label": label,
        "operating_radius": radius,
        "domain_lo": -radius,
        "domain_hi": radius,
    }


def generate_nexus(
    ranges: list[dict], eval_dtype: str, validation_grid: int, gate_power: int | None
) -> tuple[dict[str, dict], dict]:
    profiles: dict[str, dict] = {}
    schedule: list[str] = []
    for item in ranges:
        label, radius = item["label"], float(item["radius"])
        spec = build_nexus_profile(radius, eval_dtype, gate_power)
        metrics = error_summary(spec, radius, eval_dtype, validation_grid)
        profile_id = f"nexus-r{radius:g}"
        profiles[label] = {
            **common_fields(profile_id, "NEXUS", label, radius),
            **spec,
            "middle_degree": 12,
            "sign_levels": 4 * (spec["sign_dg"] + spec["sign_df"]),
            "provenance": (
                "NEXUS src/gelu.cpp as released (two CKK20 signs at +-3.5 gating 0 / "
                "degree-12 polynomial / x); normaliser delta = R + 3.5 (8.5 at R = 5); "
                "sign depth preserves the released band width in x; gate power "
                f"{spec['gate_power']} suppresses one-ulp sign residuals (MOAI's "
                "gelu.hpp squares the gate for the same reason)"
            ),
            **metrics,
        }
        schedule.append(
            f"{label}:d12-sign{spec['sign_dg']}g{spec['sign_df']}f-p{spec['gate_power']}"
        )
        print(
            f"NEXUS {label:>4s} delta={spec['delta']:g} sign=({spec['sign_dg']},{spec['sign_df']}) "
            f"gate^{spec['gate_power']} max={metrics['max_abs_error']:.3e} "
            f"{eval_dtype}={metrics.get(f'max_abs_error_{eval_dtype}', metrics['max_abs_error']):.3e}"
        )
    method = {
        "id": "nexus",
        "display_name": DISPLAY_NAMES["nexus"],
        "profiles": {label: profile["id"] for label, profile in profiles.items()},
        "degree_schedule": ";".join(schedule),
        "implementation": "released-code reconstruction with range-adapted normaliser, sign depth and gate power",
        "released_configuration": {
            "interval": [-5.0, 5.0],
            "delta": NEXUS_RELEASED_DELTA,
            "sign": list(NEXUS_SIGN),
            "gate_power": 1,
        },
    }
    return profiles, method


def generate_euston(
    ranges: list[dict], eval_dtype: str, validation_grid: int
) -> tuple[dict[str, dict], dict]:
    profiles: dict[str, dict] = {}
    schedule: list[str] = []
    for item in ranges:
        label, radius = item["label"], float(item["radius"])
        spec = build_euston_profile(radius)
        metrics = error_summary(spec, radius, eval_dtype, validation_grid)
        own_target = evaluate_spec(spec, radius, validation_grid, eval_dtype, sigmoid_gelu)
        profile_id = f"euston-r{radius:g}"
        profiles[label] = {
            **common_fields(profile_id, "Euston", label, radius),
            **spec,
            "sign_levels": 4 * (spec["sign_dg"] + spec["sign_df"]),
            "own_target": "x * sigmoid(1.702 x)",
            "max_abs_error_vs_own_target": own_target["max_abs_error"],
            "rmse_vs_own_target": own_target["rmse"],
            "provenance": (
                "Euston gelu.cpp/func_main.cpp as released (sigmoid form, CKK20 sign, "
                "degree-7 exp with squarings, 3-iteration Goldschmidt inverse); "
                "normaliser delta = 1.2 R (6 at R = 5); sign depth preserves the released "
                f"band width; exp squarings r = {spec['exp_squarings']} keep 1.702 R / 2^r "
                f"<= {EUSTON_EXP_INTERVAL:g}"
            ),
            **metrics,
        }
        schedule.append(
            f"{label}:sign{spec['sign_dg']}g{spec['sign_df']}f-exp7x{spec['exp_squarings']}-inv3"
        )
        print(
            f"Euston {label:>4s} delta={spec['delta']:g} sign=({spec['sign_dg']},{spec['sign_df']}) "
            f"r={spec['exp_squarings']} max={metrics['max_abs_error']:.3e} "
            f"own-target={own_target['max_abs_error']:.3e}"
        )
    method = {
        "id": "euston",
        "display_name": DISPLAY_NAMES["euston"],
        "profiles": {label: profile["id"] for label, profile in profiles.items()},
        "degree_schedule": ";".join(schedule),
        "implementation": "released-code reconstruction with range-adapted normaliser, sign depth and exp squarings",
        "released_configuration": {
            "interval": [-5.0, 5.0],
            "delta": EUSTON_RELEASED_DELTA,
            "sign": list(EUSTON_SIGN),
            "exp_squarings": 1,
        },
    }
    return profiles, method


def generate_moai(
    ranges: list[dict],
    eval_dtype: str,
    validation_grid: int,
    base_candidates: tuple[float, ...],
    extension_factor: float,
) -> tuple[dict[str, dict], dict, list[dict]]:
    profiles: dict[str, dict] = {}
    schedule: list[str] = []
    trials: list[dict] = []
    for item in ranges:
        label, radius = item["label"], float(item["radius"])
        started = time.time()
        spec, range_trials = select_moai_profile(radius, eval_dtype, base_candidates, extension_factor)
        for trial in range_trials:
            trials.append({"range_label": label, "radius": radius, **trial})
        metrics = error_summary(spec, radius, eval_dtype, validation_grid)
        profile_id = f"moai-r{radius:g}"
        profiles[label] = {
            **common_fields(profile_id, "MOAI", label, radius),
            **spec,
            "extension_levels": 2 * spec["extension_stages"],
            "provenance": (
                f"MOAI: degree-{MOAI_DEGREE} minimax fit of the {spec['factor_target']} factor on "
                f"[-{spec['base_radius']:g}, {spec['base_radius']:g}] (the paper's degree-23 "
                "minimax) composed with Cheon-Kim-Park domain-extension stages (the paper's "
                "named wide-interval mechanism); base radius and stage count chosen to minimise "
                "the max error on [-R, R]"
            ),
            **metrics,
        }
        schedule.append(f"{label}:d{MOAI_DEGREE}-B{spec['base_radius']:g}-s{spec['extension_stages']}")
        print(
            f"MOAI  {label:>4s} B={spec['base_radius']:g} stages={spec['extension_stages']} "
            f"factor-err={spec['factor_minimax_error']:.2e} max={metrics['max_abs_error']:.3e} "
            f"({time.time() - started:.1f}s)"
        )
    method = {
        "id": "moai",
        "display_name": DISPLAY_NAMES["moai"],
        "profiles": {label: profile["id"] for label, profile in profiles.items()},
        "degree_schedule": ";".join(schedule),
        "implementation": (
            f"degree-{MOAI_DEGREE} tanh-factor minimax with range-adapted base radius and "
            "Cheon-Kim-Park extension stages"
        ),
        "released_configuration": {
            "degree": MOAI_DEGREE,
            "paper_interval": [-20.0, 10.0],
            "extension_factor": extension_factor,
        },
    }
    return profiles, method, trials


# --------------------------------------------------------------------------
# summary
# --------------------------------------------------------------------------

SUMMARY_FIELDS = [
    "method",
    "family",
    "range_label",
    "radius",
    "configuration",
    "max_abs_error",
    "rmse",
    "max_abs_error_eval_dtype",
    "profile_id",
    "provenance",
]


def configuration_string(profile: dict) -> str:
    kind = profile["kind"]
    if kind == "spa":
        return (
            f"k={profile['degree_square']} PS{profile['ps_split']} "
            f"ctct={profile['ps_ctct_mults']} depth={profile['ps_depth_raw_input']}"
        )
    if kind == "nexus":
        return (
            f"delta={profile['delta']:g} sign=({profile['sign_dg']},{profile['sign_df']}) "
            f"gate^{profile['gate_power']} d12"
        )
    if kind == "euston":
        return (
            f"delta={profile['delta']:g} sign=({profile['sign_dg']},{profile['sign_df']}) "
            f"exp7x{profile['exp_squarings']} inv{profile['inverse_iterations']}"
        )
    if kind == "moai":
        return f"d{profile['degree']} B={profile['base_radius']:g} stages={profile['extension_stages']}"
    return kind


def summary_rows(catalog: dict, eval_dtype: str) -> list[dict]:
    rows: list[dict] = []
    range_radius = {item["label"]: item["radius"] for item in catalog["ranges"]}
    key = f"max_abs_error_{eval_dtype}"

    def row(method: str, family: str, label: str, profile_id: str, provenance: str) -> dict:
        profile = catalog["profiles"][profile_id]
        return {
            "method": method,
            "family": family,
            "range_label": label,
            "radius": range_radius[label],
            "configuration": configuration_string(profile),
            "max_abs_error": profile["max_abs_error"],
            "rmse": profile["rmse"],
            "max_abs_error_eval_dtype": profile.get(key, profile["max_abs_error"]),
            "profile_id": profile_id,
            "provenance": provenance,
        }

    for variant in catalog["methods"]["spa"]:
        for label, profile_id in variant["profiles"].items():
            rows.append(row(variant["id"], "SPA", label, profile_id, "proposed SPA degree sweep"))
    for method in BASELINES:
        for label, profile_id in catalog["methods"][method]["profiles"].items():
            profile = catalog["profiles"][profile_id]
            rows.append(row(method, profile["family"], label, profile_id, profile["provenance"]))
    return rows


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Generate one shared GELU profile catalog for plaintext evaluation and the "
            "matching ciphertext implementation."
        )
    )
    parser.add_argument("--range-plan", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--spa-target-errors",
        default="2.1e-2,1e-3,1e-4",
        help="Fast, balanced and accurate maximum-error targets.",
    )
    parser.add_argument("--spa-small-split", type=int, default=4)
    parser.add_argument("--spa-other-split", type=int, default=8)
    parser.add_argument(
        "--spa-max-blocks",
        type=int,
        default=40,
        help="GELU needs roughly 1.7x the SiLU degree at the same radius, hence the higher cap.",
    )
    parser.add_argument("--lp-grid", type=int, default=3000)
    parser.add_argument("--validation-grid", type=int, default=300001)
    parser.add_argument(
        "--eval-dtype",
        default="float32",
        choices=["float32", "float64"],
        help=(
            "Dtype the GPU activation swap will use (eval_methods.py --activation-dtype). "
            "Errors are recorded in float64 and in this dtype; NEXUS's gate power depends on it."
        ),
    )
    parser.add_argument(
        "--nexus-gate-power",
        default="auto",
        help=(
            "'auto' applies the leakage rule in profile_math.py; an integer fixes the power "
            "(1 = released code, 2 = MOAI's variant of it)."
        ),
    )
    parser.add_argument(
        "--moai-base-candidates",
        default=",".join(f"{value:g}" for value in MOAI_BASE_CANDIDATES),
        help="Base radii tried for MOAI's degree-23 fit; the radius itself is always tried too.",
    )
    parser.add_argument("--moai-extension-factor", type=float, default=MOAI_EXTENSION_FACTOR)
    parser.add_argument(
        "--target",
        default="tanh",
        choices=sorted(ACTIVATION_TARGETS),
        help=(
            "GELU form the profiles are fitted to and measured against: 'tanh' is the "
            "model's gelu_pytorch_tanh; 'erf' is the exact erf-GELU that MOAI's and "
            "NEXUS's released polynomials approximate (eval_methods --target must match)."
        ),
    )
    args = parser.parse_args()
    import profile_math

    profile_math.set_activation_target(args.target)

    if args.moai_extension_factor <= 1.0 or args.moai_extension_factor > 1.5:
        raise ValueError("--moai-extension-factor must be in (1, 1.5]")
    gate_power = None if args.nexus_gate_power == "auto" else int(args.nexus_gate_power)
    if gate_power is not None and gate_power < 1:
        raise ValueError("--nexus-gate-power must be 'auto' or a positive integer")

    plan = json.loads(args.range_plan.read_text())
    ranges = plan["ranges"]
    if len(ranges) != 3:
        raise RuntimeError("the current experiment expects exactly three range groups")
    small_label = ranges[0]["label"]
    targets = parse_targets(args.spa_target_errors)

    spa_profiles, spa_variants, spa_search_trials = select_spa_profiles(
        ranges=ranges,
        targets=targets,
        small_label=small_label,
        small_split=args.spa_small_split,
        other_split=args.spa_other_split,
        max_blocks=args.spa_max_blocks,
        lp_grid=args.lp_grid,
        validation_grid=args.validation_grid,
        eval_dtype=args.eval_dtype,
    )

    profiles: dict[str, dict] = dict(spa_profiles)
    methods: dict[str, object] = {"spa": spa_variants}

    nexus_profiles, methods["nexus"] = generate_nexus(
        ranges, args.eval_dtype, args.validation_grid, gate_power
    )
    moai_profiles, methods["moai"], moai_trials = generate_moai(
        ranges,
        args.eval_dtype,
        args.validation_grid,
        parse_floats(args.moai_base_candidates),
        args.moai_extension_factor,
    )
    euston_profiles, methods["euston"] = generate_euston(ranges, args.eval_dtype, args.validation_grid)
    for generated in (nexus_profiles, moai_profiles, euston_profiles):
        for profile in generated.values():
            profiles[profile["id"]] = profile

    catalog = {
        "format": "activation-profile-catalog-v4-gelu",
        "target": profile_math.target_name(),
        "activation_target": args.target,
        "native_activation": {"id": ACTIVATION_TARGETS[args.target]["id"], "torch_approximate": ACTIVATION_TARGETS[args.target]["torch_approximate"]},
        "evaluation_dtype": args.eval_dtype,
        "range_assignment": "static-per-channel; omitted from public method names",
        "range_plan": str(args.range_plan.resolve()),
        "range_plan_sha256": file_sha256(args.range_plan),
        "ranges": ranges,
        "spa_target_errors": targets,
        "spa_naming": (
            "SPA-k* uses the wide-range square-domain degree as the suffix; "
            "the complete R5/R20/Rwide degree schedule is stored per method."
        ),
        "spa_search_trials": spa_search_trials,
        "moai_search_trials": moai_trials,
        "baseline_adaptation": (
            "Each comparison method is extended to the calibrated radii along the "
            "parameters its own code or paper exposes for the operating interval; "
            "see profile_math.py for the rules and the per-profile search records."
        ),
        "methods": methods,
        "profiles": profiles,
    }

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(catalog, indent=2))

    rows = summary_rows(catalog, args.eval_dtype)
    summary_path = args.output.with_name("profile_summary.csv")
    with summary_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=SUMMARY_FIELDS)
        writer.writeheader()
        writer.writerows(rows)

    print("SPA variants:")
    for variant in spa_variants:
        print(
            f"  {variant['display_name']}: {variant['degree_schedule']} "
            f"target={variant['target_max_error']:.3e}"
        )
    for method in BASELINES:
        print(f"  {DISPLAY_NAMES[method]}: {methods[method]['degree_schedule']}")
    print(f"saved: {args.output}")
    print(f"saved: {summary_path}")


if __name__ == "__main__":
    main()
