"""Verify the hidden-channel permutation that groups static range classes.

Reordering the gated-MLP (GeGLU) hidden channels so each range class is
contiguous is what makes the packing practical under encryption. This
checks the permutation is output-preserving on a real activation from the
task in question, using the model's own tanh-GELU. Model weights are not
saved or modified in place.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import torch
import torch.nn.functional as F
from transformers import AutoModelForCausalLM, AutoTokenizer

from mcq_common import PROMPT_STYLES, build_records
from model_sites import iter_gated_mlps
from tasks import get_task, set_source_override


def resolve_model_path(path: str) -> str:
    candidate = Path(path).expanduser()
    if candidate.exists():
        return str(candidate.resolve())
    fallback = Path("/root") / candidate
    if fallback.exists():
        return str(fallback.resolve())
    raise FileNotFoundError(f"model directory not found: {path!r}")


def resolve_layer_plan(plan: dict, layer_name: str) -> dict:
    if layer_name in plan["layers"]:
        return plan["layers"][layer_name]
    layer_number = layer_name.split(".layers.", 1)[-1].split(".", 1)[0]
    matches = [
        value
        for key, value in plan["layers"].items()
        if f".layers.{layer_number}." in key
    ]
    if len(matches) != 1:
        raise KeyError(layer_name)
    return matches[0]


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Verify the GeGLU hidden-channel permutation used to group static "
            "range classes. Model weights are not saved or modified in place."
        )
    )
    parser.add_argument("--task", default="hellaswag")
    parser.add_argument("--split", default="", help="Defaults to the task's calibration split.")
    parser.add_argument("--prompt-style", default="plain", choices=list(PROMPT_STYLES))
    parser.add_argument("--hf-source", default="")
    parser.add_argument("--model-path", required=True)
    parser.add_argument("--range-plan", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--sample-index", type=int, default=0)
    parser.add_argument("--max-length", type=int, default=512)
    args = parser.parse_args()

    if args.hf_source:
        set_source_override(args.task, args.hf_source)
    task = get_task(args.task)
    model_path = resolve_model_path(args.model_path)
    plan = json.loads(args.range_plan.read_text())
    labels = plan["labels"]

    tokenizer = AutoTokenizer.from_pretrained(model_path, local_files_only=True)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token

    base = AutoModelForCausalLM.from_pretrained(
        model_path,
        dtype=torch.bfloat16,
        local_files_only=True,
        attn_implementation="sdpa",
    )
    model = base
    model.eval().cuda()
    model.config.use_cache = False

    captured: dict[str, torch.Tensor] = {}
    handles = []
    for name, module in iter_gated_mlps(model):

        def pre_hook(_module, inputs, name=name):
            captured[name] = inputs[0][:, -1:, :].detach().cpu()

        handles.append(module.register_forward_pre_hook(pre_hook))

    # Any real activation will do; the calibration split is used so this
    # never touches data the evaluation is scored on.
    split_name = args.split or task.calibration_split
    examples = task.loader(split_name, args.sample_index + 1, 20260901)
    records, _, _, _ = build_records(
        tokenizer,
        examples[args.sample_index : args.sample_index + 1],
        choice_prefix=task.choice_prefix,
        max_length=args.max_length,
        prompt_style=args.prompt_style,
        system_prompt=task.chat_system_prompt,
    )
    input_tensor = torch.tensor([records[0].input_ids], dtype=torch.long, device="cuda")

    with torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16):
        model(input_ids=input_tensor, use_cache=False)

    for handle in handles:
        handle.remove()

    modules = dict(model.named_modules())
    rows: list[dict] = []
    sort_key = lambda name: int(name.split(".layers.", 1)[-1].split(".", 1)[0])

    for name in sorted(captured, key=sort_key):
        module = modules[name]
        layer_plan = resolve_layer_plan(plan, name)
        permutation = torch.tensor(
            layer_plan["permutation"],
            dtype=torch.long,
            device="cuda",
        )
        hidden = captured[name].cuda().float()

        with torch.inference_mode():
            gate_weight = module.gate_proj.weight.float()
            up_weight = module.up_proj.weight.float()
            down_weight = module.down_proj.weight.float()
            gate_bias = None if module.gate_proj.bias is None else module.gate_proj.bias.float()
            up_bias = None if module.up_proj.bias is None else module.up_proj.bias.float()
            down_bias = None if module.down_proj.bias is None else module.down_proj.bias.float()

            gate = F.linear(hidden, gate_weight, gate_bias)
            up = F.linear(hidden, up_weight, up_bias)
            activation = lambda value: F.gelu(value, approximate="tanh")
            original = F.linear(activation(gate) * up, down_weight, down_bias)

            gate_permuted = gate.index_select(-1, permutation)
            up_permuted = up.index_select(-1, permutation)
            down_permuted = down_weight.index_select(1, permutation)
            transformed = F.linear(
                activation(gate_permuted) * up_permuted,
                down_permuted,
                down_bias,
            )

            difference = (original - transformed).abs()
            denominator = original.abs().max().clamp_min(1e-12)

        result = {
            "layer": name,
            "layer_index": layer_plan["layer_index"],
        }
        for label in labels:
            result[f"channels_{label}"] = layer_plan["range_counts"][label]
        result.update(
            {
                "max_abs_original": float(original.abs().max().item()),
                "max_abs_difference": float(difference.max().item()),
                "mean_abs_difference": float(difference.mean().item()),
                "relative_max_difference": float((difference.max() / denominator).item()),
            }
        )
        rows.append(result)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    print(f"saved: {args.output}")
    print("global max absolute difference:", max(row["max_abs_difference"] for row in rows))
    print("global max relative difference:", max(row["relative_max_difference"] for row in rows))


if __name__ == "__main__":
    main()
