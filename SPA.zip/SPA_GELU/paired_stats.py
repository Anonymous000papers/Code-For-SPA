"""Paired-comparison statistics, free of torch and scipy.

Kept separate from ``mcq_common`` so that offline analysis (and the
test suite) can use them without importing a deep-learning stack.
The exact test is computed in log space rather than through scipy: an
earlier version fell back to a normal approximation when the import
failed, and on a 52/28 split the two disagree (0.0097 against 0.0073).
A p-value that silently changes method is not safe in a paper pipeline.
"""

from __future__ import annotations

import math

import numpy as np


def exact_two_sided_binomial(successes: int, trials: int) -> float:
    """Exact two-sided binomial p-value at p = 0.5.

    Computed in log space so it is self-contained and stable for large
    numbers of discordant pairs. Under p = 0.5 the null distribution is
    symmetric, so the two-sided p-value is twice the lower tail.
    """
    if trials <= 0:
        return 1.0
    tail = min(successes, trials - successes)
    log_half = -trials * math.log(2.0)
    log_terms = [
        math.lgamma(trials + 1)
        - math.lgamma(index + 1)
        - math.lgamma(trials - index + 1)
        + log_half
        for index in range(tail + 1)
    ]
    largest = max(log_terms)
    log_tail = largest + math.log(sum(math.exp(term - largest) for term in log_terms))
    return min(1.0, 2.0 * math.exp(log_tail))


PROMPT_STYLES = ("plain", "chat")


def mcnemar(reference_correct: np.ndarray, method_correct: np.ndarray) -> dict[str, float]:
    """Exact paired test on the discordant examples."""
    to_wrong = int(np.sum(reference_correct & ~method_correct))
    to_right = int(np.sum(~reference_correct & method_correct))
    discordant = to_wrong + to_right
    p_value = 1.0 if discordant == 0 else exact_two_sided_binomial(to_right, discordant)
    return {
        "mcnemar_to_wrong": to_wrong,
        "mcnemar_to_right": to_right,
        "mcnemar_discordant": discordant,
        "mcnemar_p": p_value,
        "mcnemar_test": "exact binomial, two-sided",
    }


def minimum_detectable_effect(example_count: int, flip_count: int) -> float:
    """Smallest net accuracy shift (pp) a paired test could resolve here."""
    if flip_count < 5 or example_count <= 0:
        return float("nan")
    return 100.0 * 2.0 * (0.98 / math.sqrt(flip_count)) * (flip_count / example_count)


def paired_bootstrap(
    differences: np.ndarray,
    resamples: int = 10000,
    seed: int = 20260901,
    alpha: float = 0.05,
) -> dict[str, float]:
    """Paired bootstrap on per-unit differences.

    Used for continuous metrics such as per-token NLL, where McNemar does
    not apply. Distribution-free, so it needs no t-distribution CDF and no
    scipy. The p-value is the two-sided proportion of resampled means
    falling on the opposite side of zero from the observed mean.
    """
    differences = np.asarray(differences, dtype=np.float64)
    differences = differences[np.isfinite(differences)]
    count = differences.size
    if count == 0:
        return {"mean": float("nan"), "ci_low": float("nan"), "ci_high": float("nan"), "p": 1.0}

    observed = float(differences.mean())
    rng = np.random.default_rng(seed)
    means = differences[rng.integers(0, count, size=(resamples, count))].mean(axis=1)
    low, high = np.quantile(means, [alpha / 2.0, 1.0 - alpha / 2.0])

    if observed == 0.0:
        p_value = 1.0
    else:
        crossings = float(np.mean(means <= 0.0) if observed > 0 else np.mean(means >= 0.0))
        p_value = min(1.0, 2.0 * crossings)
    return {
        "mean": observed,
        "ci_low": float(low),
        "ci_high": float(high),
        "p": p_value,
        "units": count,
    }


def paired_ratio_bootstrap(
    numerators: np.ndarray,
    denominators: np.ndarray,
    resamples: int = 10000,
    seed: int = 20260901,
    alpha: float = 0.05,
) -> dict[str, float]:
    """Paired bootstrap of a ratio of sums, ``sum(num) / sum(den)``.

    For corpus-level token NLL the numerator of unit ``i`` is the window's
    NLL difference summed over its tokens and the denominator its token
    count, so the observed statistic is exactly the difference of the two
    corpus NLLs. Units are resampled jointly and the ratio recomputed on
    each replicate. The p-value is the two-sided proportion of replicates
    on the opposite side of zero from the observed ratio.
    """
    numerators = np.asarray(numerators, dtype=np.float64)
    denominators = np.asarray(denominators, dtype=np.float64)
    if numerators.shape != denominators.shape:
        raise ValueError("numerators and denominators must have the same shape")
    keep = np.isfinite(numerators) & np.isfinite(denominators) & (denominators > 0)
    numerators, denominators = numerators[keep], denominators[keep]
    count = numerators.size
    if count == 0 or denominators.sum() <= 0:
        return {"ratio": float("nan"), "ci_low": float("nan"), "ci_high": float("nan"), "p": 1.0, "units": 0}

    observed = float(numerators.sum() / denominators.sum())
    rng = np.random.default_rng(seed)
    index = rng.integers(0, count, size=(resamples, count))
    ratios = numerators[index].sum(axis=1) / denominators[index].sum(axis=1)
    low, high = np.quantile(ratios, [alpha / 2.0, 1.0 - alpha / 2.0])
    if observed == 0.0:
        p_value = 1.0
    else:
        crossings = float(np.mean(ratios <= 0.0) if observed > 0 else np.mean(ratios >= 0.0))
        p_value = min(1.0, 2.0 * crossings)
    return {
        "ratio": observed,
        "ci_low": float(low),
        "ci_high": float(high),
        "p": p_value,
        "units": count,
    }
