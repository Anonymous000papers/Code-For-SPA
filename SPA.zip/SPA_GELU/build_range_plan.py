"""Freeze per-channel range assignments (r5 / r20 / wide) from the calibration statistics."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
from collections import defaultdict
from pathlib import Path

LAYER_RE = re.compile(r"(?:^|\.)layers\.(\d+)\.")


def layer_index(name: str) -> int:
    match = LAYER_RE.search(name)
    return int(match.group(1)) if match else -1


def parse_radii(text: str) -> list[float]:
    values = [float(value) for value in text.split(",") if value.strip()]
    if not values or values != sorted(set(values)):
        raise ValueError("radii must be unique and strictly increasing")
    return values


def label_for_radius(radius: float) -> str:
    return f"r{radius:g}".replace(".", "_")


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def select_wide_radius(required: float, candidates: list[float], minimum: float) -> float:
    for radius in candidates:
        if radius > minimum and radius >= required:
            return radius
    raise RuntimeError(
        f"required radius {required:.6g} exceeds the available candidates {candidates}"
    )


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Build a validation-independent per-channel range plan. The two base "
            "ranges are fixed; the wide range is selected from train calibration."
        )
    )
    parser.add_argument("--channel-calibration", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--base-radii", default="5,20")
    parser.add_argument(
        "--wide-candidates",
        default="24,32,40,48,56,64,80,96,112,128,160,192,256,320,384,448,512",
    )
    parser.add_argument("--margin", type=float, default=1.10)
    args = parser.parse_args()

    base_radii = parse_radii(args.base_radii)
    if len(base_radii) != 2:
        raise ValueError("--base-radii must contain exactly two radii")
    if args.margin < 1.0:
        raise ValueError("--margin must be at least 1")

    wide_candidates = parse_radii(args.wide_candidates)
    with args.channel_calibration.open(newline="") as handle:
        rows = list(csv.DictReader(handle))
    if not rows:
        raise RuntimeError("channel calibration is empty")

    calibration_max = max(float(row["max_abs"]) for row in rows)
    required_wide = calibration_max * args.margin
    wide_radius = select_wide_radius(required_wide, wide_candidates, base_radii[-1])

    ranges = [
        {"label": label_for_radius(base_radii[0]), "radius": base_radii[0], "role": "base"},
        {"label": label_for_radius(base_radii[1]), "radius": base_radii[1], "role": "base"},
        {"label": "wide", "radius": wide_radius, "role": "train-calibrated"},
    ]
    radii_by_label = {item["label"]: item["radius"] for item in ranges}
    labels = [item["label"] for item in ranges]

    by_layer: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        by_layer[row["layer"]].append(row)

    totals = {label: 0 for label in labels}
    layer_plans: dict[str, dict] = {}
    summary_rows: list[dict] = []

    for layer in sorted(by_layer, key=layer_index):
        channel_rows = sorted(by_layer[layer], key=lambda row: int(row["channel"]))
        assignments: list[str] = []
        maxima: list[float] = []

        for row in channel_rows:
            maximum = float(row["max_abs"])
            bound = maximum * args.margin
            maxima.append(maximum)
            for item in ranges:
                if bound <= item["radius"]:
                    assignment = item["label"]
                    break
            else:
                raise RuntimeError(
                    f"{layer} channel {row['channel']} requires {bound:.6g}, "
                    f"above R={wide_radius:g}"
                )
            assignments.append(assignment)
            totals[assignment] += 1

        layer_bound = max(maxima) * args.margin
        layer_assignment = next(
            item["label"] for item in ranges if layer_bound <= item["radius"]
        )
        permutation = [
            index
            for label in labels
            for index, assignment in enumerate(assignments)
            if assignment == label
        ]
        if sorted(permutation) != list(range(len(assignments))):
            raise RuntimeError(f"invalid permutation for {layer}")

        counts = {label: assignments.count(label) for label in labels}
        layer_plans[layer] = {
            "layer_index": layer_index(layer),
            "observed_max_abs": max(maxima),
            "safety_bound": layer_bound,
            "layer_range": layer_assignment,
            "channel_ranges": assignments,
            "range_counts": counts,
            "permutation": permutation,
        }

        summary = {
            "layer": layer,
            "layer_index": layer_index(layer),
            "observed_max_abs": max(maxima),
            "safety_bound": layer_bound,
            "layer_range": layer_assignment,
        }
        for label in labels:
            summary[f"channels_{label}"] = counts[label]
        summary_rows.append(summary)

    # Provenance must describe the calibration that actually ran, read from
    # the metadata beside the CSV rather than assumed. Protocol A rests on
    # calibration and evaluation being separate, so a plan that misnames its
    # own source undermines the claim it exists to support.
    calibration_source = "unknown"
    sidecar = args.channel_calibration.parent / "metadata.json"
    if sidecar.exists():
        info = json.loads(sidecar.read_text())
        calibration_source = (
            f"{info.get('task', '?')} {info.get('split', '?')} "
            f"({info.get('examples', '?')} examples)"
        )
    else:
        print(f"WARNING: no {sidecar} found; calibration_source recorded as 'unknown'")

    output = {
        "format": "spa-range-plan-v2",
        "assignment": "static-per-channel",
        "calibration_source": calibration_source,
        "validation_accessed": False,
        "margin": args.margin,
        "calibration_max_abs": calibration_max,
        "required_wide_radius": required_wide,
        "ranges": ranges,
        "radii": radii_by_label,
        "labels": labels,
        "totals": totals,
        "channel_calibration": str(args.channel_calibration.resolve()),
        "channel_calibration_sha256": file_sha256(args.channel_calibration),
        "layers": layer_plans,
    }

    args.output_dir.mkdir(parents=True, exist_ok=True)
    plan_path = args.output_dir / "range_plan.json"
    plan_path.write_text(json.dumps(output, indent=2))

    summary_path = args.output_dir / "range_plan_summary.csv"
    with summary_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(summary_rows[0].keys()))
        writer.writeheader()
        writer.writerows(summary_rows)

    total_channels = sum(totals.values())
    print(f"calibration max: {calibration_max:g}")
    print(f"required wide radius: {required_wide:g}")
    print(f"selected wide radius: {wide_radius:g}")
    for label in labels:
        print(f"{label}: {totals[label]} / {total_channels} = {totals[label] / total_channels:.6%}")
    print(f"saved: {plan_path}")
    print(f"saved: {summary_path}")


if __name__ == "__main__":
    main()
