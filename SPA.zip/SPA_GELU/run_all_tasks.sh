#!/usr/bin/env bash
# Full sweep: calibrate, plan, fit profiles, audit, smoke-test, evaluate, pool.
# GELU edition: Gemma 4 E2B (gelu_pytorch_tanh), SPA vs NEXUS / MOAI / Euston.
#
# Every task calibrates on its own split and is scored on a disjoint one.
# A failing task does not abort the sweep.
#
#   bash run_all_tasks.sh                 # main tier, then appendix
#   TIER=main bash run_all_tasks.sh       # reported tasks only
#   TASKS="mmlu" bash run_all_tasks.sh    # one task
#   SMOKE_ONLY=1 bash run_all_tasks.sh    # stop before the full evaluations
set -uo pipefail

MODEL_PATH="${MODEL_PATH:?set MODEL_PATH to the Gemma 4 E2B checkpoint directory}"
# TARGET=tanh (default): the model's gelu_pytorch_tanh is the reference.
# TARGET=erf: the exact erf-GELU is substituted for the model's activation and
# is the reference; SPA and MOAI are refitted to it, NEXUS's released
# polynomial already approximates it, Euston (fitted to QuickGELU) is
# skipped, and the original activation is evaluated as "native-tanh" with
# "exact-tanh" as the same-precision control.
# Calibration is repeated on the erf branch (with the erf-GELU substituted):
# activation changes in early layers alter the inputs of later layers, so the
# tanh calibration is not assumed to carry over.
TARGET="${TARGET:-tanh}"
case "${TARGET}" in
  tanh) DEFAULT_ROOT="results/zeroshot"; TARGET_SKIP="" ;;
  erf)  DEFAULT_ROOT="results/zeroshot_erf"; TARGET_SKIP="${SKIP_METHODS:-euston}" ;;
  *) echo "TARGET must be tanh or erf" >&2; exit 2 ;;
esac
ROOT="${ROOT:-${DEFAULT_ROOT}}"
TIER="${TIER:-all}"

MAIN_TASKS="wikitext2 c4_en hellaswag mmlu social_i_qa race_high"
APPENDIX_TASKS="code_python arc_easy arc_challenge piqa"
case "${TIER}" in
  main)     DEFAULT_TASKS="${MAIN_TASKS}" ;;
  appendix) DEFAULT_TASKS="${APPENDIX_TASKS}" ;;
  *)        DEFAULT_TASKS="${MAIN_TASKS} ${APPENDIX_TASKS}" ;;
esac
TASKS="${TASKS:-${DEFAULT_TASKS}}"

COMPILE="${COMPILE:-default}"
SHARED_PROMPT="${SHARED_PROMPT:-auto}"
EVAL_BATCH="${EVAL_BATCH:-32}"
CAL_BATCH="${CAL_BATCH:-32}"
# Per-batch token budget (rows x padded length). Bounds the logits tensor,
# which with Gemma's 262k vocabulary is what runs out of memory first: a
# batch of 32 full 2048-token windows (code_python) is 32 GiB of bf16
# logits. 32768 tokens = 16 GiB; halve it on a 48 GB GPU.
MAX_BATCH_TOKENS="${MAX_BATCH_TOKENS:-16384}"
SPA_TARGETS="${SPA_TARGETS:-2.1e-2,1e-3,1e-4}"
SPA_MAX_BLOCKS="${SPA_MAX_BLOCKS:-40}"
MARGIN="${MARGIN:-1.10}"
# float32 is the protocol default; float64 separates approximation error
# from precision effects (both stages must agree, eval_methods checks).
ACT_DTYPE="${ACT_DTYPE:-float32}"
NEXUS_GATE_POWER="${NEXUS_GATE_POWER:-auto}"
WIDE_CANDIDATES="24,32,40,48,56,64,80,96,112,128,160,192,256,320,384,448,512"
THRESHOLDS="5,20,${WIDE_CANDIDATES}"
SMOKE_SAMPLES="${SMOKE_SAMPLES:-256}"
SMOKE_ONLY="${SMOKE_ONLY:-}"

export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"

# MMLU has no train split and calibrates on validation+dev; auxiliary_train is
# avoided because it is drawn from ARC and would overlap ARC-Challenge.
# ARC-Challenge's 1,119 train items are thin, so validation is added.
cal_split() {
  case "$1" in
    mmlu)          echo "validation,dev" ;;
    arc_challenge) echo "train,validation" ;;
    *)             echo "" ;;
  esac
}
# Code tokenises densest, so it gets the widest budget.
max_length() {
  case "$1" in
    race_high)          echo 2048 ;;
    code_python)        echo 2048 ;;
    wikitext2|c4_en)    echo 1536 ;;
    mmlu)               echo 1024 ;;
    piqa)               echo 1024 ;;
    *)                  echo 512 ;;
  esac
}
# Calibration volume drives the out-of-range rate at evaluation time.
cal_samples() {
  case "$1" in
    wikitext2|c4_en|code_python) echo 1500 ;;
    race_high)                   echo 8000 ;;
    *)                           echo 0 ;;
  esac
}
# WikiText-2 resolved every method on 368 windows, so scoring all 42,601 of
# code_python costs ~17 min per method for no extra resolution.
eval_samples() {
  case "$1" in
    c4_en|code_python) echo 4000 ;;
    *)                 echo 0 ;;
  esac
}

FAILED=""

prepare() {
  local TASK="$1"
  local DIR SPLIT LEN
  DIR="${ROOT}/${TASK}"
  SPLIT="$(cal_split "${TASK}")"
  LEN="$(max_length "${TASK}")"
  mkdir -p "${DIR}"

  if [[ -f "${DIR}/calibration/channel_calibration.csv" ]]; then
    echo "[1/5] reusing existing calibration"
  else
    echo "[1/5] calibration"
    python calibrate_channels.py \
      --task "${TASK}" --model-path "${MODEL_PATH}" \
      ${SPLIT:+--split "${SPLIT}"} \
      --candidate-mode all --max-length "${LEN}" \
      --max-samples "$(cal_samples "${TASK}")" --batch-size "${CAL_BATCH}" \
      --thresholds "${THRESHOLDS}" --target "${TARGET}" --activation-dtype "${ACT_DTYPE}" \
      --output-dir "${DIR}/calibration" || return 1
  fi

  echo "[2/5] range plan"
  python build_range_plan.py \
    --channel-calibration "${DIR}/calibration/channel_calibration.csv" \
    --base-radii 5,20 --wide-candidates "${WIDE_CANDIDATES}" \
    --margin "${MARGIN}" --output-dir "${DIR}/plan" || return 1

  echo "[3/5] profiles"
  python generate_method_profiles.py --range-plan "${DIR}/plan/range_plan.json" \
    --spa-target-errors "${SPA_TARGETS}" --spa-max-blocks "${SPA_MAX_BLOCKS}" \
    --eval-dtype "${ACT_DTYPE}" --nexus-gate-power "${NEXUS_GATE_POWER}" \
    --target "${TARGET}" \
    --output "${DIR}/profile_catalog.json" || return 1

  echo "[4/5] audit"
  python audit_profile_catalog.py --range-plan "${DIR}/plan/range_plan.json" \
    --profile-catalog "${DIR}/profile_catalog.json" \
    --output "${DIR}/profile_audit.json" || return 1

  echo "[5/5] smoke test (${SMOKE_SAMPLES} examples)"
  python eval_methods.py \
    --task "${TASK}" --model-path "${MODEL_PATH}" \
    --range-plan "${DIR}/plan/range_plan.json" \
    --profile-catalog "${DIR}/profile_catalog.json" \
    --methods default --max-samples "${SMOKE_SAMPLES}" \
    --max-length "${LEN}" --batch-size "${EVAL_BATCH}" \
    --compile-activation "${COMPILE}" --shared-prompt "${SHARED_PROMPT}" \
    --activation-dtype "${ACT_DTYPE}" --target "${TARGET}" ${TARGET_SKIP:+--skip-methods "${TARGET_SKIP}"} \
    --max-batch-tokens "${MAX_BATCH_TOKENS}" \
    --verify-compile --output-dir "${DIR}/smoke" || return 1
}

evaluate() {
  local TASK="$1"
  local DIR
  DIR="${ROOT}/${TASK}"
  python eval_methods.py \
    --task "${TASK}" --model-path "${MODEL_PATH}" \
    --range-plan "${DIR}/plan/range_plan.json" \
    --profile-catalog "${DIR}/profile_catalog.json" \
    --methods default --max-samples "$(eval_samples "${TASK}")" \
    --max-length "$(max_length "${TASK}")" --batch-size "${EVAL_BATCH}" \
    --compile-activation "${COMPILE}" --shared-prompt "${SHARED_PROMPT}" \
    --activation-dtype "${ACT_DTYPE}" --target "${TARGET}" ${TARGET_SKIP:+--skip-methods "${TARGET_SKIP}"} \
    --max-batch-tokens "${MAX_BATCH_TOKENS}" \
    --output-dir "${DIR}/full" || return 1
}

for TASK in ${TASKS}; do
  echo
  echo "################ ${TASK}: prepare ################"
  if ! prepare "${TASK}"; then
    echo "!!! ${TASK} failed during preparation; continuing"
    FAILED="${FAILED} ${TASK}"
  fi
done

if [[ -z "${SMOKE_ONLY}" ]]; then
  for TASK in ${TASKS}; do
    case " ${FAILED} " in *" ${TASK} "*) continue ;; esac
    echo
    echo "################ ${TASK}: full evaluation ################"
    if ! evaluate "${TASK}"; then
      echo "!!! ${TASK} failed during evaluation; continuing"
      FAILED="${FAILED} ${TASK}"
    fi
  done

  echo
  echo "################ pooled analysis ################"
  python pool_results.py --results "${ROOT}" \
    --tasks ${MAIN_TASKS} --bonferroni --output "${ROOT}/pooled_main.csv"
  echo
  echo "################ appendix ################"
  python pool_results.py --results "${ROOT}" \
    --tasks ${MAIN_TASKS} ${APPENDIX_TASKS} --bonferroni \
    --output "${ROOT}/pooled_all.csv"
  echo
  echo "################ paper tables ################"
  python export_paper_tables.py --results "${ROOT}" --tasks ${MAIN_TASKS} \
    --output-prefix "${ROOT}/paper_main"
  python export_paper_tables.py --results "${ROOT}" --tasks ${MAIN_TASKS} ${APPENDIX_TASKS} \
    --output-prefix "${ROOT}/paper_all" > /dev/null
  echo "saved: ${ROOT}/paper_all_mcq.csv, ${ROOT}/paper_all_lm.csv, ${ROOT}/paper_all.md"
fi

if [[ -n "${FAILED}" ]]; then
  echo
  echo "Tasks that failed:${FAILED}"
  echo "Re-run one with:  TASKS=\"<task>\" bash run_all_tasks.sh"
  echo "If the cause is a Hub loading script, pass --hf-source repo[:config]."
fi
