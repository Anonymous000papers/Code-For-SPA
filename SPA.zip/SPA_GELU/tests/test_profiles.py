"""Offline checks for the GELU profile catalog machinery.

Runs without a GPU. torch is optional: when it is importable the numpy
and torch evaluation paths are compared, otherwise that group is skipped.

    python tests/test_profiles.py
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from activation_approximations import (  # noqa: E402
    F4_COEFFICIENTS,
    G4_COEFFICIENTS,
    chebval,
    cheon_kim_park_extension,
    ckk20_sign,
    evaluate_profile,
    odd_polynomial,
)
from profile_math import (  # noqa: E402
    EUSTON_RELEASED_DELTA,
    EUSTON_SIGN,
    NEXUS_MIDDLE_COEFFICIENTS,
    NEXUS_RELEASED_DELTA,
    NEXUS_SIGN,
    build_euston_profile,
    build_nexus_profile,
    error_summary,
    euston_spec,
    euston_squarings,
    evaluate_spec,
    fit_direct_minimax,
    fit_spa_minimax,
    gelu,
    nexus_gate_power,
    nexus_spec,
    spa_ps_cost,
    select_moai_profile,
    select_sign_depth,
    sigmoid_gelu,
    sign_band_half_width,
    tanh_factor,
)


def check(name: str, condition: bool, detail: str = "") -> None:
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {name}" + (f"  {detail}" if detail else ""))
    if not condition:
        raise AssertionError(name)


# --------------------------------------------------------------------------
# primitives
# --------------------------------------------------------------------------


def test_chebval_matches_numpy() -> None:
    from numpy.polynomial.chebyshev import chebval as np_chebval

    rng = np.random.default_rng(0)
    for degree in (0, 1, 7, 31):
        coefficients = list(rng.normal(size=degree + 1))
        t = np.linspace(-1.0, 1.0, 2001)
        ours = chebval(t, coefficients)
        check(
            f"chebval degree {degree} matches numpy",
            np.allclose(ours, np_chebval(t, coefficients), rtol=0, atol=1e-11),
        )


def test_ckk20_sign_constants_and_saturation() -> None:
    check("f4(1) = 1 exactly", odd_polynomial(np.array([1.0]), F4_COEFFICIENTS)[0] == 1.0)
    check("g4 coefficients are the CKK20 ones", abs(G4_COEFFICIENTS[0] - 5850 / 1024) < 1e-15)
    y = np.linspace(-1.0, 1.0, 20001)
    s = ckk20_sign(y, 2, 2, 1.0)
    check("sign is odd", np.allclose(s, -s[::-1], atol=1e-12))
    check("sign stays within [-1, 1] (+tolerance)", float(np.max(np.abs(s))) <= 1.0 + 1e-9)
    band = sign_band_half_width(2, 2)
    outside = np.abs(y) >= band * (1 + 1e-6)
    check(
        "band half-width bounds the non-saturated region",
        float(np.max(np.abs(np.abs(s[outside]) - 1.0))) <= 1e-3 + 1e-12,
    )
    check(
        "deeper compositions narrow the band",
        sign_band_half_width(3, 3) < sign_band_half_width(2, 2) and sign_band_half_width(4, 4) < sign_band_half_width(3, 3),
    )


def test_cheon_kim_park_extension() -> None:
    base, stages = 6.0, 4
    covered = base * 1.5**stages
    x = np.linspace(-covered, covered, 100001)
    y = cheon_kim_park_extension(x, base, stages)
    check("extension maps the covered interval into the base interval", float(np.max(np.abs(y))) <= base + 1e-9)
    check("extension is monotone", bool(np.all(np.diff(y) >= -1e-12)))
    # Each stage distorts by 4 y^3 / (27 S^2); at |x| <= 1 with B = 6 the
    # four stages add up to about 7e-3. This distortion, not the fit, is
    # what limits MOAI's accuracy once extension stages are needed.
    small = np.linspace(-1.0, 1.0, 101)
    distortion = float(np.max(np.abs(cheon_kim_park_extension(small, base, stages) - small)))
    check("extension is near-identity near the origin", distortion < 1e-2, f"{distortion:.2e}")
    check("zero stages is the identity", np.array_equal(cheon_kim_park_extension(x, base, 0), x))


# --------------------------------------------------------------------------
# target and SPA
# --------------------------------------------------------------------------


def test_gelu_targets() -> None:
    x = np.linspace(-8.0, 8.0, 1601)
    check("GELU is complementary-gated: GELU(x) - GELU(-x) = x", np.allclose(gelu(x) - gelu(-x), x, atol=1e-12))
    check("GELU(0) = 0 and GELU(3) ~ 3", gelu(np.array([0.0]))[0] == 0.0 and abs(gelu(np.array([3.0]))[0] - 3.0) < 5e-3)
    gap = float(np.max(np.abs(sigmoid_gelu(x) - gelu(x))))
    check("sigmoid-GELU differs from tanh-GELU by about 0.02", 0.015 < gap < 0.025, f"gap={gap:.4f}")
    check("tanh factor is odd and bounded", np.allclose(tanh_factor(x), -tanh_factor(-x)) and float(np.max(np.abs(tanh_factor(x)))) <= 1.0)


def test_spa_fit_and_identity() -> None:
    radius = 20.0
    coefficients, lp_error = fit_spa_minimax(radius, 23)
    spec = {"kind": "spa", "operating_radius": radius, "coefficients": [float(c) for c in coefficients]}
    metrics = evaluate_spec(spec, radius)
    check("SPA k=23 at R=20 reaches ~5e-3", metrics["max_abs_error"] < 6e-3, f"{metrics['max_abs_error']:.3e}")
    check("LP error is close to the validated error", abs(lp_error - metrics["max_abs_error"]) < 0.5 * metrics["max_abs_error"])
    x = np.linspace(-radius, radius, 20001)
    value = evaluate_profile(spec, x)
    reflected = evaluate_profile(spec, -x)
    check("SPA reflection identity holds exactly", float(np.max(np.abs((value - reflected) - x))) < 5e-12)
    # no-loss theorem: a direct degree-2k minimax fit of GELU matches the
    # square-domain degree-k fit.
    direct, direct_error = fit_direct_minimax(gelu, 24, -5.0, 5.0)
    spa_coefficients, _ = fit_spa_minimax(5.0, 12)
    spa_error = evaluate_spec({"kind": "spa", "operating_radius": 5.0, "coefficients": list(spa_coefficients)}, 5.0)["max_abs_error"]
    check(
        "direct degree-24 and SPA k=12 agree (no-loss theorem)",
        abs(direct_error - spa_error) < 0.05 * max(direct_error, spa_error),
        f"direct={direct_error:.3e} spa={spa_error:.3e}",
    )


def test_spa_ps_cost() -> None:
    cost = spa_ps_cost(7, 4)
    check("PS cost k=7 s=4: 2 blocks", cost["ps_blocks"] == 2)
    check("PS cost k=7 s=4: ct-ct mults = s + B + ceil(log2 B) - 2 = 5", cost["ps_ctct_mults"] == 5)
    check("PS cost k=7 s=4: depth = 2 + 2 + ceil(log2 3) = 6", cost["ps_depth_raw_input"] == 6)
    single = spa_ps_cost(3, 4)
    check("single block: ct-ct mults = k, eta = ceil(log2 k)", single["ps_ctct_mults"] == 3 and single["ps_depth_raw_input"] == 2 + 2 + 1)


# --------------------------------------------------------------------------
# baselines: reconstructions against independent formulas
# --------------------------------------------------------------------------


def reference_nexus(x: np.ndarray) -> np.ndarray:
    """Literal transcription of NEXUS src/gelu.cpp (delta 1/8.5, (2,2))."""

    def poly(v, c):
        return v * (c[0] + v * v * (c[1] + v * v * (c[2] + v * v * (c[3] + v * v * c[4]))))

    def sgn(v):
        for _ in range(2):
            v = poly(v, G4_COEFFICIENTS)
        for _ in range(2):
            v = poly(v, F4_COEFFICIENTS)
        return 0.5 * v

    b0 = sgn((x + 3.5) / 8.5)
    b1 = sgn((x - 3.5) / 8.5)
    a = NEXUS_MIDDLE_COEFFICIENTS
    ax = a[0] + a[1] * x + a[2] * x**2 + a[3] * x**4 + a[4] * x**6 + a[5] * x**8 + a[6] * x**10 + a[7] * x**12
    return ax * (b0 - b1) + x * (b1 + 0.5)


def test_nexus_reconstruction() -> None:
    x = np.linspace(-5.0, 5.0, 20001)
    spec = nexus_spec(5.0, *NEXUS_SIGN)
    check("nexus spec at R=5 has the released normaliser", spec["delta"] == NEXUS_RELEASED_DELTA)
    check(
        "nexus evaluator matches a literal transcription of the released code",
        float(np.max(np.abs(evaluate_profile(spec, x) - reference_nexus(x)))) < 1e-10,
    )
    err = evaluate_spec(spec, 5.0)["max_abs_error"]
    check("released NEXUS is accurate to ~4e-4 on [-5, 5]", err < 6e-4, f"{err:.3e}")
    # Gate sharpening preserves the partition of unity across the +3.5 band.
    band = np.linspace(3.0, 4.0, 2001)
    for power in (2, 3):
        plain = nexus_spec(20.0, 3, 2, 1)
        sharp = nexus_spec(20.0, 3, 2, power)
        check(
            f"gate power {power} does not open a dip at the breakpoint",
            float(np.max(np.abs(evaluate_profile(sharp, band) - evaluate_profile(plain, band)))) < 2e-3,
        )
    check("gate power 1 at R=5 in float32 (released code)", nexus_gate_power(5.0, "float32")[0] == 1)
    check("gate power rises with the radius", nexus_gate_power(20.0, "float32", 3, 2)[0] >= 2 and nexus_gate_power(64.0, "float32", 3, 3)[0] >= 3)
    # In float64 the ulp is negligible but the composition's own residual
    # at |y| = 1 (1.3e-11 for (3, 2)) still leaks 3e-2 at R = 20.
    check("intrinsic residual also forces sharpening in float64", nexus_gate_power(20.0, "float64", 3, 2)[0] == 2)
    check("a deep sign needs no sharpening in float64", nexus_gate_power(20.0, "float64", 4, 4)[0] == 1)


def reference_euston(x: np.ndarray) -> np.ndarray:
    """Literal transcription of Euston's gelu.cpp / func_main.cpp for [-5, 5]."""
    from profile_math import EUSTON_EXP_COEFFICIENTS

    def poly(v, c):
        return v * (c[0] + v * v * (c[1] + v * v * (c[2] + v * v * (c[3] + v * v * c[4]))))

    def sgn(v):
        for _ in range(3):
            v = poly(v, G4_COEFFICIENTS)
        for _ in range(3):
            v = poly(v, F4_COEFFICIENTS)
        return v

    def exp_neg(y):
        z = y / 2.0
        p = sum(c * z**i for i, c in enumerate(EUSTON_EXP_COEFFICIENTS))
        return p * p

    def inverse(v):
        y = 1.0 - v
        res = 2.0 - v
        for _ in range(3):
            y = y * y
            res = res * (1.0 + y)
        return res

    s = sgn(x / 6.0)
    a = x * s
    z = a * inverse(1.0 + exp_neg(-1.702 * a))
    return z * (s * exp_neg((1.702 / 2.0) * a * (s - 1.0)))


def test_euston_reconstruction() -> None:
    x = np.linspace(-5.0, 5.0, 20001)
    spec = euston_spec(5.0, *EUSTON_SIGN)
    check("euston spec at R=5 has the released normaliser and one squaring", spec["delta"] == EUSTON_RELEASED_DELTA and spec["exp_squarings"] == 1)
    check(
        "euston evaluator matches a literal transcription of the released code",
        float(np.max(np.abs(evaluate_profile(spec, x) - reference_euston(x)))) < 1e-9,
    )
    own = evaluate_spec(spec, 5.0, target=sigmoid_gelu)["max_abs_error"]
    check("Euston approximates its own sigmoid target well on [-5, 5]", own < 1e-2, f"{own:.3e}")
    check("squarings keep the exp argument in the fitted interval", all(1.702 * r / 2 ** euston_squarings(r) <= 5.0 + 1e-9 for r in (5.0, 20.0, 64.0, 128.0)))


def test_sign_depth_rule() -> None:
    (dg, df), record = select_sign_depth(NEXUS_RELEASED_DELTA, NEXUS_RELEASED_DELTA, NEXUS_SIGN)
    check("the released normaliser keeps the released depth", (dg, df) == NEXUS_SIGN)
    (dg, df), record = select_sign_depth(67.5, NEXUS_RELEASED_DELTA, NEXUS_SIGN)
    check("a wider normaliser costs compositions", dg + df > sum(NEXUS_SIGN))
    check(
        "chosen depth respects the released band width in x",
        record["band_half_width_x"] <= record["released_band_half_width_x"] * (1 + 1e-9),
    )
    cheaper = [t for t in record["trials"] if t["total"] < dg + df]
    check("no cheaper depth satisfies the budget", all(t["band_half_width_x"] > record["released_band_half_width_x"] for t in cheaper))


def test_adapted_baselines_are_finite_and_accurate() -> None:
    for radius in (20.0, 64.0):
        nexus = build_nexus_profile(radius, "float32")
        summary = error_summary(nexus, radius, "float32", points=100001)
        check(
            f"adapted NEXUS at R={radius:g} keeps the released accuracy in float32",
            summary["max_abs_error_float32"] < 1e-3 and summary["nonfinite_points_float32"] == 0,
            f"{summary['max_abs_error_float32']:.3e}",
        )
        euston = build_euston_profile(radius)
        summary = error_summary(euston, radius, "float32", points=100001)
        check(f"adapted Euston at R={radius:g} is finite in float32", summary["nonfinite_points_float32"] == 0)
        check(
            f"adapted Euston at R={radius:g} carries the sigmoid-form floor",
            summary["max_abs_error"] >= 0.02,
            f"{summary['max_abs_error']:.3e}",
        )


def test_moai_selection() -> None:
    spec, trials = select_moai_profile(20.0, "float32", base_candidates=(5.0, 7.0, 20.0), points=50001)
    check("MOAI degree is 23", spec["degree"] == 23 and len(spec["coefficients"]) == 24)
    check("MOAI extension covers the radius", spec["covered_radius"] >= 20.0 - 1e-9)
    check("MOAI picks the smallest error among the trials", spec_error(spec) <= min(t["max_abs_error"] for t in trials) * 1.02)
    direct = [t for t in trials if t["base_radius"] == 20.0][0]
    extended = [t for t in trials if t["base_radius"] == 7.0][0]
    check(
        "extension beats a direct degree-23 fit on [-20, 20]",
        extended["max_abs_error"] < 0.2 * direct["max_abs_error"],
        f"direct={direct['max_abs_error']:.3e} extended={extended['max_abs_error']:.3e}",
    )


def spec_error(spec: dict) -> float:
    return evaluate_spec(spec, 20.0, points=50001)["max_abs_error"]


# --------------------------------------------------------------------------
# numpy / torch equivalence
# --------------------------------------------------------------------------


def test_numpy_torch_equivalence() -> None:
    try:
        import torch
    except ImportError:
        print("[SKIP] torch not importable; numpy/torch equivalence not checked")
        return
    x = np.linspace(-20.0, 20.0, 4001)
    specs = {
        "spa": {"kind": "spa", "operating_radius": 20.0, "coefficients": list(fit_spa_minimax(20.0, 15)[0])},
        "nexus": build_nexus_profile(20.0, "float64"),
        "euston": build_euston_profile(20.0),
        "moai": select_moai_profile(20.0, "float64", base_candidates=(7.0,), points=20001)[0],
    }
    for kind, spec in specs.items():
        numpy_value = evaluate_profile(spec, x)
        torch_value = evaluate_profile(spec, torch.tensor(x, dtype=torch.float64)).numpy()
        check(f"{kind}: torch float64 matches numpy", np.allclose(numpy_value, torch_value, rtol=0, atol=1e-12))
        torch32 = evaluate_profile(spec, torch.tensor(x, dtype=torch.float32))
        check(f"{kind}: torch float32 input stays float32", torch32.dtype == torch.float32)


def test_erf_target_switch() -> None:
    """--target erf: fits and errors refer to the exact erf-GELU."""
    import profile_math
    from scipy.special import erf as scipy_erf

    x = np.linspace(-8.0, 8.0, 3201)
    try:
        profile_math.set_activation_target("erf")
        check("target name follows the switch", "erf" in profile_math.target_name())
        check("gelu is the exact erf-GELU", np.allclose(profile_math.gelu(x), 0.5 * x * (1.0 + scipy_erf(x / np.sqrt(2.0))), atol=1e-14))
        check("the MOAI factor is erf(x/sqrt 2)", np.allclose(profile_math.activation_factor(x), scipy_erf(x / np.sqrt(2.0)), atol=1e-14))
        coefficients, _ = profile_math.fit_spa_minimax(5.0, 11)
        spec = {"kind": "spa", "operating_radius": 5.0, "coefficients": list(coefficients)}
        err = profile_math.evaluate_spec(spec, 5.0)["max_abs_error"]
        check("SPA R5 k11 refit reaches the ciphertext catalog's erf error", 6.0e-6 < err < 7.0e-6, f"{err:.3e}")
        nexus_err = profile_math.evaluate_spec(profile_math.nexus_spec(5.0, 2, 2, 1), 5.0)["max_abs_error"]
        check("released NEXUS graph measures ~6.9e-4 against erf-GELU", 6.5e-4 < nexus_err < 7.2e-4, f"{nexus_err:.3e}")
        moai_spec, _ = profile_math.select_moai_profile(5.0, "float32", base_candidates=(5.0,), points=20001)
        check("MOAI spec records its erf factor target", moai_spec["factor_target"] == "erf(x/sqrt(2))")
    finally:
        profile_math.set_activation_target("tanh")
    check("target restored to tanh", profile_math.activation_target() == "tanh")
    try:
        profile_math.set_activation_target("gelu-something")
    except ValueError:
        check("unknown target is rejected", True)
    else:
        check("unknown target is rejected", False)


def main() -> None:
    tests = [value for key, value in sorted(globals().items()) if key.startswith("test_")]
    for test in tests:
        test()
    print(f"\n{len(tests)} test groups passed")


if __name__ == "__main__":
    main()
