"""Offline checks for export_paper_tables.py and round_catalog_coefficients.py.

    python tests/test_paper_tables.py

Builds a tiny synthetic run (two multiple-choice tasks, one corpus) and a
catalog in a temporary directory; no GPU, torch or network.
"""

from __future__ import annotations

import csv
import json
import math
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import export_paper_tables as ept  # noqa: E402
import round_catalog_coefficients as rcc  # noqa: E402


def check(name: str, condition: bool, detail: str = "") -> None:
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {name}" + (f"  {detail}" if detail else ""))
    if not condition:
        raise AssertionError(name)


def write_mcq(path: Path, gold: list[int], preds: dict[str, list[int]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = ["index", "key", "gold", "n_choices"] + [f"{m}_{s}" for m in preds for s in ("pred", "pred_raw")]
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for i, g in enumerate(gold):
            row = {"index": i, "key": f"k{i}", "gold": g, "n_choices": 4}
            for m, values in preds.items():
                row[f"{m}_pred"] = values[i]
                row[f"{m}_pred_raw"] = values[i]
            writer.writerow(row)


def write_lm(path: Path, tokens: list[int], totals: dict[str, list[float]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = ["index", "key", "scored_tokens"] + [f"{m}_{s}" for m in totals for s in ("total_logprob", "nll_per_token")]
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for i, n in enumerate(tokens):
            row = {"index": i, "key": f"w{i}", "scored_tokens": n}
            for m, values in totals.items():
                row[f"{m}_total_logprob"] = values[i]
                row[f"{m}_nll_per_token"] = -values[i] / n if math.isfinite(values[i]) else "nan"
            writer.writerow(row)


def test_mcq_protocol() -> None:
    gold = [0, 1, 2, 3, 0, 1, 2, 3, 0, 1]
    native = [0, 1, 2, 3, 1, 2, 3, 0, 0, 1]  # 6 correct
    # method: two failures (-1), one of them where native was right; one
    # flip between two wrong answers (disagreement, but concordant).
    method = [0, 1, -1, 3, 2, 2, 3, 0, 0, -1]
    with tempfile.TemporaryDirectory() as tmp:
        run = Path(tmp) / "t1" / "full"
        write_mcq(run / "predictions.csv", gold, {"native": native, "m": method})
        gold_a, preds = ept.load_mcq(run / "predictions.csv")
        rows, carry = ept.mcq_rows_for_task("model", "t1", gold_a, preds, {}, "acc_norm", 500, 42)
    m = [r for r in rows if r["method"] == "m"][0]
    check("strict accuracy counts failures as wrong", abs(m["accuracy_strict"] - 4 / 10) < 1e-12, str(m["accuracy_strict"]))
    check("delta is in percentage points", abs(m["delta_accuracy_pp"] - (-20.0)) < 1e-9)
    check("invalid fraction", abs(m["invalid_fraction"] - 0.2) < 1e-12)
    # disagreements: positions 2 (invalid), 4 (1 vs 2), 9 (invalid) -> 3/10
    check("disagreement counts failures and wrong-vs-wrong flips", abs(m["prediction_disagreement_rate"] - 0.3) < 1e-12)
    check("b = native right, method wrong", m["mcnemar_b"] == 2)   # positions 2 and 9
    check("c = native wrong, method right", m["mcnemar_c"] == 0)
    check("discordant is b + c, smaller than disagreements", m["mcnemar_discordant"] == 2 < 3)
    check("interval brackets the point estimate", m["delta_accuracy_ci95_low"] <= m["delta_accuracy_pp"] <= m["delta_accuracy_ci95_high"])
    check("normalization unit follows the task's rule", "bytes" in m["normalization_unit"])


def test_pooled_and_macro_differ() -> None:
    per_task = {}
    for task, count, native_rate, method_rate in (("big", 1000, 0.6, 0.6), ("small", 100, 0.6, 0.5)):
        rng = np.random.default_rng(1)
        gold = np.zeros(count, dtype=int)
        native = np.where(rng.random(count) < native_rate, 0, 1)
        method = np.where(rng.random(count) < method_rate, 0, 1)
        _, carry = ept.mcq_rows_for_task("model", task, gold, {"native": native, "m": method}, {}, "acc", 300, 42)
        per_task[task] = carry
    rows = ept.aggregate_rows("model", per_task, 300, 42)
    pooled = [r for r in rows if r["scope"] == "POOLED" and r["method"] == "m"][0]
    macro = [r for r in rows if r["scope"] == "MACRO" and r["method"] == "m"][0]
    task_deltas = {t: per_task[t]["m"]["delta"] for t in per_task}
    check("pooled is sample weighted", abs(pooled["delta_accuracy_pp"] - (1000 * task_deltas["big"] + 100 * task_deltas["small"]) / 1100) < 1e-9)
    check("macro is the equal-weighted mean", abs(macro["delta_accuracy_pp"] - np.mean(list(task_deltas.values()))) < 1e-9)
    check("the two levels differ here", abs(pooled["delta_accuracy_pp"] - macro["delta_accuracy_pp"]) > 0.5)
    check("macro n_total is the number of tasks", macro["n_total"] == 2 and pooled["n_total"] == 1100)


def test_lm_protocol() -> None:
    tokens = [10, 1000, 500]
    native = [-30.0, -3000.0, -1500.0]
    complete = [-40.0, -2800.0, -1500.0]
    lossy = [-40.0, -2800.0, float("nan")]
    with tempfile.TemporaryDirectory() as tmp:
        run = Path(tmp) / "c" / "full"
        write_lm(run / "predictions.csv", tokens, {"native": native, "ok": complete, "lossy": lossy})
        toks, totals = ept.load_lm(run / "predictions.csv")
        rows = {r["method"]: r for r in ept.lm_rows_for_corpus("model", "c", toks, totals, {}, 500, 42)}
    ok, lossy_row = rows["ok"], rows["lossy"]
    expected = ((40 + 2800 + 1500) - (30 + 3000 + 1500)) / 1510
    check("delta is the corpus-level ratio of sums", abs(ok["delta_nll_per_token"] - expected) < 1e-12)
    check("delta PPL follows 100(exp(delta) - 1)", abs(ok["delta_ppl_pct"] - 100 * (math.exp(expected) - 1)) < 1e-9)
    check("complete method has a full-corpus NLL", ok["status"] == "complete" and math.isfinite(ok["nll_per_token"]))
    check("lossy method has no full-corpus value", lossy_row["status"].startswith("shared subset") and not math.isfinite(lossy_row["nll_per_token"]))
    shared_expected = ((40 + 2800) - (30 + 3000)) / 1010
    check("lossy delta is on the shared windows", abs(lossy_row["delta_nll_per_token"] - shared_expected) < 1e-12)
    check("shared tokens reported", lossy_row["tokens_shared"] == 1010 and lossy_row["windows_invalid"] == 1)


def test_rounding_derivation() -> None:
    rng = np.random.default_rng(0)
    coefficients = [0.5] + [float(v) for v in rng.normal(0, 1e-2, 11)]
    profile = {"id": "spa-r5-k11", "kind": "spa", "operating_radius": 5.0, "coefficients": coefficients, "degree_square": 11, "max_abs_error": 1e-4}
    catalog = {
        "format": "test",
        "target": "GELU (gelu_pytorch_tanh)",
        "range_plan_sha256": "abc",
        "methods": {
            "spa": [
                {"id": "spa-k7", "tier": "fast", "display_name": "SPA-k7", "target_max_error": 2.1e-2, "profiles": {"r5": "spa-r5-k11"}},
                {"id": "spa-k11", "tier": "balanced", "display_name": "SPA-k11", "target_max_error": 1e-3, "profiles": {"r5": "spa-r5-k11"}},
            ]
        },
        "profiles": {"spa-r5-k11": profile},
    }
    with tempfile.TemporaryDirectory() as tmp:
        src = Path(tmp) / "profile_catalog.json"
        out = Path(tmp) / "profile_catalog_rounding.json"
        src.write_text(json.dumps(catalog))
        result = subprocess.run(
            [sys.executable, str(ROOT / "round_catalog_coefficients.py"), "--profile-catalog", str(src), "--output", str(out), "--decimals", "1,3"],
            capture_output=True, text=True,
        )
        check("rounding script runs", result.returncode == 0, result.stderr[-400:])
        derived = json.loads(out.read_text())
    ids = [v["id"] for v in derived["methods"]["spa"]]
    check("balanced tier was picked and derived variants added", ids == ["spa-k7", "spa-k11", "spa-k11-d1", "spa-k11-d3"], str(ids))
    check("range plan hash is unchanged", derived["range_plan_sha256"] == "abc")
    d1 = derived["profiles"]["spa-r5-k11-d1"]
    d3 = derived["profiles"]["spa-r5-k11-d3"]
    check("coefficients are rounded, not refitted", d1["coefficients"] == [round(c, 1) for c in coefficients] and d3["coefficients"] == [round(c, 3) for c in coefficients])
    for d in (d1, d3):
        check(f"E_coeff <= l1 bound (d={d['rounding_decimals']})", d["coefficient_perturbation_max"] <= d["coefficient_l1_perturbation"] * (1 + 1e-9) + 1e-15)
    check("coarser rounding perturbs more", d1["coefficient_perturbation_max"] > d3["coefficient_perturbation_max"])
    check("degree and radius untouched", d1["degree_square"] == 11 and d1["operating_radius"] == 5.0)
    # bound tightness: with a single perturbed coefficient the bound is attained
    single = np.zeros(4); single[2] = 0.25
    t = np.linspace(-1, 1, 20001)
    check("bound is attained for a single-coefficient perturbation", abs(np.abs(rcc.chebval(t, single)).max() - 0.25) < 1e-9)
    labels = ept.catalog_labels(derived)
    check("exporter labels rounded variants by tier and decimals", labels["spa-k11-d3"][0] == "spa@0.001/d3" and labels["spa-k11"][0] == "spa@0.001")


def test_macro_streams_and_no_shared_windows() -> None:
    """Task streams are independent (two tasks of equal size must not get the
    same indices), stable under iteration order, shared across methods within
    a task; and an empty shared-window set is reported as missing, not zero."""
    a = ept.bootstrap_indices(100, 50, ept.mcq_task_seed(42, "task_a"))
    b = ept.bootstrap_indices(100, 50, ept.mcq_task_seed(42, "task_b"))
    a_again = ept.bootstrap_indices(100, 50, ept.mcq_task_seed(42, "task_a"))
    check("two tasks of equal size get different indices", not np.array_equal(a, b))
    check("a task's stream is reproducible", np.array_equal(a, a_again))
    check("the root seed still matters", not np.array_equal(a, ept.bootstrap_indices(100, 50, ept.mcq_task_seed(43, "task_a"))))
    gold = np.zeros(100, dtype=int)
    preds = {"native": np.zeros(100, dtype=int), "m1": np.zeros(100, dtype=int), "m2": np.ones(100, dtype=int)}
    _, carry = ept.mcq_rows_for_task("model", "task_a", gold, preds, {}, "acc", 50, 42)
    check("methods within a task share the paired indices", carry["m1"]["replicates"].shape == carry["m2"]["replicates"].shape)

    tokens = [10, 20]
    native = [-30.0, -60.0]
    lossy = [float("nan"), float("nan")]
    with tempfile.TemporaryDirectory() as tmp:
        run = Path(tmp) / "c" / "full"
        write_lm(run / "predictions.csv", tokens, {"native": native, "lossy": lossy})
        toks, totals = ept.load_lm(run / "predictions.csv")
        rows = {r["method"]: r for r in ept.lm_rows_for_corpus("model", "c", toks, totals, {}, 100, 42)}
    check("no shared windows -> status no_shared", rows["lossy"]["status"] == "no_shared")
    check("no shared windows -> delta is missing, not zero", math.isnan(rows["lossy"]["delta_nll_per_token"]))
    markdown = ept.render_markdown([], list(rows.values()))
    check("markdown states the missing comparison", "no shared windows" in markdown)
    check("reference row still reads reference", "| reference |" in markdown or "reference" in markdown)


def test_erf_target_groups_and_secondary_reference() -> None:
    """erf-target run: the reference id is native (Exact-erf), native-tanh is
    the original model, exact-tanh the same-precision control; every row gets
    Delta_erf (vs the reference) and Delta_native (vs native-tanh)."""
    rng = np.random.default_rng(5)
    n = 400
    gold = rng.integers(0, 4, n)
    erf = np.where(rng.random(n) < 0.6, gold, (gold + 1) % 4)          # Exact-erf: 60%
    tanh = erf.copy(); flip = rng.random(n) < 0.05; tanh[flip] = (tanh[flip] + 1) % 4   # Native-tanh differs on 5%
    exact_tanh = tanh.copy()                                             # bit-identical to native-tanh
    poly = erf.copy(); flip = rng.random(n) < 0.02; poly[flip] = (poly[flip] + 2) % 4   # a polynomial near Exact-erf
    preds = {"native": erf, "native-tanh": tanh, "exact-tanh": exact_tanh, "spa-k47": poly}
    metadata = {"task_kind": "mcq", "primary_metric": "acc_norm", "model": "/x/google_gemma-4-E2B-it",
                "activation_target": "erf",
                "group_names": {"native": "Exact-erf", "native-tanh": "Native-tanh", "exact-tanh": "Exact-tanh"}}
    catalog = {"methods": {"spa": [{"id": "spa-k47", "target_max_error": 1e-3, "degree_schedule": "r5:k11;r20:k31;wide:k47"}]}}
    labels = ept.catalog_labels(catalog, metadata)
    check("group labels come from the run metadata", labels["native"][0] == "Exact-erf" and labels["native-tanh"][0] == "Native-tanh")
    rows, carry = ept.mcq_rows_for_task("gemma", "t", gold, preds, labels, "acc_norm", 300, 42, secondary_reference="native-tanh")
    by = {r["method"]: r for r in rows}
    check("reference row is labelled Exact-erf and flagged", by["Exact-erf"]["_is_reference"] and by["Exact-erf"]["delta_accuracy_pp"] == 0.0)
    check("Exact-erf vs Native-tanh is reported (the substitution's own effect)",
          abs(by["Exact-erf"]["delta_accuracy_pp_vs_secondary"] - 100 * ((erf == gold).mean() - (tanh == gold).mean())) < 1e-12)
    check("Native-tanh vs itself is zero", by["Native-tanh"]["delta_accuracy_pp_vs_secondary"] == 0.0
          and by["Native-tanh"]["delta_accuracy_vs_secondary_ci95_low"] == 0.0)
    check("Exact-tanh equals Native-tanh (numerical path is neutral)",
          by["Exact-tanh"]["delta_accuracy_pp_vs_secondary"] == 0.0 and by["Exact-tanh"]["prediction_disagreement_rate_vs_secondary"] == 0.0)
    d_erf = by["spa@0.001"]["delta_accuracy_pp"]; d_nat = by["spa@0.001"]["delta_accuracy_pp_vs_secondary"]
    check("polynomial row carries both deltas", abs(d_erf - 100 * ((poly == gold).mean() - (erf == gold).mean())) < 1e-12
          and abs(d_nat - 100 * ((poly == gold).mean() - (tanh == gold).mean())) < 1e-12)
    check("secondary intervals bracket the point estimate",
          by["spa@0.001"]["delta_accuracy_vs_secondary_ci95_low"] <= d_nat <= by["spa@0.001"]["delta_accuracy_vs_secondary_ci95_high"])
    agg = ept.aggregate_rows("gemma", {"t": carry, "u": carry}, 300, 42)
    pooled = [r for r in agg if r["scope"] == "POOLED" and r["method"] == "spa@0.001"][0]
    check("pooled rows carry the secondary delta too", abs(pooled["delta_accuracy_pp_vs_secondary"] - d_nat) < 1e-9)
    md = ept.render_markdown(rows + agg, [])
    check("markdown names both references", "vs Exact-erf" in md and "vs Native-tanh" in md)

    # LM: both deltas per corpus
    tokens = [100, 200, 150]
    totals = {"native": [-300.0, -620.0, -450.0], "native-tanh": [-310.0, -600.0, -455.0], "spa-k47": [-301.0, -621.0, -452.0]}
    with tempfile.TemporaryDirectory() as tmp:
        run = Path(tmp) / "c" / "full"
        write_lm(run / "predictions.csv", tokens, totals)
        toks, tot = ept.load_lm(run / "predictions.csv")
        lm = {r["method"]: r for r in ept.lm_rows_for_corpus("gemma", "c", toks, tot, labels, 300, 42, secondary_reference="native-tanh")}
    expected = ((301 + 621 + 452) - (310 + 600 + 455)) / 450
    check("LM secondary delta is corpus-level vs Native-tanh", abs(lm["spa@0.001"]["delta_nll_per_token_vs_secondary"] - expected) < 1e-12)
    check("Exact-erf vs Native-tanh NLL delta is present",
          abs(lm["Exact-erf"]["delta_nll_per_token_vs_secondary"] - (((300 + 620 + 450) - (310 + 600 + 455)) / 450)) < 1e-12)


def main() -> None:
    tests = [value for key, value in sorted(globals().items()) if key.startswith("test_")]
    for test in tests:
        test()
    print(f"\n{len(tests)} test groups passed")


if __name__ == "__main__":
    main()
