"""Regression tests that need a real torch (CPU is enough, no GPU).

    python tests/test_torch_paths.py

Each group pins a scoring or activation-swap invariant:

* ``NaN * 0`` in the scoring reduction let a NaN at an unscored position
  contaminate a sequence's total;
* the finiteness audit ran before the cast back to bf16;
* padded positions ran through the polynomial and, when it diverged,
  poisoned the real tokens of the sequence through attention;
* a missing token mask silently widened the audit to the whole tensor.
"""

from __future__ import annotations

import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

try:
    import torch
except ImportError:  # pragma: no cover - exercised on machines without torch
    print("[SKIP] torch is not importable; tests/test_torch_paths.py needs it")
    sys.exit(0)

import numpy as np  # noqa: E402

from mcq_common import sequence_logprob  # noqa: E402


def check(name: str, condition: bool, detail: str = "") -> None:
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {name}" + (f"  {detail}" if detail else ""))
    if not condition:
        raise AssertionError(name)


def _eval_methods():
    """eval_methods imports transformers at module level; stub it so the
    activation classes can be tested on a CPU box without it."""
    import types

    if "transformers" not in sys.modules:
        stub = types.ModuleType("transformers")
        stub.AutoModelForCausalLM = object
        stub.AutoTokenizer = object
        sys.modules["transformers"] = stub
    if "tqdm.auto" not in sys.modules:
        tqdm_auto = types.ModuleType("tqdm.auto")
        tqdm_auto.tqdm = lambda *a, **k: None
        tqdm_mod = types.ModuleType("tqdm")
        tqdm_mod.auto = tqdm_auto
        sys.modules.setdefault("tqdm", tqdm_mod)
        sys.modules["tqdm.auto"] = tqdm_auto
    if "datasets" not in sys.modules:
        datasets = types.ModuleType("datasets")
        datasets.load_dataset = lambda *a, **k: None
        sys.modules["datasets"] = datasets
    import eval_methods

    return eval_methods


def test_scoring_selects_instead_of_multiplying() -> None:
    """Only the scored position carries -log(3); every other position's
    logits are NaN. The total must be -log(3), not NaN."""
    vocab = 3
    logits = torch.full((1, 4, vocab), float("nan"))
    logits[0, 1, :] = 0.0  # uniform: log-prob of any token is -log(3)
    labels = torch.full((1, 4), -100, dtype=torch.long)
    labels[0, 2] = 1  # scored by the logits at position 1
    for impl in ("logsoftmax", "cross_entropy"):
        total = sequence_logprob(logits, labels, chunk=2, impl=impl)
        check(
            f"{impl}: NaN at unscored positions does not contaminate the total",
            abs(float(total[0]) + math.log(3)) < 1e-6,
            f"{float(total[0])}",
        )
    # A NaN at a scored position is a real failure and must survive.
    logits[0, 1, :] = float("nan")
    total = sequence_logprob(logits, labels, chunk=2, impl="logsoftmax")
    check("a NaN at the scored position is kept", math.isnan(float(total[0])))


def _method_activation(em, profile_spec: dict, width: int, radius: float):
    profile = em.PolynomialProfile(profile_spec, compile_mode="off")
    plan = {"channel_ranges": ["r"] * width}
    return em.MethodActivation("test", plan, {"r": radius}, {"r": profile}, collect_stats=True)


def test_pad_positions_are_isolated() -> None:
    """A profile that diverges outside its interval must not emit NaN at
    padded positions, and the audit must see the real tokens only."""
    em = _eval_methods()
    em.set_activation_dtype("float32")
    # A NEXUS-style profile: CKK20 sign diverges for |x| > delta.
    from profile_math import nexus_spec

    spec = nexus_spec(5.0, 2, 2, 1)
    spec.update(domain_lo=-5.0, domain_hi=5.0)
    module = _method_activation(em, spec, width=4, radius=5.0)

    x = torch.zeros((1, 3, 4), dtype=torch.bfloat16)
    x[0, 0] = torch.tensor([1.0, -2.0, 3.0, 0.5])  # real
    x[0, 1] = torch.tensor([0.1, 0.2, -0.3, 4.0])  # real
    x[0, 2] = torch.tensor([200.0, -300.0, 150.0, 1e4])  # padding: far outside
    mask = torch.tensor([[1, 1, 0]])
    em.TOKEN_MASK.set(mask)
    out = module(x)
    em.TOKEN_MASK.set(None)

    check("output is finite everywhere, padding included", bool(torch.isfinite(out).all()))
    reference = torch.nn.functional.gelu(x.float(), approximate="tanh").to(torch.bfloat16)
    check("padded position carries the reference activation", torch.equal(out[0, 2], reference[0, 2]))
    check(
        "real positions carry the profile",
        bool((out[0, :2].float() - reference[0, :2].float()).abs().max() < 0.05),
    )
    stats = module.stats()
    check("padding is not counted as input", stats["activation_input_count"] == 2 * 4)
    check("padded positions are reported", stats["activation_padded_positions"] == 1 * 4)
    check("no range violation is charged to padding", stats["range_violation_count"] == 0)
    check("no non-finite output is charged to padding", stats["activation_nonfinite_count"] == 0)

    # Without a pad mask the same batch would have produced non-finite
    # values: confirm the profile really diverges there, so the test is
    # testing the isolation and not a benign input.
    raw = em.evaluate_profile(spec, x[0, 2].float())
    check("the profile itself is non-finite on the padded input", not bool(torch.isfinite(raw).all()))


def test_nonfinite_audit_runs_after_the_cast() -> None:
    """A value finite in float32 but above bf16's range is inf downstream;
    the audit must count it."""
    em = _eval_methods()
    em.set_activation_dtype("float32")
    spec = {
        "kind": "spa",
        "operating_radius": 1.0,
        "coefficients": [3.4e38, 0.0],  # constant 3.4e38 + x/2: finite in fp32, above bf16 max
        "domain_lo": -1.0,
        "domain_hi": 1.0,
    }
    module = _method_activation(em, spec, width=2, radius=1.0)
    x = torch.tensor([[[0.5, -0.5]]], dtype=torch.bfloat16)
    em.TOKEN_MASK.set(torch.tensor([[1]]))
    out = module(x)
    em.TOKEN_MASK.set(None)
    stats = module.stats()
    check("float32 value is finite", stats["activation_max_abs_finite_output_before_cast"] > 1e38)
    check("bf16 output is non-finite", not bool(torch.isfinite(out).all()))
    check("the audit counts the cast overflow", stats["activation_nonfinite_count"] == 2)
    check("overflow-on-cast is reported separately", stats["activation_cast_overflow_count"] == 2)


def test_missing_token_mask_raises() -> None:
    em = _eval_methods()
    em.TOKEN_MASK.set(None)
    z = torch.zeros((1, 2, 3))
    try:
        em.TOKEN_MASK.valid_for(z)
    except RuntimeError:
        check("missing token mask raises", True)
    else:
        check("missing token mask raises", False)
    em.TOKEN_MASK.set(torch.ones((2, 2)))
    try:
        em.TOKEN_MASK.valid_for(z)
    except RuntimeError:
        check("mismatched token mask raises", True)
    else:
        check("mismatched token mask raises", False)
    em.TOKEN_MASK.set(None)


def test_profiles_agree_between_numpy_and_torch() -> None:
    from activation_approximations import evaluate_profile
    from profile_math import build_euston_profile, build_nexus_profile, fit_spa_minimax, select_moai_profile

    x = np.linspace(-20.0, 20.0, 4001)
    specs = {
        "spa": {"kind": "spa", "operating_radius": 20.0, "coefficients": list(fit_spa_minimax(20.0, 15)[0])},
        "nexus": build_nexus_profile(20.0, "float64"),
        "euston": build_euston_profile(20.0),
        "moai": select_moai_profile(20.0, "float64", base_candidates=(7.0,), points=20001)[0],
    }
    for kind, spec in specs.items():
        numpy_value = evaluate_profile(spec, x)
        torch_value = evaluate_profile(spec, torch.tensor(x, dtype=torch.float64)).numpy()
        check(f"{kind}: torch float64 matches numpy", np.allclose(numpy_value, torch_value, rtol=0, atol=1e-12))


def main() -> None:
    tests = [value for key, value in sorted(globals().items()) if key.startswith("test_")]
    for test in tests:
        test()
    print(f"\n{len(tests)} test groups passed")


if __name__ == "__main__":
    main()
