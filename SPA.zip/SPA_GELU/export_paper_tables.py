"""Export the standardised paper tables from an existing run.

Post-processing only: nothing here re-runs a model or refits a profile.
The inputs are the per-example ``predictions.csv`` files, the per-task
``metadata.json`` and ``profile_catalog.json``.

    python export_paper_tables.py --results results/zeroshot \\
        --tasks wikitext2 c4_en hellaswag mmlu social_i_qa race_high \\
        --output-prefix results/zeroshot/paper_main

writes ``<prefix>_mcq.csv``, ``<prefix>_lm.csv`` and ``<prefix>.md``; when
the catalog carries coefficient-rounding variants (Experiment B,
``round_catalog_coefficients.py``) it also writes ``<prefix>_coefficients.csv``
with the per-range coefficient perturbation of each rounded profile.

Multiple-choice protocol
------------------------
For every model, task and method: ``n_total`` (fixed), ``accuracy_strict``
(method failures count as wrong), ``delta_accuracy_pp`` against native,
``invalid_fraction``, ``prediction_disagreement_rate`` (a failure is a
prediction that was not preserved and stays in the denominator) and a
paired bootstrap CI for the accuracy difference: the same resampled
indices are applied to both methods and the difference of the two strict
correctness means is recomputed (10,000 replicates, seed 42, percentile
interval). ``mcnemar_discordant`` is ``b + c`` and is kept as a separate
column; it is not the disagreement count, since two wrong answers that
differ are a disagreement but concordant. The task's own decision rule is
preserved (``primary_metric``, e.g. byte-normalised or raw score) and
recorded with its ``normalization_unit``.

Three levels are reported and labelled: per task (primary), ``POOLED``
(all examples of the listed tasks concatenated, i.e. sample weighted) and
``MACRO`` (equally weighted mean of the per-task changes; its interval is
the replicate-wise mean of the per-task bootstrap replicates). SPA ids
are rewritten to their tier label ``spa@<target>`` because the degree
that meets a target depends on the task's wide radius; the task-local id
and degree schedule are kept in ``config``.

Language-modelling protocol
---------------------------
With ``l[m, i]`` the total NLL of window ``i`` under method ``m``, ``n[i]``
its scored tokens and ``J[m]`` the windows valid under both native and
``m``: ``delta_nll = sum_{J} (l[m] - l[native]) / sum_{J} n`` and
``delta_ppl_pct = 100 (exp(delta_nll) - 1)``. The bootstrap resamples
windows and recomputes the ratio of sums. When a method lost windows, its
full-corpus NLL and PPL are printed as ``—†`` and the paired quantities
are labelled as shared-subset results; the number of windows lost and the
shared token count are reported. Effect sizes and intervals are the main
columns; verdict labels, MDE and bootstrap p-values stay in the raw
summaries.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path

import numpy as np

REFERENCE = "native"
NORMALIZATION_UNIT = {
    "acc": "none (summed log-probability)",
    "acc_norm": "bytes of the continuation",
    "acc_token_norm": "tokens of the continuation",
}

MCQ_FIELDS = [
    "model",
    "scope",
    "task",
    "method",
    "config",
    "primary_metric",
    "normalization_unit",
    "n_total",
    "accuracy_strict",
    "delta_accuracy_pp",
    "delta_accuracy_ci95_low",
    "delta_accuracy_ci95_high",
    "invalid_count",
    "invalid_fraction",
    "prediction_disagreement_rate",
    "mcnemar_b",
    "mcnemar_c",
    "mcnemar_discordant",
    "secondary_reference",
    "delta_accuracy_pp_vs_secondary",
    "delta_accuracy_vs_secondary_ci95_low",
    "delta_accuracy_vs_secondary_ci95_high",
    "prediction_disagreement_rate_vs_secondary",
]

COEFFICIENT_FIELDS = [
    "model",
    "task",
    "method",
    "variant_id",
    "derived_from",
    "rounding_decimals",
    "range_label",
    "radius",
    "degree_square",
    "nonzero_coefficients",
    "coefficient_l1_perturbation",
    "coefficient_perturbation_max",
    "max_abs_error",
    "max_abs_error_unrounded",
]

LM_FIELDS = [
    "model",
    "corpus",
    "method",
    "config",
    "windows_total",
    "windows_invalid",
    "windows_shared",
    "tokens_total",
    "tokens_shared",
    "nll_per_token",
    "perplexity",
    "nll_per_token_shared",
    "reference_nll_per_token_shared",
    "delta_nll_per_token",
    "delta_nll_ci95_low",
    "delta_nll_ci95_high",
    "delta_ppl_pct",
    "status",
    "secondary_reference",
    "delta_nll_per_token_vs_secondary",
    "delta_nll_vs_secondary_ci95_low",
    "delta_nll_vs_secondary_ci95_high",
    "delta_ppl_pct_vs_secondary",
    "windows_shared_vs_secondary",
]


# --------------------------------------------------------------------------
# loading
# --------------------------------------------------------------------------


def read_json(path: Path) -> dict:
    return json.loads(path.read_text()) if path.exists() else {}


def model_name(metadata: dict) -> str:
    model = str(metadata.get("model") or metadata.get("model_path") or "")
    return Path(model).name or "model"


def catalog_labels(catalog: dict, metadata: dict | None = None) -> dict[str, tuple[str, str]]:
    """method id -> (cross-task label, task-local config string).

    The reference run always has the id ``native``; under the erf target it
    computes the substituted erf-GELU, so the run's ``group_names`` metadata
    (Exact-erf / Native-tanh / Exact-tanh) is used for the labels."""
    labels: dict[str, tuple[str, str]] = {}
    for method_id, group in (metadata or {}).get("group_names", {}).items():
        labels[method_id] = (group, f"{method_id}: {group}")
    for variant in catalog.get("methods", {}).get("spa", []):
        label = f"spa@{float(variant['target_max_error']):g}"
        decimals = variant.get("rounding_decimals")
        if decimals is not None:
            label = f"{label}/d{decimals}"
        config = f"{variant['id']}: {variant.get('degree_schedule', '')}"
        labels[variant["id"]] = (label, config)
    for method_id in ("nexus", "moai", "euston", "orion", "ensi", "sylph", "thor"):
        spec = catalog.get("methods", {}).get(method_id)
        if isinstance(spec, dict):
            labels[method_id] = (method_id, f"{method_id}: {spec.get('degree_schedule', '')}")
    return labels


def coefficient_rows(model: str, task: str, catalog: dict, labels: dict[str, tuple[str, str]]) -> list[dict]:
    """Per-range coefficient perturbation of rounded SPA variants."""
    rows: list[dict] = []
    for variant in catalog.get("methods", {}).get("spa", []):
        if variant.get("rounding_decimals") is None:
            continue
        label, _ = labels.get(variant["id"], (variant["id"], variant["id"]))
        for range_label, profile_id in variant["profiles"].items():
            profile = catalog["profiles"][profile_id]
            rows.append(
                {
                    "model": model,
                    "task": task,
                    "method": label,
                    "variant_id": variant["id"],
                    "derived_from": variant.get("derived_from", ""),
                    "rounding_decimals": variant["rounding_decimals"],
                    "range_label": range_label,
                    "radius": profile.get("operating_radius"),
                    "degree_square": profile.get("degree_square"),
                    "nonzero_coefficients": profile.get("nonzero_coefficients"),
                    "coefficient_l1_perturbation": profile.get("coefficient_l1_perturbation"),
                    "coefficient_perturbation_max": profile.get("coefficient_perturbation_max"),
                    "max_abs_error": profile.get("max_abs_error"),
                    "max_abs_error_unrounded": profile.get("max_abs_error_unrounded"),
                }
            )
    return rows


def load_mcq(path: Path) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    rows = list(csv.DictReader(path.open()))
    gold = np.array([int(row["gold"]) for row in rows], dtype=np.int64)
    methods = [
        name[: -len("_pred")]
        for name in rows[0]
        if name.endswith("_pred") and not name.endswith("_pred_raw")
    ]
    predictions = {
        method: np.array([int(row[f"{method}_pred"]) for row in rows], dtype=np.int64)
        for method in methods
    }
    return gold, predictions


def load_lm(path: Path) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    rows = list(csv.DictReader(path.open()))
    tokens = np.array([float(row["scored_tokens"]) for row in rows])
    methods = [key[: -len("_total_logprob")] for key in rows[0] if key.endswith("_total_logprob")]
    totals = {
        method: np.array([float(row[f"{method}_total_logprob"] or "nan") for row in rows])
        for method in methods
    }
    return tokens, totals


# --------------------------------------------------------------------------
# statistics
# --------------------------------------------------------------------------


def mcq_task_seed(seed: int, task: str) -> np.random.SeedSequence:
    """Stable task-specific stream, independent of task iteration order.

    Every task gets its own stream, so the MACRO level (replicate-wise mean
    of per-task bootstrap deltas) averages independent resamples; with one
    shared seed, two tasks of equal size would receive identical indices
    and the MACRO interval would carry artificial cross-task correlation.
    Within a task all methods share the indices, which keeps the paired
    comparison against native."""
    if seed < 0 or not task:
        raise ValueError("seed must be nonnegative and task must be nonempty")
    digest = hashlib.sha256(("mcq-bootstrap-v1:" + task).encode("utf-8")).digest()
    task_key = [int.from_bytes(digest[i : i + 4], "little") for i in range(0, 16, 4)]
    return np.random.SeedSequence([*task_key, seed])


def bootstrap_indices(count: int, resamples: int, seed: "int | np.random.SeedSequence") -> np.ndarray:
    rng = np.random.default_rng(seed)
    return rng.integers(0, count, size=(resamples, count))


def paired_delta_replicates(method_correct: np.ndarray, reference_correct: np.ndarray, index: np.ndarray) -> np.ndarray:
    """Per-replicate difference of strict-correctness means, in pp."""
    difference = method_correct.astype(np.float64) - reference_correct.astype(np.float64)
    return 100.0 * difference[index].mean(axis=1)


def percentile_interval(replicates: np.ndarray, alpha: float = 0.05) -> tuple[float, float]:
    low, high = np.quantile(replicates, [alpha / 2.0, 1.0 - alpha / 2.0])
    return float(low), float(high)


def ratio_replicates(numerators: np.ndarray, denominators: np.ndarray, index: np.ndarray) -> np.ndarray:
    return numerators[index].sum(axis=1) / denominators[index].sum(axis=1)


# --------------------------------------------------------------------------
# multiple choice
# --------------------------------------------------------------------------


def mcq_rows_for_task(
    model: str,
    task: str,
    gold: np.ndarray,
    predictions: dict[str, np.ndarray],
    labels: dict[str, tuple[str, str]],
    primary_metric: str,
    resamples: int,
    seed: int,
    secondary_reference: str | None = None,
) -> tuple[list[dict], dict[str, dict]]:
    """Per-task rows plus the per-method indicator vectors and bootstrap
    replicates needed for the pooled and macro levels.

    ``secondary_reference`` adds a second paired delta for every method
    (same resampled indices), e.g. against the original tanh model in the
    erf-target experiment: Delta_native,m next to Delta_erf,m."""
    reference_pred = predictions[REFERENCE]
    reference_correct = reference_pred == gold
    count = gold.size
    index = bootstrap_indices(count, resamples, mcq_task_seed(seed, task))
    secondary_pred = predictions.get(secondary_reference) if secondary_reference else None
    if secondary_reference and secondary_pred is None:
        raise KeyError(f"{task}: secondary reference {secondary_reference!r} is not in the predictions")
    secondary_correct = (secondary_pred == gold) if secondary_pred is not None else None
    secondary_label = labels.get(secondary_reference, (secondary_reference, ""))[0] if secondary_reference else ""
    rows: list[dict] = []
    carry: dict[str, dict] = {}
    for method_id, pred in predictions.items():
        valid = pred >= 0
        correct = valid & (pred == gold)
        disagree = (~valid) | (pred != reference_pred)
        b = int((reference_correct & ~correct).sum())
        c = int((~reference_correct & correct).sum())
        replicates = paired_delta_replicates(correct, reference_correct, index)
        low, high = percentile_interval(replicates)
        label, config = labels.get(method_id, (method_id, method_id))
        delta = 100.0 * (correct.mean() - reference_correct.mean())
        secondary: dict = {}
        if secondary_correct is not None:
            reps2 = paired_delta_replicates(correct, secondary_correct, index)
            low2, high2 = percentile_interval(reps2)
            secondary = {
                "secondary_reference": secondary_label,
                "delta_accuracy_pp_vs_secondary": 100.0 * (correct.mean() - secondary_correct.mean()),
                "delta_accuracy_vs_secondary_ci95_low": 0.0 if method_id == secondary_reference else low2,
                "delta_accuracy_vs_secondary_ci95_high": 0.0 if method_id == secondary_reference else high2,
                "prediction_disagreement_rate_vs_secondary": float(((~valid) | (pred != secondary_pred)).mean()),
            }
        rows.append(
            {
                **secondary,
                "_is_reference": method_id == REFERENCE,
                "model": model,
                "scope": "task",
                "task": task,
                "method": label,
                "config": config,
                "primary_metric": primary_metric,
                "normalization_unit": NORMALIZATION_UNIT.get(primary_metric, primary_metric),
                "n_total": count,
                "accuracy_strict": float(correct.mean()),
                "delta_accuracy_pp": delta,
                "delta_accuracy_ci95_low": low if method_id != REFERENCE else 0.0,
                "delta_accuracy_ci95_high": high if method_id != REFERENCE else 0.0,
                "invalid_count": int((~valid).sum()),
                "invalid_fraction": float((~valid).mean()),
                "prediction_disagreement_rate": float(disagree.mean()),
                "mcnemar_b": b,
                "mcnemar_c": c,
                "mcnemar_discordant": b + c,
            }
        )
        carry[label] = {
            "correct": correct,
            "reference_correct": reference_correct,
            "valid": valid,
            "disagree": disagree,
            "replicates": replicates,
            "delta": delta,
            "config": config,
            "is_reference": method_id == REFERENCE,
            "is_secondary": method_id == secondary_reference,
            "secondary_correct": secondary_correct,
            "secondary_label": secondary_label,
            "secondary_replicates": (
                paired_delta_replicates(correct, secondary_correct, index) if secondary_correct is not None else None
            ),
            "secondary_disagree": (
                ((~valid) | (pred != secondary_pred)) if secondary_pred is not None else None
            ),
        }
    return rows, carry


def aggregate_rows(model: str, per_task: dict[str, dict[str, dict]], resamples: int, seed: int) -> list[dict]:
    """POOLED (sample weighted) and MACRO (task weighted) rows over the
    methods present in every listed task."""
    tasks = list(per_task)
    if len(tasks) < 2:
        return []
    common = set.intersection(*(set(per_task[task]) for task in tasks))
    ordered = [label for label in per_task[tasks[0]] if label in common]
    rows: list[dict] = []
    for label in ordered:
        pooled_correct = np.concatenate([per_task[task][label]["correct"] for task in tasks])
        pooled_reference = np.concatenate([per_task[task][label]["reference_correct"] for task in tasks])
        pooled_valid = np.concatenate([per_task[task][label]["valid"] for task in tasks])
        pooled_disagree = np.concatenate([per_task[task][label]["disagree"] for task in tasks])
        index = bootstrap_indices(pooled_correct.size, resamples, seed)
        replicates = paired_delta_replicates(pooled_correct, pooled_reference, index)
        low, high = percentile_interval(replicates)
        b = int((pooled_reference & ~pooled_correct).sum())
        c = int((~pooled_reference & pooled_correct).sum())
        is_reference = per_task[tasks[0]][label]["is_reference"]
        secondary_cols: dict = {}
        macro_secondary: dict = {}
        if per_task[tasks[0]][label]["secondary_correct"] is not None:
            is_secondary = per_task[tasks[0]][label]["is_secondary"]
            pooled_secondary = np.concatenate([per_task[task][label]["secondary_correct"] for task in tasks])
            pooled_secondary_disagree = np.concatenate([per_task[task][label]["secondary_disagree"] for task in tasks])
            reps2 = paired_delta_replicates(pooled_correct, pooled_secondary, index)
            low2, high2 = percentile_interval(reps2)
            secondary_cols = {
                "_is_reference": is_reference,
                "secondary_reference": per_task[tasks[0]][label]["secondary_label"],
                "delta_accuracy_pp_vs_secondary": 100.0 * (pooled_correct.mean() - pooled_secondary.mean()),
                "delta_accuracy_vs_secondary_ci95_low": 0.0 if is_secondary else low2,
                "delta_accuracy_vs_secondary_ci95_high": 0.0 if is_secondary else high2,
                "prediction_disagreement_rate_vs_secondary": float(pooled_secondary_disagree.mean()),
            }
            macro_reps2 = np.mean([per_task[task][label]["secondary_replicates"] for task in tasks], axis=0)
            mlow2, mhigh2 = percentile_interval(macro_reps2)
            macro_secondary = {
                "_is_reference": is_reference,
                "secondary_reference": per_task[tasks[0]][label]["secondary_label"],
                "delta_accuracy_pp_vs_secondary": float(np.mean([
                    100.0 * (per_task[task][label]["correct"].mean() - per_task[task][label]["secondary_correct"].mean())
                    for task in tasks
                ])),
                "delta_accuracy_vs_secondary_ci95_low": 0.0 if is_secondary else mlow2,
                "delta_accuracy_vs_secondary_ci95_high": 0.0 if is_secondary else mhigh2,
                "prediction_disagreement_rate_vs_secondary": float(np.mean([
                    per_task[task][label]["secondary_disagree"].mean() for task in tasks
                ])),
            }
        rows.append(
            {
                **secondary_cols,
                "_is_reference": is_reference,
                "model": model,
                "scope": "POOLED",
                "task": "+".join(tasks),
                "method": label,
                "config": "per-task configs differ; see task rows",
                "primary_metric": "per task",
                "normalization_unit": "per task",
                "n_total": int(pooled_correct.size),
                "accuracy_strict": float(pooled_correct.mean()),
                "delta_accuracy_pp": 100.0 * (pooled_correct.mean() - pooled_reference.mean()),
                "delta_accuracy_ci95_low": 0.0 if is_reference else low,
                "delta_accuracy_ci95_high": 0.0 if is_reference else high,
                "invalid_count": int((~pooled_valid).sum()),
                "invalid_fraction": float((~pooled_valid).mean()),
                "prediction_disagreement_rate": float(pooled_disagree.mean()),
                "mcnemar_b": b,
                "mcnemar_c": c,
                "mcnemar_discordant": b + c,
            }
        )
        # MACRO: equally weighted mean of per-task deltas; the interval is
        # the replicate-wise mean, which is a bootstrap of that mean under
        # independent tasks.
        deltas = np.array([per_task[task][label]["delta"] for task in tasks])
        macro_replicates = np.mean([per_task[task][label]["replicates"] for task in tasks], axis=0)
        low, high = percentile_interval(macro_replicates)
        rows.append(
            {
                **macro_secondary,
                "_is_reference": is_reference,
                "model": model,
                "scope": "MACRO",
                "task": "+".join(tasks),
                "method": label,
                "config": "per-task configs differ; see task rows",
                "primary_metric": "per task",
                "normalization_unit": "per task",
                "n_total": len(tasks),
                "accuracy_strict": float(np.mean([per_task[task][label]["correct"].mean() for task in tasks])),
                "delta_accuracy_pp": float(deltas.mean()),
                "delta_accuracy_ci95_low": 0.0 if is_reference else low,
                "delta_accuracy_ci95_high": 0.0 if is_reference else high,
                "invalid_count": int(sum((~per_task[task][label]["valid"]).sum() for task in tasks)),
                "invalid_fraction": float(np.mean([(~per_task[task][label]["valid"]).mean() for task in tasks])),
                "prediction_disagreement_rate": float(
                    np.mean([per_task[task][label]["disagree"].mean() for task in tasks])
                ),
                "mcnemar_b": int(sum((per_task[task][label]["reference_correct"] & ~per_task[task][label]["correct"]).sum() for task in tasks)),
                "mcnemar_c": int(sum((~per_task[task][label]["reference_correct"] & per_task[task][label]["correct"]).sum() for task in tasks)),
                "mcnemar_discordant": 0,
            }
        )
        rows[-1]["mcnemar_discordant"] = rows[-1]["mcnemar_b"] + rows[-1]["mcnemar_c"]
    return rows


# --------------------------------------------------------------------------
# language modelling
# --------------------------------------------------------------------------


def lm_rows_for_corpus(
    model: str,
    corpus: str,
    tokens: np.ndarray,
    totals: dict[str, np.ndarray],
    labels: dict[str, tuple[str, str]],
    resamples: int,
    seed: int,
    secondary_reference: str | None = None,
) -> list[dict]:
    reference = totals[REFERENCE]
    reference_finite = np.isfinite(reference)
    secondary = totals.get(secondary_reference) if secondary_reference else None
    if secondary_reference and secondary is None:
        raise KeyError(f"{corpus}: secondary reference {secondary_reference!r} is not in the predictions")
    secondary_label = labels.get(secondary_reference, (secondary_reference, ""))[0] if secondary_reference else ""
    rows: list[dict] = []
    for method_id, values in totals.items():
        finite = np.isfinite(values)
        if secondary is not None:
            shared2 = finite & np.isfinite(secondary)
            if shared2.any():
                num2 = (-values[shared2]) - (-secondary[shared2])
                obs2 = float(num2.sum() / tokens[shared2].sum())
                idx2 = bootstrap_indices(int(shared2.sum()), resamples, seed)
                low2, high2 = percentile_interval(ratio_replicates(num2, tokens[shared2], idx2))
                extra = {
                    "secondary_reference": secondary_label,
                    "delta_nll_per_token_vs_secondary": obs2,
                    "delta_nll_vs_secondary_ci95_low": 0.0 if method_id == secondary_reference else low2,
                    "delta_nll_vs_secondary_ci95_high": 0.0 if method_id == secondary_reference else high2,
                    "delta_ppl_pct_vs_secondary": 100.0 * (math.exp(obs2) - 1.0),
                    "windows_shared_vs_secondary": int(shared2.sum()),
                }
            else:
                extra = {"secondary_reference": secondary_label, "delta_nll_per_token_vs_secondary": float("nan"),
                         "delta_nll_vs_secondary_ci95_low": float("nan"), "delta_nll_vs_secondary_ci95_high": float("nan"),
                         "delta_ppl_pct_vs_secondary": float("nan"), "windows_shared_vs_secondary": 0}
        else:
            extra = {}
        shared = finite & reference_finite
        lost = int((~finite).sum())
        label, config = labels.get(method_id, (method_id, method_id))
        complete = lost == 0
        nll = float(-values[finite].sum() / tokens[finite].sum()) if finite.any() else float("nan")
        row = {
            **extra,
            "_is_reference": method_id == REFERENCE,
            "model": model,
            "corpus": corpus,
            "method": label,
            "config": config,
            "windows_total": int(tokens.size),
            "windows_invalid": lost,
            "windows_shared": int(shared.sum()),
            "tokens_total": int(tokens.sum()),
            "tokens_shared": int(tokens[shared].sum()),
            "nll_per_token": nll if complete else float("nan"),
            "perplexity": math.exp(nll) if complete else float("nan"),
            "nll_per_token_shared": float(-values[shared].sum() / tokens[shared].sum()) if shared.any() else float("nan"),
            "reference_nll_per_token_shared": float(-reference[shared].sum() / tokens[shared].sum()) if shared.any() else float("nan"),
        }
        if not shared.any():
            # No window is valid under both native and the method: the
            # comparison cannot be made and must not be reported as zero.
            row.update(delta_nll_per_token=float("nan"), delta_nll_ci95_low=float("nan"),
                       delta_nll_ci95_high=float("nan"), delta_ppl_pct=float("nan"), status="no_shared")
            rows.append(row)
            continue
        if method_id == REFERENCE:
            row.update(delta_nll_per_token=0.0, delta_nll_ci95_low=0.0, delta_nll_ci95_high=0.0, delta_ppl_pct=0.0)
        else:
            numerators = (-values[shared]) - (-reference[shared])
            observed = float(numerators.sum() / tokens[shared].sum())
            index = bootstrap_indices(int(shared.sum()), resamples, seed)
            replicates = ratio_replicates(numerators, tokens[shared], index)
            low, high = percentile_interval(replicates)
            row.update(
                delta_nll_per_token=observed,
                delta_nll_ci95_low=low,
                delta_nll_ci95_high=high,
                delta_ppl_pct=100.0 * (math.exp(observed) - 1.0),
            )
        if method_id == REFERENCE:
            row["status"] = "reference"
        elif complete:
            row["status"] = "complete"
        else:
            row["status"] = f"shared subset ({lost} of {tokens.size} windows lost); no full-corpus value"
        rows.append(row)
    return rows


# --------------------------------------------------------------------------
# rendering
# --------------------------------------------------------------------------


def fmt_pct(value: float, digits: int = 2) -> str:
    return "—" if not np.isfinite(value) else f"{100.0 * value:.{digits}f}"


def fmt_signed(value: float, digits: int = 2) -> str:
    return "—" if not np.isfinite(value) else f"{value:+.{digits}f}"


def render_markdown(mcq_rows: list[dict], lm_rows: list[dict]) -> str:
    lines: list[str] = []
    if mcq_rows:
        secondary = next((r.get("secondary_reference") for r in mcq_rows if r.get("secondary_reference")), "")
        reference_label = next((r["method"] for r in mcq_rows if r.get("_is_reference")), REFERENCE)
        head = f"| Model | Scope | Task | Method | Acc. % | Δ pp vs {reference_label} [95% CI] | Invalid % | Disagreement % |"
        sep = "|---|---|---|---|---|---|---|---|"
        if secondary:
            head = head[:-1] + f" Δ pp vs {secondary} [95% CI] | Disagreement vs {secondary} % |"
            sep += "---|---|"
        lines += ["## Multiple choice (strict accuracy; failures count as wrong)", "", head, sep]
        for row in mcq_rows:
            ci = (
                "reference"
                if row.get("_is_reference")
                else f"{fmt_signed(row['delta_accuracy_pp'])} [{fmt_signed(row['delta_accuracy_ci95_low'])}, {fmt_signed(row['delta_accuracy_ci95_high'])}]"
            )
            line = (
                f"| {row['model']} | {row['scope']} | {row['task']} | {row['method']} | "
                f"{fmt_pct(row['accuracy_strict'])} | {ci} | {fmt_pct(row['invalid_fraction'])} | "
                f"{fmt_pct(row['prediction_disagreement_rate'])} |"
            )
            if secondary:
                if row.get("delta_accuracy_pp_vs_secondary", "") == "":
                    line += " — | — |"
                else:
                    line += (
                        f" {fmt_signed(row['delta_accuracy_pp_vs_secondary'])} [{fmt_signed(row['delta_accuracy_vs_secondary_ci95_low'])}, "
                        f"{fmt_signed(row['delta_accuracy_vs_secondary_ci95_high'])}] | {fmt_pct(row['prediction_disagreement_rate_vs_secondary'])} |"
                    )
            lines.append(line)
        lines += [
            "",
            "POOLED = all examples concatenated (sample weighted); MACRO = equally weighted mean of "
            "per-task changes. spa@<target> is a tier label: the degree behind it differs per task "
            "(see the `config` column of the CSV).",
            "",
        ]
    if lm_rows:
        secondary_lm = next((r.get("secondary_reference") for r in lm_rows if r.get("secondary_reference")), "")
        head = "| Model | Corpus | Method | NLL/token | PPL | ΔNLL/token vs reference [95% CI] | ΔPPL % | Invalid windows | Status |"
        sep = "|---|---|---|---|---|---|---|---|---|"
        if secondary_lm:
            head = head[:-1] + f" ΔNLL/token vs {secondary_lm} [95% CI] | ΔPPL % vs {secondary_lm} |"
            sep += "---|---|"
        lines += ["## Language modelling (corpus-level token NLL)", "", head, sep]
        for row in lm_rows:
            complete = row["status"] in ("complete", "reference")
            nll = f"{row['nll_per_token']:.5f}" if complete else "—†"
            ppl = f"{row['perplexity']:.2f}" if complete else "—†"
            if row["status"] == "no_shared":
                delta = "— (no shared windows)"
                dppl = "—"
            elif row.get("_is_reference"):
                delta = "reference"
                dppl = ""
            else:
                delta = (
                    f"{row['delta_nll_per_token']:+.5f} "
                    f"[{row['delta_nll_ci95_low']:+.5f}, {row['delta_nll_ci95_high']:+.5f}]"
                )
                dppl = f"{row['delta_ppl_pct']:+.3f}"
                if not complete:
                    delta += " (shared subset)"
            line = (
                f"| {row['model']} | {row['corpus']} | {row['method']} | {nll} | {ppl} | {delta} | {dppl} | "
                f"{row['windows_invalid']} / {row['windows_total']} | {row['status']} |"
            )
            if row.get("secondary_reference"):
                d2 = row.get("delta_nll_per_token_vs_secondary")
                line += (
                    f" {d2:+.5f} [{row['delta_nll_vs_secondary_ci95_low']:+.5f}, {row['delta_nll_vs_secondary_ci95_high']:+.5f}] | "
                    f"{row['delta_ppl_pct_vs_secondary']:+.3f} |"
                    if isinstance(d2, float) and math.isfinite(d2) else " — | — |"
                )
            lines.append(line)
        lines += [
            "",
            "† no complete valid result on the full corpus; the paired quantities are computed on the "
            "windows valid under both native and the method (shared tokens in the CSV) and are not a "
            "full-corpus ranking. ΔPPL % = 100 (exp(ΔNLL) − 1).",
            "",
        ]
    return "\n".join(lines)


def write_csv(path: Path, rows: list[dict], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


# --------------------------------------------------------------------------
# main
# --------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument("--results", type=Path, required=True, help="e.g. results/zeroshot")
    parser.add_argument("--tasks", nargs="+", default=None, help="Default: every task with a prediction file.")
    parser.add_argument("--subdir", default="full", help="Run subdirectory (full, smoke, rounding, ...).")
    parser.add_argument("--catalog-name", default="profile_catalog.json")
    parser.add_argument("--output-prefix", type=Path, default=None, help="Default: <results>/paper_<subdir>")
    parser.add_argument("--bootstrap-resamples", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--model-name", type=str, default=None, help="Explicit model label for the exported tables.")
    parser.add_argument(
        "--secondary-reference", type=str, default=None,
        help="Method id for a second paired delta on every row (e.g. native-tanh in the erf-target run). "
             "'auto' picks native-tanh when the run's activation_target is erf.",
    )
    args = parser.parse_args()

    tasks = args.tasks or sorted(
        path.parent.parent.name for path in args.results.glob(f"*/{args.subdir}/predictions.csv")
    )
    prefix = args.output_prefix or args.results / f"paper_{args.subdir}"

    mcq_rows: list[dict] = []
    lm_rows: list[dict] = []
    coefficient_table: list[dict] = []
    per_task: dict[str, dict[str, dict]] = {}
    models: set[str] = set()
    for task in tasks:
        run_dir = args.results / task / args.subdir
        predictions = run_dir / "predictions.csv"
        if not predictions.exists():
            print(f"skipping {task}: {predictions} not found")
            continue
        metadata = read_json(run_dir / "metadata.json")
        catalog = read_json(args.results / task / args.catalog_name)
        labels = catalog_labels(catalog, metadata)
        secondary = args.secondary_reference
        if secondary == "auto":
            secondary = "native-tanh" if metadata.get("activation_target") == "erf" else None
        explicit_name = (args.model_name or "").strip()
        model = explicit_name or model_name(metadata)
        if model == "model":
            raise ValueError(f"Missing model identity for task {task!r}; provide --model-name.")
        models.add(model)
        coefficient_table += coefficient_rows(model, task, catalog, labels)
        if metadata.get("task_kind") == "lm":
            tokens, totals = load_lm(predictions)
            lm_rows += lm_rows_for_corpus(model, task, tokens, totals, labels, args.bootstrap_resamples, args.seed, secondary)
            continue
        gold, preds = load_mcq(predictions)
        primary_metric = str(metadata.get("primary_metric", "acc_norm"))
        rows, carry = mcq_rows_for_task(
            model, task, gold, preds, labels, primary_metric, args.bootstrap_resamples, args.seed, secondary
        )
        mcq_rows += rows
        per_task[task] = carry

    if len(models) > 1:
        print(f"note: results span several models {sorted(models)}; POOLED/MACRO rows mix them")
    mcq_rows += aggregate_rows("+".join(sorted(models)), per_task, args.bootstrap_resamples, args.seed)

    write_csv(prefix.with_name(prefix.name + "_mcq.csv"), mcq_rows, MCQ_FIELDS)
    write_csv(prefix.with_name(prefix.name + "_lm.csv"), lm_rows, LM_FIELDS)
    if coefficient_table:
        write_csv(prefix.with_name(prefix.name + "_coefficients.csv"), coefficient_table, COEFFICIENT_FIELDS)
        print(f"saved: {prefix.with_name(prefix.name + '_coefficients.csv')}")
    markdown = render_markdown(mcq_rows, lm_rows)
    prefix.with_suffix(".md").write_text(markdown)
    print(markdown)
    print(f"saved: {prefix.with_name(prefix.name + '_mcq.csv')}")
    print(f"saved: {prefix.with_name(prefix.name + '_lm.csv')}")
    print(f"saved: {prefix.with_suffix('.md')}")


if __name__ == "__main__":
    main()
