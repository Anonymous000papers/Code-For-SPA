#!/usr/bin/env bash
# Experiment B: coefficient precision of the balanced SPA tier.
#
# For every task that already has a range plan and a profile catalog
# (i.e. after run_all_tasks.sh), derive a catalog whose balanced SPA
# profiles are copied with coefficients rounded to d decimal places,
# evaluate native / exact / full / d1..d5 on the same evaluation split with
# the same settings as the main run, and export the standardised tables.
# Nothing is recalibrated or refitted.
#
#   MODEL_PATH=<path-to-gemma-4-e2b-it> bash run_rounding_experiment.sh
#   TASKS="hellaswag wikitext2" bash run_rounding_experiment.sh
#   DECIMALS=2,3,4 TIER_NAME=accurate bash run_rounding_experiment.sh
set -uo pipefail

ROOT="${ROOT:-results/zeroshot}"
MODEL_PATH="${MODEL_PATH:?set MODEL_PATH to the model checkpoint directory}"
TASKS="${TASKS:-wikitext2 c4_en hellaswag mmlu social_i_qa race_high}"
DECIMALS="${DECIMALS:-1,2,3,4,5}"
TIER_NAME="${TIER_NAME:-balanced}"
EVAL_BATCH="${EVAL_BATCH:-32}"
MAX_BATCH_TOKENS="${MAX_BATCH_TOKENS:-16384}"
COMPILE="${COMPILE:-default}"
SHARED_PROMPT="${SHARED_PROMPT:-auto}"
ACT_DTYPE="${ACT_DTYPE:-float32}"
SUBDIR="${SUBDIR:-rounding}"
TARGET="${TARGET:-tanh}"   # must match the catalog under ROOT (tanh: results/zeroshot, erf: results/zeroshot_erf)
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"

# Same per-task budgets as run_all_tasks.sh, so the runs are comparable.
max_length() {
  case "$1" in
    race_high)          echo 2048 ;;
    code_python)        echo 2048 ;;
    wikitext2|c4_en)    echo 1536 ;;
    mmlu)               echo 1024 ;;
    piqa)               echo 1024 ;;
    *)                  echo 512 ;;
  esac
}
eval_samples() {
  case "$1" in
    c4_en|code_python) echo 4000 ;;
    *)                 echo 0 ;;
  esac
}

FAILED=""
DONE=""
for TASK in ${TASKS}; do
  DIR="${ROOT}/${TASK}"
  if [[ ! -f "${DIR}/plan/range_plan.json" || ! -f "${DIR}/profile_catalog.json" ]]; then
    echo "!!! ${TASK}: no range plan / catalog under ${DIR}; run run_all_tasks.sh first"
    FAILED="${FAILED} ${TASK}"
    continue
  fi
  echo
  echo "################ ${TASK}: coefficient rounding ################"
  if ! python round_catalog_coefficients.py \
        --profile-catalog "${DIR}/profile_catalog.json" \
        --output "${DIR}/profile_catalog_${SUBDIR}.json" \
        --tier "${TIER_NAME}" --decimals "${DECIMALS}"; then
    echo "!!! ${TASK} failed while deriving the rounded catalog; continuing"
    FAILED="${FAILED} ${TASK}"
    continue
  fi
  METHODS="native,exact,$(python -c "import json,sys; print(','.join(json.load(open(sys.argv[1]))['rounding_experiment']['method_ids']))" "${DIR}/profile_catalog_${SUBDIR}.json")"
  echo "methods: ${METHODS}"
  if ! python eval_methods.py \
        --task "${TASK}" --model-path "${MODEL_PATH}" \
        --range-plan "${DIR}/plan/range_plan.json" \
        --profile-catalog "${DIR}/profile_catalog_${SUBDIR}.json" \
        --methods "${METHODS}" --max-samples "$(eval_samples "${TASK}")" \
        --max-length "$(max_length "${TASK}")" --batch-size "${EVAL_BATCH}" \
        --compile-activation "${COMPILE}" --shared-prompt "${SHARED_PROMPT}" \
        --activation-dtype "${ACT_DTYPE}" --target "${TARGET}" --max-batch-tokens "${MAX_BATCH_TOKENS}" \
        --output-dir "${DIR}/${SUBDIR}"; then
    echo "!!! ${TASK} failed during evaluation; continuing"
    FAILED="${FAILED} ${TASK}"
    continue
  fi
  DONE="${DONE} ${TASK}"
done

if [[ -n "${DONE}" ]]; then
  echo
  echo "################ tables ################"
  python export_paper_tables.py --results "${ROOT}" --subdir "${SUBDIR}" \
    --catalog-name "profile_catalog_${SUBDIR}.json" --tasks ${DONE} \
    --output-prefix "${ROOT}/paper_${SUBDIR}"
fi

if [[ -n "${FAILED}" ]]; then
  echo
  echo "Tasks that failed:${FAILED}"
fi
