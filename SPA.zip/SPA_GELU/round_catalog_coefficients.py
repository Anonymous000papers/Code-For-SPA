"""Experiment B: coefficient precision of the balanced SPA profiles.

Derives a catalog in which the balanced tier's SPA profiles are copied
with their *normalised Chebyshev coefficients* rounded to ``d`` decimal
places, ``d in {1, 2, 3, 4, 5}``, alongside the unrounded original
(``full``). Nothing else moves: model weights, range plan (the derived
catalog keeps the plan hash the evaluator checks), degrees, PS split and
the source of the coefficients are those of the original catalog. No
profile is refitted and no range is reselected; the only operation is
``round(c_i, d)`` on the coefficients as stored.

    python round_catalog_coefficients.py \\
        --profile-catalog results/zeroshot/hellaswag/profile_catalog.json \\
        --output results/zeroshot/hellaswag/profile_catalog_rounding.json

The derived catalog adds one SPA variant per ``d`` (ids
``<variant>-d<d>``, e.g. ``spa-k47-d3``) and records, per range profile:

* ``coefficient_l1_perturbation``  = ||c_d - c||_1,
* ``coefficient_perturbation_max`` = ||P_{c_d} - P_c||_inf on the
  approximation interval (E_coeff), computed in float64,
* ``max_abs_error`` of the rounded profile against the exact activation
  (approximation error plus coefficient perturbation; the plaintext
  analogue of E_total) next to ``max_abs_error_unrounded``,
* ``nonzero_coefficients``.

On the interval, |T_i(t)| <= 1 for every Chebyshev polynomial, so
||P_{c_d} - P_c||_inf <= ||c_d - c||_1; the script verifies the bound
holds for every profile. The bound describes the ideal (real-arithmetic)
perturbation; it says nothing about bf16 output rounding in the plaintext
run or CKKS error in the ciphertext one. E_HE and E_total under
encryption are measured by the ciphertext implementation from this same
catalog file.

Run the evaluation on the derived catalog with ``run_rounding_experiment.sh``
and export the tables with ``export_paper_tables.py --subdir rounding
--catalog-name profile_catalog_rounding.json``.
"""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import numpy as np
from numpy.polynomial.chebyshev import chebval

GRID = 200001


def silu(x: np.ndarray) -> np.ndarray:
    return x / (1.0 + np.exp(-x))


def gelu_tanh(x: np.ndarray) -> np.ndarray:
    inner = np.sqrt(2.0 / np.pi) * (x + 0.044715 * x**3)
    return 0.5 * x * (1.0 + np.tanh(inner))


def gelu_erf(x: np.ndarray) -> np.ndarray:
    from scipy.special import erf

    return 0.5 * x * (1.0 + erf(x / np.sqrt(2.0)))


def pick_activation(name: str, catalog: dict):
    if name == "auto":
        explicit = catalog.get("activation_target")
        target = str(catalog.get("target", "")).lower()
        if explicit == "erf" or ("erf" in target and "gelu" in target):
            name = "gelu-erf"
        elif "gelu" in target:
            name = "gelu"
        elif "silu" in target:
            name = "silu"
        else:
            raise ValueError("cannot infer the activation from the catalog target; pass --activation")
    return {"silu": silu, "gelu": gelu_tanh, "gelu-erf": gelu_erf}[name], name


def spa_value(x: np.ndarray, radius: float, coefficients: list[float]) -> np.ndarray:
    t = 2.0 * (x / radius) ** 2 - 1.0
    return 0.5 * x + chebval(t, np.asarray(coefficients, dtype=np.float64))


def pick_variant(catalog: dict, tier: str, variant_id: str | None) -> dict:
    variants = catalog["methods"]["spa"]
    if variant_id:
        matches = [v for v in variants if v["id"] == variant_id]
        if not matches:
            raise ValueError(f"no SPA variant {variant_id!r}; available: {[v['id'] for v in variants]}")
        return matches[0]
    by_tier = [v for v in variants if v.get("tier") == tier]
    if by_tier:
        return by_tier[0]
    order = {"fast": 0, "balanced": 1, "accurate": 2}
    if tier in order and len(variants) > order[tier]:
        return variants[order[tier]]
    raise ValueError(f"cannot identify the {tier!r} tier; pass --variant")


def round_profile(profile: dict, decimals: int, activation) -> dict:
    if profile["kind"] != "spa":
        raise ValueError(f"{profile['id']} is not a SPA profile")
    radius = float(profile["operating_radius"])
    original = [float(c) for c in profile["coefficients"]]
    rounded = [round(c, decimals) for c in original]
    delta = np.asarray(rounded) - np.asarray(original)

    t = np.linspace(-1.0, 1.0, GRID)
    perturbation = np.abs(chebval(t, delta))
    e_coeff = float(perturbation.max()) if delta.size else 0.0
    l1 = float(np.abs(delta).sum())
    if e_coeff > l1 * (1.0 + 1e-9) + 1e-15:
        raise AssertionError(f"{profile['id']} d={decimals}: E_coeff {e_coeff} exceeds the l1 bound {l1}")

    x = np.linspace(-radius, radius, GRID)
    exact = activation(x)
    error_rounded = float(np.max(np.abs(spa_value(x, radius, rounded) - exact)))
    error_original = float(np.max(np.abs(spa_value(x, radius, original) - exact)))

    derived = copy.deepcopy(profile)
    derived["id"] = f"{profile['id']}-d{decimals}"
    derived["coefficients"] = rounded
    derived["rounding_decimals"] = decimals
    derived["derived_from"] = profile["id"]
    derived["coefficient_l1_perturbation"] = l1
    derived["coefficient_perturbation_max"] = e_coeff
    derived["max_abs_error"] = error_rounded
    derived["max_abs_error_unrounded"] = error_original
    derived["nonzero_coefficients"] = int(np.count_nonzero(np.asarray(rounded)))
    derived["fit_method"] = f"{profile.get('fit_method', 'spa')}; coefficients rounded to {decimals} decimals (not refitted)"
    for key in list(derived):
        if key.startswith("max_abs_error_float") or key.startswith("rmse") or key.startswith("nonfinite_points"):
            derived.pop(key, None)  # dtype-specific numbers belong to the unrounded fit
    return derived


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument("--profile-catalog", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--tier", default="balanced", choices=["fast", "balanced", "accurate"])
    parser.add_argument("--variant", default=None, help="Explicit SPA variant id instead of --tier.")
    parser.add_argument("--decimals", default="1,2,3,4,5")
    parser.add_argument("--activation", default="auto", choices=["auto", "silu", "gelu", "gelu-erf"])
    args = parser.parse_args()

    catalog = json.loads(args.profile_catalog.read_text())
    activation, activation_name = pick_activation(args.activation, catalog)
    variant = pick_variant(catalog, args.tier, args.variant)
    decimals = [int(value) for value in args.decimals.split(",") if value.strip()]
    if any(d < 0 for d in decimals):
        raise ValueError("--decimals must be non-negative integers")

    derived = copy.deepcopy(catalog)
    new_variants: list[dict] = []
    table: list[dict] = []
    for d in decimals:
        new_variant = copy.deepcopy(variant)
        new_variant["id"] = f"{variant['id']}-d{d}"
        new_variant["display_name"] = f"{variant['display_name']}/d{d}"
        new_variant["rounding_decimals"] = d
        new_variant["derived_from"] = variant["id"]
        new_variant["profiles"] = {}
        new_variant["coefficient_perturbation"] = {}
        for label, profile_id in variant["profiles"].items():
            profile = round_profile(catalog["profiles"][profile_id], d, activation)
            derived["profiles"][profile["id"]] = profile
            new_variant["profiles"][label] = profile["id"]
            new_variant["coefficient_perturbation"][label] = {
                key: profile[key]
                for key in (
                    "coefficient_l1_perturbation",
                    "coefficient_perturbation_max",
                    "max_abs_error",
                    "max_abs_error_unrounded",
                    "nonzero_coefficients",
                )
            }
            table.append({"range": label, "d": d, **new_variant["coefficient_perturbation"][label], "degree": profile["degree_square"], "radius": profile["operating_radius"]})
        new_variants.append(new_variant)
    derived["methods"]["spa"] = list(catalog["methods"]["spa"]) + new_variants
    derived["format"] = f"{catalog.get('format', 'activation-profile-catalog')}+rounding"
    derived["rounding_experiment"] = {
        "tier": variant.get("tier", args.tier),
        "variant": variant["id"],
        "full_precision_variant": variant["id"],
        "decimals": decimals,
        "activation": activation_name,
        "rule": (
            "normalised Chebyshev coefficients rounded half-to-even to d decimal places; "
            "range plan, degrees, PS split and coefficient source unchanged; no refit"
        ),
        "bound": "||P_{c_d} - P_c||_inf <= ||c_d - c||_1 on the approximation interval (verified per profile)",
        "bound_scope": "ideal real-arithmetic perturbation; excludes bf16 output rounding and CKKS error",
        "source_catalog": str(args.profile_catalog.resolve()),
        "method_ids": [variant["id"]] + [v["id"] for v in new_variants],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(derived, indent=2))

    print(f"variant {variant['id']} ({variant.get('tier', args.tier)} tier), activation {activation_name}")
    print(f"{'range':>5s} {'R':>6s} {'k':>4s} {'d':>2s} {'nonzero':>7s} {'||dc||_1':>11s} {'E_coeff':>11s} {'max err':>11s} {'unrounded':>11s}")
    for row in table:
        print(
            f"{row['range']:>5s} {row['radius']:>6g} {row['degree']:>4d} {row['d']:>2d} {row['nonzero_coefficients']:>7d} "
            f"{row['coefficient_l1_perturbation']:>11.3e} {row['coefficient_perturbation_max']:>11.3e} "
            f"{row['max_abs_error']:>11.3e} {row['max_abs_error_unrounded']:>11.3e}"
        )
    print("methods to evaluate:", ",".join(["native", "exact"] + derived["rounding_experiment"]["method_ids"]))
    print(f"saved: {args.output}")


if __name__ == "__main__":
    main()
