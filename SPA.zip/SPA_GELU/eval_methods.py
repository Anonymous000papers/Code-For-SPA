"""Evaluate GELU-approximation methods on a multiple-choice or LM task.

Scores one task under each activation method by swapping the ``act_fn``
of every text-decoder gated MLP (``gelu_pytorch_tanh`` in Gemma 4) for a
channel-grouped polynomial profile from the catalog:

* any task registered in ``tasks.py``, with any number of choices;
* the model is evaluated zero-shot, exactly as released;
* activation statistics accumulate on device instead of forcing a GPU
  sync on every MLP call;
* every method is compared to native with a paired McNemar test.

The range plan and profile catalog are consumed unchanged from
``build_range_plan.py`` and ``generate_method_profiles.py``.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import re
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from tqdm.auto import tqdm
from transformers import AutoModelForCausalLM, AutoTokenizer

from activation_approximations import evaluate_profile
from mcq_common import (
    OOM_BACKOFF_EVENTS,
    batch_count,
    build_records,
    choice_geometry,
    compute_lm_metrics,
    compute_metrics,
    minimum_detectable_effect,
    score_records,
    set_seed,
)
from model_sites import activation_name, iter_gated_mlps
from tasks import get_task, set_source_override

LAYER_PATTERN = re.compile(r"(?:^|\.)layers\.(\d+)(?:\.|$)")


def resolve_model_path(path: str) -> str:
    candidate = Path(path).expanduser()
    if candidate.exists():
        return str(candidate.resolve())
    fallback = Path("/root") / candidate
    if fallback.exists():
        return str(fallback.resolve())
    raise FileNotFoundError(f"model directory not found: {path!r} (also tried {fallback})")


COMPILE_MODES = ("off", "default", "max-autotune")

# Precision of the swapped activation. float32 is the protocol default (as
# for SiLU); float64 is available to separate approximation error from
# precision effects, e.g. NEXUS's sign-residual leakage. Set once from the
# command line before any profile is built.
ACTIVATION_DTYPES = {"float32": torch.float32, "float64": torch.float64}
ACTIVATION_DTYPE = torch.float32
SUPPORTED_MODEL_ACTIVATIONS = {"gelu_pytorch_tanh", "gelu_tanh", "gelu_new"}

# GELU form used as the experiment's reference. "tanh": the model's own
# activation is the reference (``native`` runs it in bf16, ``exact`` in the
# activation dtype). "erf": the exact erf-GELU is substituted for the
# model's activation and becomes the reference (``native``); SPA/MOAI are
# fitted to it in the catalog, NEXUS's released polynomial approximates it,
# and the original model activation is kept as the extra method
# ``model-native`` so the effect of the substitution itself is measured.
ACTIVATION_TARGET = "tanh"
TARGET_TORCH_APPROXIMATE = {"tanh": "tanh", "erf": "none"}


def set_activation_dtype(name: str) -> None:
    global ACTIVATION_DTYPE
    ACTIVATION_DTYPE = ACTIVATION_DTYPES[name]


def set_activation_target(name: str) -> None:
    global ACTIVATION_TARGET
    if name not in TARGET_TORCH_APPROXIMATE:
        raise ValueError(f"unknown activation target {name!r}")
    ACTIVATION_TARGET = name


def reference_gelu(z: torch.Tensor) -> torch.Tensor:
    """The experiment's reference GELU in the activation dtype."""
    return torch.nn.functional.gelu(z, approximate=TARGET_TORCH_APPROXIMATE[ACTIVATION_TARGET])


class TokenMask:
    """Attention mask for the batch currently in flight.

    Padded positions run through the MLP with unconstrained gate values.
    Two things depend on knowing where they are:

    * Activation auditing ignores them, matching calibration.
    * The swapped activation is not applied to them. The attention mask
      keeps a padded position's *finite* output away from every real
      token, but not a non-finite one: a NaN key or value at a padded
      position poisons all real positions of that sequence, because the
      masked softmax weight is exactly 0 and ``0 * NaN = NaN`` in the
      attention product. Sign-gated methods (NEXUS, Euston) diverge for
      inputs outside their normalised interval, which padding routinely
      exceeds. Padding does not exist in the encrypted setting, so at
      padded positions the reference activation is used instead.

    The mask is therefore required: ``valid_for`` raises when it is
    missing or does not match, rather than quietly widening the audit to
    the whole tensor.
    """

    current: "torch.Tensor | None" = None

    def set(self, mask) -> None:
        self.current = mask

    def valid_for(self, z: "torch.Tensor") -> "torch.Tensor":
        mask = self.current
        if mask is None:
            raise RuntimeError(
                "token mask is not set; the model was run outside score_records "
                "while a method activation was installed"
            )
        if z.dim() != 3 or tuple(mask.shape) != tuple(z.shape[:2]):
            raise RuntimeError(
                f"token mask shape {tuple(mask.shape)} does not match activation "
                f"shape {tuple(z.shape)}"
            )
        return mask.bool().unsqueeze(-1)


TOKEN_MASK = TokenMask()

# One PolynomialProfile per (profile id, compile mode), shared across all 28
# layers. Building one per layer would mean 28 separate torch.compile calls
# for the same kernel.
_PROFILE_CACHE: dict[tuple[str, str], "PolynomialProfile"] = {}


def configure_dynamo(profile_budget: int = 64) -> None:
    """Raise Dynamo's recompile ceiling before compiling any profile.

    Every profile compiles through the same ``PolynomialProfile.evaluate``
    code object and is distinguished only by a guard on ``self``, so a
    full sweep needs one cache entry per profile. The default per-code
    limit is 8; exceeding it makes Dynamo fall back to eager with a
    warning rather than an error, which would quietly undo the speedup.
    """
    import torch._dynamo as dynamo

    for name, value in (
        ("cache_size_limit", profile_budget),
        ("recompile_limit", profile_budget),
        ("accumulated_cache_size_limit", profile_budget * 8),
        ("accumulated_recompile_limit", profile_budget * 8),
    ):
        if hasattr(dynamo.config, name):
            setattr(dynamo.config, name, max(getattr(dynamo.config, name), value))


def get_profile(profile_id: str, spec: dict, compile_mode: str) -> "PolynomialProfile":
    key = (profile_id, compile_mode)
    if key not in _PROFILE_CACHE:
        if compile_mode != "off":
            configure_dynamo()
        _PROFILE_CACHE[key] = PolynomialProfile(spec, compile_mode=compile_mode).to("cuda")
    return _PROFILE_CACHE[key]


class PolynomialProfile(nn.Module):
    """One catalog profile as an elementwise module.

    The maths is ``activation_approximations.evaluate_profile``, the same
    function the fitter and the audit use, so the GPU path cannot drift
    from the reference. Constants are Python floats inside the spec, which
    ``torch.compile`` folds into the fused kernel.
    """

    def __init__(self, spec: dict, compile_mode: str = "off"):
        super().__init__()
        self.spec = spec
        self.compile_mode = compile_mode
        self.kernel = None
        self.kind = spec["kind"]
        self.domain_lo = float(spec["domain_lo"])
        self.domain_hi = float(spec["domain_hi"])
        if self.kind not in {"spa", "nexus", "moai", "euston"}:
            raise ValueError(f"unknown profile kind: {self.kind}")

    def evaluate(self, z: torch.Tensor) -> torch.Tensor:
        """Pure elementwise body. Identical maths to the uncompiled path."""
        return evaluate_profile(self.spec, z)

    def _kernel(self):
        """Build the evaluator once.

        Compiling flattens the input to 1-D and marks that dimension
        dynamic, so a single Triton kernel serves every batch shape. Every
        loop in the evaluators (Clenshaw recurrence, sign compositions,
        exp squarings, extension stages) has a Python-int bound, so the
        whole profile unrolls and fuses into one kernel.
        """
        if self.kernel is None:
            if self.compile_mode == "off":
                self.kernel = self.evaluate
            else:
                options: dict = {"dynamic": True}
                if self.compile_mode == "max-autotune":
                    options["mode"] = "max-autotune-no-cudagraphs"
                self.kernel = torch.compile(self.evaluate, **options)
        return self.kernel

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        z = x.to(ACTIVATION_DTYPE)
        if self.compile_mode == "off":
            return self.evaluate(z)
        return self._kernel()(z.reshape(-1)).view(z.shape)


class MethodActivation(nn.Module):
    """Channel-grouped polynomial activation with on-device audit counters."""

    COUNT_INPUTS = 0
    COUNT_RANGE_VIOLATIONS = 1
    COUNT_DOMAIN_VIOLATIONS = 2
    COUNT_NONFINITE = 3
    COUNT_CAST_OVERFLOW = 4
    COUNT_PADDED = 5

    def __init__(
        self,
        method_id: str,
        layer_plan: dict,
        radii: dict[str, float],
        profiles: dict[str, "PolynomialProfile"],
        collect_stats: bool = True,
    ):
        super().__init__()
        self.method_id = method_id
        self.radii = radii
        self.collect_stats = collect_stats
        self.profile_labels = list(radii)
        self.profiles = nn.ModuleDict({label: profiles[label] for label in self.profile_labels})

        assignments = layer_plan["channel_ranges"]
        self.expected_width = len(assignments)
        covered = 0
        for label in self.profile_labels:
            indices = [index for index, value in enumerate(assignments) if value == label]
            covered += len(indices)
            self.register_buffer(
                f"indices_{label}", torch.tensor(indices, dtype=torch.long), persistent=False
            )
        if covered != self.expected_width:
            raise RuntimeError(
                f"range plan covers {covered} of {self.expected_width} channels; "
                "every channel must be assigned exactly one profile"
            )

        self.register_buffer("counters", torch.zeros(6, dtype=torch.int64), persistent=False)
        self.register_buffer("maxima", torch.zeros(3, dtype=torch.float32), persistent=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        z = x.to(ACTIVATION_DTYPE)
        if z.shape[-1] != self.expected_width:
            raise RuntimeError(
                f"activation width {z.shape[-1]} does not match the range plan "
                f"width {self.expected_width}"
            )
        output = torch.empty_like(z)
        # Always required, not only when auditing: padded positions get
        # the reference activation (see TokenMask).
        valid = TOKEN_MASK.valid_for(z)

        for label in self.profile_labels:
            indices = getattr(self, f"indices_{label}")
            if indices.numel() == 0:
                continue
            values = z.index_select(-1, indices)
            profile = self.profiles[label]
            output.index_copy_(-1, indices, profile(values))

            if self.collect_stats:
                radius = self.radii[label]
                over_range = (values.abs() > radius) & valid
                out_of_domain = ((values < profile.domain_lo) | (values > profile.domain_hi)) & valid
                self.counters[self.COUNT_RANGE_VIOLATIONS].add_(over_range.sum())
                self.counters[self.COUNT_DOMAIN_VIOLATIONS].add_(out_of_domain.sum())

        # Padded positions: reference activation, so nothing non-finite can
        # enter the attention product from a position that is not part of
        # the experiment.
        output = torch.where(valid, output, reference_gelu(z))
        # What goes downstream is the cast tensor. A value that is finite in
        # float32 but above the bf16 range becomes inf on the cast, so the
        # finiteness audit is taken after casting, and the cast overflow is
        # counted separately.
        cast = output.to(x.dtype)

        if self.collect_stats:
            finite_before = torch.isfinite(output) & valid
            finite_after = torch.isfinite(cast) & valid
            zero = torch.zeros((), dtype=z.dtype, device=z.device)
            counted = int(valid.sum().item()) * z.shape[-1]
            padded = (z.shape[0] * z.shape[1] - int(valid.sum().item())) * z.shape[-1]
            inputs = torch.where(valid, z.abs(), zero)
            outputs = torch.where(finite_after, cast.to(z.dtype).abs(), zero)
            outputs_before_cast = torch.where(finite_before, output.abs(), zero)
            self.counters[self.COUNT_INPUTS].add_(counted)
            self.counters[self.COUNT_PADDED].add_(padded)
            self.counters[self.COUNT_NONFINITE].add_((valid & ~finite_after).sum())
            self.counters[self.COUNT_CAST_OVERFLOW].add_((finite_before & ~finite_after).sum())
            self.maxima[0].copy_(torch.maximum(self.maxima[0], inputs.amax()))
            self.maxima[1].copy_(torch.maximum(self.maxima[1], outputs.amax()))
            self.maxima[2].copy_(torch.maximum(self.maxima[2], outputs_before_cast.amax()))
        return cast

    def stats(self) -> dict[str, float | int]:
        counters = self.counters.tolist()
        maxima = self.maxima.tolist()
        denominator = max(1, counters[self.COUNT_INPUTS])
        return {
            "activation_input_count": counters[self.COUNT_INPUTS],
            "activation_max_abs_input": maxima[0],
            "range_violation_count": counters[self.COUNT_RANGE_VIOLATIONS],
            "range_violation_fraction": counters[self.COUNT_RANGE_VIOLATIONS] / denominator,
            "method_domain_violation_count": counters[self.COUNT_DOMAIN_VIOLATIONS],
            "method_domain_violation_fraction": counters[self.COUNT_DOMAIN_VIOLATIONS] / denominator,
            "activation_nonfinite_count": counters[self.COUNT_NONFINITE],
            "activation_cast_overflow_count": counters[self.COUNT_CAST_OVERFLOW],
            "activation_max_abs_finite_output": maxima[1],
            "activation_max_abs_finite_output_before_cast": maxima[2],
            "activation_padded_positions": counters[self.COUNT_PADDED],
        }


class ExactActivation(nn.Module):
    """Reference tanh-GELU (``gelu_pytorch_tanh``) in the activation dtype.

    ``native`` runs the model's own bf16 activation; ``exact`` isolates the
    effect of the float32/64 cast that every polynomial profile also pays.
    """

    def __init__(self, collect_stats: bool = True, approximate: str | None = None):
        super().__init__()
        self.approximate = approximate  # None: the experiment's reference form
        self.collect_stats = collect_stats
        self.register_buffer("counters", torch.zeros(1, dtype=torch.int64), persistent=False)
        self.register_buffer("maxima", torch.zeros(2, dtype=torch.float32), persistent=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        z = x.to(ACTIVATION_DTYPE)
        output = (
            reference_gelu(z)
            if self.approximate is None
            else torch.nn.functional.gelu(z, approximate=self.approximate)
        )
        if self.collect_stats:
            valid = TOKEN_MASK.valid_for(z)
            zero = torch.zeros((), dtype=z.dtype, device=z.device)
            counted = int(valid.sum().item()) * z.shape[-1]
            inputs = torch.where(valid, z.abs(), zero)
            outputs = torch.where(valid, output.abs(), zero)
            self.counters[0].add_(counted)
            self.maxima[0].copy_(torch.maximum(self.maxima[0], inputs.amax()))
            self.maxima[1].copy_(torch.maximum(self.maxima[1], outputs.amax()))
        return output.to(x.dtype)

    def stats(self) -> dict[str, float | int]:
        maxima = self.maxima.tolist()
        return {
            "activation_input_count": int(self.counters[0].item()),
            "activation_max_abs_input": maxima[0],
            "range_violation_count": 0,
            "range_violation_fraction": 0.0,
            "method_domain_violation_count": 0,
            "method_domain_violation_fraction": 0.0,
            "activation_nonfinite_count": 0,
            "activation_cast_overflow_count": 0,
            "activation_max_abs_finite_output": maxima[1],
            "activation_max_abs_finite_output_before_cast": maxima[1],
            "activation_padded_positions": 0,
        }


class ActivationProxy(nn.Module):
    def __init__(self, layer_name: str, native_fn):
        super().__init__()
        self.layer_name = layer_name
        self.native_fn = native_fn
        self.impl: nn.Module | None = None

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.impl is None:
            return self.native_fn(x)
        return self.impl(x)


def install_proxies(model) -> list[ActivationProxy]:
    """Wrap ``act_fn`` of every text-decoder gated MLP.

    Discovery goes through ``model_sites`` so that Gemma 4's vision MLPs
    (same attribute shape) and the per-layer-input gate GELU are left
    alone; only the sites that were calibrated are swapped.
    """
    proxies: list[ActivationProxy] = []
    for name, module in iter_gated_mlps(model):
        if isinstance(module.act_fn, ActivationProxy):
            continue
        proxy = ActivationProxy(name, module.act_fn)
        module.act_fn = proxy
        proxies.append(proxy)
    if not proxies:
        raise RuntimeError("no gated MLP activation sites were found in the text backbone")
    return proxies


def resolve_layer_plan(plan: dict, layer_name: str) -> dict:
    if layer_name in plan["layers"]:
        return plan["layers"][layer_name]
    match = LAYER_PATTERN.search(layer_name)
    if match is None:
        raise KeyError(f"could not read a layer index from {layer_name}")
    number = match.group(1)
    matches = [
        value
        for key, value in plan["layers"].items()
        if (found := LAYER_PATTERN.search(key)) and found.group(1) == number
    ]
    if len(matches) != 1:
        raise KeyError(f"could not resolve range plan for {layer_name}")
    return matches[0]


def method_registry(catalog: dict) -> dict[str, dict]:
    if ACTIVATION_TARGET == "tanh":
        registry: dict[str, dict] = {
            "native": {"display_name": "Native", "family": "native"},
            "exact": {"display_name": "Exact", "family": "exact"},
        }
    else:
        # Group names of the erf-target experiment. The reference run keeps
        # the id "native" because the harness, pooling and export treat that
        # id as "the reference"; its display name and the metadata say what
        # it computes. The two tanh controls let the target switch be
        # separated from the numerical path: Native-tanh (bf16 act_fn) vs
        # Exact-tanh (fp32 tanh, cast back) is the path, Exact-tanh vs
        # Exact-erf is the function.
        registry = {
            "native": {"display_name": "Exact-erf (reference: erf-GELU in the activation dtype, cast back)", "family": "native"},
            "native-tanh": {"display_name": "Native-tanh (original model activation, bf16)", "family": "native-tanh"},
            "exact-tanh": {"display_name": "Exact-tanh (tanh-GELU in the activation dtype, cast back)", "family": "exact-tanh"},
        }
    for variant in catalog["methods"]["spa"]:
        registry[variant["id"]] = {
            "display_name": variant["display_name"],
            "family": "spa",
            "profiles": variant["profiles"],
            "degree_schedule": variant["degree_schedule"],
            "target_max_error": variant["target_max_error"],
        }
    for method_id in ("nexus", "moai", "euston"):
        spec = catalog["methods"][method_id]
        registry[method_id] = {
            "display_name": spec["display_name"],
            "family": method_id,
            "profiles": spec["profiles"],
            "degree_schedule": spec["degree_schedule"],
            "implementation": spec["implementation"],
        }
    return registry


def set_method(
    proxies: list[ActivationProxy],
    method_id: str,
    registry: dict[str, dict],
    catalog: dict,
    plan: dict,
    collect_stats: bool,
    compile_mode: str = "off",
) -> None:
    method = registry[method_id]
    radii = {label: float(radius) for label, radius in plan["radii"].items()}
    for proxy in proxies:
        if method_id == "native-tanh" or (method_id == "native" and ACTIVATION_TARGET == "tanh"):
            proxy.impl = None  # the model's own act_fn, in its own dtype
            continue
        if method_id == "exact-tanh":
            proxy.impl = ExactActivation(collect_stats=collect_stats, approximate="tanh").to("cuda")
            continue
        if method_id == "exact" or method_id == "native":
            # tanh: exact = reference GELU in the activation dtype;
            # erf: native = the substituted erf-GELU, the experiment's reference.
            proxy.impl = ExactActivation(collect_stats=collect_stats).to("cuda")
            continue
        profiles = {
            label: get_profile(profile_id, catalog["profiles"][profile_id], compile_mode)
            for label, profile_id in method["profiles"].items()
        }
        proxy.impl = MethodActivation(
            method_id=method_id,
            layer_plan=resolve_layer_plan(plan, proxy.layer_name),
            radii=radii,
            profiles=profiles,
            collect_stats=collect_stats,
        ).to("cuda")


def nan_aware_max(current: float, candidate: float) -> float:
    """Maximum that keeps NaN instead of discarding it.

    Python's ``max(a, b)`` returns ``a`` when ``b`` is NaN, because the
    comparison is False. Reducing per-layer activation maxima with it would
    drop the NaN of a layer that overflowed and report a plausible-looking
    maximum instead of flagging the failure.
    """
    if math.isnan(current) or math.isnan(candidate):
        return float("nan")
    return max(current, candidate)


def runtime_stats(proxies: list[ActivationProxy]) -> dict[str, float | int]:
    total: dict[str, float | int] = {
        "activation_input_count": 0,
        "activation_max_abs_input": 0.0,
        "range_violation_count": 0,
        "method_domain_violation_count": 0,
        "activation_nonfinite_count": 0,
        "activation_cast_overflow_count": 0,
        "activation_max_abs_finite_output": 0.0,
        "activation_max_abs_finite_output_before_cast": 0.0,
        "activation_padded_positions": 0,
    }
    for proxy in proxies:
        if proxy.impl is None:
            continue
        stats = proxy.impl.stats()
        for key in (
            "activation_input_count",
            "range_violation_count",
            "method_domain_violation_count",
            "activation_nonfinite_count",
            "activation_cast_overflow_count",
            "activation_padded_positions",
        ):
            total[key] = int(total[key]) + int(stats.get(key, 0))
        total["activation_max_abs_input"] = nan_aware_max(
            float(total["activation_max_abs_input"]), float(stats["activation_max_abs_input"])
        )
        total["activation_max_abs_finite_output"] = nan_aware_max(
            float(total["activation_max_abs_finite_output"]),
            float(stats["activation_max_abs_finite_output"]),
        )
        total["activation_max_abs_finite_output_before_cast"] = nan_aware_max(
            float(total["activation_max_abs_finite_output_before_cast"]),
            float(stats.get("activation_max_abs_finite_output_before_cast", stats["activation_max_abs_finite_output"])),
        )
    denominator = max(1, int(total["activation_input_count"]))
    total["range_violation_fraction"] = int(total["range_violation_count"]) / denominator
    total["method_domain_violation_fraction"] = (
        int(total["method_domain_violation_count"]) / denominator
    )
    return total


def verify_compiled_profiles(method_id: str, tolerance: float = 1e-5) -> None:
    """Check each compiled profile against its eager counterpart.

    The compiled kernel must be numerically equivalent, not merely close
    in aggregate: an accuracy delta of 0.02 pp is the signal being
    measured, so a systematic drift in the activation would be
    indistinguishable from a real result.
    """
    for (profile_id, mode), profile in _PROFILE_CACHE.items():
        if mode == "off":
            continue
        radius = float(profile.spec.get("operating_radius", profile.domain_hi))
        probe = torch.linspace(-radius, radius, 4096, device="cuda", dtype=ACTIVATION_DTYPE)
        with torch.inference_mode():
            eager = profile.evaluate(probe)
            fused = profile._kernel()(probe.reshape(-1)).view(probe.shape)
        deviation = (eager - fused).abs().max().item()
        scale = max(1.0, eager.abs().max().item())
        if not (deviation / scale < tolerance):
            raise RuntimeError(
                f"compiled profile {profile_id} deviates from eager by "
                f"{deviation:.3e} (relative {deviation / scale:.3e}) for method {method_id}"
            )
        print(f"  compile check {profile_id}: max deviation {deviation:.3e}")


def parse_methods(text: str, registry: dict[str, dict], skip: str = "") -> list[str]:
    if text.strip().lower() in {"default", "all"}:
        methods = list(registry)
    else:
        methods = [value.strip() for value in text.split(",") if value.strip()]
        unknown = [method for method in methods if method not in registry]
        if unknown:
            raise ValueError(f"unknown methods: {unknown}; available: {list(registry)}")
    skipped = {value.strip() for value in skip.split(",") if value.strip()}
    methods = [method for method in methods if method not in skipped or method == "native"]
    if "native" not in methods:
        methods.insert(0, "native")
    return methods


SUMMARY_FIELDS = [
    "method",
    "display_name",
    "degree_schedule",
    "implementation",
    "status",
    "seconds",
    "valid_fraction",
    "invalid_examples",
    "primary_metric",
    "primary_delta_pp_vs_native",
    "primary_strict_delta_pp_vs_native",
    "acc_strict",
    "acc_norm_strict",
    "acc_norm",
    "acc_norm_delta_pp_vs_native",
    "acc",
    "acc_token_norm",
    "nll",
    "flips_vs_reference",
    "mcnemar_to_wrong",
    "mcnemar_to_right",
    "mcnemar_discordant",
    "mcnemar_p",
    "mcnemar_test",
    "token_nll",
    "token_nll_shared",
    "reference_token_nll_shared",
    "perplexity",
    "perplexity_delta_pct",
    "delta_token_nll",
    "delta_token_nll_ci_low",
    "delta_token_nll_ci_high",
    "delta_token_nll_p",
    "delta_window_mean_nll",
    "delta_window_mean_nll_p",
    "bootstrap_windows",
    "scored_tokens",
    "minimum_detectable_effect_pp",
    "kl_reference_to_method",
    "agreement_acc_norm",
    "agreement_acc",
    "max_prob_shift",
    "activation_input_count",
    "activation_max_abs_input",
    "range_violation_count",
    "range_violation_fraction",
    "method_domain_violation_count",
    "method_domain_violation_fraction",
    "activation_nonfinite_count",
    "activation_cast_overflow_count",
    "activation_max_abs_finite_output",
    "activation_max_abs_finite_output_before_cast",
    "activation_padded_positions",
    "truncated_candidate_sequences",
    "truncated_continuations",
]


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Evaluate SPA variants and the NEXUS/MOAI/Euston GELU reconstructions "
            "on a task using one calibration-derived static per-channel range plan."
        )
    )
    parser.add_argument("--task", default="hellaswag")
    parser.add_argument("--model-path", required=True)
    parser.add_argument("--range-plan", type=Path, required=True)
    parser.add_argument("--profile-catalog", type=Path, required=True)
    parser.add_argument("--methods", default="default")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--split", default="", help="Defaults to the task's evaluation split.")
    parser.add_argument("--prompt-style", default="plain", choices=["plain", "chat"])
    parser.add_argument("--max-samples", type=int, default=0, help="0 uses the whole split.")
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument(
        "--max-batch-tokens",
        type=int,
        default=16384,
        help=(
            "Cap on rows x padded length per batch (0 = none). Bounds the logits tensor: "
            "with Gemma's 262k vocabulary, 16384 tokens is 8 GiB of bf16 logits. A batch "
            "that still runs out of memory is split in halves and retried automatically."
        ),
    )
    parser.add_argument("--max-length", type=int, default=1024)
    parser.add_argument(
        "--logit-chunk",
        type=int,
        default=256,
        help="Time slice for the log-softmax; lower it if memory is tight.",
    )
    parser.add_argument(
        "--no-stats",
        action="store_true",
        help=(
            "Skip activation auditing. Faster, but range violations go unreported. "
            "Padded positions still receive the reference activation."
        ),
    )
    parser.add_argument(
        "--compile-activation",
        default="off",
        choices=list(COMPILE_MODES),
        help=(
            "Fuse the Clenshaw recurrence into one Triton kernel. 'off' keeps "
            "the eager path bit-for-bit. Expect a large speedup on high-degree "
            "methods, at the cost of a one-off compile per profile."
        ),
    )
    parser.add_argument(
        "--target",
        default="tanh",
        choices=sorted(TARGET_TORCH_APPROXIMATE),
        help=(
            "Reference GELU form. 'tanh': the model's gelu_pytorch_tanh (default). "
            "'erf': substitute the exact erf-GELU for the model's activation and use it as "
            "the reference; the catalog must have been generated with --target erf."
        ),
    )
    parser.add_argument(
        "--skip-methods",
        default="",
        help="Comma-separated method ids to leave out (e.g. euston for the erf-target run).",
    )
    parser.add_argument(
        "--activation-dtype",
        default="float32",
        choices=list(ACTIVATION_DTYPES),
        help=(
            "Precision of the swapped activation (native stays bf16). Must match the "
            "catalog's --eval-dtype: NEXUS's gate power is chosen for it."
        ),
    )
    parser.add_argument(
        "--verify-compile",
        action="store_true",
        help="Compare compiled and eager output per profile before scoring.",
    )
    parser.add_argument(
        "--shared-prompt",
        default="off",
        choices=["off", "auto"],
        help=(
            "Score single-token candidates that share a context with one "
            "forward pass instead of one per candidate. Exact for a causal "
            "model. Applies to MMLU (~4x fewer sequences); HellaSwag, "
            "ARC-Challenge and any partial-evaluation task are ineligible."
        ),
    )
    parser.add_argument(
        "--loss-impl",
        default="logsoftmax",
        choices=["logsoftmax", "cross_entropy"],
        help=(
            "'cross_entropy' avoids materialising a full float32 log_softmax "
            "and roughly halves peak logit memory."
        ),
    )
    parser.add_argument(
        "--hf-source",
        default="",
        help=(
            "Override the Hub repo for this task, as repo[:config], "
            "comma-separated for several candidates in order. Use when a "
            "canonical repo still ships a loading script or goes offline."
        ),
    )
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    if not torch.cuda.is_available():
        raise RuntimeError("a CUDA GPU is required")

    set_seed(args.seed)
    set_activation_dtype(args.activation_dtype)
    set_activation_target(args.target)
    if args.hf_source:
        set_source_override(args.task, args.hf_source)
    task = get_task(args.task)
    split = args.split or task.eval_split
    model_path = resolve_model_path(args.model_path)

    for label, path in (("range plan", args.range_plan), ("profile catalog", args.profile_catalog)):
        if not path.exists():
            raise SystemExit(
                f"{label} not found: {path}\n"
                f"Run the calibration and planning stages for {args.task!r} first:\n"
                f"  TASKS={args.task!r} bash run_all_tasks.sh\n"
                "If you moved the working tree, copy results/ across as well; the "
                "plans are not regenerated automatically."
            )
    plan = json.loads(args.range_plan.read_text())
    catalog = json.loads(args.profile_catalog.read_text())
    if plan.get("validation_accessed", True):
        raise RuntimeError("range plan is not validation-independent")
    if catalog["range_plan_sha256"] != hashlib.sha256(args.range_plan.read_bytes()).hexdigest():
        raise RuntimeError("profile catalog was generated from a different range plan")
    catalog_target = catalog.get("activation_target", "tanh")
    if catalog_target != args.target:
        raise RuntimeError(
            f"profile catalog was generated for --target {catalog_target} but this run uses "
            f"--target {args.target}; regenerate with generate_method_profiles.py --target {args.target}"
        )
    catalog_dtype = catalog.get("evaluation_dtype", "float32")
    if catalog_dtype != args.activation_dtype:
        raise RuntimeError(
            f"profile catalog was generated for {catalog_dtype} but --activation-dtype is "
            f"{args.activation_dtype}; regenerate with --eval-dtype {args.activation_dtype}"
        )

    registry = method_registry(catalog)
    methods = parse_methods(args.methods, registry, args.skip_methods)
    collect_stats = not args.no_stats

    tokenizer = AutoTokenizer.from_pretrained(model_path, local_files_only=True)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "right"

    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        dtype=torch.bfloat16,
        local_files_only=True,
        attn_implementation="sdpa",
    )
    model.eval().cuda()
    model.config.use_cache = False
    model_activation = activation_name(model)
    if model_activation not in SUPPORTED_MODEL_ACTIVATIONS:
        raise RuntimeError(
            f"this harness expects a tanh-GELU model but the hidden activation is "
            f"{model_activation!r}"
        )
    if args.target == "erf":
        print("target erf: the exact erf-GELU replaces the model's activation and is the reference "
              "(id 'native', displayed as Exact-erf); the original model is 'native-tanh' and the "
              "same-precision tanh control is 'exact-tanh'")
    proxies = install_proxies(model)
    print(f"activation sites: {len(proxies)} text-decoder MLPs, model activation {model_activation}")

    examples = task.loader(split, args.max_samples, args.seed)
    records, truncated, max_choices, shared_examples = build_records(
        tokenizer,
        examples,
        choice_prefix=task.choice_prefix,
        max_length=args.max_length,
        prompt_style=args.prompt_style,
        system_prompt=task.chat_system_prompt,
        shared_prompt=args.shared_prompt == "auto",
    )
    gold = np.array([example.gold for example in examples], dtype=np.int64)
    choice_mask, scored_tokens, scored_bytes = choice_geometry(
        records, len(examples), max_choices
    )
    print(
        f"task={task.name} split={split} examples={len(examples)} "
        f"choices<={max_choices} sequences={len(records)} truncated[{truncated}]"
    )
    if truncated.continuations:
        share = 100.0 * truncated.continuations / max(1, len(records))
        print(
            f"  NOTE: {truncated.continuations} candidate(s) ({share:.2f}%) were longer "
            f"than --max-length {args.max_length} and were shortened. Every method "
            "scores the same tokens, so the paired comparison holds, but raise "
            "--max-length if this is more than a handful."
        )
    if args.shared_prompt == "auto":
        eligible = 100.0 * shared_examples / max(1, len(examples))
        print(
            f"shared-prompt fast path: {shared_examples}/{len(examples)} examples "
            f"({eligible:.1f}%), {len(examples) * max_choices - len(records)} "
            "sequences avoided"
        )

    args.output_dir.mkdir(parents=True, exist_ok=True)

    def _write_metadata() -> None:
        """Write run provenance. Shared by the MCQ and LM output paths."""
        metadata = {
            "protocol": "A",
            "task": task.name,
            "evaluation_split": split,
            "calibration_split": task.calibration_split,
            "prompt_style": args.prompt_style,
            "shots": 0,
            "training": "none (zero-shot, released weights)",
            "model": model_path,
            "model_activation": model_activation,
            "activation_target": args.target,
            "group_names": (
                {"native": "Native-tanh", "exact": "Exact-tanh"} if args.target == "tanh"
                else {"native": "Exact-erf", "native-tanh": "Native-tanh", "exact-tanh": "Exact-tanh"}
            ),
            "reference_activation": (
                "model act_fn (gelu_pytorch_tanh, bf16)" if args.target == "tanh"
                else f"Exact-erf: erf-GELU substituted for {model_activation}, computed in {args.activation_dtype} and cast back"
            ),
            "catalog_target": catalog.get("target"),
            "activation_dtype": args.activation_dtype,
            "batch_size": args.batch_size,
            "max_batch_tokens": args.max_batch_tokens,
            "oom_backoff_events": list(OOM_BACKOFF_EVENTS),
            "activation_sites": (
                "text-decoder gated-MLP act_fn only; per-layer-input gate GELU, attention "
                "and norms stay native"
            ),
            "activation_site_count": len(proxies),
            "validation_used_for_range_or_degree_selection": False,
            "range_assignment": "static-per-channel",
            "primary_metric": task.primary_metric,
            "task_kind": task.kind,
            "activation_stats_masked_to_real_tokens": True,
            "padded_positions": "reference GELU (swapped activation applied to real tokens only)",
            "nonfinite_audit": "on the tensor after casting back to the model dtype",
            "ranges": plan["ranges"],
            "methods": methods,
            "profile_catalog": str(args.profile_catalog.resolve()),
            "examples": len(examples),
            "candidate_sequences": len(records),
            "truncated_prompts": truncated.prompts,
            "truncated_continuations": truncated.continuations,
            "oracle_or_clipping": False,
            "activation_stats_collected": collect_stats,
            "compile_activation": args.compile_activation,
            "loss_impl": args.loss_impl,
            "shared_prompt": args.shared_prompt,
            "shared_prompt_examples": shared_examples,
        }
        (args.output_dir / "metadata.json").write_text(json.dumps(metadata, indent=2))

    print(f"saved: {args.output_dir / 'predictions.csv'}")

    summaries: list[dict] = []
    stored: dict[str, dict] = {}
    reference: dict | None = None
    native_primary = float("nan")
    native_acc_norm = float("nan")
    native_strict = float("nan")
    chunks = batch_count(records, args.batch_size, args.max_batch_tokens)

    for method_id in methods:
        print(f"\n=== {registry[method_id]['display_name']} ({method_id}) ===")
        set_method(
            proxies, method_id, registry, catalog, plan, collect_stats, args.compile_activation
        )
        if args.verify_compile and args.compile_activation != "off":
            verify_compiled_profiles(method_id)

        started = time.time()
        progress = tqdm(total=chunks, desc="scoring", leave=False)
        scores = score_records(
            model,
            records,
            example_count=len(examples),
            max_choices=max_choices,
            batch_size=args.batch_size,
            max_batch_tokens=args.max_batch_tokens,
            pad_id=tokenizer.pad_token_id,
            logit_chunk=args.logit_chunk,
            loss_impl=args.loss_impl,
            on_batch=TOKEN_MASK.set,
            progress=progress,
        )
        progress.close()
        elapsed = time.time() - started

        if task.kind == "lm":
            metrics, state = compute_lm_metrics(
                scores,
                scored_tokens,
                reference=None if method_id == "native" else reference,
                seed=args.seed,
            )
        else:
            metrics, state = compute_metrics(
                scores,
                gold,
                choice_mask,
                scored_tokens,
                scored_bytes,
                primary_metric=task.primary_metric,
                reference=None if method_id == "native" else reference,
            )

        if method_id == "native":
            reference = state
            native_primary = float(metrics[task.primary_metric])
            if task.kind == "lm":
                metrics["delta_token_nll"] = 0.0
                metrics["delta_token_nll_ci_low"] = 0.0
                metrics["delta_token_nll_ci_high"] = 0.0
                metrics["delta_token_nll_p"] = 1.0
                metrics["delta_window_mean_nll"] = 0.0
                metrics["delta_window_mean_nll_p"] = 1.0
                metrics["perplexity_delta_pct"] = 0.0
                metrics["reference_token_nll_shared"] = native_primary
                metrics["token_nll_shared"] = native_primary
            native_acc_norm = float(metrics["acc_norm"])
            native_strict = native_primary
            metrics["kl_reference_to_method"] = 0.0
            metrics["max_prob_shift"] = 0.0
            metrics["flips_vs_reference"] = 0
            metrics["mcnemar_to_wrong"] = 0
            metrics["mcnemar_to_right"] = 0
            metrics["mcnemar_discordant"] = 0
            metrics["mcnemar_p"] = 1.0
            metrics["mcnemar_test"] = "reference run"
            for name in ("acc", "acc_norm", "acc_token_norm"):
                metrics[f"agreement_{name}"] = 1.0

        metrics.update(runtime_stats(proxies))
        nonfinite = int(metrics.get("activation_nonfinite_count", 0) or 0)
        if nonfinite or metrics.get("invalid_examples"):
            print(
                f"  WARNING: {method_id} produced {nonfinite} non-finite activations "
                f"on real tokens and lost {metrics.get('invalid_examples', 0)} examples. "
                "Accuracy below excludes them, which favours the method; "
                "acc_strict counts them as wrong."
            )
        metrics["method"] = method_id
        metrics["seconds"] = round(elapsed, 2)
        metrics["display_name"] = registry[method_id]["display_name"]
        metrics["degree_schedule"] = registry[method_id].get("degree_schedule", "")
        metrics["implementation"] = registry[method_id].get(
            "implementation",
            "proposed SPA degree variant" if method_id.startswith("spa-k") else "control",
        )
        primary = float(metrics[task.primary_metric])
        scale = 1.0 if task.kind == "lm" else 100.0
        metrics["primary_delta_pp_vs_native"] = (
            scale * (primary - native_primary) if np.isfinite(primary) else float("nan")
        )
        norm = float(metrics["acc_norm"])
        metrics["acc_norm_delta_pp_vs_native"] = (
            100.0 * (norm - native_acc_norm)
            if np.isfinite(norm) and np.isfinite(native_acc_norm)
            else float("nan")
        )
        # Excluding examples a method destroyed biases its accuracy upward,
        # since those are precisely where it failed. Report both.
        invalid = int(metrics.get("invalid_examples", 0) or 0)
        for name in () if task.kind == "lm" else ("acc", "acc_norm", "acc_token_norm"):
            value = float(metrics[name])
            metrics[f"{name}_strict"] = (
                value * (len(examples) - invalid) / len(examples)
                if np.isfinite(value)
                else float("nan")
            )
        if task.kind == "lm":
            metrics["primary_strict_delta_pp_vs_native"] = float("nan")
        else:
            strict = float(metrics[f"{task.primary_metric}_strict"])
            metrics["primary_strict_delta_pp_vs_native"] = (
                100.0 * (strict - native_strict) if np.isfinite(strict) else float("nan")
            )
        metrics["minimum_detectable_effect_pp"] = minimum_detectable_effect(
            len(examples), int(metrics.get("flips_vs_reference", 0) or 0)
        )
        metrics["truncated_candidate_sequences"] = truncated.prompts
        metrics["truncated_continuations"] = truncated.continuations

        summaries.append(metrics)
        stored[method_id] = {"scores": scores, "state": state}
        printable = {key: metrics.get(key) for key in SUMMARY_FIELDS if key in metrics}
        print(json.dumps(printable, indent=2, default=str))

    with (args.output_dir / "summary.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=SUMMARY_FIELDS)
        writer.writeheader()
        for row in summaries:
            writer.writerow({key: row.get(key, "") for key in SUMMARY_FIELDS})

    if task.kind == "lm":
        with (args.output_dir / "predictions.csv").open("w", newline="") as handle:
            fields = ["index", "key", "scored_tokens"] + [
                f"{method_id}_{suffix}"
                for method_id in methods
                for suffix in ("total_logprob", "nll_per_token")
            ]
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader()
            for index, example in enumerate(examples):
                row: dict[str, object] = {
                    "index": index,
                    "key": example.key,
                    "scored_tokens": int(scored_tokens[index, 0]),
                }
                for method_id in methods:
                    result = stored[method_id]
                    row[f"{method_id}_total_logprob"] = result["scores"][index, 0]
                    row[f"{method_id}_nll_per_token"] = result["state"]["per_window_nll"][index]
                writer.writerow(row)
        _write_metadata()
        print(f"\nsaved: {args.output_dir / 'summary.csv'}")
        print(f"saved: {args.output_dir / 'predictions.csv'}")
        return

    prediction_fields = ["index", "key", "gold", "n_choices"]
    for method_id in methods:
        prediction_fields.append(f"{method_id}_pred")
        prediction_fields.append(f"{method_id}_pred_raw")
        for choice in range(max_choices):
            prediction_fields.append(f"{method_id}_score_{choice}")
            prediction_fields.append(f"{method_id}_p_{choice}")

    with (args.output_dir / "predictions.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=prediction_fields)
        writer.writeheader()
        for index, example in enumerate(examples):
            row: dict[str, object] = {
                "index": index,
                "key": example.key,
                "gold": example.gold,
                "n_choices": len(example.choices),
            }
            for method_id in methods:
                result = stored[method_id]
                row[f"{method_id}_pred"] = int(
                    result["state"]["predictions"][task.primary_metric][index]
                )
                row[f"{method_id}_pred_raw"] = int(result["state"]["predictions"]["acc"][index])
                for choice in range(max_choices):
                    row[f"{method_id}_score_{choice}"] = result["scores"][index, choice]
                    row[f"{method_id}_p_{choice}"] = result["state"]["probabilities"][index, choice]
            writer.writerow(row)

    _write_metadata()
    print(f"\nsaved: {args.output_dir / 'summary.csv'}")
    print(f"saved: {args.output_dir / 'predictions.csv'}")


if __name__ == "__main__":
    main()
