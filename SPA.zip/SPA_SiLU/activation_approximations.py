from __future__ import annotations

import torch


def chebval(x: torch.Tensor, coefficients: torch.Tensor) -> torch.Tensor:
    """Evaluate a first-kind Chebyshev series with Clenshaw recurrence."""
    if coefficients.numel() == 1:
        return torch.zeros_like(x) + coefficients[0]

    next_value = torch.zeros_like(x)
    next_next_value = torch.zeros_like(x)
    for index in range(coefficients.numel() - 1, 0, -1):
        value = 2.0 * x * next_value - next_next_value + coefficients[index]
        next_next_value, next_value = next_value, value
    return x * next_value - next_next_value + coefficients[0]
