"""Tokenisation, batched candidate scoring and N-way metrics.

Scoring machinery shared by every task:

* candidates are variable in number and length, not a fixed pair;
* batches are padded with an attention mask instead of requiring every
  sequence in a batch to share an exact length;
* log-softmax is chunked over time so long prompts do not materialise a
  full float32 copy of the logits;
* accuracy is reported raw, byte-normalised and token-normalised,
  because candidate continuations differ in length;
* every method is compared to the reference run with a paired McNemar
  test rather than an independent confidence interval.
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from typing import NamedTuple

import numpy as np
import torch

from paired_stats import (
    exact_two_sided_binomial,
    mcnemar,
    minimum_detectable_effect,
    paired_bootstrap,
    paired_ratio_bootstrap,
)

# Re-exported so callers keep a single import site for the harness.
__all__ = [
    "PROMPT_STYLES",
    "build_records",
    "choice_geometry",
    "compute_metrics",
    "encode_pair_chat",
    "encode_pair_plain",
    "exact_two_sided_binomial",
    "compute_lm_metrics",
    "mcnemar",
    "minimum_detectable_effect",
    "paired_bootstrap",
    "score_records",
    "sequence_logprob",
    "set_seed",
    "Truncation",
    "fit_to_budget",
]

PROMPT_STYLES = ("plain", "chat")


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


# --------------------------------------------------------------------------
# Tokenisation
# --------------------------------------------------------------------------


def encode_pair_plain(
    tokenizer,
    context: str,
    continuation: str,
) -> tuple[list[int], list[int]]:
    """Split ``context + continuation`` into prompt and scored tokens.

    Encoding the two pieces separately can disagree with encoding the
    concatenation when the boundary merges into one token, so the split
    is taken from the joint encoding and verified.
    """
    context_ids = tokenizer.encode(context, add_special_tokens=True)
    joint_ids = tokenizer.encode(context + continuation, add_special_tokens=True)

    boundary = len(context_ids)
    if joint_ids[:boundary] != context_ids:
        # Boundary merge: back off to the longest shared prefix.
        boundary = 0
        limit = min(len(context_ids), len(joint_ids))
        while boundary < limit and joint_ids[boundary] == context_ids[boundary]:
            boundary += 1

    if boundary >= len(joint_ids):
        raise ValueError(
            "continuation produced no scored tokens for context "
            f"{context[:80]!r} / continuation {continuation[:40]!r}"
        )
    return joint_ids[:boundary], joint_ids[boundary:]


def encode_pair_chat(
    tokenizer,
    context: str,
    continuation: str,
    system_prompt: str,
) -> tuple[list[int], list[int]]:
    """Chat-template variant (the instruction-tuned model's own format)."""
    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.append({"role": "user", "content": context})

    prompt_ids = tokenizer.apply_chat_template(
        messages, tokenize=True, add_generation_prompt=True
    )
    joint_ids = tokenizer.apply_chat_template(
        messages + [{"role": "assistant", "content": continuation.strip()}],
        tokenize=True,
        add_generation_prompt=False,
    )
    if len(joint_ids) > len(prompt_ids) and joint_ids[: len(prompt_ids)] == prompt_ids:
        return prompt_ids, joint_ids[len(prompt_ids) :]

    suffix = tokenizer.encode(continuation.strip(), add_special_tokens=False)
    if tokenizer.eos_token_id is not None:
        suffix = suffix + [tokenizer.eos_token_id]
    return prompt_ids, suffix


class Truncation(NamedTuple):
    """How many sequences had to be trimmed, by which part was trimmed."""

    prompts: int = 0
    continuations: int = 0

    def __str__(self) -> str:
        return f"prompts={self.prompts} continuations={self.continuations}"

    def __add__(self, other: "Truncation") -> "Truncation":
        return Truncation(
            self.prompts + other.prompts, self.continuations + other.continuations
        )


def fit_to_budget(
    prompt_ids: list[int],
    continuation_ids: list[int],
    max_length: int,
    head: int = 64,
) -> tuple[list[int], list[int], Truncation]:
    """Fit a prompt and its scored continuation into ``max_length``.

    The continuation is what gets scored, so the prompt yields first,
    keeping its start and the part adjacent to the answer.

    If the continuation alone overflows the budget it is trimmed from the
    right rather than raising. A handful of PIQA solutions run past 500
    tokens, and aborting a 16,000-example calibration over one outlier is
    worse than scoring a shortened candidate: every method sees the
    identical token sequence, so the paired comparison stays valid even
    though that item's absolute score does not match an untruncated run.
    Counts are reported so a large number is never silently absorbed.
    """
    if max_length < 2:
        raise ValueError(f"max_length={max_length} is too small to score anything")

    if len(continuation_ids) >= max_length:
        return prompt_ids[:1], continuation_ids[: max_length - 1], Truncation(1, 1)

    budget = max_length - len(continuation_ids)
    if len(prompt_ids) <= budget:
        return prompt_ids, continuation_ids, Truncation(0, 0)

    keep_head = min(head, max(1, budget // 5))
    keep_tail = budget - keep_head
    # ``prompt_ids[-0:]`` is the whole prompt, not an empty tail.
    tail_ids = prompt_ids[-keep_tail:] if keep_tail > 0 else []
    fitted = prompt_ids[:keep_head] + tail_ids
    if len(fitted) + len(continuation_ids) > max_length:
        raise RuntimeError(
            f"truncation produced {len(fitted) + len(continuation_ids)} tokens "
            f"for a budget of {max_length}"
        )
    return fitted, continuation_ids, Truncation(1, 0)


@dataclass
class Record:
    """One scoring unit.

    Normally one (example, choice) pair. When every candidate for an
    example is a single token and they all share one context, the record
    instead covers all of them: the prompt is run once and the candidate
    log-probabilities are read off the final position. That is exact for
    a causal model, since logits at the last prompt position cannot
    depend on tokens appended after it.
    """

    example: int
    choice: int
    input_ids: list[int]
    labels: list[int]
    length: int
    scored_tokens: int
    scored_bytes: int
    shared_choices: list[int] | None = None
    shared_tokens: list[int] | None = None
    shared_bytes: list[int] | None = None

    @property
    def is_shared(self) -> bool:
        return self.shared_choices is not None


def build_records(
    tokenizer,
    examples,
    choice_prefix: str,
    max_length: int,
    prompt_style: str = "plain",
    system_prompt: str = "",
    shared_prompt: bool = False,
) -> tuple[list[Record], Truncation, int, int]:
    """Tokenise every (example, choice) pair.

    Returns the records, a ``Truncation`` count, the maximum number of
    choices seen (counts may vary per example), and how many examples took
    the shared-prompt fast path.
    """
    if prompt_style not in PROMPT_STYLES:
        raise ValueError(f"prompt_style must be one of {PROMPT_STYLES}")

    records: list[Record] = []
    truncated = Truncation()
    max_choices = 0
    shared_examples = 0

    for example_index, example in enumerate(examples):
        max_choices = max(max_choices, len(example.choices))
        pending: list[Record] = []
        for choice_index, choice in enumerate(example.choices):
            continuation = f"{choice_prefix}{choice}"
            # A partial-evaluation task substitutes the option into the
            # context, so the context can differ per choice.
            context = example.context_for(choice_index)
            if prompt_style == "plain":
                prompt_ids, continuation_ids = encode_pair_plain(
                    tokenizer, context, continuation
                )
            else:
                prompt_ids, continuation_ids = encode_pair_chat(
                    tokenizer, context, continuation, system_prompt
                )

            prompt_ids, continuation_ids, trimmed = fit_to_budget(
                prompt_ids, continuation_ids, max_length
            )
            truncated = truncated + trimmed
            if trimmed.continuations:
                # The byte normaliser must describe what was actually
                # scored, not the candidate text we started from.
                continuation = tokenizer.decode(continuation_ids)
            input_ids = prompt_ids + continuation_ids
            pending.append(
                Record(
                    example=example_index,
                    choice=choice_index,
                    input_ids=input_ids,
                    labels=[-100] * len(prompt_ids) + continuation_ids,
                    length=len(input_ids),
                    scored_tokens=len(continuation_ids),
                    # Byte length of the continuation *text* is the
                    # normaliser used by the standard HellaSwag protocol.
                    scored_bytes=max(1, len(continuation.encode("utf-8"))),
                )
            )

        collapsed = _collapse_shared_prompt(pending) if shared_prompt else None
        if collapsed is None:
            records.extend(pending)
        else:
            records.append(collapsed)
            shared_examples += 1

    return records, truncated, max_choices, shared_examples


def _collapse_shared_prompt(pending: list[Record]) -> Record | None:
    """Merge an example's records into one prompt-only record, if eligible.

    Requires every candidate to be exactly one token and every candidate
    to share an identical prompt. Tasks whose option sits in the context
    and tasks with multi-token answers (HellaSwag, ARC-Challenge) are
    ineligible and fall through unchanged.
    """
    if len(pending) < 2:
        return None
    if any(record.scored_tokens != 1 for record in pending):
        return None
    prompt_length = pending[0].length - 1
    prompt = pending[0].input_ids[:prompt_length]
    for record in pending[1:]:
        if record.length - 1 != prompt_length or record.input_ids[:prompt_length] != prompt:
            return None
    return Record(
        example=pending[0].example,
        choice=-1,
        input_ids=prompt,
        labels=[-100] * prompt_length,
        length=prompt_length,
        scored_tokens=1,
        scored_bytes=1,
        shared_choices=[record.choice for record in pending],
        shared_tokens=[record.input_ids[-1] for record in pending],
        shared_bytes=[record.scored_bytes for record in pending],
    )


# --------------------------------------------------------------------------
# Scoring
# --------------------------------------------------------------------------


def sequence_logprob(
    logits: torch.Tensor,
    labels: torch.Tensor,
    chunk: int = 256,
    impl: str = "logsoftmax",
) -> torch.Tensor:
    """Summed conditional log-likelihood per sequence.

    Work is sliced along time so peak float32 memory is
    ``batch * chunk * vocab`` rather than the whole logit tensor.

    ``impl="logsoftmax"`` is the reference path. ``impl="cross_entropy"``
    computes the same quantity through the fused kernel, which never
    materialises the log-softmax output and so roughly halves peak logit
    memory. Both upcast to float32 before the reduction, so they agree to
    floating-point noise.
    """
    if impl not in {"logsoftmax", "cross_entropy"}:
        raise ValueError(f"unknown loss impl {impl!r}")

    batch, time, vocab = logits.shape
    shift_labels = labels[:, 1:]
    mask = shift_labels.ne(-100)
    total = torch.zeros(batch, dtype=torch.float32, device=logits.device)

    for start in range(0, time - 1, chunk):
        stop = min(start + chunk, time - 1)
        slice_logits = logits[:, start:stop, :].float()
        slice_labels = shift_labels[:, start:stop]
        slice_mask = mask[:, start:stop]

        if impl == "cross_entropy":
            negative_logp = torch.nn.functional.cross_entropy(
                slice_logits.reshape(-1, vocab),
                slice_labels.reshape(-1),
                reduction="none",
                ignore_index=-100,
            ).view(slice_labels.shape)
            token_logp = -negative_logp
        else:
            safe_labels = slice_labels.masked_fill(~slice_mask, 0)
            token_logp = (
                torch.log_softmax(slice_logits, dim=-1)
                .gather(-1, safe_labels.unsqueeze(-1))
                .squeeze(-1)
            )
        # Unscored positions are excluded by selection, never by
        # multiplying with zero: a NaN logit at a prompt or padded position
        # would survive ``NaN * 0`` and contaminate the sequence total. A
        # NaN at a scored position is a real failure and is kept.
        total = total + torch.where(slice_mask, token_logp, torch.zeros_like(token_logp)).sum(dim=-1)
    return total


@torch.inference_mode()
def score_records(
    model,
    records: list[Record],
    example_count: int,
    max_choices: int,
    batch_size: int,
    pad_id: int,
    logit_chunk: int = 256,
    loss_impl: str = "logsoftmax",
    on_batch=None,
    progress=None,
) -> np.ndarray:
    """Score every record, returning ``[examples, max_choices]`` log-likelihoods.

    Records are sorted by length before batching so that padding stays
    small; the attention mask keeps padded positions out of the model.
    """
    scores = np.full((example_count, max_choices), np.nan, dtype=np.float64)
    device = next(model.parameters()).device

    # Shared-prompt records use a different reduction, so they are batched
    # separately rather than mixed in.
    groups = [
        [r for r in records if not r.is_shared],
        [r for r in records if r.is_shared],
    ]
    order: list[Record] = []
    boundaries: list[int] = []
    for group in groups:
        group.sort(key=lambda record: record.length)
        for start in range(0, len(group), batch_size):
            boundaries.append(len(order))
            order.extend(group[start : start + batch_size])
    boundaries.append(len(order))

    for index in range(len(boundaries) - 1):
        chunk = order[boundaries[index] : boundaries[index + 1]]
        if not chunk:
            continue
        width = max(record.length for record in chunk)
        input_ids = torch.full((len(chunk), width), pad_id, dtype=torch.long)
        labels = torch.full((len(chunk), width), -100, dtype=torch.long)
        attention = torch.zeros((len(chunk), width), dtype=torch.long)
        for row, record in enumerate(chunk):
            span = record.length
            input_ids[row, :span] = torch.tensor(record.input_ids, dtype=torch.long)
            labels[row, :span] = torch.tensor(record.labels, dtype=torch.long)
            attention[row, :span] = 1

        input_ids = input_ids.to(device)
        labels = labels.to(device)
        attention = attention.to(device)

        if on_batch is not None:
            # Publish the token mask so activation auditing can exclude
            # padding, matching how calibration collects its statistics.
            on_batch(attention)

        with torch.autocast("cuda", dtype=torch.bfloat16):
            logits = model(
                input_ids=input_ids,
                attention_mask=attention,
                use_cache=False,
            ).logits

        if chunk[0].is_shared:
            # One forward per example: read the candidate log-probabilities
            # off the final prompt position.
            rows = torch.arange(len(chunk), device=device)
            positions = torch.tensor(
                [record.length - 1 for record in chunk], device=device
            )
            final = torch.log_softmax(logits[rows, positions, :].float(), dim=-1)
            widest = max(len(record.shared_tokens) for record in chunk)
            candidates = torch.zeros((len(chunk), widest), dtype=torch.long)
            for row, record in enumerate(chunk):
                candidates[row, : len(record.shared_tokens)] = torch.tensor(
                    record.shared_tokens, dtype=torch.long
                )
            values = final.gather(1, candidates.to(device)).cpu().numpy()
            for row, record in enumerate(chunk):
                for slot, choice in enumerate(record.shared_choices):
                    scores[record.example, choice] = float(values[row, slot])
        else:
            values = (
                sequence_logprob(logits, labels, chunk=logit_chunk, impl=loss_impl)
                .cpu()
                .numpy()
            )
            for record, value in zip(chunk, values):
                scores[record.example, record.choice] = float(value)
        if on_batch is not None:
            on_batch(None)
        if progress is not None:
            progress.update(1)

    return scores


def batch_count(records: list[Record], batch_size: int) -> int:
    shared = sum(1 for record in records if record.is_shared)
    standard = len(records) - shared
    return -(-standard // batch_size) + -(-shared // batch_size)


# --------------------------------------------------------------------------
# Metrics
# --------------------------------------------------------------------------


def choice_geometry(
    records: list[Record],
    example_count: int,
    max_choices: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Per-(example, choice) validity mask, token counts and byte counts."""
    mask = np.zeros((example_count, max_choices), dtype=bool)
    tokens = np.ones((example_count, max_choices), dtype=np.float64)
    byte_lengths = np.ones((example_count, max_choices), dtype=np.float64)
    for record in records:
        if record.is_shared:
            for choice, size in zip(record.shared_choices, record.shared_bytes):
                mask[record.example, choice] = True
                tokens[record.example, choice] = 1.0
                byte_lengths[record.example, choice] = max(1, size)
            continue
        mask[record.example, record.choice] = True
        tokens[record.example, record.choice] = max(1, record.scored_tokens)
        byte_lengths[record.example, record.choice] = max(1, record.scored_bytes)
    return mask, tokens, byte_lengths


def _masked_argmax(values: np.ndarray, mask: np.ndarray) -> np.ndarray:
    return np.where(mask, values, -np.inf).argmax(axis=1)


def _masked_softmax(scores: np.ndarray, mask: np.ndarray) -> np.ndarray:
    with np.errstate(invalid="ignore", divide="ignore", over="ignore"):
        shifted = np.where(mask, scores, -np.inf)
        shifted = shifted - np.nanmax(shifted, axis=1, keepdims=True)
        weights = np.where(mask, np.exp(shifted), 0.0)
        total = weights.sum(axis=1, keepdims=True)
        return weights / total


def compute_metrics(
    scores: np.ndarray,
    gold: np.ndarray,
    choice_mask: np.ndarray,
    scored_tokens: np.ndarray,
    scored_bytes: np.ndarray,
    primary_metric: str = "acc_norm",
    reference: dict | None = None,
) -> tuple[dict, dict]:
    """Metrics for one method, plus the state a later method compares against."""
    gold = np.asarray(gold, dtype=np.int64)
    finite = np.where(choice_mask, np.isfinite(scores), True).all(axis=1)

    rules = {
        "acc": scores,
        "acc_norm": np.divide(scores, scored_bytes, where=choice_mask, out=np.full_like(scores, np.nan)),
        "acc_token_norm": np.divide(scores, scored_tokens, where=choice_mask, out=np.full_like(scores, np.nan)),
    }
    if primary_metric not in rules:
        raise ValueError(f"primary_metric must be one of {sorted(rules)}")

    predictions = {
        name: np.where(finite, _masked_argmax(values, choice_mask), -1)
        for name, values in rules.items()
    }
    probabilities = _masked_softmax(scores, choice_mask)
    probabilities[~finite] = np.nan

    metrics: dict[str, object] = {
        "status": "ok" if finite.all() else "nonfinite",
        "valid_fraction": float(finite.mean()),
        "invalid_examples": int((~finite).sum()),
        "primary_metric": primary_metric,
    }

    if not finite.any():
        for name in rules:
            metrics[name] = float("nan")
        metrics["nll"] = float("nan")
        state = {"predictions": predictions, "probabilities": probabilities, "finite": finite}
        return metrics, state

    for name, predicted in predictions.items():
        correct = (predicted == gold) & finite
        metrics[name] = float(correct[finite].mean())

    gold_probability = probabilities[np.arange(len(gold)), gold][finite]
    metrics["nll"] = float(np.mean(-np.log(np.clip(gold_probability, 1e-30, 1.0))))

    if reference is not None:
        shared = finite & reference["finite"]
        if shared.any():
            reference_probabilities = reference["probabilities"][shared]
            current_probabilities = probabilities[shared]
            epsilon = 1e-30
            kl = np.sum(
                np.where(
                    choice_mask[shared],
                    reference_probabilities
                    * (
                        np.log(np.clip(reference_probabilities, epsilon, 1.0))
                        - np.log(np.clip(current_probabilities, epsilon, 1.0))
                    ),
                    0.0,
                ),
                axis=1,
            )
            metrics["kl_reference_to_method"] = float(np.mean(kl))
            metrics["max_prob_shift"] = float(
                np.max(np.abs(reference_probabilities - current_probabilities))
            )
            for name in rules:
                metrics[f"agreement_{name}"] = float(
                    np.mean(reference["predictions"][name][shared] == predictions[name][shared])
                )
            metrics["flips_vs_reference"] = int(
                np.sum(
                    reference["predictions"][primary_metric][shared]
                    != predictions[primary_metric][shared]
                )
            )
            metrics.update(
                mcnemar(
                    reference["predictions"][primary_metric][shared] == gold[shared],
                    predictions[primary_metric][shared] == gold[shared],
                )
            )

    state = {"predictions": predictions, "probabilities": probabilities, "finite": finite}
    return metrics, state




def compute_lm_metrics(
    scores: np.ndarray,
    scored_tokens: np.ndarray,
    reference: dict | None = None,
    bootstrap_resamples: int = 10000,
    seed: int = 20260901,
) -> tuple[dict, dict]:
    """Per-token NLL and perplexity for a language-modelling corpus.

    ``scores`` holds each window's summed log-likelihood in column 0 and
    ``scored_tokens`` its token count. The corpus figure weights windows
    by length, as a perplexity should, and so does the paired comparison:
    ``delta_token_nll`` is the difference of corpus-level token NLLs on
    the shared windows, and its interval comes from resampling paired
    windows and recomputing that ratio of sums. The equally weighted mean
    of per-window differences is a different statistic (it can even have
    the opposite sign when window lengths vary) and is reported
    separately as ``delta_window_mean_nll``.

    This is the metric that has no ceiling and no quantisation to whole
    examples, so it separates approximation profiles that every accuracy
    table reports as identical.
    """
    totals = scores[:, 0]
    counts = np.maximum(scored_tokens[:, 0], 1.0)
    finite = np.isfinite(totals)

    metrics: dict[str, object] = {
        "status": "ok" if finite.all() else "nonfinite",
        "valid_fraction": float(finite.mean()),
        "invalid_examples": int((~finite).sum()),
        "primary_metric": "token_nll",
        "scored_tokens": int(counts[finite].sum()) if finite.any() else 0,
    }
    for name in ("acc", "acc_norm", "acc_token_norm"):
        metrics[name] = float("nan")

    per_window = np.where(finite, -totals / counts, np.nan)
    state = {"per_window_nll": per_window, "finite": finite, "totals": totals}

    if not finite.any():
        metrics["token_nll"] = float("nan")
        metrics["perplexity"] = float("nan")
        metrics["nll"] = float("nan")
        return metrics, state

    token_nll = float(-totals[finite].sum() / counts[finite].sum())
    metrics["token_nll"] = token_nll
    metrics["perplexity"] = float(np.exp(min(token_nll, 700.0)))
    metrics["nll"] = token_nll

    if reference is not None:
        shared = finite & reference["finite"]
        # Per-window numerator (method NLL minus reference NLL, summed over
        # the window's tokens) and denominator (tokens).
        numerators = (-totals[shared]) - (-reference["totals"][shared])
        result = paired_ratio_bootstrap(
            numerators,
            counts[shared],
            resamples=bootstrap_resamples,
            seed=seed,
        )
        metrics["delta_token_nll"] = result["ratio"]
        metrics["delta_token_nll_ci_low"] = result["ci_low"]
        metrics["delta_token_nll_ci_high"] = result["ci_high"]
        metrics["delta_token_nll_p"] = result["p"]
        metrics["bootstrap_windows"] = result.get("units", 0)
        window_mean = paired_bootstrap(
            per_window[shared] - reference["per_window_nll"][shared],
            resamples=bootstrap_resamples,
            seed=seed,
        )
        metrics["delta_window_mean_nll"] = window_mean["mean"]
        metrics["delta_window_mean_nll_p"] = window_mean["p"]
        reference_nll = float(
            -reference["totals"][shared].sum() / counts[shared].sum()
        )
        metrics["perplexity_delta_pct"] = 100.0 * float(
            np.exp(min(token_nll - reference_nll, 700.0)) - 1.0
        )
        # When a method loses windows, its absolute token_nll sits on a
        # different sample than the reference's. The delta columns are
        # already paired on the shared subset; this exposes the base they
        # are paired against so the absolute figure stays interpretable.
        metrics["reference_token_nll_shared"] = reference_nll
        metrics["token_nll_shared"] = float(
            -totals[shared].sum() / counts[shared].sum()
        )

    return metrics, state
