"""Audit a frozen profile catalog: hash chain to the range plan, recomputed errors, evaluator reflection identity."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from numpy.polynomial.chebyshev import chebval


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description="Validate a generated activation profile catalog against its range plan.")
    parser.add_argument("--range-plan", type=Path, required=True)
    parser.add_argument("--profile-catalog", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    plan = json.loads(args.range_plan.read_text())
    catalog = json.loads(args.profile_catalog.read_text())
    errors: list[str] = []
    checks: dict[str, object] = {}

    if catalog.get("range_plan_sha256") != sha256(args.range_plan):
        errors.append("profile catalog does not match the range plan")

    labels = plan["labels"]
    radii = {label: float(plan["radii"][label]) for label in labels}
    checks["ranges"] = radii
    if labels[:2] != ["r5", "r20"]:
        errors.append(f"expected base labels r5,r20, found {labels[:2]}")

    variants = catalog["methods"]["spa"]
    if len(variants) != 3:
        errors.append(f"expected three SPA variants, found {len(variants)}")

    degrees_by_label = {label: [] for label in labels}
    spa_checks = []
    for variant in variants:
        target = float(variant["target_max_error"])
        wide_degree = int(variant["degrees"][labels[-1]])
        expected_id = f"spa-k{wide_degree}"
        if variant["id"] != expected_id:
            errors.append(f"{variant['id']} should be named {expected_id}")

        item = {
            "method": variant["id"],
            "target_max_error": target,
            "profiles": {},
        }
        for label in labels:
            profile_id = variant["profiles"][label]
            profile = catalog["profiles"][profile_id]
            degree = int(profile["degree_square"])
            degrees_by_label[label].append(degree)
            if abs(float(profile["operating_radius"]) - radii[label]) > 1e-12:
                errors.append(f"{profile_id} has the wrong radius")
            if float(profile["max_abs_error"]) > target * (1.0 + 1e-9):
                errors.append(f"{profile_id} exceeds its target error")
            coefficients = np.asarray(profile["coefficients"], dtype=np.float64)
            if len(coefficients) != degree + 1 or not np.isfinite(coefficients).all():
                errors.append(f"{profile_id} has an invalid coefficient vector")

            x = np.linspace(-radii[label], radii[label], 50001)
            t = 2.0 * (x / radii[label]) ** 2 - 1.0
            value = 0.5 * x + chebval(t, coefficients)
            reflected = 0.5 * (-x) + chebval(t, coefficients)
            identity_error = float(np.max(np.abs((value - reflected) - x)))
            if identity_error > 5e-12:
                errors.append(f"{profile_id} violates the SPA reflection identity")

            item["profiles"][label] = {
                "profile_id": profile_id,
                "degree": degree,
                "max_abs_error": profile["max_abs_error"],
                "reflection_identity_error": identity_error,
            }
        spa_checks.append(item)

    for label, degrees in degrees_by_label.items():
        if not all(a < b for a, b in zip(degrees, degrees[1:])):
            errors.append(f"SPA degrees are not strictly increasing for {label}: {degrees}")
    checks["spa_variants"] = spa_checks
    checks["spa_degrees_by_range"] = degrees_by_label

    baseline_checks = {}
    for method in ("orion", "ensi", "sylph", "thor"):
        method_spec = catalog["methods"].get(method)
        if not method_spec:
            errors.append(f"missing method {method}")
            continue
        missing = [label for label in labels if label not in method_spec["profiles"]]
        if missing:
            errors.append(f"{method} is missing profiles {missing}")
        baseline_checks[method] = method_spec["profiles"]
    checks["baseline_profiles"] = baseline_checks

    result = {
        "status": "pass" if not errors else "fail",
        "errors": errors,
        "checks": checks,
        "range_plan_sha256": sha256(args.range_plan),
        "profile_catalog_sha256": sha256(args.profile_catalog),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
