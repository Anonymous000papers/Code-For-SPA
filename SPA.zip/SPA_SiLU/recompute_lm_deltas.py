"""Recompute the language-modelling deltas of an existing run.

The paired perplexity comparison is the difference of corpus-level token
NLLs with a ratio-of-sums bootstrap (see README). The inputs it needs — each window's summed log-probability and token
count, per method — are already in ``full/predictions.csv``, so a run
does not have to be repeated to get the corrected numbers.

    python recompute_lm_deltas.py --results results/zeroshot

For every language-modelling task found, the script prints the corrected
table and rewrites the delta columns of ``full/summary.csv`` in place
(keeping a ``summary.csv.bak``), so ``pool_results.py`` picks them up.

This only corrects the statistic. The other fixes in the same change
(padded-position isolation, NaN masking during scoring, the post-cast
audit) change which windows are finite and can only be applied by
re-running the evaluation.
"""

from __future__ import annotations

import argparse
import csv
import shutil
from pathlib import Path

import numpy as np

from paired_stats import paired_bootstrap, paired_ratio_bootstrap

DELTA_FIELDS = [
    "delta_token_nll",
    "delta_token_nll_ci_low",
    "delta_token_nll_ci_high",
    "delta_token_nll_p",
    "delta_window_mean_nll",
    "delta_window_mean_nll_p",
    "bootstrap_windows",
]


def load_predictions(path: Path) -> tuple[list[str], np.ndarray, dict[str, np.ndarray]]:
    rows = list(csv.DictReader(path.open()))
    if not rows or "scored_tokens" not in rows[0]:
        raise ValueError(f"{path} is not a language-modelling predictions file")
    methods = [
        key[: -len("_total_logprob")] for key in rows[0] if key.endswith("_total_logprob")
    ]
    tokens = np.array([float(row["scored_tokens"]) for row in rows])
    totals = {
        method: np.array([float(row[f"{method}_total_logprob"] or "nan") for row in rows])
        for method in methods
    }
    return methods, tokens, totals


def corrected_deltas(
    tokens: np.ndarray, totals: dict[str, np.ndarray], reference: str, resamples: int, seed: int
) -> dict[str, dict[str, float]]:
    out: dict[str, dict[str, float]] = {}
    reference_totals = totals[reference]
    for method, method_totals in totals.items():
        shared = np.isfinite(method_totals) & np.isfinite(reference_totals)
        if method == reference:
            out[method] = {field: 0.0 for field in DELTA_FIELDS}
            out[method]["delta_token_nll_p"] = 1.0
            out[method]["delta_window_mean_nll_p"] = 1.0
            out[method]["bootstrap_windows"] = int(shared.sum())
            continue
        numerators = (-method_totals[shared]) - (-reference_totals[shared])
        ratio = paired_ratio_bootstrap(numerators, tokens[shared], resamples=resamples, seed=seed)
        window = paired_bootstrap(
            (-method_totals[shared] / tokens[shared]) - (-reference_totals[shared] / tokens[shared]),
            resamples=resamples,
            seed=seed,
        )
        out[method] = {
            "delta_token_nll": ratio["ratio"],
            "delta_token_nll_ci_low": ratio["ci_low"],
            "delta_token_nll_ci_high": ratio["ci_high"],
            "delta_token_nll_p": ratio["p"],
            "delta_window_mean_nll": window["mean"],
            "delta_window_mean_nll_p": window["p"],
            "bootstrap_windows": ratio["units"],
            "windows_lost": int((~np.isfinite(method_totals)).sum()),
        }
    return out


def update_summary(path: Path, deltas: dict[str, dict[str, float]]) -> None:
    rows = list(csv.DictReader(path.open()))
    fields = list(rows[0].keys())
    for field in DELTA_FIELDS:
        if field not in fields:
            fields.append(field)
    for row in rows:
        method = row.get("method")
        if method in deltas:
            for field in DELTA_FIELDS:
                row[field] = deltas[method].get(field, row.get(field, ""))
    shutil.copyfile(path, path.with_suffix(".csv.bak"))
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument("--results", type=Path, required=True, help="e.g. results/zeroshot")
    parser.add_argument("--reference", default="native")
    parser.add_argument("--bootstrap-resamples", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260901)
    parser.add_argument("--dry-run", action="store_true", help="Print the tables, leave summary.csv alone.")
    args = parser.parse_args()

    for predictions in sorted(args.results.glob("*/full/predictions.csv")):
        try:
            methods, tokens, totals = load_predictions(predictions)
        except ValueError:
            continue  # multiple-choice task
        if args.reference not in totals:
            print(f"{predictions.parent.parent.name}: no {args.reference} column, skipped")
            continue
        deltas = corrected_deltas(tokens, totals, args.reference, args.bootstrap_resamples, args.seed)
        task = predictions.parent.parent.name
        print(f"\n{task}: {len(tokens)} windows, {int(tokens.sum())} tokens")
        print(f"  {'method':14s} {'corpus delta':>13s} {'95% CI':>24s} {'p':>8s} {'window-mean':>12s} {'lost':>5s}")
        for method in methods:
            d = deltas[method]
            if method == args.reference:
                continue
            print(
                f"  {method:14s} {d['delta_token_nll']:>+13.6f} "
                f"[{d['delta_token_nll_ci_low']:>+10.6f},{d['delta_token_nll_ci_high']:>+10.6f}] "
                f"{d['delta_token_nll_p']:>8.4f} {d['delta_window_mean_nll']:>+12.6f} {d.get('windows_lost', 0):>5d}"
            )
        summary = predictions.with_name("summary.csv")
        if args.dry_run or not summary.exists():
            continue
        update_summary(summary, deltas)
        print(f"  updated {summary} (backup: summary.csv.bak)")


if __name__ == "__main__":
    main()
