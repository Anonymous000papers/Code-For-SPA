"""Fit and select every method's profiles on the frozen range plan and write the profile catalog."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

import numpy as np

from profile_math import (
    chebyshev_interpolant,
    evaluate_composite,
    evaluate_direct,
    evaluate_logistic_first,
    evaluate_spa,
    fit_asinh_composite,
    fit_direct_minimax,
    fit_spa_minimax,
    logistic,
    silu,
)


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def parse_targets(text: str) -> list[float]:
    targets = [float(value) for value in text.split(",") if value.strip()]
    if len(targets) != 3:
        raise ValueError("--spa-target-errors must contain exactly three values")
    if not (targets[0] > targets[1] > targets[2] > 0):
        raise ValueError("SPA target errors must be strictly decreasing")
    return targets


def range_split(label: str, small_label: str, small_split: int, other_split: int) -> int:
    return small_split if label == small_label else other_split


def spa_candidates(split: int, max_blocks: int) -> list[int]:
    return [blocks * split - 1 for blocks in range(1, max_blocks + 1)]


def select_spa_profiles(
    ranges: list[dict],
    targets: list[float],
    small_label: str,
    small_split: int,
    other_split: int,
    max_blocks: int,
    lp_grid: int,
    validation_grid: int,
) -> tuple[dict[str, dict], list[dict], list[dict]]:
    profiles: dict[str, dict] = {}
    search_trials: list[dict] = []
    selections: list[dict] = [
        {"tier": tier, "target_max_error": target, "profiles": {}, "degrees": {}}
        for tier, target in zip(("fast", "balanced", "accurate"), targets)
    ]

    for range_item in ranges:
        label = range_item["label"]
        radius = float(range_item["radius"])
        split = range_split(label, small_label, small_split, other_split)
        candidates = spa_candidates(split, max_blocks)
        selected_for_target: dict[float, str] = {}

        for degree in candidates:
            coefficients, lp_error = fit_spa_minimax(radius, degree, lp_grid)
            metrics = evaluate_spa(radius, coefficients, validation_grid)
            profile_id = f"spa-r{radius:g}-k{degree}"
            profile = {
                "id": profile_id,
                "kind": "spa",
                "family": "SPA",
                "range_label": label,
                "operating_radius": radius,
                "domain_lo": -radius,
                "domain_hi": radius,
                "degree_square": degree,
                "degree_x": 2 * degree,
                "ps_split": split,
                "ps_blocks": (degree + split) // split,
                "coefficients": [float(value) for value in coefficients],
                "fit_method": "discrete Chebyshev-basis minimax LP",
                "lp_error": lp_error,
                **metrics,
            }
            profiles[profile_id] = profile
            search_trials.append(
                {
                    "range_label": label,
                    "radius": radius,
                    "degree_square": degree,
                    "ps_split": split,
                    "max_abs_error": metrics["max_abs_error"],
                    "rmse": metrics["rmse"],
                }
            )
            print(
                f"SPA {label:>4s} k={degree:>3d} PS{split} "
                f"max={metrics['max_abs_error']:.6e}"
            )

            for target in targets:
                if target not in selected_for_target and metrics["max_abs_error"] <= target:
                    selected_for_target[target] = profile_id
            if len(selected_for_target) == len(targets):
                break

        missing = [target for target in targets if target not in selected_for_target]
        if missing:
            raise RuntimeError(
                f"no SPA degree for {label} met target errors {missing}; "
                "increase --spa-max-blocks"
            )

        chosen_degrees: list[int] = []
        for selection in selections:
            profile_id = selected_for_target[selection["target_max_error"]]
            degree = int(profiles[profile_id]["degree_square"])
            chosen_degrees.append(degree)
            selection["profiles"][label] = profile_id
            selection["degrees"][label] = degree

        if len(set(chosen_degrees)) != len(chosen_degrees):
            raise RuntimeError(
                f"SPA target errors produced duplicate degrees for {label}: {chosen_degrees}. "
                "Choose targets that cross distinct PS cost buckets."
            )

    wide_label = ranges[-1]["label"]
    used_ids: set[str] = set()
    for selection in selections:
        wide_degree = selection["degrees"][wide_label]
        method_id = f"spa-k{wide_degree}"
        if method_id in used_ids:
            raise RuntimeError(f"duplicate SPA method ID: {method_id}")
        used_ids.add(method_id)
        selection["id"] = method_id
        selection["display_name"] = f"SPA-k{wide_degree}"
        selection["naming_rule"] = "suffix is the square-domain degree of the wide profile"
        selection["degree_schedule"] = ";".join(
            f"{item['label']}:k{selection['degrees'][item['label']]}"
            for item in ranges
        )

    selected_ids = {
        profile_id
        for selection in selections
        for profile_id in selection["profiles"].values()
    }
    selected_profiles = {
        profile_id: profile
        for profile_id, profile in profiles.items()
        if profile_id in selected_ids
    }
    return selected_profiles, selections, search_trials


def generate_orion(ranges: list[dict]) -> dict[str, dict]:
    profiles: dict[str, dict] = {}
    for item in ranges:
        label = item["label"]
        radius = float(item["radius"])
        lo, hi = -2.0 * radius, 2.0 * radius
        coefficients = chebyshev_interpolant(silu, 127, lo, hi)
        profile_id = f"orion-r{radius:g}"
        profiles[label] = {
            "id": profile_id,
            "kind": "direct",
            "family": "Orion",
            "range_label": label,
            "operating_radius": radius,
            "domain_lo": lo,
            "domain_hi": hi,
            "degree": 127,
            "ps_split": 16,
            "coefficients": [float(value) for value in coefficients],
            "provenance": "degree-127 Chebyshev interpolation with margin-2 fit domain",
            **evaluate_direct(coefficients, lo, hi, silu, radius),
        }
    return profiles


def generate_ensi(ranges: list[dict]) -> dict[str, dict]:
    profiles: dict[str, dict] = {}
    for item in ranges:
        label = item["label"]
        radius = float(item["radius"])
        lo, hi = -radius, radius
        coefficients = chebyshev_interpolant(logistic, 16, lo, hi)
        profile_id = f"ensi-r{radius:g}"
        profiles[label] = {
            "id": profile_id,
            "kind": "logistic-first",
            "family": "ENSI",
            "range_label": label,
            "operating_radius": radius,
            "domain_lo": lo,
            "domain_hi": hi,
            "degree": 16,
            "ps_split": 4,
            "coefficients": [float(value) for value in coefficients],
            "provenance": "degree-16 Chebyshev logistic approximation followed by multiplication by x",
            **evaluate_logistic_first(coefficients, lo, hi, radius),
        }
    return profiles


def generate_sylph(ranges: list[dict]) -> dict[str, dict]:
    profiles: dict[str, dict] = {}
    for item in ranges:
        label = item["label"]
        radius = float(item["radius"])
        lo, hi = -radius, radius
        coefficients = fit_direct_minimax(silu, 31, lo, hi)
        profile_id = f"sylph-r{radius:g}"
        profiles[label] = {
            "id": profile_id,
            "kind": "direct",
            "family": "Sylph",
            "range_label": label,
            "operating_radius": radius,
            "domain_lo": lo,
            "domain_hi": hi,
            "degree": 31,
            "ps_split": 8,
            "coefficients": [float(value) for value in coefficients],
            "provenance": "range-adapted degree-31 direct SiLU minimax reconstruction",
            **evaluate_direct(coefficients, lo, hi, silu, radius),
        }
    return profiles


def generate_thor(ranges: list[dict]) -> dict[str, dict]:
    profiles: dict[str, dict] = {}
    for item in ranges:
        label = item["label"]
        radius = float(item["radius"])
        alpha, stage1, stage2 = fit_asinh_composite(radius, 31, 27)
        profile_id = f"thor-r{radius:g}"
        profiles[label] = {
            "id": profile_id,
            "kind": "composite",
            "family": "THOR",
            "range_label": label,
            "operating_radius": radius,
            "domain_lo": -radius,
            "domain_hi": radius,
            "degree_stage1": 31,
            "degree_stage2": 27,
            "ps_split_stage1": 8,
            "ps_split_stage2": 4,
            "warp_alpha": alpha,
            "stage1_coefficients": [float(value) for value in stage1],
            "stage2_coefficients": [float(value) for value in stage2],
            "provenance": "range-adapted 31-to-27 asinh-composite reconstruction used by the ciphertext benchmark",
            **evaluate_composite(radius, stage1, stage2),
        }
    return profiles


def summary_rows(catalog: dict) -> list[dict]:
    rows: list[dict] = []
    range_radius = {item["label"]: item["radius"] for item in catalog["ranges"]}

    for variant in catalog["methods"]["spa"]:
        for label, profile_id in variant["profiles"].items():
            profile = catalog["profiles"][profile_id]
            rows.append(
                {
                    "method": variant["id"],
                    "family": "SPA",
                    "range_label": label,
                    "radius": range_radius[label],
                    "degree": profile["degree_square"],
                    "ps_split": profile["ps_split"],
                    "max_abs_error": profile["max_abs_error"],
                    "rmse": profile["rmse"],
                    "profile_id": profile_id,
                    "provenance": "proposed SPA degree sweep",
                }
            )

    for method in ("orion", "ensi", "sylph", "thor"):
        for label, profile_id in catalog["methods"][method]["profiles"].items():
            profile = catalog["profiles"][profile_id]
            if "degree" in profile:
                degree = profile["degree"]
                split = profile["ps_split"]
            else:
                degree = f"{profile['degree_stage1']}x{profile['degree_stage2']}"
                split = f"{profile['ps_split_stage1']}/{profile['ps_split_stage2']}"
            rows.append(
                {
                    "method": method,
                    "family": profile["family"],
                    "range_label": label,
                    "radius": range_radius[label],
                    "degree": degree,
                    "ps_split": split,
                    "max_abs_error": profile["max_abs_error"],
                    "rmse": profile["rmse"],
                    "profile_id": profile_id,
                    "provenance": profile["provenance"],
                }
            )
    return rows


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Generate one shared profile catalog for plaintext evaluation and the "
            "matching ciphertext implementation."
        )
    )
    parser.add_argument("--range-plan", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--spa-target-errors",
        default="2.1e-2,1e-3,1e-4",
        help="Fast, balanced and accurate maximum-error targets.",
    )
    parser.add_argument("--spa-small-split", type=int, default=4)
    parser.add_argument("--spa-other-split", type=int, default=8)
    parser.add_argument("--spa-max-blocks", type=int, default=20)
    parser.add_argument("--lp-grid", type=int, default=3000)
    parser.add_argument("--validation-grid", type=int, default=300001)
    args = parser.parse_args()

    plan = json.loads(args.range_plan.read_text())
    ranges = plan["ranges"]
    if len(ranges) != 3:
        raise RuntimeError("the current experiment expects exactly three range groups")
    small_label = ranges[0]["label"]
    targets = parse_targets(args.spa_target_errors)

    spa_profiles, spa_variants, spa_search_trials = select_spa_profiles(
        ranges=ranges,
        targets=targets,
        small_label=small_label,
        small_split=args.spa_small_split,
        other_split=args.spa_other_split,
        max_blocks=args.spa_max_blocks,
        lp_grid=args.lp_grid,
        validation_grid=args.validation_grid,
    )

    profiles: dict[str, dict] = dict(spa_profiles)
    methods: dict[str, object] = {"spa": spa_variants}

    generators = {
        "orion": generate_orion,
        "ensi": generate_ensi,
        "sylph": generate_sylph,
        "thor": generate_thor,
    }
    for method, generator in generators.items():
        generated = generator(ranges)
        profile_map: dict[str, str] = {}
        for label, profile in generated.items():
            profiles[profile["id"]] = profile
            profile_map[label] = profile["id"]
        if method == "orion":
            degree_schedule = ";".join(f"{item['label']}:d127-m2" for item in ranges)
            implementation = "source-policy reconstruction"
        elif method == "ensi":
            degree_schedule = ";".join(f"{item['label']}:d16" for item in ranges)
            implementation = "range-adapted logistic-first reconstruction"
        elif method == "sylph":
            degree_schedule = ";".join(f"{item['label']}:d31" for item in ranges)
            implementation = "range-adapted degree-31 minimax reconstruction"
        else:
            degree_schedule = ";".join(f"{item['label']}:d31x27" for item in ranges)
            implementation = "range-adapted 31-to-27 composite reconstruction"
        methods[method] = {
            "id": method,
            "display_name": method.upper() if method in {"ensi", "thor"} else method.capitalize(),
            "profiles": profile_map,
            "degree_schedule": degree_schedule,
            "implementation": implementation,
        }

    catalog = {
        "format": "activation-profile-catalog-v3",
        "target": "SiLU",
        "range_assignment": "static-per-channel; omitted from public method names",
        "range_plan": str(args.range_plan.resolve()),
        "range_plan_sha256": file_sha256(args.range_plan),
        "ranges": ranges,
        "spa_target_errors": targets,
        "spa_naming": (
            "SPA-k* uses the wide-range square-domain degree as the suffix; "
            "the complete R5/R20/Rwide degree schedule is stored per method."
        ),
        "spa_search_trials": spa_search_trials,
        "methods": methods,
        "profiles": profiles,
    }

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(catalog, indent=2))

    rows = summary_rows(catalog)
    summary_path = args.output.with_name("profile_summary.csv")
    with summary_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    print("SPA variants:")
    for variant in spa_variants:
        print(
            f"  {variant['display_name']}: {variant['degree_schedule']} "
            f"target={variant['target_max_error']:.3e}"
        )
    print(f"saved: {args.output}")
    print(f"saved: {summary_path}")


if __name__ == "__main__":
    main()
