"""Offline checks for the multiple-choice harness.

Runs without torch, transformers, datasets or a GPU: those modules are
stubbed so the pure-numpy scoring and metric logic can be exercised.

    python tests/test_mcq_harness.py
"""

from __future__ import annotations

import sys
import types
from pathlib import Path

import numpy as np

# Imported before the torch stub is installed: scipy's array-api layer
# probes torch.Tensor when torch is importable, and the stub has none.
try:
    from scipy.stats import binomtest as _scipy_binomtest
except Exception:  # noqa: BLE001
    _scipy_binomtest = None

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def _install_stubs() -> None:
    if "torch" not in sys.modules:
        torch = types.ModuleType("torch")

        class _Ctx:
            def __call__(self, fn):
                return fn

            def __enter__(self):
                return self

            def __exit__(self, *exc):
                return False

        class Tensor:
            """Placeholder for torch.Tensor.

            Required, not cosmetic: scipy's array-API layer resolves
            ``getattr(sys.modules["torch"], "Tensor")`` on every public
            call once ``torch`` is present in ``sys.modules``. Some scipy
            builds route ``binomtest`` through that path, so a stub
            without this attribute raises AttributeError at call time
            rather than at import time.
            """

        torch.Tensor = Tensor
        torch.__version__ = "0.0.0+stub"
        torch.inference_mode = lambda *a, **k: _Ctx()
        torch.no_grad = lambda *a, **k: _Ctx()
        torch.manual_seed = lambda *a, **k: None
        torch.cuda = types.SimpleNamespace(
            is_available=lambda: False, manual_seed_all=lambda *a, **k: None
        )
        sys.modules["torch"] = torch

    # Anything reachable via sys.modules["torch"] that third-party array
    # dispatch probes must exist before the first scipy call.
    getattr(sys.modules["torch"], "Tensor")

    if "datasets" not in sys.modules:
        datasets = types.ModuleType("datasets")
        datasets.load_dataset = lambda *a, **k: (_ for _ in ()).throw(
            RuntimeError("datasets is stubbed in offline tests")
        )
        sys.modules["datasets"] = datasets


_install_stubs()

from mcq_common import (  # noqa: E402
    Truncation,
    batch_count,
    compute_lm_metrics,
    build_records,
    choice_geometry,
    compute_metrics,
    encode_pair_plain,
    fit_to_budget,
    mcnemar,
    minimum_detectable_effect,
)
from paired_stats import (  # noqa: E402 - torch-free, imported without stubs
    exact_two_sided_binomial,
    paired_bootstrap,
)
from tasks import (  # noqa: E402
    CORPUS_EVAL_FRACTION,
    LETTERS,
    _chunk,
    Example,
    _field,
    _SOURCE_OVERRIDES,
    hellaswag_clean,
    set_source_override,
)


class CharTokenizer:
    """Byte-level stand-in with a BOS token, for boundary testing."""

    bos = 256
    eos_token_id = 257

    def encode(self, text: str, add_special_tokens: bool = True) -> list[int]:
        ids = list(text.encode("utf-8"))
        return ([self.bos] + ids) if add_special_tokens else ids


class MergingTokenizer(CharTokenizer):
    """Merges a trailing space with the following letter, to force a merge."""

    def encode(self, text: str, add_special_tokens: bool = True) -> list[int]:
        ids: list[int] = [self.bos] if add_special_tokens else []
        index = 0
        raw = text.encode("utf-8")
        while index < len(raw):
            if raw[index] == 0x20 and index + 1 < len(raw):
                ids.append(1000 + raw[index + 1])
                index += 2
            else:
                ids.append(raw[index])
                index += 1
        return ids


def check(name: str, condition: bool, detail: str = "") -> None:
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {name}" + (f"  {detail}" if detail else ""))
    if not condition:
        raise AssertionError(name)


def test_encode_pair_clean_boundary() -> None:
    tokenizer = CharTokenizer()
    prompt, continuation = encode_pair_plain(tokenizer, "abc", " de")
    check(
        "clean boundary splits at the context length",
        prompt == [256, 97, 98, 99] and continuation == [32, 100, 101],
        f"prompt={prompt} continuation={continuation}",
    )


def test_encode_pair_merged_boundary() -> None:
    tokenizer = MergingTokenizer()
    prompt, continuation = encode_pair_plain(tokenizer, "abc", " de")
    joint = tokenizer.encode("abc" + " de")
    check(
        "merged boundary still reconstructs the joint encoding",
        prompt + continuation == joint and len(continuation) > 0,
        f"prompt={prompt} continuation={continuation}",
    )


def test_truncation_keeps_head_and_tail() -> None:
    prompt = list(range(500))
    trimmed, continuation, trunc = fit_to_budget(prompt, [1000] * 10, max_length=100)
    check(
        "the prompt yields first and keeps both ends",
        trunc.prompts == 1 and trunc.continuations == 0 and len(trimmed) == 90,
        f"len={len(trimmed)} first={trimmed[0]} last={trimmed[-1]}",
    )
    check("the scored continuation is untouched", continuation == [1000] * 10)
    check("both ends of the prompt survive", trimmed[0] == 0 and trimmed[-1] == 499)

    prompt, continuation, trunc = fit_to_budget([1, 2, 3], [4, 5], max_length=100)
    check(
        "a sequence inside the budget is left alone",
        prompt == [1, 2, 3] and continuation == [4, 5] and trunc == (0, 0),
    )

    # Budget of exactly one prompt token: keep_tail is 0, and a naive
    # ``prompt_ids[-0:]`` would return the whole prompt.
    prompt, continuation, trunc = fit_to_budget(list(range(13)), [7] * 7, max_length=8)
    check(
        "a one-token prompt budget yields exactly one token",
        len(prompt) + len(continuation) == 8 and prompt == [0],
        f"total={len(prompt) + len(continuation)}",
    )
    for budget in range(2, 40):
        prompt, continuation, _ = fit_to_budget(list(range(100)), [7] * (budget - 1), max_length=budget)
        check(f"budget {budget} is never exceeded", len(prompt) + len(continuation) <= budget)


def test_oversized_continuation_does_not_raise() -> None:
    """A single 525-token PIQA solution must not abort the whole run."""
    prompt = list(range(30))
    continuation = list(range(1000, 1525))
    fitted_prompt, fitted_continuation, trunc = fit_to_budget(
        prompt, continuation, max_length=512
    )
    check(
        "an over-long continuation is trimmed, not fatal",
        trunc.continuations == 1 and trunc.prompts == 1,
        f"{trunc}",
    )
    check(
        "the result fits the budget with at least one prompt token",
        len(fitted_prompt) + len(fitted_continuation) == 512 and len(fitted_prompt) >= 1,
        f"{len(fitted_prompt)} + {len(fitted_continuation)}",
    )
    check(
        "the kept continuation is a prefix of the original",
        fitted_continuation == continuation[: len(fitted_continuation)],
    )
    check(
        "raising the budget avoids trimming entirely",
        fit_to_budget(prompt, continuation, max_length=1024)[2] == (0, 0),
        "this is why PIQA runs at --max-length 1024",
    )


def test_truncation_counts_accumulate() -> None:
    total = Truncation() + Truncation(1, 0) + Truncation(1, 1)
    check("counts add per kind", total == (2, 1), f"{total}")
    check("the repr names both kinds", "prompts=2" in str(total) and "continuations=1" in str(total))


def test_records_and_geometry() -> None:
    tokenizer = CharTokenizer()
    examples = [
        Example(context="a cat", choices=["sat", "ran away quickly"], gold=0, key="x"),
        Example(context="a dog", choices=["barked", "slept", "ate"], gold=2, key="y"),
    ]
    records, truncated, max_choices, _ = build_records(
        tokenizer, examples, choice_prefix=" ", max_length=256
    )
    check("one record per (example, choice)", len(records) == 5 and max_choices == 3)
    check("nothing truncated at max_length=256", truncated == (0, 0))

    mask, tokens, byte_lengths = choice_geometry(records, len(examples), max_choices)
    check(
        "geometry marks the ragged third choice correctly",
        mask.tolist() == [[True, True, False], [True, True, True]],
    )
    check(
        "byte normaliser counts the continuation text including its prefix",
        byte_lengths[0, 0] == len(" sat".encode()) and byte_lengths[0, 1] == len(" ran away quickly".encode()),
        f"{byte_lengths[0, 0]} {byte_lengths[0, 1]}",
    )
    check(
        "padded choice slots keep a safe normaliser of 1",
        byte_lengths[0, 2] == 1 and tokens[0, 2] == 1,
    )


def test_per_choice_contexts() -> None:
    """WinoGrande shape: the option sits in the context, not the continuation."""
    tokenizer = CharTokenizer()
    prefix, suffix = "The trophy did not fit in the case because ", " was too big"
    example = Example(
        context=prefix,
        contexts=[prefix + "the trophy", prefix + "the case"],
        choices=[suffix.strip(), suffix.strip()],
        gold=0,
        key="w1",
    )
    records, _, max_choices, _ = build_records(
        tokenizer, [example], choice_prefix=" ", max_length=256
    )
    check("both options produce a record", len(records) == 2 and max_choices == 2)

    decoded = []
    for record in records:
        prompt_length = record.length - record.scored_tokens
        decoded.append(bytes(record.input_ids[1:prompt_length]).decode())
    check(
        "each option is substituted into its own context",
        decoded[0].endswith("the trophy") and decoded[1].endswith("the case"),
        f"{decoded[0]!r} / {decoded[1]!r}",
    )
    check(
        "the scored continuation is identical for both options",
        records[0].labels[-records[0].scored_tokens :]
        == records[1].labels[-records[1].scored_tokens :],
    )
    check(
        "identical continuations make length normalisation a no-op",
        records[0].scored_bytes == records[1].scored_bytes,
    )


def test_context_for_defaults_to_shared() -> None:
    shared = Example(context="ctx", choices=["a", "b"], gold=0)
    check(
        "a shared-context example returns the same context for every choice",
        shared.context_for(0) == "ctx" and shared.context_for(1) == "ctx",
    )
    try:
        Example(context="ctx", choices=["a", "b"], gold=0, contexts=["only one"])
    except ValueError:
        check("a mismatched contexts list is rejected", True)
    else:
        check("a mismatched contexts list is rejected", False)


def test_ragged_choice_counts() -> None:
    """ARC-Challenge carries items with three, four or five options."""
    tokenizer = CharTokenizer()
    examples = [
        Example(context="q1", choices=["a", "b", "c"], gold=0),
        Example(context="q2", choices=["a", "b", "c", "d", "e"], gold=4),
    ]
    records, _, max_choices, _ = build_records(
        tokenizer, examples, choice_prefix=" ", max_length=256
    )
    check("max_choices tracks the widest item", max_choices == 5 and len(records) == 8)

    mask, _, _ = choice_geometry(records, len(examples), max_choices)
    check(
        "the narrow item leaves its unused slots masked out",
        mask[0].tolist() == [True, True, True, False, False],
    )
    scores = np.where(mask, np.array([[0.0, -1, -2, 0, 0], [-3, -2, -1, -0.5, -0.1]]), np.nan)
    metrics, _ = compute_metrics(
        scores, np.array([0, 4]), mask, np.ones((2, 5)), np.ones((2, 5))
    )
    check(
        "argmax never selects a masked slot",
        metrics["acc_norm"] == 1.0,
        "the 3-option item must not pick slot 3 or 4",
    )


def test_letters_cover_the_widest_option_set() -> None:
    check("LETTERS spans every option count the tasks use", len(LETTERS) >= 5)


def test_metrics_length_normalisation() -> None:
    # Choice 1 wins on raw log-likelihood only because it is shorter.
    scores = np.array([[-6.0, -4.0]])
    mask = np.array([[True, True]])
    tokens = np.array([[6.0, 2.0]])
    byte_lengths = np.array([[6.0, 2.0]])
    gold = np.array([0])

    metrics, _ = compute_metrics(
        scores, gold, mask, tokens, byte_lengths, primary_metric="acc_norm"
    )
    check("raw accuracy picks the short candidate", metrics["acc"] == 0.0)
    check(
        "byte-normalised accuracy picks the gold candidate",
        metrics["acc_norm"] == 1.0,
        "-6/6 = -1.0 beats -4/2 = -2.0",
    )
    check("status is ok when every score is finite", metrics["status"] == "ok")


def test_metrics_reference_comparison() -> None:
    rng = np.random.default_rng(0)
    n, c = 400, 4
    scores = rng.normal(size=(n, c))
    mask = np.ones((n, c), dtype=bool)
    lengths = np.full((n, c), 3.0)
    gold = rng.integers(0, c, size=n)

    base, reference = compute_metrics(scores, gold, mask, lengths, lengths)
    same, _ = compute_metrics(scores, gold, mask, lengths, lengths, reference=reference)
    check("identical scores give zero KL", abs(same["kl_reference_to_method"]) < 1e-12)
    check("identical scores give full agreement", same["agreement_acc_norm"] == 1.0)
    check("identical scores give zero flips", same["flips_vs_reference"] == 0)
    check("identical scores give a null McNemar", same["mcnemar_p"] == 1.0)

    perturbed = scores + rng.normal(scale=0.05, size=(n, c))
    shifted, _ = compute_metrics(perturbed, gold, mask, lengths, lengths, reference=reference)
    check(
        "a perturbation produces positive KL and some flips",
        shifted["kl_reference_to_method"] > 0 and shifted["flips_vs_reference"] > 0,
        f"kl={shifted['kl_reference_to_method']:.3e} flips={shifted['flips_vs_reference']}",
    )
    check(
        "discordant pairs never exceed total flips",
        shifted["mcnemar_discordant"] <= shifted["flips_vs_reference"],
    )


def test_metrics_nonfinite() -> None:
    scores = np.array([[0.0, -1.0], [np.nan, -2.0], [-3.0, -1.0]])
    mask = np.ones((3, 2), dtype=bool)
    lengths = np.ones((3, 2))
    gold = np.array([0, 0, 1])
    metrics, _ = compute_metrics(scores, gold, mask, lengths, lengths)
    check("non-finite rows are flagged", metrics["status"] == "nonfinite")
    check("invalid rows are counted and excluded", metrics["invalid_examples"] == 1)
    check("accuracy uses the valid rows only", metrics["acc_norm"] == 1.0)


def test_mcnemar_matches_reference_calculation() -> None:
    # 52 reference-correct-only against 28 the other way.
    reference_correct = np.array([True] * 52 + [False] * 28 + [True] * 100)
    method_correct = np.array([False] * 52 + [True] * 28 + [True] * 100)
    result = mcnemar(reference_correct, method_correct)
    check(
        "McNemar recovers the discordant split",
        result["mcnemar_to_wrong"] == 52 and result["mcnemar_to_right"] == 28,
    )
    check(
        "McNemar p matches the independently computed value",
        abs(result["mcnemar_p"] - 0.0097) < 5e-4,
        f"p={result['mcnemar_p']:.5f}",
    )
    check("the test used is recorded", result["mcnemar_test"].startswith("exact"))
    null = mcnemar(np.array([True, False]), np.array([True, False]))
    check("no discordant pairs gives p = 1", null["mcnemar_p"] == 1.0)


def test_exact_binomial_matches_scipy() -> None:
    """Optional cross-check. The harness never calls scipy at run time."""
    if _scipy_binomtest is None:
        print("[SKIP] scipy cross-check: scipy.stats unavailable")
        return
    cases = [(28, 80), (3, 7), (4, 8), (0, 5), (14, 28), (250, 600), (1, 1), (900, 1801)]
    worst = 0.0
    try:
        for successes, trials in cases:
            mine = exact_two_sided_binomial(successes, trials)
            theirs = float(_scipy_binomtest(successes, trials, 0.5).pvalue)
            worst = max(worst, abs(mine - theirs))
    except Exception as exc:  # noqa: BLE001
        print(f"[SKIP] scipy cross-check: {type(exc).__name__}: {exc}")
        return
    check(
        "self-contained exact test matches scipy across tail sizes",
        worst < 1e-12,
        f"max abs difference {worst:.2e} over {len(cases)} cases",
    )


def test_exact_binomial_self_consistency() -> None:
    """Scipy-free properties, so the exact test is verified everywhere."""
    check("p = 1 when the split is even", exact_two_sided_binomial(40, 80) == 1.0)
    check("p = 1 for a single trial", exact_two_sided_binomial(1, 1) == 1.0)
    check(
        "the statistic is symmetric in the two directions",
        all(
            abs(exact_two_sided_binomial(k, n) - exact_two_sided_binomial(n - k, n)) < 1e-15
            for k, n in [(28, 80), (3, 20), (7, 15), (0, 9)]
        ),
    )
    check(
        "an all-one-way split matches 2 / 2**n",
        abs(exact_two_sided_binomial(0, 10) - 2.0 / 2 ** 10) < 1e-15,
        f"{exact_two_sided_binomial(0, 10):.8f}",
    )
    check(
        "p falls monotonically as the split gets more lopsided",
        (
            exact_two_sided_binomial(40, 80)
            > exact_two_sided_binomial(32, 80)
            > exact_two_sided_binomial(28, 80)
            > exact_two_sided_binomial(20, 80)
        ),
    )
    check(
        "the 52/28 split reproduces the documented value",
        abs(exact_two_sided_binomial(28, 80) - 0.00968285) < 1e-7,
        f"p={exact_two_sided_binomial(28, 80):.8f}",
    )
    check(
        "large discordant counts stay finite and in range",
        0.0 < exact_two_sided_binomial(4800, 10000) <= 1.0,
    )


def test_minimum_detectable_effect() -> None:
    value = minimum_detectable_effect(3270, 8)
    check(
        "MDE reproduces the reference figure for 8 flips in 3,270 items",
        abs(value - 0.170) < 5e-3,
        f"{value:.4f} pp",
    )
    check("too few flips gives nan", np.isnan(minimum_detectable_effect(3270, 2)))


def test_hellaswag_cleaning() -> None:
    raw = "  A man [title] then he [header] jumps   over it. "
    # The reference implementation applies a single replace("  ", " ") pass,
    # so a run of three spaces collapses to two rather than to one. That
    # quirk is kept deliberately: matching it is what makes the absolute
    # accuracy comparable to published HellaSwag numbers.
    check(
        "title markers become sentence breaks and brackets are stripped",
        hellaswag_clean(raw) == "A man. then he jumps  over it.",
        repr(hellaswag_clean(raw)),
    )
    check(
        "a single space run is left untouched",
        hellaswag_clean("a b c") == "a b c",
    )


def test_example_validation() -> None:
    try:
        Example(context="c", choices=["a", "b"], gold=5)
    except ValueError:
        check("out-of-range gold index is rejected", True)
    else:
        check("out-of-range gold index is rejected", False)


def test_shared_prompt_collapse() -> None:
    """MMLU shape: identical context, one-token candidates.

    MergingTokenizer is used rather than CharTokenizer because the fast
    path requires each candidate to be a single token. A byte-level
    tokenizer splits " A" into two, which a real Llama tokenizer does
    not; the eligibility check correctly refuses in that case.
    """
    tokenizer = MergingTokenizer()
    examples = [
        Example(context="Q1\nAnswer:", choices=["A", "B", "C", "D"], gold=2, key="m1"),
        Example(context="Q2\nAnswer:", choices=["A", "B", "C", "D"], gold=0, key="m2"),
    ]
    plain, _, wide_plain, shared_plain = build_records(
        tokenizer, examples, choice_prefix=" ", max_length=256, shared_prompt=False
    )
    fast, _, wide_fast, shared_fast = build_records(
        tokenizer, examples, choice_prefix=" ", max_length=256, shared_prompt=True
    )
    check("without the flag, one record per candidate", len(plain) == 8 and shared_plain == 0)
    check("with the flag, one record per example", len(fast) == 2 and shared_fast == 2)
    check("choice count is unchanged", wide_plain == wide_fast == 4)
    check(
        "the collapsed record carries every candidate token",
        fast[0].shared_choices == [0, 1, 2, 3] and len(fast[0].shared_tokens) == 4,
    )
    check(
        "the candidate tokens are the final token of each full sequence",
        fast[0].shared_tokens == [record.input_ids[-1] for record in plain[:4]],
    )
    check(
        "the collapsed prompt equals the shared prefix",
        fast[0].input_ids == plain[0].input_ids[:-1],
    )

    mask_plain, _, bytes_plain = choice_geometry(plain, 2, 4)
    mask_fast, _, bytes_fast = choice_geometry(fast, 2, 4)
    check(
        "geometry is identical either way",
        (mask_plain == mask_fast).all() and (bytes_plain == bytes_fast).all(),
    )
    check("batch_count splits the two groups", batch_count(fast, 32) == 1)


def test_shared_prompt_rejects_ineligible_shapes() -> None:
    tokenizer = MergingTokenizer()

    multi = [Example(context="ctx", choices=["one", "two"], gold=0)]
    records, _, _, shared = build_records(
        tokenizer, multi, choice_prefix=" ", max_length=256, shared_prompt=True
    )
    check(
        "multi-token candidates are not collapsed",
        len(records) == 2 and shared == 0,
        "HellaSwag and ARC-Challenge must be unaffected",
    )

    byte_level, _, _, byte_shared = build_records(
        CharTokenizer(),
        [Example(context="Q\nAnswer:", choices=["A", "B"], gold=0)],
        choice_prefix=" ",
        max_length=256,
        shared_prompt=True,
    )
    check(
        "a tokenizer that splits the candidate is refused",
        len(byte_level) == 2 and byte_shared == 0,
        "eligibility is checked on tokens, not on the source text",
    )

    prefix = "The trophy did not fit because "
    winogrande = [
        Example(
            context=prefix,
            contexts=[prefix + "the trophy", prefix + "the case"],
            choices=["x", "x"],
            gold=0,
        )
    ]
    records, _, _, shared = build_records(
        tokenizer, winogrande, choice_prefix=" ", max_length=256, shared_prompt=True
    )
    check(
        "per-choice contexts are not collapsed",
        len(records) == 2 and shared == 0,
        "WinoGrande candidates differ in the prompt, not the continuation",
    )


def test_nan_aware_max() -> None:
    """The reduction that hid THOR's overflow must keep NaN."""
    import importlib.util

    spec = importlib.util.spec_from_file_location("_em", ROOT / "eval_methods.py")
    # eval_methods imports torch heavily; read the helper directly instead.
    source = (ROOT / "eval_methods.py").read_text()
    namespace: dict = {"math": __import__("math")}
    start = source.index("def nan_aware_max")
    end = source.index("\ndef ", start + 1)
    exec(source[start:end], namespace)  # noqa: S102 - reading our own source
    nan_aware_max = namespace["nan_aware_max"]

    nan = float("nan")
    check("plain max drops a trailing NaN", max(20.0, nan) == 20.0)
    check("nan_aware_max keeps it", np.isnan(nan_aware_max(20.0, nan)))
    check("nan_aware_max keeps a leading NaN", np.isnan(nan_aware_max(nan, 20.0)))
    check("ordinary values still reduce normally", nan_aware_max(3.0, 7.0) == 7.0)
    check("spec loader is available", spec is not None)


def test_lm_metrics() -> None:
    """WikiText-2 shape: one continuation per window, per-token NLL."""
    rng = np.random.default_rng(7)
    windows = 300
    tokens = rng.integers(700, 900, size=windows).astype(float)
    per_token = 3.0 + rng.normal(0, 0.4, size=windows)
    scores = (-(per_token * tokens)).reshape(-1, 1)
    counts = tokens.reshape(-1, 1)

    base, reference = compute_lm_metrics(scores, counts)
    check("accuracy is not reported for a corpus", np.isnan(base["acc_norm"]))
    check(
        "corpus NLL is token-weighted, not a mean of window means",
        abs(base["token_nll"] - (per_token * tokens).sum() / tokens.sum()) < 1e-9,
        f"{base['token_nll']:.6f}",
    )
    check(
        "perplexity is exp of the token NLL",
        abs(base["perplexity"] - np.exp(base["token_nll"])) < 1e-6,
    )

    same, _ = compute_lm_metrics(scores, counts, reference=reference, bootstrap_resamples=2000)
    check("an identical run has zero delta", abs(same["delta_token_nll"]) < 1e-12)
    check("an identical run is a null", same["delta_token_nll_p"] == 1.0)

    # A shift far below what accuracy could ever resolve.
    nudged = (-((per_token + 0.004) * tokens)).reshape(-1, 1)
    shifted, _ = compute_lm_metrics(
        nudged, counts, reference=reference, bootstrap_resamples=4000
    )
    check(
        "a 0.004 nat/token shift is resolved",
        shifted["delta_token_nll_p"] < 0.01 and shifted["delta_token_nll"] > 0,
        f"delta={shifted['delta_token_nll']:.5f} p={shifted['delta_token_nll_p']:.4f}",
    )
    check(
        "the confidence interval excludes zero",
        shifted["delta_token_nll_ci_low"] > 0,
        f"[{shifted['delta_token_nll_ci_low']:.5f}, {shifted['delta_token_nll_ci_high']:.5f}]",
    )
    check(
        "perplexity delta has the right sign and scale",
        0.0 < shifted["perplexity_delta_pct"] < 1.0,
        f"{shifted['perplexity_delta_pct']:.4f}%",
    )


def test_lm_delta_is_corpus_level() -> None:
    """The paired delta must be the difference of corpus token NLLs, not
    an equally weighted mean of per-window differences."""
    from paired_stats import paired_ratio_bootstrap

    # Two windows: a short one where the method is much worse and a long
    # one where it is slightly better. Window-equal mean says "worse";
    # the corpus says "better".
    counts = np.array([[10.0], [1000.0]])
    reference_scores = np.array([[-30.0], [-3000.0]])
    method_scores = np.array([[-40.0], [-2800.0]])
    _, reference = compute_lm_metrics(reference_scores, counts)
    metrics, _ = compute_lm_metrics(method_scores, counts, reference=reference, bootstrap_resamples=500)
    corpus_delta = (40.0 + 2800.0) / 1010.0 - (30.0 + 3000.0) / 1010.0
    window_mean = ((4.0 - 3.0) + (2.8 - 3.0)) / 2.0
    check("window-equal mean has the opposite sign here", window_mean > 0 and corpus_delta < 0)
    check(
        "delta_token_nll is the corpus-level difference",
        abs(metrics["delta_token_nll"] - corpus_delta) < 1e-12,
        f"{metrics['delta_token_nll']:.6f} vs {corpus_delta:.6f}",
    )
    check(
        "delta_token_nll equals token_nll_shared minus reference_token_nll_shared",
        abs(metrics["delta_token_nll"] - (metrics["token_nll_shared"] - metrics["reference_token_nll_shared"])) < 1e-12,
    )
    check(
        "the window-equal statistic is still available under its own name",
        abs(metrics["delta_window_mean_nll"] - window_mean) < 1e-12,
    )

    # Bootstrap replicates recompute the ratio of sums on paired windows.
    rng = np.random.default_rng(3)
    tokens = rng.integers(500, 1500, size=200).astype(float)
    numerators = 0.01 * tokens + rng.normal(0, 5.0, size=200)
    result = paired_ratio_bootstrap(numerators, tokens, resamples=3000)
    check("observed ratio is sum/sum", abs(result["ratio"] - numerators.sum() / tokens.sum()) < 1e-12)
    check("interval brackets the observed ratio", result["ci_low"] <= result["ratio"] <= result["ci_high"])
    check("a consistent 0.01 nat/token shift is resolved", result["p"] < 0.01 and result["ci_low"] > 0)


def test_lm_metrics_handle_nonfinite() -> None:
    scores = np.array([[-100.0], [np.nan], [-200.0]])
    counts = np.array([[50.0], [50.0], [100.0]])
    metrics, state = compute_lm_metrics(scores, counts)
    check("a broken window is flagged", metrics["status"] == "nonfinite")
    check("it is excluded from the corpus figure", metrics["invalid_examples"] == 1)
    check(
        "the surviving windows still weight by length",
        abs(metrics["token_nll"] - 300.0 / 150.0) < 1e-9,
        f"{metrics['token_nll']}",
    )
    check("state marks it non-finite", not state["finite"][1])


def test_bootstrap_is_deterministic() -> None:
    values = np.random.default_rng(3).normal(0.01, 0.1, 250)
    first = paired_bootstrap(values, resamples=1500, seed=11)
    second = paired_bootstrap(values, resamples=1500, seed=11)
    check("the same seed gives the same interval", first == second)


def test_field_tolerates_mirror_schemas() -> None:
    """Parquet mirrors do not always keep the original column names."""
    check("the canonical name wins", _field({"label": 2, "answer": 9}, "label", "answer") == 2)
    check("an alternative is accepted", _field({"answer": 9}, "label", "answer") == 9)
    check("a None value falls through", _field({"sol1": None, "solution1": "x"},
                                               "sol1", "solution1") == "x")
    try:
        _field({"goal": "g"}, "sol1", "solution1")
    except KeyError as exc:
        check(
            "a miss names the columns actually present",
            "goal" in str(exc) and "sol1" in str(exc),
            str(exc)[:80],
        )
    else:
        check("a miss names the columns actually present", False)


def test_source_override_parsing() -> None:
    _SOURCE_OVERRIDES.pop("demo", None)
    set_source_override("demo", "org/repo")
    check("a bare repo parses", _SOURCE_OVERRIDES["demo"] == (("org/repo", None),))
    set_source_override("demo", "org/repo:configA, other/repo")
    check(
        "config and multiple candidates parse in order",
        _SOURCE_OVERRIDES["demo"] == (("org/repo", "configA"), ("other/repo", None)),
        str(_SOURCE_OVERRIDES["demo"]),
    )
    set_source_override("demo", "   ")
    check(
        "an empty override leaves the previous value alone",
        _SOURCE_OVERRIDES["demo"] == (("org/repo", "configA"), ("other/repo", None)),
    )
    _SOURCE_OVERRIDES.pop("demo", None)


def test_corpus_chunking_and_disjoint_split() -> None:
    """LM corpora must never score a window the range plan was fitted on."""
    text = "x" * 35000
    windows = _chunk(text, 3500)
    check("a clean multiple chunks exactly", len(windows) == 10)

    ragged = _chunk("y" * 35000 + "z" * 200, 3500)
    check(
        "a short trailing remnant is dropped",
        len(ragged) == 10,
        "200 chars is under the quarter-window floor",
    )
    kept = _chunk("y" * 35000 + "z" * 2000, 3500)
    check("a substantial remnant is kept", len(kept) == 11)

    cut = int(len(windows) * (1.0 - CORPUS_EVAL_FRACTION))
    calibration, evaluation = windows[:cut], windows[cut:]
    check(
        "calibration and evaluation windows are disjoint",
        cut > 0 and len(evaluation) > 0 and calibration[-1] is not evaluation[0],
        f"{len(calibration)} calibration / {len(evaluation)} evaluation",
    )
    check(
        "every window is used exactly once",
        len(calibration) + len(evaluation) == len(windows),
    )


def test_public_surface_is_complete() -> None:
    """Guard against an edit removing a name the harness imports.

    A refactor once removed PROMPT_STYLES from mcq_common as collateral
    damage while extracting another function; nothing caught it until a
    GPU run failed. This walks every name the entry points import.
    """
    import ast
    import importlib

    for module_name in ("mcq_common", "tasks", "paired_stats"):
        module = importlib.import_module(module_name)
        for name in getattr(module, "__all__", []):
            check(f"{module_name}.{name} exists", hasattr(module, name))

    for entry in ("eval_methods.py", "calibrate_channels.py", "pool_results.py"):
        tree = ast.parse((ROOT / entry).read_text())
        wanted: list[tuple[str, str]] = []
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module in {
                "mcq_common",
                "tasks",
                "paired_stats",
                "activation_approximations",
            }:
                wanted.extend((node.module, alias.name) for alias in node.names)
        for module_name, name in wanted:
            module = importlib.import_module(module_name)
            check(f"{entry} imports {module_name}.{name}", hasattr(module, name))


def main() -> None:
    tests = [value for key, value in sorted(globals().items()) if key.startswith("test_")]
    for test in tests:
        test()
    print(f"\n{len(tests)} test groups passed")


if __name__ == "__main__":
    main()
