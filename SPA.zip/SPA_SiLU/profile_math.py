"""Polynomial fitting, error measurement and range-adaptation rules for SiLU and the comparison methods."""
from __future__ import annotations

import math
from collections.abc import Callable

import numpy as np
from numpy.polynomial.chebyshev import chebfit, chebpts1, chebval
from scipy.optimize import linprog, minimize_scalar

ArrayFunc = Callable[[np.ndarray], np.ndarray]


def silu(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=np.float64)
    return 0.5 * x * (1.0 + np.tanh(0.5 * x))


def logistic(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=np.float64)
    return 0.5 * (1.0 + np.tanh(0.5 * x))


def map_t_to_x(t: np.ndarray, lo: float, hi: float) -> np.ndarray:
    return 0.5 * (hi - lo) * t + 0.5 * (hi + lo)


def chebyshev_interpolant(
    func: ArrayFunc,
    degree: int,
    lo: float,
    hi: float,
) -> np.ndarray:
    nodes = chebpts1(degree + 1)
    values = func(map_t_to_x(nodes, lo, hi))
    return np.asarray(chebfit(nodes, values, degree), dtype=np.float64)


def solve_minimax_on_grid(
    target: np.ndarray,
    vandermonde: np.ndarray,
) -> tuple[np.ndarray, float]:
    rows = len(target)
    upper = np.hstack([vandermonde, -np.ones((rows, 1))])
    lower = np.hstack([-vandermonde, -np.ones((rows, 1))])
    constraints = np.vstack([upper, lower])
    bounds = np.concatenate([target, -target])
    objective = np.concatenate([np.zeros(vandermonde.shape[1]), [1.0]])
    variable_bounds = [(None, None)] * vandermonde.shape[1] + [(0.0, None)]

    result = linprog(
        objective,
        A_ub=constraints,
        b_ub=bounds,
        bounds=variable_bounds,
        method="highs",
    )
    if not result.success:
        raise RuntimeError(f"minimax LP failed: {result.message}")
    return np.asarray(result.x[:-1], dtype=np.float64), float(result.x[-1])


def spa_target(t: np.ndarray, radius: float) -> np.ndarray:
    x = radius * np.sqrt(np.maximum(0.0, 0.5 * (t + 1.0)))
    return silu(x) - 0.5 * x


def fit_spa_minimax(
    radius: float,
    degree: int,
    grid_size: int = 3000,
) -> tuple[np.ndarray, float]:
    theta = np.linspace(0.0, np.pi, grid_size)
    t = np.sort(np.cos(theta))
    target = spa_target(t, radius)
    vandermonde = np.polynomial.chebyshev.chebvander(t, degree)
    return solve_minimax_on_grid(target, vandermonde)


def evaluate_spa(
    radius: float,
    coefficients: np.ndarray,
    points: int = 300001,
) -> dict[str, float]:
    x = np.linspace(-radius, radius, points, dtype=np.float64)
    t = 2.0 * (x / radius) ** 2 - 1.0
    approximation = 0.5 * x + chebval(t, coefficients)
    error = approximation - silu(x)
    absolute = np.abs(error)
    index = int(np.argmax(absolute))
    return {
        "max_abs_error": float(absolute[index]),
        "mean_abs_error": float(np.mean(absolute)),
        "rmse": float(np.sqrt(np.mean(error * error))),
        "argmax_x": float(x[index]),
    }


def fit_direct_minimax(
    func: ArrayFunc,
    degree: int,
    lo: float,
    hi: float,
    grid_size: int = 3001,
    validation_points: int = 200001,
    refinements: int = 6,
) -> np.ndarray:
    uniform = np.linspace(-1.0, 1.0, grid_size)
    lobatto = np.cos(np.pi * np.arange(grid_size) / (grid_size - 1))
    grid = np.unique(np.concatenate([uniform, lobatto]))
    dense = np.linspace(-1.0, 1.0, validation_points)
    dense_target = func(map_t_to_x(dense, lo, hi))
    coefficients: np.ndarray | None = None

    for _ in range(refinements):
        target = func(map_t_to_x(grid, lo, hi))
        vandermonde = np.polynomial.chebyshev.chebvander(grid, degree)
        coefficients, lp_error = solve_minimax_on_grid(target, vandermonde)
        error = chebval(dense, coefficients) - dense_target
        absolute = np.abs(error)
        max_error = float(np.max(absolute))

        derivative_sign = np.sign(np.diff(error))
        if len(derivative_sign):
            for i in range(1, len(derivative_sign)):
                if derivative_sign[i] == 0:
                    derivative_sign[i] = derivative_sign[i - 1]
            for i in range(len(derivative_sign) - 2, -1, -1):
                if derivative_sign[i] == 0:
                    derivative_sign[i] = derivative_sign[i + 1]
            extrema = np.where(derivative_sign[:-1] * derivative_sign[1:] <= 0)[0] + 1
        else:
            extrema = np.array([], dtype=int)
        extrema = np.unique(np.concatenate([[0], extrema, [len(dense) - 1]]))
        strong = extrema[absolute[extrema] >= 0.75 * max_error]
        additions = dense[np.unique(np.concatenate([strong, [int(np.argmax(absolute))]]))]
        old_size = len(grid)
        grid = np.unique(np.concatenate([grid, additions]))
        if len(grid) == old_size or max_error <= lp_error * (1.0 + 5e-7):
            break

    if coefficients is None:
        raise RuntimeError("minimax fit did not run")
    return coefficients


def evaluate_direct(
    coefficients: np.ndarray,
    lo: float,
    hi: float,
    func: ArrayFunc,
    operating_radius: float,
    points: int = 300001,
) -> dict[str, float]:
    x = np.linspace(-operating_radius, operating_radius, points, dtype=np.float64)
    t = 2.0 * (x - lo) / (hi - lo) - 1.0
    approximation = chebval(t, coefficients)
    error = approximation - func(x)
    absolute = np.abs(error)
    return {
        "max_abs_error": float(np.max(absolute)),
        "mean_abs_error": float(np.mean(absolute)),
        "rmse": float(np.sqrt(np.mean(error * error))),
    }


def evaluate_logistic_first(
    coefficients: np.ndarray,
    lo: float,
    hi: float,
    operating_radius: float,
    points: int = 300001,
) -> dict[str, float]:
    x = np.linspace(-operating_radius, operating_radius, points, dtype=np.float64)
    t = 2.0 * (x - lo) / (hi - lo) - 1.0
    approximation = x * chebval(t, coefficients)
    error = approximation - silu(x)
    absolute = np.abs(error)
    return {
        "max_abs_error": float(np.max(absolute)),
        "mean_abs_error": float(np.mean(absolute)),
        "rmse": float(np.sqrt(np.mean(error * error))),
    }


def fit_asinh_composite(
    radius: float,
    degree_stage1: int = 31,
    degree_stage2: int = 27,
) -> tuple[float, np.ndarray, np.ndarray]:
    dense_t = np.linspace(-1.0, 1.0, 120001)
    target = silu(radius * dense_t)

    def build(alpha: float) -> tuple[np.ndarray, np.ndarray]:
        scale = math.sinh(alpha)
        stage1_nodes = chebpts1(degree_stage1 + 1)
        stage1 = chebfit(
            stage1_nodes,
            np.arcsinh(scale * stage1_nodes) / alpha,
            degree_stage1,
        )
        stage2_nodes = chebpts1(degree_stage2 + 1)
        stage2 = chebfit(
            stage2_nodes,
            silu(radius * np.sinh(alpha * stage2_nodes) / scale),
            degree_stage2,
        )
        return np.asarray(stage1, dtype=np.float64), np.asarray(stage2, dtype=np.float64)

    def objective(alpha: float) -> float:
        stage1, stage2 = build(alpha)
        coordinate = chebval(dense_t, stage1)
        return float(np.max(np.abs(chebval(coordinate, stage2) - target)))

    optimum = minimize_scalar(
        objective,
        bounds=(0.25, 4.0),
        method="bounded",
        options={"xatol": 1e-10},
    )
    stage1, stage2 = build(float(optimum.x))
    return float(optimum.x), stage1, stage2


def evaluate_composite(
    radius: float,
    stage1: np.ndarray,
    stage2: np.ndarray,
    points: int = 300001,
) -> dict[str, float]:
    t = np.linspace(-1.0, 1.0, points, dtype=np.float64)
    x = radius * t
    coordinate = chebval(t, stage1)
    approximation = chebval(coordinate, stage2)
    error = approximation - silu(x)
    absolute = np.abs(error)
    return {
        "max_abs_error": float(np.max(absolute)),
        "mean_abs_error": float(np.mean(absolute)),
        "rmse": float(np.sqrt(np.mean(error * error))),
        "stage1_output_min": float(np.min(coordinate)),
        "stage1_output_max": float(np.max(coordinate)),
    }
