"""Task registry for multiple-choice activation-replacement evaluation.

A task turns a HuggingFace split into a list of ``Example`` objects made
of plain text. Tokenisation, scoring and metrics live in
``mcq_common.py``, so adding a task never requires touching the harness.

Two shapes of task are supported:

* **shared context** (HellaSwag, MMLU, ARC-Challenge): one context, N
  candidate continuations.
* **per-choice context**: the candidate is substituted into the context
  and the scored continuation is the shared remainder, as the
  partial-evaluation protocol requires. No registered task uses this at
  present; ``Example.contexts`` keeps the capability because dropping it
  would make a partial-evaluation task expensive to add back.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass, field

import numpy as np
from datasets import load_dataset

LETTERS = "ABCDEFGH"


@dataclass
class Example:
    """One multiple-choice item, as text."""

    context: str
    choices: list[str]
    gold: int
    key: str = ""
    contexts: list[str] | None = None

    def __post_init__(self) -> None:
        if not self.choices:
            raise ValueError("an example needs at least one choice")
        if not 0 <= self.gold < len(self.choices):
            raise ValueError(f"gold index {self.gold} outside 0..{len(self.choices) - 1}")
        if self.contexts is not None and len(self.contexts) != len(self.choices):
            raise ValueError("contexts must have one entry per choice")

    def context_for(self, index: int) -> str:
        return self.context if self.contexts is None else self.contexts[index]


@dataclass
class TaskSpec:
    """A benchmark, plus how it is scored.

    ``kind`` is ``"mcq"`` for candidate-scoring tasks and ``"lm"`` for
    language-modelling corpora, where each example carries a single
    continuation and the metric is per-token NLL rather than accuracy.

    ``tier`` is ``"main"`` for tasks that carry the reported result and
    ``"appendix"`` for those that only add pooling volume. The split comes
    from measured resolution, not from taste: the appendix tasks returned
    null on every method with minimum detectable effects of 0.27 to 1.5
    percentage points.
    """

    name: str
    loader: Callable[[str, int, int], list[Example]]
    eval_split: str
    calibration_split: str
    choice_prefix: str = " "
    primary_metric: str = "acc_norm"
    chat_system_prompt: str = ""
    hf_sources: tuple = field(default_factory=tuple)
    kind: str = "mcq"
    tier: str = "main"
    notes: str = ""


_SOURCE_OVERRIDES: dict[str, tuple] = {}


def set_source_override(task_name: str, spec: str) -> None:
    """Point a task at a different Hub repo without editing this file.

    ``spec`` is ``repo`` or ``repo:config``, optionally comma-separated to
    give several candidates in order. Exposed as ``--hf-source`` so a repo
    that goes offline or drops its loading script can be worked around at
    the command line.
    """
    sources = []
    for piece in spec.split(","):
        piece = piece.strip()
        if not piece:
            continue
        repo, _, config = piece.partition(":")
        sources.append((repo, config or None))
    if sources:
        _SOURCE_OVERRIDES[task_name] = tuple(sources)


def _load_split(sources: tuple, split: str, task: str | None = None):
    """Load ``split`` from the first source that resolves.

    Each source is a repo id or a ``(repo id, config)`` pair. Several are
    listed per task because ``datasets>=3.0`` refuses Python loading
    scripts, and a number of canonical repos still ship one; the parquet
    mirrors are listed first for exactly that reason.
    """
    if task and task in _SOURCE_OVERRIDES:
        sources = _SOURCE_OVERRIDES[task]

    failures: list[str] = []
    for source in sources:
        path, config = source if isinstance(source, tuple) else (source, None)
        label = f"{path}{'/' + config if config else ''}"
        try:
            dataset = load_dataset(path, config) if config else load_dataset(path)
        except Exception as exc:  # noqa: BLE001 - report every attempt
            failures.append(f"  {label}: {exc}")
            continue
        if split not in dataset:
            failures.append(f"  {label}: has splits {sorted(dataset)}, not {split!r}")
            continue
        if label != str(sources[0]):
            print(f"  loaded {split!r} from fallback source {label}")
        return dataset[split]

    hint = ""
    if any("no longer supported" in failure for failure in failures):
        hint = (
            "\nEvery candidate ships a Python loading script, which datasets>=3.0 "
            "refuses. Point at a parquet mirror with --hf-source repo[:config]."
        )
    raise RuntimeError(
        f"could not load split {split!r} from any source:\n"
        + "\n".join(failures)
        + hint
    )


def _field(row: dict, *names: str):
    """Fetch the first present column, tolerating mirror schema drift.

    Parquet mirrors do not always keep the original column names, so
    loaders name the alternatives they accept and fail with the actual
    schema rather than a bare KeyError.
    """
    for name in names:
        if name in row and row[name] is not None:
            return row[name]
    raise KeyError(
        f"none of {list(names)} present; this source has columns {sorted(row)}"
    )


def _subsample(dataset, max_samples: int, seed: int):
    if max_samples <= 0 or max_samples >= len(dataset):
        return dataset
    rng = np.random.default_rng(seed)
    indices = np.sort(rng.choice(len(dataset), size=max_samples, replace=False))
    return dataset.select(indices.tolist())


# --------------------------------------------------------------------------
# HellaSwag
# --------------------------------------------------------------------------

HELLASWAG_SOURCES = ("Rowan/hellaswag", "hellaswag")


def hellaswag_clean(text: str) -> str:
    """Standard HellaSwag detokenisation.

    Reproduces the reference preprocessing, including its single-pass
    whitespace collapse, so absolute accuracy stays comparable to
    published numbers.
    """
    text = text.strip()
    text = text.replace(" [title]", ". ")
    text = re.sub(r"\[.*?\]", "", text)
    text = text.replace("  ", " ")
    return text


def load_hellaswag(split: str, max_samples: int = 0, seed: int = 20260901) -> list[Example]:
    dataset = _subsample(_load_split(HELLASWAG_SOURCES, split, task="hellaswag"), max_samples, seed)
    examples: list[Example] = []
    for position in range(len(dataset)):
        row = dataset[position]
        label = row.get("label", "")
        if label is None or str(label).strip() == "":
            raise ValueError(
                f"HellaSwag split {split!r} carries no labels; "
                "the test split is unlabelled, evaluate on 'validation'."
            )
        context_tail = f"{row['ctx_a']} {row['ctx_b'].capitalize()}"
        examples.append(
            Example(
                context=hellaswag_clean(f"{row['activity_label']}: {context_tail}"),
                choices=[hellaswag_clean(ending) for ending in row["endings"]],
                gold=int(label),
                key=str(row.get("ind", position)),
            )
        )
    return examples


# --------------------------------------------------------------------------
# MMLU
# --------------------------------------------------------------------------

MMLU_SOURCES = (("cais/mmlu", "all"), ("hails/mmlu_no_train", "all"))


def load_mmlu(split: str, max_samples: int = 0, seed: int = 20260901) -> list[Example]:
    """Zero-shot MMLU in the standard letter-answer format.

    The options are enumerated in the context and the scored continuation
    is a single letter. That is the conventional protocol, but it is also
    the least sensitive readout available: one token decides the item, so
    an activation perturbation has a single position to act on.
    """
    dataset = _subsample(_load_split(MMLU_SOURCES, split, task="mmlu"), max_samples, seed)
    examples: list[Example] = []
    for position in range(len(dataset)):
        row = dataset[position]
        options = list(row["choices"])
        subject = str(row.get("subject", "")).replace("_", " ").strip()
        header = (
            f"The following are multiple choice questions (with answers) about {subject}."
            if subject
            else "The following are multiple choice questions (with answers)."
        )
        enumerated = "\n".join(f"{LETTERS[i]}. {text}" for i, text in enumerate(options))
        examples.append(
            Example(
                context=f"{header}\n\n{row['question'].strip()}\n{enumerated}\nAnswer:",
                choices=[LETTERS[i] for i in range(len(options))],
                gold=int(row["answer"]),
                key=f"{subject}:{position}",
            )
        )
    return examples


# --------------------------------------------------------------------------
# ARC-Challenge
# --------------------------------------------------------------------------

def _arc_sources(config: str) -> tuple:
    return (("allenai/ai2_arc", config), ("ai2_arc", config))


ARC_SOURCES = _arc_sources("ARC-Challenge")
ARC_EASY_SOURCES = _arc_sources("ARC-Easy")


def _load_arc(config: str, split: str, max_samples: int, seed: int) -> list[Example]:
    """ARC with the answer text as the scored continuation.

    A minority of items carry three or five options rather than four. The
    harness handles ragged choice counts, so they need no special case.
    """
    dataset = _subsample(_load_split(_arc_sources(config), split, task=config), max_samples, seed)
    examples: list[Example] = []
    skipped = 0
    for position in range(len(dataset)):
        row = dataset[position]
        labels = list(row["choices"]["label"])
        texts = list(row["choices"]["text"])
        key = str(row.get("answerKey", "")).strip()
        if key not in labels:
            skipped += 1
            continue
        examples.append(
            Example(
                context=f"Question: {row['question'].strip()}\nAnswer:",
                choices=[text.strip() for text in texts],
                gold=labels.index(key),
                key=str(row.get("id", position)),
            )
        )
    if skipped:
        print(f"{config} {split}: skipped {skipped} rows with an unresolvable answerKey")
    return examples


def load_arc_challenge(split: str, max_samples: int = 0, seed: int = 20260901) -> list[Example]:
    return _load_arc("ARC-Challenge", split, max_samples, seed)


def load_arc_easy(split: str, max_samples: int = 0, seed: int = 20260901) -> list[Example]:
    """Same format as ARC-Challenge at lower difficulty, and twice the test set."""
    return _load_arc("ARC-Easy", split, max_samples, seed)


# --------------------------------------------------------------------------
# PIQA
# --------------------------------------------------------------------------

PIQA_SOURCES = (
    ("lighteval/piqa", None),
    ("baber/piqa", None),
    ("ybisk/piqa", None),
    ("piqa", None),
)


def load_piqa(split: str, max_samples: int = 0, seed: int = 20260901) -> list[Example]:
    """Physical commonsense, two solutions per goal."""
    dataset = _subsample(_load_split(PIQA_SOURCES, split, task="piqa"), max_samples, seed)
    examples: list[Example] = []
    for position in range(len(dataset)):
        row = dataset[position]
        label = int(_field(row, "label"))
        if label < 0:
            raise ValueError(
                f"PIQA split {split!r} is unlabelled; evaluate on 'validation'."
            )
        examples.append(
            Example(
                context=f"Question: {str(_field(row, 'goal')).strip()}\nAnswer:",
                choices=[
                    str(_field(row, "sol1", "solution1")).strip(),
                    str(_field(row, "sol2", "solution2")).strip(),
                ],
                gold=label,
                key=str(position),
            )
        )
    return examples


# --------------------------------------------------------------------------
# SocialIQA
# --------------------------------------------------------------------------

# The canonical repos still ship a loading script, which datasets>=3.0
# refuses, so the parquet mirror leads.
SIQA_SOURCES = (
    ("lighteval/siqa", None),
    ("allenai/social_i_qa", None),
    ("social_i_qa", None),
)


def load_social_i_qa(split: str, max_samples: int = 0, seed: int = 20260901) -> list[Example]:
    """Social commonsense. Three options and a low base rate, so many
    items sit near the decision boundary."""
    dataset = _subsample(
        _load_split(SIQA_SOURCES, split, task="social_i_qa"), max_samples, seed
    )
    examples: list[Example] = []
    for position in range(len(dataset)):
        row = dataset[position]
        label = str(_field(row, "label", "answer")).strip()
        if label not in {"1", "2", "3"}:
            raise ValueError(
                f"SocialIQA split {split!r} has an unusable label {label!r} at row "
                f"{position}; this loader expects the 1/2/3 convention. A mirror "
                "using 0/1/2 would need the offset removed below."
            )
        context = str(_field(row, "context")).strip()
        question = str(_field(row, "question")).strip()
        answers = [
            str(_field(row, "answerA", "answer_a", "answerA_text")).strip(),
            str(_field(row, "answerB", "answer_b", "answerB_text")).strip(),
            str(_field(row, "answerC", "answer_c", "answerC_text")).strip(),
        ]
        examples.append(
            Example(
                context=f"{context}\nQuestion: {question}\nAnswer:",
                choices=answers,
                gold=int(label) - 1,
                key=str(position),
            )
        )
    return examples


# --------------------------------------------------------------------------
# RACE (high school)
# --------------------------------------------------------------------------

RACE_SOURCES = (("ehovy/race", "high"), ("race", "high"), ("EleutherAI/race", "high"))


def load_race_high(split: str, max_samples: int = 0, seed: int = 20260901) -> list[Example]:
    """Reading comprehension over full passages.

    The only task in the set with contexts in the hundreds of tokens,
    which is the regime the range plan has otherwise never been tested
    in. Activation outliers in Llama-family models grow with sequence
    length, so this is where a train-calibrated plan is most likely to
    stop covering.
    """
    dataset = _subsample(_load_split(RACE_SOURCES, split, task="race_high"), max_samples, seed)
    examples: list[Example] = []
    for position in range(len(dataset)):
        row = dataset[position]
        options = list(row["options"])
        answer = str(row["answer"]).strip().upper()
        if answer not in LETTERS[: len(options)]:
            raise ValueError(f"RACE row {position} has answer {answer!r}")
        article = " ".join(str(row["article"]).split())
        question = " ".join(str(row["question"]).split())
        examples.append(
            Example(
                context=f"Article: {article}\n\nQuestion: {question}\nAnswer:",
                choices=[str(option).strip() for option in options],
                gold=LETTERS.index(answer),
                key=str(row.get("example_id", position)),
            )
        )
    return examples


# --------------------------------------------------------------------------
# WikiText-2 (language modelling)
# --------------------------------------------------------------------------

# --------------------------------------------------------------------------
# Language-modelling corpora
# --------------------------------------------------------------------------

WIKITEXT_SOURCES = (
    ("Salesforce/wikitext", "wikitext-2-raw-v1"),
    ("wikitext", "wikitext-2-raw-v1"),
)
C4_SOURCES = (("NeelNanda/c4-10k", None), ("stas/c4-en-10k", None))
CODE_SOURCES = (
    ("codeparrot/codeparrot-clean-valid", None),
    ("bigcode/the-stack-smol", "data/python"),
)

CORPUS_WINDOW_CHARS = 3500
CORPUS_EVAL_FRACTION = 0.25


def _chunk(text: str, window_chars: int) -> list[str]:
    windows = [
        text[start : start + window_chars]
        for start in range(0, len(text), window_chars)
    ]
    return [window for window in windows if len(window) > window_chars // 4]


def _corpus_loader(
    sources: tuple,
    task: str,
    text_columns: tuple[str, ...] = ("text",),
    hf_split: str | None = None,
    window_chars: int = CORPUS_WINDOW_CHARS,
):
    """Build a loader that turns a text corpus into fixed-size windows.

    Chunking is by character count rather than tokens so this module needs
    no tokenizer; roughly 3,500 characters lands near 900 tokens.

    Corpora that ship a single split are cut deterministically into a
    calibration part and a disjoint evaluation part, so Protocol A holds:
    nothing the range plan is fitted on is ever scored. Corpora with real
    splits (WikiText-2) use them directly.
    """

    def load(split: str, max_samples: int = 0, seed: int = 20260901) -> list[Example]:
        dataset = _load_split(sources, hf_split or split, task=task)
        column = next((name for name in text_columns if name in dataset.column_names), None)
        if column is None:
            raise KeyError(
                f"{task}: none of {list(text_columns)} present; "
                f"this source has columns {dataset.column_names}"
            )
        text = "\n".join(piece for piece in dataset[column] if piece and piece.strip())
        windows = _chunk(text, window_chars)

        if hf_split is not None:
            # One split on the Hub: carve a disjoint eval tail off the end.
            cut = int(len(windows) * (1.0 - CORPUS_EVAL_FRACTION))
            if split in {"train", "calibration"}:
                windows = windows[:cut]
            elif split in {"test", "validation"}:
                windows = windows[cut:]
            else:
                raise ValueError(f"{task}: unknown split {split!r}")

        if 0 < max_samples < len(windows):
            rng = np.random.default_rng(seed)
            keep = np.sort(rng.choice(len(windows), size=max_samples, replace=False))
            windows = [windows[index] for index in keep]

        return [
            Example(context="", choices=[window], gold=0, key=str(index))
            for index, window in enumerate(windows)
        ]

    return load


load_wikitext2 = _corpus_loader(WIKITEXT_SOURCES, task="wikitext2")
load_c4_en = _corpus_loader(C4_SOURCES, task="c4_en", hf_split="train")
# Code tokenises denser than prose: 3,500 characters of Python can exceed
# 1,536 tokens, which would truncate many windows. A shorter
# window keeps every window intact and yields more of them.
CODE_WINDOW_CHARS = 2500

load_code_python = _corpus_loader(
    CODE_SOURCES,
    task="code_python",
    text_columns=("content", "text", "code"),
    hf_split="train",
    window_chars=CODE_WINDOW_CHARS,
)


TASKS: dict[str, TaskSpec] = {
    "hellaswag": TaskSpec(
        name="hellaswag",
        loader=load_hellaswag,
        eval_split="validation",
        calibration_split="train",
        primary_metric="acc_norm",
        chat_system_prompt="Continue the passage with the most plausible ending.",
        hf_sources=HELLASWAG_SOURCES,
        notes=(
            "train 39,905 / validation 10,042 / test unlabelled. Endings vary "
            "in length, so byte-normalised accuracy is primary."
        ),
    ),
    "mmlu": TaskSpec(
        name="mmlu",
        loader=load_mmlu,
        eval_split="test",
        calibration_split="validation",
        primary_metric="acc",
        chat_system_prompt="Answer the multiple choice question with a single letter.",
        hf_sources=MMLU_SOURCES,
        notes=(
            "test 14,042 / validation 1,531 / dev 285. No native train split, so "
            "calibration runs on validation; pass --split validation,dev to use "
            "both. auxiliary_train is deliberately not used: it is drawn from "
            "ARC, MC_TEST, OBQA and RACE, which would overlap ARC-Challenge. "
            "All continuations are one letter, so acc and acc_norm coincide."
        ),
    ),
    "arc_easy": TaskSpec(
        name="arc_easy",
        tier="appendix",
        loader=load_arc_easy,
        eval_split="test",
        calibration_split="train",
        primary_metric="acc_norm",
        chat_system_prompt="Answer the question.",
        hf_sources=ARC_EASY_SOURCES,
        notes=(
            "train 2,251 / validation 570 / test 2,376. Identical format to "
            "ARC-Challenge at lower difficulty, so the pair isolates whether "
            "difficulty changes the conclusion at matched format."
            "\n\nAppendix tier: null on every method at MDE 0.27-0.87 pp; kept because the matched format against ARC-Challenge shows difficulty does not change the conclusion."
        ),
    ),
    "piqa": TaskSpec(
        name="piqa",
        tier="appendix",
        loader=load_piqa,
        eval_split="validation",
        calibration_split="train",
        primary_metric="acc_norm",
        chat_system_prompt="Answer the question.",
        hf_sources=PIQA_SOURCES,
        notes=(
            "train 16,113 / validation 1,838 / test unlabelled. Two options "
            "of unequal length, so acc_norm is primary."
            "\n\nAppendix tier: null on every method at MDE 0.28-0.85 pp."
        ),
    ),
    "social_i_qa": TaskSpec(
        name="social_i_qa",
        loader=load_social_i_qa,
        eval_split="validation",
        calibration_split="train",
        primary_metric="acc_norm",
        chat_system_prompt="Answer the question about the situation.",
        hf_sources=SIQA_SOURCES,
        notes=(
            "train 33,410 / validation 1,954. Three options and a base rate "
            "near 47%, so many items sit close to the boundary and the flip "
            "rate should be high. Large calibration split."
        ),
    ),
    "race_high": TaskSpec(
        name="race_high",
        loader=load_race_high,
        eval_split="test",
        calibration_split="train",
        primary_metric="acc_norm",
        chat_system_prompt="Answer the question about the passage.",
        hf_sources=RACE_SOURCES,
        notes=(
            "train 62,445 / validation 3,451 / test 3,498. Contexts run to "
            "several hundred tokens, the only long-context regime in the set. "
            "Run it with --max-length 2048."
        ),
    ),
    "c4_en": TaskSpec(
        name="c4_en",
        loader=load_c4_en,
        eval_split="test",
        calibration_split="train",
        primary_metric="token_nll",
        hf_sources=C4_SOURCES,
        kind="lm",
        notes=(
            "Web text rather than the encyclopedic register of WikiText-2. "
            "Single Hub split, cut 75/25 into disjoint calibration and "
            "evaluation windows."
        ),
    ),
    "code_python": TaskSpec(
        name="code_python",
        tier="appendix",
        loader=load_code_python,
        eval_split="test",
        calibration_split="train",
        primary_metric="token_nll",
        hf_sources=CODE_SOURCES,
        kind="lm",
        notes=(
            "Python source. The furthest domain from the MCQ benchmarks, so "
            "the most likely to push the required operating radius past the "
            "72 that WikiText-2 needed. Single Hub split, cut 75/25."
            "\n\nAppendix tier: WikiText-2 and C4 carry the reported perplexity axis; this is kept for the operating-range argument, since code tokenises densest of the three."
        ),
    ),
    "wikitext2": TaskSpec(
        name="wikitext2",
        loader=load_wikitext2,
        eval_split="test",
        calibration_split="train",
        primary_metric="token_nll",
        hf_sources=WIKITEXT_SOURCES,
        kind="lm",
        notes=(
            "Raw WikiText-2 in ~3,500-character windows, about 370 at test. "
            "Scored as per-token NLL and perplexity with a paired bootstrap, "
            "not accuracy. No ceiling and no argmax quantisation, so it "
            "resolves differences far below what any accuracy table can. "
            "Calibrating on its train split also yields a generic-corpus "
            "range plan, independent of any benchmark."
        ),
    ),
    "arc_challenge": TaskSpec(
        name="arc_challenge",
        tier="appendix",
        loader=load_arc_challenge,
        eval_split="test",
        calibration_split="train",
        primary_metric="acc_norm",
        chat_system_prompt="Answer the question.",
        hf_sources=ARC_SOURCES,
        notes=(
            "train 1,119 / validation 299 / test 1,172. Choice counts vary "
            "between 3 and 5. Calibration on 1,119 train items is thin; pass "
            "--split train,validation to add 299 more."
            "\n\nAppendix tier: null on every method at MDE 0.41-1.48 pp; also scores far below the model card, which uses chat-formatted MCQ rather than continuation scoring."
        ),
    ),
}


def get_task(name: str) -> TaskSpec:
    if name not in TASKS:
        raise ValueError(f"unknown task {name!r}; available: {sorted(TASKS)}")
    return TASKS[name]
