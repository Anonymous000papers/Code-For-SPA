#!/usr/bin/env python3
"""Compile and exercise gelu_bench against a scale-aware arithmetic test double.

NOT a SEAL build, encryption/noise test, security check, or timing experiment.
The production CMake target NEVER adds tests/arithmetic_model to include paths.
"""
from pathlib import Path
import csv,json,os,shutil,subprocess,tempfile
ROOT=Path(__file__).resolve().parents[1]
CXX=shutil.which('g++') or shutil.which('clang++')
if not CXX:raise SystemExit('C++17 compiler required')
records=[]
with tempfile.TemporaryDirectory() as temp:
    out=Path(temp);binary=out/'arithmetic-model-NOT-SEAL'
    subprocess.run([CXX,'-std=c++17','-O1','-Wall','-Wextra','-Wpedantic',
                    '-I'+str(ROOT/'tests/arithmetic_model'),'-I'+str(ROOT/'src'),
                    str(ROOT/'src/gelu_bench.cpp'),'-o',str(binary)],check=True)
    for R in (5,20):
        for mode in ('grid','random'):
            csv_path=out/f'r{R}_{mode}.csv';samples=out/f'r{R}_{mode}_samples.csv'
            command=[str(binary),'--methods','moai,euston','--range',str(-R),str(R),
                     '--poly-degree','8192','--slots','4096','--input',mode,'--no-sec',
                     '--warmup','1','--repeat','2','--euston-breakdown','1',
                     '--csv-out',str(csv_path),'--samples-csv',str(samples)]
            result=subprocess.run(command,text=True,capture_output=True)
            if result.returncode:raise RuntimeError(result.stdout+result.stderr)
            rows=list(csv.DictReader(csv_path.open()));assert len(rows)==2
            for r in rows:
                assert None not in r and all(v is not None for v in r.values()),r
                assert r['context_count']=='1' and r['bootstraps']=='0'
                assert r['security_validation']=='disabled-diagnostic-only'
                for k in ('encrypt','decrypt','decode','dynamic_plain_encode'):assert r[k]=='0'
                # MOAI is the imported plaintext model profile: 1 (y/B) + 6 (degree-23
                # Chebyshev product tree and coefficients) + 1 (reconstruction) at R5,
                # plus 2 per extension stage (3 stages) at R20.
                assert int(r['consumed_levels'])==((8 if R==5 else 14) if r['method']=='moai' else (40 if R==5 else 42))
                if r['method']=='moai':
                    assert r['active_profile']==('moai-r5' if R==5 else 'moai-r20')
                    assert int(r['ct_ct_total'])==(23 if R==5 else 29) and int(r['ct_plain_multiply'])==(36 if R==5 else 42)
                    assert int(r['polynomial_degree'])==23
                if r['method']=='euston':
                    assert int(r['consumed_levels'])==(40 if R==5 else 42)
                    assert int(r['ct_ct_total'])==(55 if R==5 else 59)
                    assert r['ct_plain_multiply']=='43'
                    assert float(r['ckks_extra_max'])<1e-9
                    assert r['output_chain']=='4'
                    assert float(r['euston_sign_scale'])==1.2*R
                    assert r['euston_tau']==('1' if R==5 else '3')
                elif R==20:
                    assert float(r['ckks_extra_max'])<1e-9
                    # the imported plaintext moai-r20 profile (B=7, 3 stages): 4.54e-3 vs erf-GELU
                    assert .0044<float(r['method_bias_max'])<.0047
                records.append({'method':r['method'],'radius':R,'input_mode':mode,
                    'context_count':int(r['context_count']),'consumed_levels':int(r['consumed_levels']),
                    'ct_ct_total':int(r['ct_ct_total']),'ct_plain_multiply':int(r['ct_plain_multiply']),
                    'rescale_operations':int(r['rescale']),
                    'scale_bookkeeping_residual_NOT_CKKS':float(r['ckks_extra_max'])})
            assert len(list(csv.DictReader(samples.open())))==4
    # Guards are checked before arithmetic, including removed source stress flag.
    for extra,needle in [(['--euston-tau','1'],'exp tau'),
                         (['--euston-sign-scale','6'],'normalization'),
                         (['--euston-levels','40'],'middle primes'),
                         (['--allow-euston-wide'],'removed')]:
        p=subprocess.run([str(binary),'--method','euston','--range','-20','20',
                          '--poly-degree','8192','--slots','4096','--no-sec',*extra],text=True,capture_output=True)
        assert p.returncode!=0 and needle in p.stderr,(extra,p.stderr)
    p=subprocess.run([str(binary),'--method','euston','--range','-20','20'],text=True,capture_output=True)
    assert p.returncode!=0 and 'security table' in p.stderr
    p=subprocess.run([str(binary),'--method','euston','--range','-20','20','--describe-plan'],text=True,capture_output=True)
    assert p.returncode==0 and 'plan_only: true' in p.stdout
record={'status':'PASS_ARITHMETIC_MODEL_ONLY','encryption_executed':False,
        'seal_headers_used':False,'security_validated':False,'measurements':records}
report=os.environ.get('ARITHMETIC_MODEL_REPORT')
if report:Path(report).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
