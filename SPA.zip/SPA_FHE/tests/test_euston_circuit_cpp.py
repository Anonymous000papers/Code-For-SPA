#!/usr/bin/env python3
"""Compiles euston_circuit.hpp against a plain C++ evaluator and checks the released circuit end to end."""
from pathlib import Path
import shutil,subprocess,tempfile
ROOT=Path(__file__).resolve().parents[1]
compiler=shutil.which('g++') or shutil.which('clang++')
if compiler is None: raise SystemExit('A C++17 compiler is required for the arithmetic circuit test')
with tempfile.TemporaryDirectory() as d:
    out=Path(d)/'euston_circuit_test'
    subprocess.run([compiler,'-std=c++17','-O2','-Wall','-Wextra','-pedantic',
                    '-I'+str(ROOT/'src'),str(ROOT/'tests/euston_circuit_test.cpp'),'-o',str(out)],check=True)
    subprocess.run([str(out)],check=True)
