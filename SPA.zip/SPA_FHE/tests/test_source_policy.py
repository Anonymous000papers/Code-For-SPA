#!/usr/bin/env python3
"""Source-level policy checks: no secret-dependent branching, stable method names, single-chain evaluation, expected build targets."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
gelu = (ROOT / "src/gelu_bench.cpp").read_text()
silu = (ROOT / "src/silu_bench.cpp").read_text()
core = (ROOT / "src/spa_ckks_core.hpp").read_text()
header = (ROOT / "src/spa_silu_profiles.hpp").read_text()
gelu_header = (ROOT / "src/spa_profiles.hpp").read_text()
cmake = (ROOT / "CMakeLists.txt").read_text()
run_gelu = (ROOT / "scripts/run_gelu.sh").read_text()
run_silu = (ROOT / "scripts/run_silu.sh").read_text()
run_all = (ROOT / "scripts/run_all.sh").read_text()
readme = (ROOT / "README.md").read_text()

for method in ("spa-k39", "spa-k63", "spa-k87"):
    assert f'"{method}"' in gelu_header
for method in ("moai", "nexus", "euston"):
    assert f'"{method}"' in gelu
for method in ("spa-k39", "spa-k63", "spa-k87", "orion", "ensi", "sylph", "thor"):
    assert f'"{method}"' in silu or method.startswith("spa-")

for obsolete in ("spa-r56", "SPA_R56", "wide_profile"):
    assert obsolete not in silu, obsolete
    assert obsolete not in header, obsolete
for obsolete in ("R56_METHODS", "LEVELS_R56", "run_matrix r56", "r56) run_matrix"):
    assert obsolete not in run_silu, obsolete

public_sources = gelu + silu + run_gelu + run_silu + readme
for obsolete in (
    "moai-tanh23", "moai-v2", "euston-adapted",
    "spa-silu-r8-k15-ps4-raw", "speedup_vs_cachemir_thor",
    "spa-direct", "spa-r8-fused", "spa-r20-fused",
):
    assert obsolete not in public_sources, obsolete

assert "BumbleBee" not in gelu and "BumbleBee" not in silu
assert "NexusMethod" in gelu
assert "NexusConfig" in gelu
assert "nexus_required_sign_scale" in gelu
assert "source-domain" in gelu
assert "ill-conditioned-range-extension" in gelu
assert "gate_condition_max" in gelu
assert "--reserve-levels" in gelu
assert "--prime-bits" in gelu
assert "--prime-bits" in silu
assert "speedup_vs_spa_k87" in silu
assert "profile_catalog_sha256" in silu
assert "active_square_degree" in silu
assert "int repeats = 10;" in gelu
assert "int repeats = 10;" in silu
assert "double lo = -5.0;" in gelu and "double hi = 5.0;" in gelu
assert "double lo = -5.0;" in silu and "double hi = 5.0;" in silu
assert "add_benchmark(gelu_bench" in cmake
assert "add_benchmark(silu_bench" in cmake
assert "add_benchmark(gelu_quickgelu_bench gelu_bench.cpp)" in cmake
assert "SPA_GELU_TARGET_QUICKGELU=1" in cmake
assert "VERSION 1.15" in cmake
assert "MoaiModelMethod" in gelu and "MOAI_COEFFICIENTS_HIGH_TO_LOW" not in gelu and "gelu_range_profiles::moai" not in gelu
assert "moai_model_eval.hpp" in gelu and (ROOT / "src/moai_model_profiles.hpp").exists()
assert "moai_host_check" in cmake and "SPA_MOAI_MODEL_HEADER" in (ROOT / "src/moai_model_eval.hpp").read_text()
assert "add_benchmark(gelu_quickgelu_bench gelu_bench.cpp)" in cmake and "SPA_GELU_TARGET_QUICKGELU=1" in cmake
assert 'native_target_id() { return "quickgelu"; }' in (ROOT / "src/spa_quickgelu_profiles.hpp").read_text()
assert "quickgelu)" in run_gelu and "TARGET=quickgelu" in run_all
assert "profile_ps_host_check" in cmake
assert (ROOT / "scripts/validate_balanced_profiles.py").exists()
assert (ROOT / "tests/profile_ps_host_check.cpp").exists()
host_check = (ROOT / "tests/profile_ps_host_check.cpp").read_text()
for needed in ("decompose_chebyshev", "encodes_to_nonzero", "profile_plain_eval", "y_power * y_power"):
    assert needed in host_check
for generator in ("scripts/generate_spa_profiles.py", "scripts/generate_silu_spa_profiles.py"):
    text = (ROOT / generator).read_text()
    assert "TIER_TARGETS" in text and '"degrees": {"r5": 3, "r20": 15}' not in text

# Native targets: erf-GELU and QuickGELU, one decomposition schema.
assert not (ROOT / "src/spa_gelu_tanh_profiles.hpp").exists()
assert not (ROOT / "configs/spa_gelu_tanh_profiles.json").exists()
assert 'native_target_id() { return "erf-gelu"; }' in gelu_header
assert "SPA_PROFILE_HEADER" in core and "gelu_tanh_exact" not in core
assert "SPA_GELU_TARGET_TANH" not in gelu and "SPA_GELU_TARGET_QUICKGELU" in gelu and "native_activation" in gelu
assert "gelu_tanh_bench" not in cmake and "gelu_quickgelu_bench" in cmake
assert 'R5_METHODS="${ERF_METHODS:-spa-k39,spa-k63,spa-k87,nexus,moai}"' in run_gelu
assert 'spa-k39,spa-k63,spa-k87,euston}' in run_gelu and "TARGET=tanh" not in run_all
for source in (gelu, silu):
    assert "e_target,e_poly,e_coeff,e_he,e_total,decomposition_bound" in source
    assert "host_reference_semantics" in source
    assert "unrounded_reference" in source
    assert 'CSV_SCHEMA = "spa-1"' in source or ",spa-1," in source
assert "fit_target_id() const override { return \"quickgelu\"; }" in gelu
assert 'TARGET="${TARGET:-erf}"' in run_gelu and "gelu_quickgelu_bench" in run_gelu
for script in (run_gelu, run_silu):
    assert "roundB" in script and "precC" in script and "PRECISION_POINTS" in script
assert "TARGET=quickgelu" in run_all
assert "e_target" in readme and "Experiment C" in readme

# k=3 with PS4 is a one-block profile. The core must allow split=degree+1
# and must not evaluate an unused giant-step generator for that case.
assert "plan.ps_split > assignment.max_degree + 1" in core
assert "if (nodes.size() == 1) return" in core

assert 'LEVELS_R5="${LEVELS_R5:-${LEVELS:-22}}"' in run_gelu
assert 'LEVELS_R20="${LEVELS_R20:-${LEVELS:-30}}"' in run_gelu
assert 'RESERVE_LEVELS="${RESERVE_LEVELS:-4}"' in run_gelu
assert 'PRECISION_BITS="${PRECISION_BITS:-46}"' in run_gelu
assert 'R20_METHODS="${ERF_METHODS:-spa-k39,spa-k63,spa-k87,nexus,moai}"' in run_gelu
assert "euston" not in run_gelu.split('R5_METHODS="${ERF_METHODS:-', 1)[1].split('}', 1)[0]
assert 'R5_METHODS="${QUICKGELU_METHODS:-spa-k39,spa-k63,spa-k87,euston}"' in run_gelu
assert "euston_circuit::make_config" in gelu
assert "multiply_constant_exact_scale" in gelu
assert "gelu_range_profiles::catalog_sha256" in gelu
assert "profile_catalog_sha256" in gelu
assert "active_square_degree" in gelu
assert "speedup_vs_spa_k87" in gelu
assert "spa-warp" not in gelu
assert "spa-r8" not in gelu
assert "spa-r20" not in gelu
assert '--baseline spa_k87=spa-k87' in run_gelu

assert 'LEVELS_R5="${LEVELS_R5:-${LEVELS:-16}}"' in run_silu
assert 'LEVELS_R20="${LEVELS_R20:-${LEVELS:-16}}"' in run_silu
assert 'PRECISION_BITS="${PRECISION_BITS:-46}"' in run_silu
assert 'R5_METHODS="spa-k39,spa-k63,spa-k87,orion,ensi,sylph,thor"' in run_silu
assert 'R20_METHODS="spa-k39,spa-k63,spa-k87,orion-wide,thor-wide"' in run_silu
assert 'run_matrix r5 -5 5 ' in run_silu
assert 'run_matrix r20 -20 20 ' in run_silu
assert 'usage: $0 [build|r5|r20|roundB|precC|all|full]' in run_silu
assert "cleanup_obsolete_r56_results" in run_silu
assert "euston" not in silu.lower()
assert "euston" not in run_silu.lower()
assert "fused" not in run_gelu.lower()
assert "fused" not in run_silu.lower()
assert "INCLUDE_EUSTON" not in run_gelu
assert 'bash "${ROOT}/scripts/run_silu.sh" "${MODE}"' in run_all
assert 'TARGET=erf bash "${ROOT}/scripts/run_gelu.sh" "${MODE}"' in run_all

print("source policy checks passed")

assert "sign_env_" not in gelu and "raw_sign_" not in gelu
assert "->decrypt(" not in gelu
assert "->decode(" not in gelu
assert "->encrypt(" not in gelu
for forbidden in ("moai-ext", "euston-ext", "moai_ext", "euston_ext"):
    assert forbidden not in gelu + run_gelu
assert 'm.context_count=1' in gelu
assert 'args.secure128 &&' in gelu and 'CoeffModulus::MaxBitCount' in gelu
print("single-chain and stable-name source checks passed")
