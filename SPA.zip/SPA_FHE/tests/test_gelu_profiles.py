#!/usr/bin/env python3
"""erf-GELU SPA catalog invariants: tiers, degrees, fit-error windows, Experiment B variants, header hash."""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

import numpy as np
from numpy.polynomial.chebyshev import chebval
from scipy.special import erf

ROOT = Path(__file__).resolve().parents[1]
profile_path = ROOT / "configs/spa_profiles.json"
profile_bytes = profile_path.read_bytes()
profile_sha256 = hashlib.sha256(profile_bytes).hexdigest()
data = json.loads(profile_bytes)

assert data["format"] == "spa-gelu-two-range-v1"
assert data["target"] == "exact erf-GELU"
assert data["structure"] == "x/2 + Q_k(2*x^2/R^2 - 1)"
assert data["ranges"] == [
    {"label": "r5", "radius": 5.0},
    {"label": "r20", "radius": 20.0},
]
assert "legacy warped profile is excluded" in data["warp_policy"]

# Tiers are selected by target error on the PS ladder, the plaintext rule:
# fast <= 2.1e-2, balanced <= 1e-3, accurate <= 1e-4 per range. For the
# GELU targets this is one ladder step above the SiLU schedule.
expected = {
    "spa-k39": ("r5:k7;r20:k23", {"r5": 7, "r20": 23}, "fast"),
    "spa-k63": ("r5:k11;r20:k31", {"r5": 11, "r20": 31}, "balanced"),
    "spa-k87": ("r5:k11;r20:k39", {"r5": 11, "r20": 39}, "accurate"),
}
assert data["tier_selection"]["targets"] == {"fast": 2.1e-2, "balanced": 1e-3, "accurate": 1e-4}
methods = {item["id"]: item for item in data["method_variants"]}
assert set(expected) <= set(methods)
for method_id, (schedule, degrees, tier) in expected.items():
    method = methods[method_id]
    assert method["degree_schedule"] == schedule
    assert method["degrees"] == degrees
    assert method["tier"] == tier
    assert set(method["profiles"]) == {"r5", "r20"}

profiles = {item["name"]: item for item in data["profiles"]}
assert len([p for p in profiles.values() if p.get("rounding_decimals") is None]) == 5
assert len(profiles) == 15
for method_id, (_, degrees, tier) in expected.items():
    target = data["tier_selection"]["targets"][tier]
    for label, degree in degrees.items():
        radius = {"r5": 5, "r20": 20}[label]
        assert profiles[f"spa-gelu-r{radius}-k{degree}"]["dense_max_abs_error"] <= target
    # the selected degree is the smallest on the ladder that meets the target
    for entry in data["tier_selection"]["ladder"]:
        if entry["range_label"] in degrees and entry["degree_square"] < degrees[entry["range_label"]]:
            assert entry["dense_max_abs_error"] > target
for method in methods.values():
    for label, profile_id in method["profiles"].items():
        profile = profiles[profile_id]
        assert profile["range_label"] == label
        assert profile["degree_square"] == method["degrees"][label]
        assert profile["warp_a"] == 0.0
        assert len(profile["coefficients_chebyshev_low_to_high"]) == profile["degree_square"] + 1
        radius = float(profile["R"])
        x = np.linspace(-radius, radius, 100001)
        t = 2.0 * (x / radius) ** 2 - 1.0
        approx = 0.5 * x + chebval(t, profile["coefficients_chebyshev_low_to_high"])
        exact = 0.5 * x * (1.0 + erf(x / math.sqrt(2.0)))
        measured = float(np.max(np.abs(approx - exact)))
        stored = float(profile["dense_max_abs_error"])
        assert measured <= stored * 1.01 + 1e-10, (profile_id, measured, stored)
        assert float(np.max(np.abs((approx - approx[::-1]) - x))) < 2e-11

header = (ROOT / "src/spa_profiles.hpp").read_text()
assert profile_sha256 in header
assert 'native_target_id() { return "erf-gelu"; }' in header
assert '"spa-k63-d3"' in header and "rounding_decimals" in header
for method_id in expected:
    assert f'"{method_id}"' in header
for obsolete in ("spa-r8", "spa-r20", "spa-warp", "r20-warp08"):
    assert obsolete not in header

# Fixed regression windows for the committed refit.
errors = {name: float(profile["dense_max_abs_error"]) for name, profile in profiles.items()}
assert 1.1e-3 < errors["spa-gelu-r5-k7"] < 1.3e-3
assert 6.0e-6 < errors["spa-gelu-r5-k11"] < 7.0e-6
assert 4.9e-3 < errors["spa-gelu-r20-k23"] < 5.1e-3
assert 4.2e-4 < errors["spa-gelu-r20-k31"] < 4.4e-4
assert 2.0e-5 < errors["spa-gelu-r20-k39"] < 2.4e-5


# Experiment B variants: rounded copies of the balanced tier, nothing refitted.
rounded = {mid: m for mid, m in methods.items() if m.get("rounding_decimals") is not None}
assert set(rounded) == {f"spa-k63-d{d}" for d in (1, 2, 3, 4, 5)}, set(rounded)
for method_id, method in rounded.items():
    d = method["rounding_decimals"]
    assert method["derived_from"] == "spa-k63"
    assert method["degree_schedule"] == methods["spa-k63"]["degree_schedule"]
    for label, profile_id in method["profiles"].items():
        profile = profiles[profile_id]
        source = profiles[profile["derived_from"]]
        assert profile["derived_from"] == methods["spa-k63"]["profiles"][label]
        assert profile["degree_square"] == source["degree_square"]
        assert profile["ps_split"] == source["ps_split"]
        assert profile["R"] == source["R"]
        assert profile["coefficients_chebyshev_low_to_high"] == [
            round(c, d) for c in source["coefficients_chebyshev_low_to_high"]
        ]
        assert profile["coefficient_perturbation_max"] <= profile["coefficient_l1_perturbation"] * (1 + 1e-9) + 1e-15
        assert profile["unrounded_dense_max_abs_error"] == source["dense_max_abs_error"]
    for label in method["profiles"]:
        assert profiles[method["profiles"][label]]["rounding_decimals"] == d
base_profiles = {name: p for name, p in profiles.items() if p.get("rounding_decimals") is None}

print("SPA GELU three-tier profile checks passed")
