#!/usr/bin/env python3
"""The imported MOAI model profiles: header and JSON agree to the last bit,
the structure is the plaintext catalog's, and the import is reproducible."""
from __future__ import annotations

import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

for suffix, target in (("", "erf-gelu"),):
    record = json.loads((ROOT / f"configs/moai_model_profiles{suffix}.json").read_text())
    header = (ROOT / f"src/moai_model_profiles{suffix}.hpp").read_text()
    assert record["native_target_id"] == target
    assert f'native_target_id() {{ return "{target}"; }}' in header
    assert record["source_catalog_sha256"] in header and len(record["source_catalog_sha256"]) == 64
    assert record["note"].startswith("imported verbatim")
    for label, expect in (("r5", (5.0, 5.0, 0)), ("r20", (20.0, 7.0, 3))):
        p = record["profiles"][label]
        assert p["kind"] == "moai" and p["id"] == f"moai-{label}"
        assert (p["operating_radius"], p["base_radius"], p["extension_stages"]) == expect
        assert p["degree"] == 23 and len(p["coefficients"]) == 24 and p["extension_factor"] == 1.5
        # every coefficient in the header round-trips to the JSON double
        block = header[header.index(f"profile_{label}()"):]
        block = block[block.index("{", block.index("{", block.index("{") + 1) + 1):]
        numbers = re.findall(r"\n\s+(-?[0-9][0-9.e+-]*),", block[: block.index("},")])
        assert [float(v) for v in numbers] == [float(c) for c in p["coefficients"]], label
        assert f"{float(p['max_abs_error']):.17g}" in block
    assert "profile_for_radius" in header and "never by ciphertext values" in header

# The evaluator header mirrors the plaintext definition (stages outermost first,
# constant 4/(27 s^2), y/B, Clenshaw, 0.5 x (1 + P)).
evaluator = (ROOT / "src/moai_model_eval.hpp").read_text()
for needed in ("extension_stages - 1; r >= 0; --r", "4.0 / (27.0 * scale * scale)", "1.0 / p.base_radius",
               "0.5 * x * (1.0 + factor)", "circuit_host", "plain_host"):
    assert needed in evaluator, needed

# Re-running the import on the recorded source reproduces the header when the
# source is available (it is on the machine that produced it); otherwise the
# import is exercised on a synthetic catalog.
catalog = {
    "activation_target": "erf", "target": "GELU (exact erf)", "range_plan_sha256": "x",
    "methods": {"moai": {"profiles": {"r5": "moai-r5", "r20": "moai-r20"}}},
    "profiles": {
        "moai-r5": {"id": "moai-r5", "kind": "moai", "operating_radius": 5.0, "base_radius": 5.0, "extension_stages": 0,
                    "extension_factor": 1.5, "degree": 1, "coefficients": [0.1234567890123456789, -1e-10], "max_abs_error": 1e-6},
        "moai-r20": {"id": "moai-r20", "kind": "moai", "operating_radius": 20.0, "base_radius": 7.0, "extension_stages": 3,
                     "extension_factor": 1.5, "degree": 1, "coefficients": [0.5, 0.25], "max_abs_error": 1e-3},
    },
}
with tempfile.TemporaryDirectory() as tmp:
    src = Path(tmp) / "profile_catalog.json"
    src.write_text(json.dumps(catalog))
    out_h, out_j = Path(tmp) / "h.hpp", Path(tmp) / "j.json"
    run = subprocess.run([sys.executable, str(ROOT / "scripts/import_model_moai_profiles.py"), "--catalog", str(src),
                          "--cross-check", str(src), "--output-header", str(out_h), "--output-json", str(out_j)],
                         capture_output=True, text=True)
    assert run.returncode == 0, run.stderr
    assert "0.12345678901234568," in out_h.read_text() and "-1e-10," in out_h.read_text()
    assert json.loads(out_j.read_text())["profiles"]["r5"]["coefficients"][0] == 0.1234567890123456789
    # a differing cross-check catalog is rejected
    other = json.loads(src.read_text()); other["profiles"]["moai-r5"]["coefficients"][0] = 0.2
    (Path(tmp) / "other.json").write_text(json.dumps(other))
    run = subprocess.run([sys.executable, str(ROOT / "scripts/import_model_moai_profiles.py"), "--catalog", str(src),
                          "--cross-check", str(Path(tmp) / "other.json"), "--output-header", str(out_h), "--output-json", str(out_j)],
                         capture_output=True, text=True)
    assert run.returncode != 0 and "differs" in run.stderr

print("MOAI model profile checks passed")
