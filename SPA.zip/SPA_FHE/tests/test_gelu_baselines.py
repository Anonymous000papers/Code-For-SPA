#!/usr/bin/env python3
"""Committed public fits, naming, and reproducibility; not encrypted tests."""
import hashlib,json,subprocess,sys,tempfile
from pathlib import Path
import numpy as np
from numpy.polynomial.chebyshev import chebval
from scipy.special import erf
ROOT=Path(__file__).resolve().parents[1]
a=json.loads((ROOT/'configs/gelu_baseline_profiles.json').read_text())
sha=a.pop('catalog_sha256')
assert hashlib.sha256(json.dumps(a,sort_keys=True,separators=(',',':')).encode()).hexdigest()==sha
assert sha in (ROOT/'src/gelu_baseline_profiles.hpp').read_text()
m=a['moai'];assert m['method']=='moai' and m['degree']==24 and m['radius']==20
assert m['input_coordinate']=='x/radius'
x=np.linspace(-20,20,300001)
y=chebval(x/20,m['coefficients_low_to_high'])
e=float(np.max(abs(y-.5*x*(1+erf(x/np.sqrt(2))))))
assert abs(e-m['grid_error']['max_abs'])<1e-11
assert .066<e<.067
assert abs(y[-1]-20)<.067
p=a['euston_exp']; assert p['method']=='euston' and p['degree']==7
assert p['coefficients_low_to_high'][0]==1.
z=np.linspace(-5,0,300001);v=np.polynomial.polynomial.polyval(z,p['coefficients_low_to_high'])
assert np.all((v>0)&(v<=1+1e-10))
assert np.max(abs(v-np.exp(z)))<3.3e-5
q=1-(1+v)/2;r=1+q
for _ in range(3): q=q*q;r=r*(1+q)
rec=r/2
assert np.max(abs(rec-1/(1+v)))<=1.6e-5
assert rec[-1]==.5
# Refit in a temporary output tree. Never overwrite the release profiles.
with tempfile.TemporaryDirectory() as d:
    subprocess.run([sys.executable,str(ROOT/'scripts/generate_gelu_baselines.py'),'--root',d],check=True,stdout=subprocess.PIPE)
    b=json.loads((Path(d)/'configs/gelu_baseline_profiles.json').read_text())
    assert np.max(abs(np.array(b['moai']['coefficients_low_to_high'])-m['coefficients_low_to_high']))<2e-8
    assert np.max(abs(np.array(b['euston_exp']['coefficients_low_to_high'])-p['coefficients_low_to_high']))<2e-8
print('MOAI/Euston R20 refit checks passed (plaintext only)')
