#!/usr/bin/env python3
"""The QuickGELU SPA catalog and header are reproduced byte for byte by the generator."""
from __future__ import annotations

import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

with tempfile.TemporaryDirectory() as tmp_dir:
    tmp = Path(tmp_dir)
    json_out = tmp / "profiles.json"
    header_out = tmp / "profiles.hpp"
    summary_out = tmp / "summary.csv"
    subprocess.run(
        [
            sys.executable,
            str(ROOT / "scripts/generate_spa_profiles.py"),
            "--target", "quickgelu",
            "--json-out", str(json_out),
            "--header-out", str(header_out),
            "--summary-out", str(summary_out),
        ],
        check=True,
        cwd=ROOT,
        stdout=subprocess.PIPE,
        text=True,
    )
    assert json_out.read_bytes() == (ROOT / "configs/spa_quickgelu_profiles.json").read_bytes()
    assert header_out.read_bytes() == (ROOT / "src/spa_quickgelu_profiles.hpp").read_bytes()
    assert summary_out.read_bytes() == (ROOT / "configs/spa_quickgelu_profile_summary.csv").read_bytes()

print("SPA QuickGELU two-range refit reproducibility checks passed")
