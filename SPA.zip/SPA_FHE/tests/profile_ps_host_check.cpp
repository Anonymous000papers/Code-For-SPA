// Host-side mirror of the ciphertext SPA Paterson-Stockmeyer evaluation.
//
// Reads a profile (radius, PS split, scale bits, coefficients) and a list of
// inputs x, and prints for every x the value of the polynomial evaluated
// (a) exactly as the ciphertext path does it, in double precision:
//     decompose_chebyshev(...) blocks, T_j(t) from the ChebDAG product rules,
//     block accumulation in the order of evaluate_baby_block (linear term
//     first, then c_j T_j for j = 1..split-1, then c_0), coefficients below
//     the encoding resolution skipped, pairwise giant-step recombination
//     with y, y^2, y^4, ... in the order of evaluate_ps, and
// (b) by profile_plain_eval (Clenshaw), the benchmark's host reference.
//
// No keys, no CKKS, no model. This is Check A of the balanced-profile
// validation: an implementation-consistency check between evaluators, not a
// bound on the activation error (that is Check B, in Python).
//
// Input file format (whitespace separated):
//     radius split scale_bits
//     n c_0 c_1 ... c_{n-1}
//     m
//     x_1 ... x_m          (one per line, printed with %.17g by the caller)
// Output: one line per input, "%.17g %.17g %.17g" = x_echo ps clenshaw.
// The caller compares x_echo bitwise to what it wrote, so both evaluators are
// guaranteed to see exactly the same inputs.

#include "spa_ckks_core.hpp"

#include <cstdio>
#include <fstream>
#include <iostream>
#include <optional>
#include <string>
#include <vector>

namespace {

using namespace spa;

class HostChebDAG {
public:
    explicit HostChebDAG(double t) : cache_(2, 0.0), present_(2, false) {
        cache_[1] = t;
        present_[1] = true;
    }
    double T(int n) {
        if (n <= 0) throw std::invalid_argument("T(0) is a plaintext constant");
        if (static_cast<std::size_t>(n) >= cache_.size()) {
            cache_.resize(static_cast<std::size_t>(n + 1), 0.0);
            present_.resize(static_cast<std::size_t>(n + 1), false);
        }
        if (present_[static_cast<std::size_t>(n)]) return cache_[static_cast<std::size_t>(n)];
        double out;
        if ((n & 1) == 0) {
            const double half = T(n / 2);
            out = half * half;          // square_and_rescale
            out = out + out;            // double_inplace
            out = out - 1.0;            // add_minus_one_inplace
        } else {
            const double left = T((n - 1) / 2);
            const double right = T((n + 1) / 2);
            out = left * right;         // multiply_and_rescale
            out = out + out;            // double_inplace
            out = out - T(1);           // sub_cipher_inplace(T(1))
        }
        cache_[static_cast<std::size_t>(n)] = out;
        present_[static_cast<std::size_t>(n)] = true;
        return out;
    }

private:
    std::vector<double> cache_;
    std::vector<bool> present_;
};

// Mirrors evaluate_baby_block: returns the block value, or nothing when no
// ciphertext term survives (the constant, if any, is then pending).
std::optional<double> host_baby_block(double x, HostChebDAG &dag, const ChebPolynomial &block,
                                      int block_index, int split, double scale, bool &constant_pending,
                                      double &pending_value) {
    double acc = 0.0;
    bool started = false;
    if (block_index == 0) {
        acc = x * 0.5;  // linear plaintext 0.5 applied to the raw input
        started = true;
    }
    for (int j = 1; j < split; ++j) {
        if (j >= static_cast<int>(block.size())) break;
        const double c = block[static_cast<std::size_t>(j)];
        if (!encodes_to_nonzero(c, scale)) continue;
        const double term = dag.T(j) * c;
        acc = started ? acc + term : term;
        started = true;
    }
    const double c0 = block.empty() ? 0.0 : block[0];
    constant_pending = false;
    pending_value = 0.0;
    if (!started) {
        if (encodes_to_nonzero(c0, scale)) {
            constant_pending = true;
            pending_value = c0;
        }
        return std::nullopt;
    }
    if (encodes_to_nonzero(c0, scale * scale)) acc = acc + c0;
    return acc;
}

double host_ps(double x, double radius, const ChebPolynomial &coeffs, int split, double scale) {
    const double t = 2.0 * x * x / (radius * radius) - 1.0;  // as profile_plain_eval
    HostChebDAG dag(t);
    const ChebDecomposition decomposition = decompose_chebyshev(coeffs, split);
    std::vector<std::optional<double>> nodes;
    std::vector<double> pending;
    std::vector<bool> is_pending;
    for (std::size_t b = 0; b < decomposition.blocks.size(); ++b) {
        bool constant_pending = false;
        double pending_value = 0.0;
        nodes.push_back(host_baby_block(x, dag, decomposition.blocks[b], static_cast<int>(b), split, scale,
                                        constant_pending, pending_value));
        is_pending.push_back(constant_pending);
        pending.push_back(pending_value);
    }
    if (nodes.empty() || !nodes[0]) throw std::runtime_error("empty PS result");
    if (nodes.size() == 1) return *nodes[0];
    double y_power = dag.T(split);
    while (nodes.size() > 1) {
        std::vector<std::optional<double>> next;
        std::vector<bool> next_pending;
        std::vector<double> next_value;
        for (std::size_t i = 0; i < nodes.size(); i += 2) {
            std::optional<double> combined = nodes[i];
            bool carried = !nodes[i] && is_pending[i];
            double carried_value = carried ? pending[i] : 0.0;
            if (i + 1 < nodes.size()) {
                std::optional<double> scaled;
                if (nodes[i + 1]) {
                    scaled = *nodes[i + 1] * y_power;             // multiply_and_rescale
                } else if (is_pending[i + 1]) {
                    scaled = y_power * pending[i + 1];            // y_power * c0 (plaintext)
                }
                if (scaled) {
                    if (combined) combined = *combined + *scaled;
                    else if (carried) throw std::runtime_error("constant block below a live block");
                    else combined = scaled;
                }
            }
            next.push_back(combined);
            next_pending.push_back(!combined && carried);
            next_value.push_back(carried_value);
        }
        nodes = std::move(next);
        is_pending = std::move(next_pending);
        pending = std::move(next_value);
        if (nodes.size() > 1) y_power = y_power * y_power;   // square_and_rescale
    }
    if (!nodes[0]) throw std::runtime_error("empty PS result");
    return *nodes[0];
}

}  // namespace

int main(int argc, char **argv) {
    if (argc != 2) {
        std::cerr << "usage: profile_ps_host_check <input-file>\n";
        return 2;
    }
    std::ifstream in(argv[1]);
    if (!in) {
        std::cerr << "cannot open " << argv[1] << "\n";
        return 2;
    }
    double radius = 0.0;
    int split = 0;
    int scale_bits = 0;
    in >> radius >> split >> scale_bits;
    std::size_t n = 0;
    in >> n;
    ChebPolynomial coeffs(n);
    for (std::size_t i = 0; i < n; ++i) in >> coeffs[i];
    std::size_t m = 0;
    in >> m;
    if (!in || radius <= 0.0 || split <= 0 || n == 0) {
        std::cerr << "malformed input\n";
        return 2;
    }
    const double scale = std::ldexp(1.0, scale_bits);
    ProfileDef profile;
    profile.name = "host-check";
    profile.radius = radius;
    profile.warp_a = 0.0;
    profile.coefficients = coeffs;

    std::string token;
    std::size_t count = 0;
    while (count < m && (in >> token)) {
        char *end = nullptr;
        const double x = std::strtod(token.c_str(), &end);
        const double ps = host_ps(x, radius, coeffs, split, scale);
        const double clenshaw = profile_plain_eval(x, profile);
        std::printf("%.17g %.17g %.17g\n", x, ps, clenshaw);
        ++count;
    }
    if (count != m) {
        std::cerr << "expected " << m << " inputs, read " << count << "\n";
        return 2;
    }
    return 0;
}
