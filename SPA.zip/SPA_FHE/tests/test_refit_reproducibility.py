#!/usr/bin/env python3
"""The SiLU SPA catalog and header are reproduced byte for byte by the generator."""
from __future__ import annotations

import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

with tempfile.TemporaryDirectory() as tmp:
    tmp = Path(tmp)
    json_out = tmp / "profiles.json"
    header_out = tmp / "profiles.hpp"
    summary_out = tmp / "summary.csv"
    subprocess.run(
        [
            sys.executable,
            str(ROOT / "scripts/generate_silu_spa_profiles.py"),
            "--json-out", str(json_out),
            "--header-out", str(header_out),
            "--summary-out", str(summary_out),
        ],
        check=True,
        cwd=ROOT,
        stdout=subprocess.PIPE,
        text=True,
    )
    assert json_out.read_bytes() == (ROOT / "configs/spa_silu_profiles.json").read_bytes()
    assert header_out.read_bytes() == (ROOT / "src/spa_silu_profiles.hpp").read_bytes()
    assert summary_out.read_bytes() == (ROOT / "configs/spa_silu_profile_summary.csv").read_bytes()

print("SPA SiLU two-range refit reproducibility checks passed")
