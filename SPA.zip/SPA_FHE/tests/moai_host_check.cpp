// Host-side evaluation of the imported MOAI model profile on a supplied grid.
//
// Prints, per input x: x (echoed), P_cipher-host(x) (the ciphertext circuit's
// operation order, moai_model::circuit_host) and P_model-host(x) (the model's
// definition, moai_model::plain_host). No CKKS, no keys, no model. The caller
// compares the echo bitwise and the two values against the plaintext
// evaluator (scripts/validate_moai_model_profiles.py).
//
// Input: line 1 "r5" or "r20"; line 2 m; then m inputs (one per line).
#include "moai_model_eval.hpp"

#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <string>

int main(int argc, char **argv) {
    if (argc != 2) {
        std::cerr << "usage: moai_host_check <input-file>\n";
        return 2;
    }
    std::ifstream in(argv[1]);
    std::string label;
    std::size_t m = 0;
    in >> label >> m;
    if (!in) {
        std::cerr << "malformed input\n";
        return 2;
    }
    const moai_model::Profile &profile =
        label == "r5" ? moai_model::profile_r5() : label == "r20" ? moai_model::profile_r20()
                                                                  : throw std::invalid_argument("label must be r5 or r20");
    std::printf("# profile %s target %s source_sha256 %s\n", profile.id.c_str(), moai_model::native_target_id(),
                moai_model::source_catalog_sha256());
    std::string token;
    std::size_t count = 0;
    while (count < m && (in >> token)) {
        const double x = std::strtod(token.c_str(), nullptr);
        std::printf("%.17g %.17g %.17g\n", x, moai_model::circuit_host(x, profile), moai_model::plain_host(x, profile));
        ++count;
    }
    return count == m ? 0 : 2;
}
