#!/usr/bin/env python3
"""Source/numerical tests only. Real encrypted checks require a SEAL build."""
from pathlib import Path
import subprocess,sys,time,json,os
ROOT=Path(__file__).resolve().parents[1]
TESTS=['test_profiles.py','test_gelu_profiles.py','test_quickgelu_profiles.py','test_moai_model_profiles.py','test_error_decomposition.py','test_validator_rigor.py','test_source_policy.py','test_euston_reference.py',
       'test_refit_reproducibility.py','test_gelu_refit_reproducibility.py','test_quickgelu_refit_reproducibility.py','test_gelu_baselines.py',
       'test_euston_circuit_cpp.py','test_arithmetic_model.py']
rows=[];logs=[]
TIMEOUT_S=int(os.environ.get('SPA_TEST_TIMEOUT','900'))
for test in TESTS:
    t0=time.time()
    try:
        p=subprocess.run([sys.executable,str(ROOT/'tests'/test)],text=True,capture_output=True,timeout=TIMEOUT_S,
                         env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MPLBACKEND':'Agg'})
        out,err,rc=p.stdout,p.stderr,p.returncode
    except subprocess.TimeoutExpired as e:
        out,err,rc=(e.stdout or b'').decode() if isinstance(e.stdout,bytes) else (e.stdout or ''),f'TIMEOUT after {TIMEOUT_S}s',124
    logs.append(f'===== {test} ({time.time()-t0:.1f}s) =====\n{out}\n{err}')
    rows.append({'test':test,'returncode':rc,'seconds':round(time.time()-t0,1)})
    print(test,'PASS' if rc==0 else ('TIMEOUT' if rc==124 else 'FAIL'),f'({time.time()-t0:.1f}s)',flush=True)
status={'status':'PASS_SOURCE_AND_ARITHMETIC_ONLY' if all(x['returncode']==0 for x in rows) else 'FAIL',
        'tests':rows,'real_SEAL_build':'NOT_RUN','real_CKKS_execution':'NOT_RUN',
        'arithmetic_model_is_encryption':False}
(ROOT/'validation').mkdir(exist_ok=True)
(ROOT/'validation/source_checks.json').write_text(json.dumps(status,indent=2)+'\n')
(ROOT/'validation/source_checks.log').write_text('\n'.join(logs))
sys.exit(0 if all(x['returncode']==0 for x in rows) else 1)
