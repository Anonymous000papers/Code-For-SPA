#!/usr/bin/env python3
"""Unit checks for the rigorous parts of scripts/validate_balanced_profiles.py.

* the interval exp encloses a high-precision reference on random inputs and
  raises on non-finite input instead of falling back;
* CoverageRadius measures endpoint distances and the largest gap, including
  gaps across chunk boundaries;
* on the balanced configurations' actual float64 midpoints the measured
  coverage radius exceeds what a fixed relative margin on the nominal spacing
  would assume, which is why the radius is measured rather than assumed;
* the long-double mantissa width is recorded, not assumed.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import validate_balanced_profiles as v  # noqa: E402
from reference_helpers import CoverageRadius  # noqa: E402

LD = np.longdouble
rng = np.random.default_rng(7)

# exp enclosure against numpy's long-double exp (a reference, not a proof)
x = rng.uniform(-40.0, 600.0, 100000)
e = v.IV.point(x).exp()
ref = np.exp(x.astype(LD))
assert bool(np.all(e.lo <= ref)) and bool(np.all(ref <= e.hi))
assert float(np.max((e.hi - e.lo) / e.hi)) < 1e-15
try:
    v.IV.point(np.array([np.inf])).exp()
except FloatingPointError:
    pass
else:
    raise AssertionError("non-finite exp input must raise, not fall back")

# tanh-GELU and SiLU enclosures contain the double-precision values
xs = rng.uniform(-20.0, 20.0, 20000)
for target in ("silu", "tanh-gelu", "quickgelu"):
    enc = v.iv_activation(v.IV.point(xs), target)
    val = v.activation_double(target)(xs).astype(LD)
    assert bool(np.all(enc.lo <= val + LD(1e-14))) and bool(np.all(val - LD(1e-14) <= enc.hi)), target

# coverage radius: endpoints, largest gap, cross-chunk gap
c = CoverageRadius(1.0)
c.add(np.array([-0.9, -0.5, 0.0]))
c.add(np.array([0.3, 0.95]))
assert abs(float(c.finish()) - 0.325) < 1e-15   # gap 0.3 -> 0.95 is the widest
c = CoverageRadius(1.0)
c.add(np.array([-0.6, -0.55]))
c.add(np.array([0.9]))                            # cross-chunk gap 1.45 -> 0.725
assert abs(float(c.finish()) - 0.725) < 1e-15
c = CoverageRadius(1.0)
c.add(np.array([-0.98]))
c.add(np.array([0.2]))                            # right endpoint distance 0.8 wins
assert abs(float(c.finish()) - 0.8) < 1e-15

# a fixed relative margin on the nominal spacing does not cover the real midpoints
for radius, count in ((5.0, 1191113), (20.0, 3178304), (5.0, 2994167), (20.0, 7615761)):
    naive = np.nextafter(LD(radius) / LD(count) * (LD(1.0) + LD(2.0) ** LD(-40)), LD(np.inf))
    cover = CoverageRadius(radius)
    chunk = 1_000_000
    for start in range(0, count, chunk):
        j = np.arange(start, min(count, start + chunk), dtype=np.float64)
        cover.add((-radius + (2.0 * j + 1.0) * (radius / count)).astype(np.float64))
    measured = cover.finish()
    assert cover.count == count
    assert measured > naive, (radius, count, float(measured), float(naive))
    assert float(measured - naive) < 1e-14   # the deficit is tiny, but it is a deficit

assert v.LONGDOUBLE_NMANT == int(np.finfo(np.longdouble).nmant)
print(f"validator rigor checks passed (longdouble nmant={v.LONGDOUBLE_NMANT}, exp backend={v.EXP_BACKEND})")
