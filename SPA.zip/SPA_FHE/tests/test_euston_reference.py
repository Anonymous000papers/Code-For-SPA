#!/usr/bin/env python3
"""Euston reference construction: released coefficients, parameter derivation and the absence of bridging code paths."""
from __future__ import annotations

import math
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
gel_u = (ROOT / "src/gelu_bench.cpp").read_text()
silu = (ROOT / "src/silu_bench.cpp").read_text()
run_gelu = (ROOT / "scripts/run_gelu.sh").read_text()
run_silu = (ROOT / "scripts/run_silu.sh").read_text()

# Algorithm-4 algebra: with exact sign, exponential, and inverse, Euston's
# sign-uniform recombination is exactly QuickGELU x*sigmoid(1.702x).
x = np.linspace(-5.0, 5.0, 200001)
s = np.where(x > 0.0, 1.0, np.where(x < 0.0, -1.0, 0.0))
a = x * s
z = a / (1.0 + np.exp(-1.702 * a))
b = 0.5 * (s - 1.0) * 1.702 * a
c = s * np.exp(b)
y = z * c
# The expression gives 0 at x=0 as required.
quickgelu = x / (1.0 + np.exp(-1.702 * x))
assert float(np.max(np.abs(y - quickgelu))) < 2e-15

# Updated arithmetic is shared by plaintext and ciphertext through one template.
circuit = (ROOT / "src/euston_circuit.hpp").read_text()
for fragment in ("1.2 * radius", "c.beta*radius/5.0", "inverse_divisor = 2.0",
                 "exp_scaled(op,a,-c.beta,c)", "exp_scaled(op,b,c.beta/2.0,c)"):
    assert fragment in circuit, fragment
# Euston is compared under the QuickGELU target (its own fitting target).
assert 'R5_METHODS="${QUICKGELU_METHODS:-spa-k39,spa-k63,spa-k87,euston}"' in run_gelu
assert 'R20_METHODS="${QUICKGELU_METHODS:-spa-k39,spa-k63,spa-k87,euston}"' in run_gelu
assert "euston" not in silu.lower()
assert "euston" not in run_silu.lower()
start=gel_u.index("    void evaluate_impl(bool timing)")
end=gel_u.index('    const string id_="euston"', start)
body=gel_u[start:end]
for forbidden in ("decrypt_vector(","encrypt_vector(","->decrypt(","->decode(","->encrypt("):
    assert forbidden not in body, forbidden
assert 'euston_circuit::main_path(main_op,raw_,s,config_)' in body
assert 'if(last_counts_.decrypt ||' in body
print("Euston reference and no-bridge checks passed")
