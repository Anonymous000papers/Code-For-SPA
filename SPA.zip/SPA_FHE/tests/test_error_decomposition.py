#!/usr/bin/env python3
"""Standardised error decomposition: definitions, bound and tooling.

Checks that do not need a SEAL build:

* E_target between the fitting targets and the native targets used by the
  benchmarks (erf-GELU, tanh-GELU, QuickGELU, SiLU) on the public intervals;
* the triangle-inequality bound E_total <= E_target + E_poly + E_coeff + E_HE
  on a synthetic summary row set, accepted by check_ciphertext_results.py
  and consumed by plot_tradeoff.py;
* the coefficient-rounding bound E_coeff <= ||c_d - c||_1 on the committed
  Experiment B profiles of all three catalogs.
"""
from __future__ import annotations

import csv
import json
import math
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np
from numpy.polynomial.chebyshev import chebval
from scipy.special import erf

ROOT = Path(__file__).resolve().parents[1]


def gelu_erf(x):
    return 0.5 * x * (1.0 + erf(x / math.sqrt(2.0)))


def gelu_tanh(x):
    return 0.5 * x * (1.0 + np.tanh(math.sqrt(2.0 / math.pi) * (x + 0.044715 * x**3)))


def quickgelu(x):
    return x / (1.0 + np.exp(-1.702 * x))


def silu(x):
    return x / (1.0 + np.exp(-x))


# --- E_target between the forms, on [-20, 20] ---------------------------------
x = np.linspace(-20.0, 20.0, 400001)
e_target = {
    ("erf-gelu", "tanh-gelu"): float(np.max(np.abs(gelu_erf(x) - gelu_tanh(x)))),
    ("quickgelu", "erf-gelu"): float(np.max(np.abs(quickgelu(x) - gelu_erf(x)))),
    ("quickgelu", "tanh-gelu"): float(np.max(np.abs(quickgelu(x) - gelu_tanh(x)))),
}
assert 4.5e-4 < e_target[("erf-gelu", "tanh-gelu")] < 5.0e-4, e_target
assert 2.0e-2 < e_target[("quickgelu", "erf-gelu")] < 2.1e-2, e_target
assert 2.0e-2 < e_target[("quickgelu", "tanh-gelu")] < 2.1e-2, e_target
# SPA fits the native target, so its E_target is identically zero.
assert float(np.max(np.abs(silu(x) - 0.5 * x * (1.0 + np.tanh(0.5 * x))))) < 1e-12

# --- Experiment B: E_coeff <= ||c_d - c||_1 on every committed rounded profile --
for catalog_name in ("configs/spa_profiles.json", "configs/spa_quickgelu_profiles.json", "configs/spa_silu_profiles.json"):
    catalog = json.loads((ROOT / catalog_name).read_text())
    profiles = {p["name"]: p for p in catalog["profiles"]}
    rounded = [p for p in catalog["profiles"] if p.get("rounding_decimals") is not None]
    assert len(rounded) == 10, (catalog_name, len(rounded))
    t = np.linspace(-1.0, 1.0, 100001)
    for profile in rounded:
        source = profiles[profile["derived_from"]]
        delta = np.asarray(profile["coefficients_chebyshev_low_to_high"]) - np.asarray(source["coefficients_chebyshev_low_to_high"])
        measured = float(np.max(np.abs(chebval(t, delta))))
        l1 = float(np.sum(np.abs(delta)))
        assert measured <= l1 * (1 + 1e-9) + 1e-15, (profile["name"], measured, l1)
        assert abs(measured - profile["coefficient_perturbation_max"]) <= 1e-9 * max(1.0, measured), profile["name"]
        assert profile["rounding_decimals"] == int(profile["name"].rsplit("-d", 1)[1])
    assert catalog["rounding_experiment"]["decimals"] == [1, 2, 3, 4, 5]

# --- synthetic summary rows: bound identity, checker, exporter -----------------
COLUMNS = [
    "run_label", "method", "family", "parameter_policy", "native_target", "reference_gap_semantics",
    "reference_gap_is_ckks_only", "spa_tier", "active_profile", "range_lo", "range_hi", "reserve_levels",
    "median_ms", "context_count", "output_chain", "consumed_levels", "expected_consumed_levels",
    "encrypt", "decrypt", "decode", "dynamic_plain_encode", "bootstraps", "security_validation",
    "evaluation_scale_bits", "evaluation_prime_bits", "main_modulus_bits", "euston_g_rounds", "euston_f_rounds", "euston_tau",
    "total_max_abs", "total_rmse", "method_bias_max", "ckks_extra_max", "implementation_revision",
    "native_target_id", "fit_target_id", "e_target", "e_poly", "e_coeff", "e_he", "e_total",
    "decomposition_bound", "decomposition_bound_holds", "catalog_e_poly", "catalog_e_coeff",
    "spa_rounding_decimals", "spa_derived_from", "host_reference_semantics",
]


def row(method, family, tier, e_target_v, e_poly, e_coeff, e_he, median, decimals=-1, fit="erf-gelu", policy=""):
    e_total = 0.9 * (e_target_v + e_poly + e_coeff + e_he)  # never above the bound
    base = {c: "" for c in COLUMNS}
    base.update(
        run_label="r5", method=method, family=family, parameter_policy=policy, native_target="erf",
        reference_gap_semantics="host reference", reference_gap_is_ckks_only="1", spa_tier=tier,
        active_profile=f"{method}-profile", range_lo="-5", range_hi="5", reserve_levels="4",
        median_ms=median, context_count="1", output_chain="6", consumed_levels="6", expected_consumed_levels="6",
        encrypt="0", decrypt="0", decode="0", dynamic_plain_encode="0", bootstraps="0",
        security_validation="tc128-linked-SEAL", evaluation_scale_bits="46", evaluation_prime_bits="46",
        main_modulus_bits="1132", euston_g_rounds="3", euston_f_rounds="3", euston_tau="1",
        total_max_abs=e_total, total_rmse=e_total / 3, method_bias_max=e_target_v + e_poly + e_coeff,
        ckks_extra_max=e_he, implementation_revision="spa-1", native_target_id="erf-gelu", fit_target_id=fit,
        e_target=e_target_v, e_poly=e_poly, e_coeff=e_coeff, e_he=e_he, e_total=e_total,
        decomposition_bound=e_target_v + e_poly + e_coeff + e_he, decomposition_bound_holds="1",
        catalog_e_poly=e_poly, catalog_e_coeff=e_coeff, spa_rounding_decimals=str(decimals),
        spa_derived_from="spa-k63" if decimals >= 0 else "", host_reference_semantics="host double evaluation",
    )
    return base


rows = [
    row("spa-k63", "SPA-GELU", "balanced", 0.0, 1.25e-3, 0.0, 8e-8, 120.0),
    row("spa-k63-d3", "SPA-GELU", "balanced", 0.0, 1.25e-3, 1.25e-3, 8e-8, 118.0, decimals=3),
    row("moai", "MOAI", "", 0.0, 4.5e-3, 0.0, 6e-9, 610.0, fit="erf-gelu"),
    row("euston", "Euston", "", 2.03e-2, 1.8e-3, 0.0, 2.7e-4, 2400.0, fit="quickgelu"),
    row("nexus", "NEXUS", "", 0.0, 6.9e-4, 0.0, 3e-5, 900.0, fit="erf-gelu", policy="gate=3.5, sign_scale=8.5, dg=2, df=2, conditioning=source-domain, gate_budget=1"),
]
for r in rows:
    bound = float(r["e_target"]) + float(r["e_poly"]) + float(r["e_coeff"]) + float(r["e_he"])
    assert float(r["e_total"]) <= bound
    # method_bias already contains E_target and E_coeff; it must not be added to them.
    assert abs(float(r["method_bias_max"]) - (float(r["e_target"]) + float(r["e_poly"]) + float(r["e_coeff"]))) < 1e-15

with tempfile.TemporaryDirectory() as tmp:
    summary = Path(tmp) / "r5_summary.csv"
    with summary.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=COLUMNS)
        writer.writeheader()
        writer.writerows(rows)
    check = subprocess.run(
        [sys.executable, str(ROOT / "scripts/check_ciphertext_results.py"), "--summary", str(summary),
         "--require-methods", "spa-k63,spa-k63-d3,moai,euston,nexus"],
        capture_output=True, text=True,
    )
    assert check.returncode == 0, check.stderr
    report = json.loads(check.stdout)
    assert report["status"] == "PASS_RECORDED_FIELDS"
    assert {r["method"]: r["fit_target_id"] for r in report["rows"]}["euston"] == "quickgelu"

    plot = subprocess.run(
        [sys.executable, str(ROOT / "scripts/plot_tradeoff.py"), "--summary", str(summary), "--out", str(Path(tmp) / "tradeoff"),
         "--no-figure"],  # the test checks the points CSV; rendering is environment-dependent and slow on some hosts
        capture_output=True, text=True,
    )
    assert plot.returncode == 0, plot.stderr
    points = list(csv.DictReader((Path(tmp) / "tradeoff_points.csv").open()))
    assert len(points) == 5
    by_method = {p["method"]: p for p in points}
    assert "d=3" in by_method["spa-k63-d3"]["annotation"]
    assert "own 46-bit chain" in by_method["euston"]["annotation"] and "fit=quickgelu" in by_method["euston"]["annotation"]
    assert "dg=2" in by_method["nexus"]["annotation"] and "conditioning=source-domain" in by_method["nexus"]["annotation"]
    assert "fit=" not in by_method["moai"]["annotation"]  # fitted to the native target
    assert float(by_method["spa-k63"]["e_total"]) < float(by_method["moai"]["e_total"])

print("error decomposition checks passed (E_target erf/tanh=%.3e, quickgelu/erf=%.3e)" % (
    e_target[("erf-gelu", "tanh-gelu")], e_target[("quickgelu", "erf-gelu")]))
