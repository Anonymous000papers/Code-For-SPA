#!/usr/bin/env python3
"""SiLU SPA catalog invariants: tiers, degrees, Experiment B variants, header hash."""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

import numpy as np
from numpy.polynomial.chebyshev import chebval

ROOT = Path(__file__).resolve().parents[1]

profile_path = ROOT / "configs/spa_silu_profiles.json"
profile_bytes = profile_path.read_bytes()
profile_sha256 = hashlib.sha256(profile_bytes).hexdigest()
profiles_json = json.loads(profile_bytes)
assert profiles_json["format"] == "spa-silu-two-range-v2"
assert profiles_json["target"] == "SiLU(x)=x*sigmoid(x)"
assert profiles_json["structure"] == "x/2 + Q_k(2*x^2/R^2 - 1)"
assert profiles_json["ranges"] == [
    {"label": "r5", "radius": 5.0},
    {"label": "r20", "radius": 20.0},
]

expected_methods = {
    "spa-k39": ("r5:k3;r20:k15", {"r5": 3, "r20": 15}),
    "spa-k63": ("r5:k7;r20:k23", {"r5": 7, "r20": 23}),
    "spa-k87": ("r5:k11;r20:k31", {"r5": 11, "r20": 31}),
}
methods = {item["id"]: item for item in profiles_json["method_variants"]}
assert set(expected_methods) <= set(methods)
assert profiles_json["tier_selection"]["targets"] == {"fast": 2.1e-2, "balanced": 1e-3, "accurate": 1e-4}
for method_id, (schedule, degrees) in expected_methods.items():
    assert methods[method_id]["degree_schedule"] == schedule
    assert methods[method_id]["degrees"] == degrees
    assert set(methods[method_id]["profiles"]) == {"r5", "r20"}

profiles = {item["name"]: item for item in profiles_json["profiles"]}
assert len([p for p in profiles.values() if p.get("rounding_decimals") is None]) == 6
assert len(profiles) == 16
for method in methods.values():
    for label, profile_id in method["profiles"].items():
        profile = profiles[profile_id]
        assert profile["range_label"] == label
        assert profile["degree_square"] == method["degrees"][label]
        assert len(profile["coefficients_chebyshev_low_to_high"]) == profile["degree_square"] + 1
        radius = float(profile["R"])
        x = np.linspace(-radius, radius, 100001)
        t = 2.0 * (x / radius) ** 2 - 1.0
        approx = 0.5 * x + chebval(t, profile["coefficients_chebyshev_low_to_high"])
        exact = 0.5 * x * (1.0 + np.tanh(0.5 * x))
        measured = float(np.max(np.abs(approx - exact)))
        stored = float(profile["dense_max_abs_error"])
        assert measured <= stored * 1.01 + 1e-10, (profile_id, measured, stored)
        reflected = approx - approx[::-1]
        assert float(np.max(np.abs(reflected - x))) < 2e-11

# Experiment B variants: rounded copies of the balanced tier, nothing refitted.
rounded = {mid: m for mid, m in methods.items() if m.get("rounding_decimals") is not None}
assert set(rounded) == {f"spa-k63-d{d}" for d in (1, 2, 3, 4, 5)}, set(rounded)
for method_id, method in rounded.items():
    d = method["rounding_decimals"]
    assert method["derived_from"] == "spa-k63"
    assert method["degree_schedule"] == methods["spa-k63"]["degree_schedule"]
    for label, profile_id in method["profiles"].items():
        profile = profiles[profile_id]
        source = profiles[profile["derived_from"]]
        assert profile["derived_from"] == methods["spa-k63"]["profiles"][label]
        assert profile["degree_square"] == source["degree_square"]
        assert profile["ps_split"] == source["ps_split"]
        assert profile["R"] == source["R"]
        assert profile["coefficients_chebyshev_low_to_high"] == [
            round(c, d) for c in source["coefficients_chebyshev_low_to_high"]
        ]
        assert profile["coefficient_perturbation_max"] <= profile["coefficient_l1_perturbation"] * (1 + 1e-9) + 1e-15
        assert profile["unrounded_dense_max_abs_error"] == source["dense_max_abs_error"]
    for label in method["profiles"]:
        assert profiles[method["profiles"][label]]["rounding_decimals"] == d
base_profiles = {name: p for name, p in profiles.items() if p.get("rounding_decimals") is None}

# The generated header embeds the SHA-256 of the committed profile JSON.
header = (ROOT / "src/spa_silu_profiles.hpp").read_text()
assert profile_sha256 in header
assert "SPA_R56" not in header
assert "wide_profile" not in header

catalog = json.loads((ROOT / "configs/silu_baseline_profiles.json").read_text())
profiles = {item["cpp_id"]: item for item in catalog["chebyshev_profiles"]}
assert profiles["ORION_R8"]["dense_max_abs_error"] < 1e-8
assert profiles["ORION_R20"]["dense_max_abs_error"] < 2e-4

# Re-evaluate the corrected R8 Orion profile on the normalized t-domain.
profile = profiles["ORION_R8"]
t = np.linspace(-1.0, 1.0, 20001)
x = 16.0 * t
silu = 0.5 * x * (1.0 + np.tanh(0.5 * x))
error = np.max(np.abs(chebval(t, profile["coefficients_chebyshev_low_to_high"]) - silu))
assert error < 1e-8, error

# NEXUS source and range-extension profiles. The supplied GELU source uses
# Delta=8.5, d_g=2, d_f=2 on [-5,5]. The R20 row is an experimental
# adaptation with an additional two final f-compositions.
f = np.array([0, 315, 0, -420, 0, 378, 0, -180, 0, 35], dtype=float) / 128.0
g = np.array([0, 5850, 0, -34974, 0, 97015, 0, -113492, 0, 46623], dtype=float) / 1024.0
a = np.array([
    2.25775755e-04, 0.5, 3.96880960e-01, -6.37042698e-02,
    8.38841647e-03, -7.17830961e-04, 3.49617829e-05, -7.26059653e-07,
])

def odd9(v: np.ndarray, c: np.ndarray) -> np.ndarray:
    v2 = v * v
    return v * (c[1] + v2 * (c[3] + v2 * (c[5] + v2 * (c[7] + v2 * c[9]))))

def sign(v: np.ndarray, dg: int, df: int) -> np.ndarray:
    for round_index in range(dg):
        v = odd9(v, 0.5 * g if round_index + 1 == dg else g)
    for round_index in range(df):
        v = odd9(v, 0.5 * f if round_index + 1 == df else f)
    return v

def nexus_profile(radius: float, df: int) -> tuple[np.ndarray, np.ndarray]:
    x = np.linspace(-radius, radius, 20001)
    scale = radius + 3.5
    left_arg = (x + 3.5) / scale
    right_arg = (x - 3.5) / scale
    assert np.max(np.abs(left_arg)) <= 1.0 + 1e-12
    assert np.max(np.abs(right_arg)) <= 1.0 + 1e-12

    x2 = x * x
    middle = a[0] + a[1] * x
    power = x2.copy()
    for coefficient in a[2:]:
        middle += coefficient * power
        power *= x2
    left = sign(left_arg, dg=2, df=df)
    right = sign(right_arg, dg=2, df=df)
    approx = middle * (left - right) + x * (right + 0.5)
    exact = 0.5 * x * (1.0 + np.vectorize(math.erf)(x / math.sqrt(2.0)))
    return approx, exact

source_approx, source_exact = nexus_profile(5.0, 2)
source_error = np.abs(source_approx - source_exact)
assert np.all(np.isfinite(source_approx))
assert np.max(source_error) < 1.67e-2
assert np.mean(source_error) < 1.13e-3

wide_approx, wide_exact = nexus_profile(20.0, 4)
assert np.all(np.isfinite(wide_approx))
assert np.max(np.abs(wide_approx - wide_exact)) < 1e-3


print("profile checks passed")

# The supplied MOAI code rescales z=0.1*x coefficients by 0.1^{-i}; this is
# algebraically the same fixed polynomial in x. It cannot be range-extended by
# changing only the internal coordinate scale.
moai_high_to_low = np.array([
    3.18006986e-24, 5.70792114e-22, 3.97205561e-20, 1.31854608e-18,
    1.64153184e-17, -2.33052347e-16, -9.78309547e-15, -6.72238500e-14,
    1.43093357e-12, 2.41129634e-11, -4.00991558e-11, -3.06661368e-09,
    -1.00479838e-08, 2.05368974e-07, 1.25666834e-06, -7.76703686e-06,
    -6.75419265e-05, 1.62401656e-04, 1.97100905e-03, -1.70511673e-03,
    -3.22621248e-02, 7.22135066e-03, 3.39374355e-01, 4.92938360e-01,
    1.21149468e-02,
])
probe = np.linspace(-8.0, 8.0, 2001)
source_poly = np.polyval(moai_high_to_low, probe)
for internal_scale in (0.05, 0.1, 0.2):
    degree = len(moai_high_to_low) - 1
    rescaled = np.array([
        coefficient * internal_scale ** (-(degree - index))
        for index, coefficient in enumerate(moai_high_to_low)
    ])
    reconstructed = np.polyval(rescaled, internal_scale * probe)
    assert np.max(np.abs(source_poly - reconstructed)) < 1e-9

for radius, lower, upper in ((8.0, 4e-2, 5e-2), (20.0, 1e9, float("inf"))):
    x = np.linspace(-radius, radius, 200001)
    exact = 0.5 * x * (1.0 + np.vectorize(math.erf)(x / math.sqrt(2.0)))
    error = np.max(np.abs(np.polyval(moai_high_to_low, x) - exact))
    assert lower < error < upper, (radius, error)

# NEXUS R20 is plaintext-accurate but ill-conditioned under encrypted gates.
def nexus_condition(radius: float) -> tuple[float, float, float]:
    x = np.linspace(-radius, radius, 20001)
    x2 = x * x
    middle = a[0] + a[1] * x
    power = x2.copy()
    for coefficient in a[2:]:
        middle += coefficient * power
        power *= x2
    condition = np.max(np.abs(middle) + np.abs(x - middle))
    budget = 1e-3 / condition
    ulp_margin = budget / (2.0 ** -46)
    return float(np.max(np.abs(middle))), float(budget), float(ulp_margin)

center5, budget5, margin5 = nexus_condition(5.0)
center20, budget20, margin20 = nexus_condition(20.0)
assert 17.0 < center5 < 18.0 and budget5 > 3e-5 and margin5 > 2e9
assert center20 > 2e9 and budget20 < 2e-13 and margin20 < 14.0
