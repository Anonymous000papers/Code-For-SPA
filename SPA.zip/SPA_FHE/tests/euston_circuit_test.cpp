// Exercises the production circuit template without any homomorphic library.
// DepthValue tracks the exact critical-path schedule. It is NOT encryption.
#include "euston_circuit.hpp"
#include <iostream>
#include <iomanip>
#include <vector>
#include <stdexcept>
#include <algorithm>

struct DepthValue { double x; int depth; };
struct DepthOps {
 using Value=DepthValue;
 euston_circuit::DoubleOps plain;
 int multiplies=0,squares=0,constants=0,polynomials=0,sign_polys=0;
 Value constant_multiply(Value v,double c){++constants;return {v.x*c,v.depth+1};}
 Value multiply(Value a,Value b){++multiplies;return {a.x*b.x,std::max(a.depth,b.depth)+1};}
 Value square(Value v){++squares;return {v.x*v.x,v.depth+1};}
 Value add_constant(Value v,double c){return {v.x+c,v.depth};}
 Value polynomial(Value v,const std::vector<double>&c){++polynomials;return {plain.polynomial(v.x,c),v.depth+4};}
 Value odd9(Value v,const std::vector<double>&c){++sign_polys;return {plain.odd9(v.x,c),v.depth+4};}
};
void require(bool b,const char*msg){if(!b)throw std::runtime_error(msg);}
int main(){
 std::cout<<std::setprecision(17);
 for(double radius: {5.,20.}){
  auto c=euston_circuit::make_config(radius);
  require(c.sign_scale==1.2*radius,"wrong sign scale");
  require(c.exp_squarings==(radius==5.?1:3),"wrong tau");
  require(c.consumed_levels()==(radius==5.?40:42),"wrong level budget");
  double maxg=0,maxq=0,mind=1e300,maxd=-1e300;
  for(int i=0;i<=200000;++i){
   double x=-radius+2*radius*i/200000.;
   DepthOps op;auto s=euston_circuit::sign(op,DepthValue{x,0},c);
   auto y=euston_circuit::main_path(op,DepthValue{x,0},s,c);
   double y0=euston_circuit::plain(x,c);
   require(y.depth==c.consumed_levels(),"critical path mismatch");
   require(y.x==y0,"template arithmetic mismatch");
   require(std::isfinite(y.x),"nonfinite output");
   double gelu=.5*x*(1+std::erf(x/std::sqrt(2.)));
   double quick=x/(1+std::exp(-c.beta*x));
   maxg=std::max(maxg,std::abs(y.x-gelu));maxq=std::max(maxq,std::abs(y.x-quick));
   euston_circuit::DoubleOps d;
   double a=x*s.x;
   double q=euston_circuit::exp_scaled(d,a,-c.beta,c);
   mind=std::min(mind,1+q);maxd=std::max(maxd,1+q);
  }
  require(maxg<.025,"excessive reference approximation error");
  require(maxq<.004,"excessive QuickGELU circuit error");
  require(mind>=1.-1e-10 && maxd<=2.+1e-10,"denominator domain not covered");
  std::cout<<"radius="<<radius<<" levels="<<c.consumed_levels()<<" gelu_max="<<maxg
           <<" quick_max="<<maxq<<" denominator_min="<<mind<<" denominator_max="<<maxd<<"\n";
 }
 bool rejected=false;try{euston_circuit::make_config(20.,24.,1);}catch(const std::invalid_argument&){rejected=true;}
 require(rejected,"insufficient exp squarings were not rejected");
 rejected=false;try{euston_circuit::make_config(20.,6.);}catch(const std::invalid_argument&){rejected=true;}
 require(rejected,"source normalization at R20 not rejected");
 std::cout<<"Euston arithmetic/depth checks: PASS (no CKKS execution)\n";
}
