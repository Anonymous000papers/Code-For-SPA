#pragma once
// TEST DOUBLE ONLY. No encryption, no noise simulation, no security claim.
// Stores scaled values and enforces parms_id and scale alignment.
#include <array>
#include <vector>
#include <memory>
#include <cmath>
#include <stdexcept>
#include <algorithm>
#include <cstdint>
namespace seal {
using parms_id_type=std::array<std::uint64_t,4>;
enum class scheme_type {ckks};enum class sec_level_type {tc128,none};
struct Modulus {uint64_t v;uint64_t value() const{return v;} };
struct CoeffModulus {
 static std::vector<Modulus> Create(size_t,const std::vector<int>& b) {
   std::vector<Modulus> r;size_t i=0;
   for(int v:b) { r.push_back({(uint64_t(1)<<v)-uint64_t(131072*(++i)+1)}); }
   return r;
 }
 static int MaxBitCount(size_t n,sec_level_type){if(n==32768)return 881;if(n==16384)return 438;if(n==8192)return 218;return 0;}
};
struct EncryptionParameters {
 size_t N=0;std::vector<Modulus> q;
 explicit EncryptionParameters(scheme_type){}
 void set_poly_modulus_degree(size_t n){N=n;}
 void set_coeff_modulus(const std::vector<Modulus>& v){q=v;}
 const std::vector<Modulus>& coeff_modulus()const{return q;}
};
struct ContextData {
 EncryptionParameters p;int chain;std::shared_ptr<ContextData> next;
 explicit ContextData(EncryptionParameters a,int c):p(a),chain(c){}
 int chain_index()const{return chain;}
 parms_id_type parms_id()const{return {uint64_t(chain+1),0,0,0};}
 const EncryptionParameters& parms()const{return p;}
 std::shared_ptr<ContextData> next_context_data()const{return next;}
 int total_coeff_modulus_bit_count()const{int n=0;for(auto q:p.q)n+=int(std::ceil(std::log2((double)q.v)));return n;}
};
struct SEALContext {
 EncryptionParameters p;std::shared_ptr<ContextData> key,first;
 SEALContext(EncryptionParameters a,bool,sec_level_type):p(a){
  key=std::make_shared<ContextData>(p,int(p.q.size())-1);
  auto prev=key;
  for(int i=int(p.q.size())-2;i>=0;--i){auto b=p;b.q.resize(i+1);auto v=std::make_shared<ContextData>(b,i);prev->next=v;prev=v;}
  first=key->next;
 }
 bool parameters_set()const{return true;}
 std::shared_ptr<ContextData> key_context_data()const{return key;}
 std::shared_ptr<ContextData> first_context_data()const{return first;}
 std::shared_ptr<ContextData> get_context_data(parms_id_type id)const{
  for(auto v=key;v;v=v->next) { if(v->parms_id()==id)return v; }
  return {};
 }
};
struct Data {
 std::vector<long double> v;parms_id_type id{};double sc=1.;
 double &scale(){return sc;}double scale()const{return sc;}
 parms_id_type &parms_id(){return id;}parms_id_type parms_id()const{return id;}
};
struct Plaintext:Data{};struct Ciphertext:Data{};
struct PublicKey{};struct SecretKey{};struct RelinKeys{};
struct KeyGenerator {
 KeyGenerator(const SEALContext&){}SecretKey secret_key(){return {};}
 void create_public_key(PublicKey&){}void create_relin_keys(RelinKeys&){}
};
struct CKKSEncoder {
 const SEALContext& c;explicit CKKSEncoder(const SEALContext& x):c(x){}
 size_t slot_count()const{return c.p.N/2;}
 void encode(double d,parms_id_type id,double scale,Plaintext&p){p.id=id;p.sc=scale;p.v.assign(slot_count(),(long double)d*scale);}
 void encode(const std::vector<double>&v,parms_id_type id,double scale,Plaintext&p){p.id=id;p.sc=scale;p.v.assign(slot_count(),0.);for(size_t i=0;i<v.size();++i)p.v[i]=(long double)v[i]*scale;}
 void encode(const std::vector<double>&v,double scale,Plaintext&p){encode(v,c.first->parms_id(),scale,p);}
 void encode(double d,double scale,Plaintext&p){encode(d,c.first->parms_id(),scale,p);}
 void decode(const Plaintext&p,std::vector<double>&r){r.clear();for(auto v:p.v)r.push_back(double(v/p.sc));}
};
struct Encryptor {Encryptor(const SEALContext&,const PublicKey&){}void encrypt(const Plaintext&p,Ciphertext&x){static_cast<Data&>(x)=p;}};
struct Decryptor {Decryptor(const SEALContext&,const SecretKey&){}void decrypt(const Ciphertext&x,Plaintext&p){static_cast<Data&>(p)=x;}};
struct Evaluator {
 const SEALContext& c;explicit Evaluator(const SEALContext&x):c(x){}
 void compatible(const Data&a,const Data&b,bool scale=false)const{
  if(a.id!=b.id)throw std::runtime_error("MODEL parms_id mismatch");
  if(a.v.size()!=b.v.size())throw std::runtime_error("MODEL length mismatch");
  if(scale && std::abs(a.sc/b.sc-1)>1e-8)throw std::runtime_error("MODEL scale mismatch");
 }
 void mod_switch_to_inplace(Ciphertext&x,parms_id_type id){if(id[0]>x.id[0])throw std::runtime_error("MODEL attempted modulus raise");x.id=id;}
 void mod_switch_to_inplace(Plaintext&x,parms_id_type id){if(id[0]>x.id[0])throw std::runtime_error("MODEL attempted plain modulus raise");x.id=id;}
 void mod_switch_to_next_inplace(Ciphertext&x){auto d=c.get_context_data(x.id);if(!d||!d->next)throw std::runtime_error("MODEL chain exhausted");x.id=d->next->parms_id();}
 void multiply(const Ciphertext&a,const Ciphertext&b,Ciphertext&out){compatible(a,b);Data temp=a;temp.sc=a.sc*b.sc;for(size_t i=0;i<a.v.size();++i)temp.v[i]=a.v[i]*b.v[i];static_cast<Data&>(out)=std::move(temp);}
 void multiply_inplace(Ciphertext&a,const Ciphertext&b){multiply(a,b,a);}
 void square(const Ciphertext&a,Ciphertext&out){multiply(a,a,out);}
 void multiply_plain(const Ciphertext&a,const Plaintext&b,Ciphertext&out){compatible(a,b);Data temp=a;temp.sc=a.sc*b.sc;for(size_t i=0;i<a.v.size();++i)temp.v[i]=a.v[i]*b.v[i];static_cast<Data&>(out)=std::move(temp);}
 void multiply_plain_inplace(Ciphertext&a,const Plaintext&b){multiply_plain(a,b,a);}
 void rescale_to_next_inplace(Ciphertext&a){auto d=c.get_context_data(a.id);if(!d||!d->next)throw std::runtime_error("MODEL rescale chain exhausted");auto q=d->p.q.back().v;for(auto&v:a.v)v/=q;a.sc/=double(q);a.id=d->next->parms_id();}
 void relinearize_inplace(Ciphertext&,const RelinKeys&){}
 void add_inplace(Ciphertext&a,const Ciphertext&b){compatible(a,b,true);for(size_t i=0;i<a.v.size();++i)a.v[i]+=b.v[i];}
 void sub_inplace(Ciphertext&a,const Ciphertext&b){compatible(a,b,true);for(size_t i=0;i<a.v.size();++i)a.v[i]-=b.v[i];}
 void sub(const Ciphertext&a,const Ciphertext&b,Ciphertext&o){o=a;sub_inplace(o,b);}
 void add_plain_inplace(Ciphertext&a,const Plaintext&b){compatible(a,b,true);for(size_t i=0;i<a.v.size();++i)a.v[i]+=b.v[i];}
 void negate_inplace(Ciphertext&a){for(auto&v:a.v)v=-v;}
};
}
