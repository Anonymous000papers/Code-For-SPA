#!/usr/bin/env python3
"""Refit the two-range SPA-GELU profile family used by the CKKS benchmark.

The ciphertext benchmark evaluates only [-5,5] and [-20,20].  GELU uses the
same three SPA cost tiers and active degree schedule as SiLU on those public
intervals:

    spa-k39 : R5 k3 / PS4,  R20 k15 / PS8
    spa-k63 : R5 k7 / PS4,  R20 k23 / PS8
    spa-k87 : R5 k11 / PS4, R20 k31 / PS8

The stable method IDs identify the common SPA tiers.  The active polynomial
is recorded explicitly in every result.  Each coefficient vector is obtained
from an adaptive discrete minimax LP for the exact erf-GELU even residual

    GELU(x) - x/2 = x*erf(x/sqrt(2))/2.

The standard sweep deliberately uses the ordinary square coordinate
2*x^2/R^2-1.  The former warped profile is not mixed into the degree sweep,
so the only changing approximation parameter is the square-domain degree.

Targets.  ``--target erf`` (default) fits the exact erf-GELU and writes the
historical files (configs/spa_profiles.json, src/spa_profiles.hpp).
``--target quickgelu`` fits QuickGELU x*sigmoid(1.702x) (Euston's target) and
writes configs/spa_quickgelu_profiles.json / src/spa_quickgelu_profiles.hpp.
The headers have identical structure, so the same benchmark source builds
against either (CMake target gelu_quickgelu_bench). The plaintext harness
evaluates the tanh-GELU form separately.

Experiment B.  ``--rounding-decimals 1,2,3,4,5`` (the default) also emits, for
the balanced tier, copies of its profiles whose normalised Chebyshev
coefficients are rounded half-to-even to d decimals, as method variants
``<tier-id>-d<d>``.  Nothing else changes: degree, PS split, range and the
coefficient source are those of the unrounded fit, which is kept as the
``full`` point.  Each rounded profile records ||c_d - c||_1 and
E_coeff = ||P_{c_d} - P_c||_inf on the interval (the bound
E_coeff <= ||c_d - c||_1 holds because |T_j(t)| <= 1 and is verified).
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import re
from pathlib import Path
from typing import Any

import numpy as np
from numpy.polynomial.chebyshev import chebval, chebvander
from scipy.optimize import linprog
from scipy.special import erf

RANGES = (
    {"label": "r5", "radius": 5.0, "ps_split": 4},
    {"label": "r20", "radius": 20.0, "ps_split": 8},
)
# Tier definitions shared with the plaintext harness: a tier is the smallest
# degree on the Paterson-Stockmeyer ladder (k = m*split - 1) whose dense-grid
# maximum error meets the tier's target, selected per range. The ids are
# stable tier labels (the numbers do not denote a degree); the active
# degrees are recorded in degree_schedule.
TIER_TARGETS = (
    ("spa-k39", "SPA-k39", "fast", 2.1e-2),
    ("spa-k63", "SPA-k63", "balanced", 1e-3),
    ("spa-k87", "SPA-k87", "accurate", 1e-4),
)
MAX_PS_BLOCKS = 12


TARGETS = {
    "erf": {
        "id": "erf-gelu",
        "label": "exact erf-GELU",
        "formula": "0.5*x*(1+erf(x/sqrt(2)))",
        "profile_prefix": "spa-gelu",
        "json_out": "configs/spa_profiles.json",
        "header_out": "src/spa_profiles.hpp",
        "summary_out": "configs/spa_gelu_profile_summary.csv",
    },
    # QuickGELU x*sigmoid(1.702x): Euston's own fitting target. Its odd part
    # is x/2 and its even part (x/2)tanh(0.851x), so the SPA structure
    # x/2 + Q(2x^2/R^2 - 1) applies unchanged.
    "quickgelu": {
        "id": "quickgelu",
        "label": "QuickGELU x*sigmoid(1.702x)",
        "formula": "x/(1+exp(-1.702*x))",
        "profile_prefix": "spa-quickgelu",
        "json_out": "configs/spa_quickgelu_profiles.json",
        "header_out": "src/spa_quickgelu_profiles.hpp",
        "summary_out": "configs/spa_quickgelu_profile_summary.csv",
    },
}
TARGET = "erf"


def gelu(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=np.float64)
    if TARGET == "quickgelu":
        return x / (1.0 + np.exp(-1.702 * x))
    return 0.5 * x * (1.0 + erf(x / math.sqrt(2.0)))


def round_profile(profile: dict[str, Any], decimals: int, validation_grid: int) -> dict[str, Any]:
    """Experiment B: the same profile with coefficients rounded to ``decimals``
    places; degree, range and PS split untouched, nothing refitted."""
    radius = float(profile["R"])
    original = np.asarray(profile["coefficients_chebyshev_low_to_high"], dtype=np.float64)
    rounded = np.asarray([round(float(c), decimals) for c in original], dtype=np.float64)
    delta = rounded - original
    t = np.linspace(-1.0, 1.0, validation_grid)
    e_coeff = float(np.max(np.abs(chebval(t, delta))))
    l1 = float(np.sum(np.abs(delta)))
    if e_coeff > l1 * (1.0 + 1e-9) + 1e-15:
        raise AssertionError(f"{profile['name']} d={decimals}: E_coeff {e_coeff} exceeds ||dc||_1 {l1}")
    x = np.linspace(-radius, radius, validation_grid, dtype=np.float64)
    approximation = 0.5 * x + chebval(2.0 * (x / radius) ** 2 - 1.0, rounded)
    error = approximation - gelu(x)
    absolute = np.abs(error)
    index = int(np.argmax(absolute))
    return {
        **profile,
        "name": f"{profile['name']}-d{decimals}",
        "role": f"coefficients of {profile['name']} rounded to {decimals} decimals (Experiment B; not refitted)",
        "coefficients_chebyshev_low_to_high": [float(v) for v in rounded],
        "lp_error": float("nan"),
        "dense_max_abs_error": float(absolute[index]),
        "dense_mean_abs_error": float(np.mean(absolute)),
        "dense_rmse": float(np.sqrt(np.mean(error * error))),
        "argmax_x": float(x[index]),
        "rounding_decimals": decimals,
        "derived_from": profile["name"],
        "unrounded_dense_max_abs_error": float(profile["dense_max_abs_error"]),
        "coefficient_l1_perturbation": l1,
        "coefficient_perturbation_max": e_coeff,
        "nonzero_coefficients": int(np.count_nonzero(rounded)),
    }


def square_target(t: np.ndarray, radius: float) -> np.ndarray:
    x = radius * np.sqrt(np.maximum(0.0, 0.5 * (t + 1.0)))
    return gelu(x) - 0.5 * x


def extrema_indices(values: np.ndarray) -> np.ndarray:
    if len(values) < 3:
        return np.arange(len(values), dtype=int)
    slopes = np.sign(np.diff(values))
    for i in range(1, len(slopes)):
        if slopes[i] == 0:
            slopes[i] = slopes[i - 1]
    for i in range(len(slopes) - 2, -1, -1):
        if slopes[i] == 0:
            slopes[i] = slopes[i + 1]
    inner = np.where(slopes[:-1] * slopes[1:] <= 0)[0] + 1
    return np.unique(np.r_[0, inner, len(values) - 1])


def solve_grid_minimax(
    radius: float, degree: int, grid: np.ndarray
) -> tuple[np.ndarray, float]:
    target = square_target(grid, radius)
    vandermonde = chebvander(grid, degree)
    rows = len(grid)
    upper = np.hstack([vandermonde, -np.ones((rows, 1))])
    lower = np.hstack([-vandermonde, -np.ones((rows, 1))])
    constraints = np.vstack([upper, lower])
    rhs = np.concatenate([target, -target])
    objective = np.concatenate([np.zeros(degree + 1), [1.0]])
    bounds = [(None, None)] * (degree + 1) + [(0.0, None)]
    result = linprog(
        objective,
        A_ub=constraints,
        b_ub=rhs,
        bounds=bounds,
        method="highs",
    )
    if not result.success:
        raise RuntimeError(
            f"minimax LP failed for R={radius:g}, k={degree}: {result.message}"
        )
    return np.asarray(result.x[:-1], dtype=np.float64), float(result.x[-1])


def fit_adaptive_minimax(
    radius: float,
    degree: int,
    base_grid: int,
    validation_grid: int,
    refinements: int,
) -> tuple[np.ndarray, float, dict[str, float], list[dict[str, float]]]:
    uniform = np.linspace(-1.0, 1.0, base_grid)
    lobatto = np.cos(np.pi * np.arange(base_grid) / (base_grid - 1))
    grid = np.unique(np.concatenate([uniform, lobatto]))
    dense_t = np.linspace(-1.0, 1.0, validation_grid)
    dense_target = square_target(dense_t, radius)
    coefficients: np.ndarray | None = None
    lp_error = float("nan")
    trials: list[dict[str, float]] = []

    for iteration in range(refinements):
        coefficients, lp_error = solve_grid_minimax(radius, degree, grid)
        error = chebval(dense_t, coefficients) - dense_target
        absolute = np.abs(error)
        maximum = float(np.max(absolute))
        extrema = extrema_indices(error)
        strong = extrema[absolute[extrema] >= 0.8 * maximum]
        additions = dense_t[np.unique(np.r_[strong, int(np.argmax(absolute))])]
        old_size = len(grid)
        grid = np.unique(np.concatenate([grid, additions]))
        trials.append(
            {
                "iteration": iteration,
                "constraint_points": old_size,
                "lp_error": lp_error,
                "dense_square_target_error": maximum,
                "strong_extrema": int(len(strong)),
            }
        )
        if len(grid) == old_size or maximum <= lp_error * (1.0 + 2e-8):
            break

    if coefficients is None:
        raise RuntimeError("adaptive minimax fit did not execute")

    x = np.linspace(-radius, radius, validation_grid, dtype=np.float64)
    t = 2.0 * (x / radius) ** 2 - 1.0
    approximation = 0.5 * x + chebval(t, coefficients)
    error = approximation - gelu(x)
    absolute = np.abs(error)
    index = int(np.argmax(absolute))
    metrics = {
        "max_abs_error": float(absolute[index]),
        "mean_abs_error": float(np.mean(absolute)),
        "rmse": float(np.sqrt(np.mean(error * error))),
        "argmax_x": float(x[index]),
    }
    return coefficients, lp_error, metrics, trials


def cxx_id(value: str) -> str:
    value = re.sub(r"[^0-9A-Za-z]+", "_", value).strip("_").upper()
    if not value or value[0].isdigit():
        value = "P_" + value
    return value


def cxx_string(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"')


def emit_numbers(values: list[float], indent: str = "        ") -> list[str]:
    lines: list[str] = []
    row: list[str] = []
    for value in values:
        row.append(f"{float(value):.17e}")
        if len(row) == 3:
            lines.append(indent + ", ".join(row) + ",")
            row = []
    if row:
        lines.append(indent + ", ".join(row) + ",")
    return lines


def file_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def emit_header(data: dict[str, Any], catalog_sha256: str, path: Path) -> None:
    profiles = data["profiles"]
    methods = data["method_variants"]
    lines = [
        "#pragma once",
        "",
        "#include <cmath>",
        "#include <limits>",
        "#include <stdexcept>",
        "#include <string>",
        "#include <vector>",
        "",
        "namespace spa {",
        "",
        "struct ProfileDef {",
        "    std::string name;",
        "    double radius;",
        "    double warp_a;",
        "    double offline_max_error;",
        "    std::vector<double> coefficients;",
        "    std::string range_label{};",
        "    int degree_square = -1;",
        "    int ps_split = -1;",
        "    int ps_blocks = -1;",
        "    double offline_rmse = std::numeric_limits<double>::quiet_NaN();",
        "    // Experiment B (coefficient precision): -1 / 0 / \"\" for unrounded fits.",
        "    int rounding_decimals = -1;",
        "    double coefficient_perturbation_max = 0.0;",
        "    double coefficient_l1_perturbation = 0.0;",
        "    std::string derived_from{};",
        "};",
        "",
        "struct MethodDef {",
        "    std::string id;",
        "    std::string display_name;",
        "    std::string tier;",
        "    std::string degree_schedule;",
        "    std::string r5_profile;",
        "    std::string r20_profile;",
        "    int rounding_decimals = -1;",
        "    std::string derived_from{};",
        "};",
        "",
    ]
    for profile in profiles:
        ident = cxx_id(profile["name"])
        lines += [
            f"inline const ProfileDef {ident} = {{",
            f"    \"{cxx_string(profile['name'])}\",",
            f"    {profile['R']:.17g},",
            "    0.0,",
            f"    {profile['dense_max_abs_error']:.17e},",
            "    {",
        ]
        lines += emit_numbers(profile["coefficients_chebyshev_low_to_high"])
        lines += [
            "    },",
            f"    \"{cxx_string(profile['range_label'])}\",",
            f"    {profile['degree_square']},",
            f"    {profile['ps_split']},",
            f"    {profile['ps_blocks']},",
            f"    {profile['dense_rmse']:.17e},",
            f"    {int(profile.get('rounding_decimals', -1))},",
            f"    {float(profile.get('coefficient_perturbation_max', 0.0)):.17e},",
            f"    {float(profile.get('coefficient_l1_perturbation', 0.0)):.17e},",
            f"    \"{cxx_string(profile.get('derived_from', ''))}\",",
            "};",
            "",
        ]

    lines += [
        "inline const std::vector<const ProfileDef *> &builtin_profiles() {",
        "    static const std::vector<const ProfileDef *> value = {",
    ]
    lines += [f"        &{cxx_id(profile['name'])}," for profile in profiles]
    lines += [
        "    };",
        "    return value;",
        "}",
        "",
        "inline const ProfileDef &find_profile(const std::string &name) {",
        "    for (const auto *profile : builtin_profiles()) {",
        "        if (profile->name == name) return *profile;",
        "    }",
        "    throw std::invalid_argument(\"unknown SPA GELU profile: \" + name);",
        "}",
        "",
    ]

    for method in methods:
        ident = cxx_id(method["id"])
        lines += [
            f"inline const MethodDef {ident} = {{",
            f"    \"{cxx_string(method['id'])}\",",
            f"    \"{cxx_string(method['display_name'])}\",",
            f"    \"{cxx_string(method['tier'])}\",",
            f"    \"{cxx_string(method['degree_schedule'])}\",",
            f"    \"{cxx_string(method['profiles']['r5'])}\",",
            f"    \"{cxx_string(method['profiles']['r20'])}\",",
            f"    {int(method.get('rounding_decimals', -1))},",
            f"    \"{cxx_string(method.get('derived_from', ''))}\",",
            "};",
            "",
        ]
    lines += [
        "inline const std::vector<const MethodDef *> &builtin_methods() {",
        "    static const std::vector<const MethodDef *> value = {",
    ]
    lines += [f"        &{cxx_id(method['id'])}," for method in methods]
    lines += [
        "    };",
        "    return value;",
        "}",
        "",
        "inline const MethodDef *try_find_method(const std::string &id) {",
        "    for (const auto *method : builtin_methods()) {",
        "        if (method->id == id) return method;",
        "    }",
        "    return nullptr;",
        "}",
        "",
        "inline const ProfileDef &select_profile(const MethodDef &method, double required_radius) {",
        "    if (!(required_radius >= 0.0) || !std::isfinite(required_radius)) {",
        "        throw std::invalid_argument(\"invalid SPA GELU required radius\");",
        "    }",
        "    const ProfileDef &r5 = find_profile(method.r5_profile);",
        "    const ProfileDef &r20 = find_profile(method.r20_profile);",
        "    const double tolerance = 1e-12;",
        "    if (required_radius <= r5.radius + tolerance) return r5;",
        "    if (required_radius <= r20.radius + tolerance) return r20;",
        "    throw std::invalid_argument(\"requested GELU interval exceeds the supported radius R=20\");",
        "}",
        "",
        "inline double maximum_supported_radius() { return 20.0; }",
        "",
        f"inline const char *profile_catalog_sha256() {{ return \"{catalog_sha256}\"; }}",
        f"inline const char *native_target_id() {{ return \"{cxx_string(data['native_activation']['id'])}\"; }}",
        f"inline const char *native_target_label() {{ return \"{cxx_string(data['target'])}\"; }}",
        "",
        "} // namespace spa",
        "",
    ]
    path.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    global TARGET
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", choices=sorted(TARGETS), default="erf")
    parser.add_argument("--json-out", type=Path, default=None)
    parser.add_argument("--header-out", type=Path, default=None)
    parser.add_argument("--summary-out", type=Path, default=None)
    parser.add_argument("--base-grid", type=int, default=3001)
    parser.add_argument("--validation-grid", type=int, default=300001)
    parser.add_argument("--refinements", type=int, default=8)
    parser.add_argument(
        "--rounding-decimals", default="1,2,3,4,5",
        help="Experiment B decimal places for the rounding tier ('' disables).",
    )
    parser.add_argument("--rounding-tier", default="balanced")
    args = parser.parse_args()
    TARGET = args.target
    target = TARGETS[TARGET]
    if args.json_out is None:
        args.json_out = Path(target["json_out"])
    if args.header_out is None:
        args.header_out = Path(target["header_out"])
    if args.summary_out is None:
        args.summary_out = Path(target["summary_out"])
    decimals = [int(v) for v in args.rounding_decimals.split(",") if v.strip()]
    PROFILE_PREFIX = target["profile_prefix"]

    # Fit the PS ladder per range until every tier target is met; keep only the
    # selected profiles. Every trial is recorded in tier_selection.
    profiles: list[dict[str, Any]] = []
    all_trials: list[dict[str, Any]] = []
    selected: dict[str, dict[str, int]] = {tier: {} for _, _, tier, _ in TIER_TARGETS}
    ladder_record: list[dict[str, Any]] = []
    for range_item in RANGES:
        label = range_item["label"]
        radius = float(range_item["radius"])
        split = int(range_item["ps_split"])
        for blocks in range(1, MAX_PS_BLOCKS + 1):
            degree = blocks * split - 1
            coefficients, lp_error, metrics, trials = fit_adaptive_minimax(
                radius, degree, args.base_grid, args.validation_grid, args.refinements
            )
            profile_id = f"{PROFILE_PREFIX}-r{radius:g}-k{degree}"
            profile = {
                "name": profile_id,
                "range_label": label,
                "R": radius,
                "degree_square": degree,
                "degree_x": 2 * degree,
                "ps_split": split,
                "ps_blocks": (degree + split) // split,
                "warp_a": 0.0,
                "role": "adaptive discrete Chebyshev-basis minimax LP refit",
                "coefficients_chebyshev_low_to_high": [float(value) for value in coefficients],
                "lp_error": lp_error,
                "dense_max_abs_error": metrics["max_abs_error"],
                "dense_mean_abs_error": metrics["mean_abs_error"],
                "dense_rmse": metrics["rmse"],
                "argmax_x": metrics["argmax_x"],
            }
            ladder_record.append(
                {"range_label": label, "degree_square": degree, "ps_split": split,
                 "dense_max_abs_error": metrics["max_abs_error"]}
            )
            print(
                f"{profile_id}: max={metrics['max_abs_error']:.9e} "
                f"rmse={metrics['rmse']:.9e} lp={lp_error:.9e}"
            )
            newly = False
            for _, _, tier, target_error in TIER_TARGETS:
                if label not in selected[tier] and metrics["max_abs_error"] <= target_error:
                    selected[tier][label] = degree
                    newly = True
            if newly:
                profiles.append(profile)
                for trial in trials:
                    all_trials.append({"profile": profile_id, **trial})
            if all(label in selected[tier] for _, _, tier, _ in TIER_TARGETS):
                break
        missing = [tier for _, _, tier, _ in TIER_TARGETS if label not in selected[tier]]
        if missing:
            raise RuntimeError(f"no degree up to {MAX_PS_BLOCKS} blocks met the targets {missing} on {label}")
    METHODS = tuple(
        {"id": method_id, "display_name": display, "tier": tier, "target_max_error": target_error,
         "degrees": dict(selected[tier])}
        for method_id, display, tier, target_error in TIER_TARGETS
    )

    profile_names = {profile["name"] for profile in profiles}
    methods: list[dict[str, Any]] = []
    for source in METHODS:
        refs = {
            label: f"{target['profile_prefix']}-r{next(r['radius'] for r in RANGES if r['label'] == label):g}-k{degree}"
            for label, degree in source["degrees"].items()
        }
        if not set(refs.values()).issubset(profile_names):
            raise RuntimeError(f"incomplete profile schedule for {source['id']}")
        methods.append(
            {
                **source,
                "profiles": refs,
                "degree_schedule": ";".join(
                    f"{item['label']}:k{source['degrees'][item['label']]}"
                    for item in RANGES
                ),
                "naming_rule": (
                    "stable SPA tier ID shared with the SiLU experiment; "
                    "the active GELU degree is in degree_schedule"
                ),
            }
        )

    # Experiment B: rounded copies of the rounding tier's profiles.
    rounded_profiles: list[dict[str, Any]] = []
    rounded_methods: list[dict[str, Any]] = []
    if decimals:
        base = next((m for m in methods if m["tier"] == args.rounding_tier), None)
        if base is None:
            raise RuntimeError(f"no {args.rounding_tier!r} tier to round")
        by_name = {p["name"]: p for p in profiles}
        for d in decimals:
            variant_profiles: dict[str, str] = {}
            perturbation: dict[str, dict[str, float]] = {}
            for label, profile_id in base["profiles"].items():
                rounded = round_profile(by_name[profile_id], d, args.validation_grid)
                rounded_profiles.append(rounded)
                variant_profiles[label] = rounded["name"]
                perturbation[label] = {
                    key: rounded[key]
                    for key in (
                        "coefficient_l1_perturbation",
                        "coefficient_perturbation_max",
                        "dense_max_abs_error",
                        "unrounded_dense_max_abs_error",
                        "nonzero_coefficients",
                    )
                }
                print(
                    f"{rounded['name']}: ||dc||_1={rounded['coefficient_l1_perturbation']:.3e} "
                    f"E_coeff={rounded['coefficient_perturbation_max']:.3e} "
                    f"max={rounded['dense_max_abs_error']:.3e}"
                )
            rounded_methods.append(
                {
                    **base,
                    "id": f"{base['id']}-d{d}",
                    "display_name": f"{base['display_name']}/d{d}",
                    "profiles": variant_profiles,
                    "rounding_decimals": d,
                    "derived_from": base["id"],
                    "coefficient_perturbation": perturbation,
                    "naming_rule": (
                        f"Experiment B: {base['id']} with normalised Chebyshev coefficients "
                        f"rounded to {d} decimals; degree, PS split and range unchanged"
                    ),
                }
            )
    profiles = profiles + rounded_profiles
    methods = methods + rounded_methods

    output: dict[str, Any] = {
        "format": "spa-gelu-two-range-v1",
        "target": target["label"],
        "native_activation": {"id": target["id"], "formula": target["formula"]},
        "tier_selection": {
            "rule": "smallest degree on the PS ladder (k = m*split - 1) whose dense-grid max error meets the tier target; same rule and targets as the plaintext harness",
            "targets": {tier: target_error for _, _, tier, target_error in TIER_TARGETS},
            "ladder": ladder_record,
        },
        "rounding_experiment": {
            "tier": args.rounding_tier,
            "decimals": decimals,
            "rule": (
                "normalised Chebyshev coefficients rounded half-to-even to d decimals; "
                "degree, PS split, range and coefficient source unchanged; no refit"
            ),
            "bound": "||P_{c_d} - P_c||_inf <= ||c_d - c||_1 on the interval (verified per profile)",
            "bound_scope": "ideal real-arithmetic perturbation; excludes CKKS encoding/rescale error",
        },
        "structure": "x/2 + Q_k(2*x^2/R^2 - 1)",
        "coefficient_order": "Chebyshev T_j, low to high",
        "range_selection": (
            "R5 for public intervals within [-5,5], otherwise R20 up to [-20,20]"
        ),
        "method_naming": (
            "SPA-k39/k63/k87 are stable fast/balanced/accurate tier IDs; "
            "active GELU R5/R20 degrees are in degree_schedule"
        ),
        "fit_method": "adaptive discrete Chebyshev-basis minimax LP",
        "warp_policy": (
            "ordinary square coordinate only; the legacy warped profile is excluded "
            "from this degree-controlled sweep"
        ),
        "generation_parameters": {
            "base_grid": args.base_grid,
            "validation_grid": args.validation_grid,
            "refinements": args.refinements,
        },
        "ranges": [
            {"label": item["label"], "radius": item["radius"]} for item in RANGES
        ],
        "method_variants": methods,
        "profiles": profiles,
        "fit_trials": all_trials,
    }

    args.json_out.parent.mkdir(parents=True, exist_ok=True)
    args.header_out.parent.mkdir(parents=True, exist_ok=True)
    args.summary_out.parent.mkdir(parents=True, exist_ok=True)
    args.json_out.write_text(json.dumps(output, indent=2), encoding="utf-8")
    catalog_sha256 = file_sha256(args.json_out)
    emit_header(output, catalog_sha256, args.header_out)

    owner_by_profile: dict[str, dict[str, Any]] = {}
    for method in methods:
        for label, profile_id in method["profiles"].items():
            owner_by_profile[profile_id] = {
                "method": method["id"],
                "tier": method["tier"],
                "degree_schedule": method["degree_schedule"],
                "range_label": label,
            }

    rows: list[dict[str, Any]] = []
    for profile in profiles:
        owner = owner_by_profile[profile["name"]]
        rows.append(
            {
                "method": owner["method"],
                "tier": owner["tier"],
                "degree_schedule": owner["degree_schedule"],
                "range_label": owner["range_label"],
                "profile": profile["name"],
                "R": profile["R"],
                "degree_square": profile["degree_square"],
                "degree_x": profile["degree_x"],
                "ps_split": profile["ps_split"],
                "ps_blocks": profile["ps_blocks"],
                "warp_a": profile["warp_a"],
                "dense_max_abs_error": profile["dense_max_abs_error"],
                "dense_mean_abs_error": profile["dense_mean_abs_error"],
                "dense_rmse": profile["dense_rmse"],
                "argmax_x": profile["argmax_x"],
                "rounding_decimals": profile.get("rounding_decimals", ""),
                "derived_from": profile.get("derived_from", ""),
                "coefficient_l1_perturbation": profile.get("coefficient_l1_perturbation", ""),
                "coefficient_perturbation_max": profile.get("coefficient_perturbation_max", ""),
                "unrounded_dense_max_abs_error": profile.get("unrounded_dense_max_abs_error", ""),
                "profile_catalog_sha256": catalog_sha256,
            }
        )
    with args.summary_out.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)

    print(f"profile_catalog_sha256={catalog_sha256}")


if __name__ == "__main__":
    main()
