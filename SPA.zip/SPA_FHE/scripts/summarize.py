#!/usr/bin/env python3
"""Pool per-repeat timing samples into speed-up ratios with paired bootstrap intervals and merge the summary CSV columns."""
from __future__ import annotations

import argparse
import csv
import math
import random
import statistics
from collections import defaultdict
from pathlib import Path


def quantile(values: list[float], p: float) -> float:
    values = sorted(values)
    if not values:
        return math.nan
    if len(values) == 1:
        return values[0]
    pos = p * (len(values) - 1)
    lo = math.floor(pos)
    hi = math.ceil(pos)
    weight = pos - lo
    return values[lo] * (1.0 - weight) + values[hi] * weight


def describe(values: list[float]) -> dict[str, float]:
    return {
        "samples": float(len(values)),
        "median_ms": quantile(values, 0.50),
        "p25_ms": quantile(values, 0.25),
        "p75_ms": quantile(values, 0.75),
        "p95_ms": quantile(values, 0.95),
        "best_ms": min(values),
        "mean_ms": statistics.fmean(values),
        "stddev_ms": statistics.pstdev(values),
    }


def paired_interval(
    rounds: dict[tuple[str, int], dict[str, float]],
    method: str,
    baseline: str,
    repeats: int,
    rng: random.Random,
) -> tuple[float, float, int]:
    pairs = [(row[method], row[baseline]) for row in rounds.values()
             if method in row and baseline in row]
    if not pairs:
        return math.nan, math.nan, 0
    if method == baseline:
        return 1.0, 1.0, len(pairs)
    ratios: list[float] = []
    for _ in range(repeats):
        sample = [pairs[rng.randrange(len(pairs))] for _ in pairs]
        ratios.append(statistics.median(b for _, b in sample) /
                      statistics.median(m for m, _ in sample))
    return quantile(ratios, 0.025), quantile(ratios, 0.975), len(pairs)


def parse_baseline(value: str) -> tuple[str, str]:
    if "=" not in value:
        raise argparse.ArgumentTypeError("baseline must be NAME=METHOD")
    name, method = value.split("=", 1)
    if not name or not method:
        raise argparse.ArgumentTypeError("baseline must be NAME=METHOD")
    return name, method


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--samples", type=Path, required=True)
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--baseline", action="append", type=parse_baseline, default=[])
    parser.add_argument("--bootstrap", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260831)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    samples: dict[str, list[float]] = defaultdict(list)
    rounds: dict[tuple[str, int], dict[str, float]] = defaultdict(dict)
    with args.samples.open(newline="") as handle:
        for row in csv.DictReader(handle):
            key = (row["run_label"], int(row["round"]))
            method = row["method"]
            value = float(row["time_ms"])
            if method in rounds[key]:
                raise ValueError(f"duplicate sample for {key}: {method}")
            rounds[key][method] = value
            samples[method].append(value)

    metadata: dict[str, dict[str, str]] = {}
    with args.summary.open(newline="") as handle:
        for row in csv.DictReader(handle):
            metadata[row["method"]] = row

    if not samples:
        raise ValueError("no timing samples")
    pooled = {method: describe(values) for method, values in samples.items()}
    baselines = dict(args.baseline)
    rng = random.Random(args.seed)

    metadata_fields = [
        "family", "provenance", "reconstruction_status", "input_semantics",
        "parameter_policy", "native_target", "reference_gap_semantics",
        "profile_catalog_sha256", "spa_tier", "degree_schedule",
        "active_profile", "active_degree_square", "active_ps_split",
        "active_ps_blocks",
        "range_lo", "range_hi", "design_lo", "design_hi",
        "offline_max_error", "offline_rmse", "consumed_levels",
        "main_modulus_bits", "ct_ct_total", "ct_plain_multiply",
        "relinearize", "rescale", "mod_switch", "total_max_abs",
        "method_bias_max", "ckks_extra_max", "outside_domain_count",
        "outside_profile_count", "implementation_revision", "poly_modulus_degree",
        "security_validation", "context_count", "evaluation_scale_bits", "evaluation_prime_bits",
        "polynomial_degree", "euston_sign_scale", "euston_g_rounds", "euston_f_rounds",
        "euston_tau", "euston_inverse_iterations", "expected_consumed_levels", "bootstraps",
        "encrypt", "decrypt", "decode", "dynamic_plain_encode",
        "native_target_id", "fit_target_id", "e_target", "e_poly", "e_coeff",
        "e_he", "e_total", "decomposition_bound", "decomposition_bound_holds",
        "catalog_e_poly", "catalog_e_coeff", "spa_rounding_decimals",
        "spa_derived_from", "host_reference_semantics",
    ]
    fields = [
        "method", *metadata_fields, "samples", "median_ms", "p25_ms",
        "p75_ms", "p95_ms", "best_ms", "mean_ms", "stddev_ms",
    ]
    for name in baselines:
        fields.extend([
            f"speedup_vs_{name}", f"speedup_vs_{name}_ci_low",
            f"speedup_vs_{name}_ci_high", f"paired_vs_{name}",
        ])

    rows: list[dict[str, object]] = []
    for method in sorted(pooled, key=lambda item: pooled[item]["median_ms"]):
        row: dict[str, object] = {"method": method, **pooled[method]}
        meta = metadata.get(method, {})
        for field in metadata_fields:
            row[field] = meta.get(field, "")
        for name, baseline in baselines.items():
            baseline_median = pooled.get(baseline, {}).get("median_ms", math.nan)
            low, high, count = paired_interval(
                rounds, method, baseline, args.bootstrap, rng)
            row[f"speedup_vs_{name}"] = (
                baseline_median / pooled[method]["median_ms"]
                if math.isfinite(baseline_median) else math.nan
            )
            row[f"speedup_vs_{name}_ci_low"] = low
            row[f"speedup_vs_{name}_ci_high"] = high
            row[f"paired_vs_{name}"] = count
        rows.append(row)

    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

    for row in rows:
        parts = [f"{row['method']}: {float(row['median_ms']):.3f} ms"]
        for name in baselines:
            speedup = float(row[f"speedup_vs_{name}"])
            low = float(row[f"speedup_vs_{name}_ci_low"])
            high = float(row[f"speedup_vs_{name}_ci_high"])
            parts.append(f"{name}={speedup:.3f}x [{low:.3f}, {high:.3f}]")
        print(", ".join(parts))
    print(args.out)


if __name__ == "__main__":
    main()
