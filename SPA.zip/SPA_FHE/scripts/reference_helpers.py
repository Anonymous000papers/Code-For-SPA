"""Helpers for the balanced-profile validator.

CoverageRadius computes, from the midpoints that were actually evaluated
(float64, chunked, not exactly equally spaced), a coverage radius

    h_cover = max( m_0 + R,  R - m_{n-1},  max_j (m_{j+1} - m_j) / 2 )

with every subtraction, division and comparison performed in long double
with upward enclosure, and with the gap between the last midpoint of one
chunk and the first of the next included. With M a bound on |e'| over the
whole interval, sup |e| <= max_j |e(m_j)| + h_cover * M, because every
x in [-R, R] is within h_cover of an evaluated midpoint.
"""

from __future__ import annotations

import numpy as np

LD = np.longdouble
POS_INF = LD(np.inf)


def up(value):
    """Next representable long double above ``value`` (outward rounding)."""
    return np.nextafter(np.asarray(value, dtype=LD), POS_INF)


class CoverageRadius:
    def __init__(self, radius: float):
        self.radius = LD(radius)
        self.first = None
        self.last = None
        self.max_gap = LD(0.0)
        self.count = 0

    def add(self, midpoints: np.ndarray) -> None:
        """Add one chunk of midpoints (ascending, float64, exactly the values
        the error is evaluated at)."""
        if midpoints.size == 0:
            return
        m = np.asarray(midpoints, dtype=LD)
        if self.last is not None:
            if not m[0] > self.last:
                raise ValueError("midpoints must be strictly increasing across chunks")
            self.max_gap = max(self.max_gap, up(m[0] - self.last)[()])
        if m.size > 1:
            gaps = up(m[1:] - m[:-1])
            if not bool(np.all(gaps > 0)):
                raise ValueError("midpoints must be strictly increasing within a chunk")
            self.max_gap = max(self.max_gap, LD(np.max(gaps)))
        if self.first is None:
            self.first = m[0]
        self.last = m[-1]
        self.count += int(m.size)

    def finish(self):
        if self.first is None:
            raise ValueError("no midpoints were added")
        left = up(self.first + self.radius)[()]      # m_0 - (-R)
        right = up(self.radius - self.last)[()]      # R - m_{n-1}
        half_gap = up(self.max_gap / LD(2.0))[()]
        if left < 0 or right < 0:
            raise ValueError("midpoints lie outside [-R, R]")
        return max(left, right, half_gap)


__all__ = ["CoverageRadius", "up"]
