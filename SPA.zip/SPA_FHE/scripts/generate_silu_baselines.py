#!/usr/bin/env python3
"""Generate SiLU benchmark coefficient profiles."""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Callable

import numpy as np
from numpy.polynomial.chebyshev import chebfit, chebpts1, chebval
from scipy.optimize import linprog, minimize_scalar


def silu(x: np.ndarray) -> np.ndarray:
    # Stable x*sigmoid(x) through tanh.
    return 0.5 * x * (1.0 + np.tanh(0.5 * x))


def logistic(x: np.ndarray) -> np.ndarray:
    return 0.5 * (1.0 + np.tanh(0.5 * x))


def map_t_to_x(t: np.ndarray, lo: float, hi: float) -> np.ndarray:
    return 0.5 * (hi - lo) * t + 0.5 * (hi + lo)


def cheb_interpolant(func: Callable[[np.ndarray], np.ndarray], degree: int,
                     lo: float, hi: float) -> np.ndarray:
    nodes = chebpts1(degree + 1)
    values = func(map_t_to_x(nodes, lo, hi))
    return np.asarray(chebfit(nodes, values, degree), dtype=float)


def orion_code_fit(func: Callable[[np.ndarray], np.ndarray], degree: int,
                    lo: float, hi: float) -> np.ndarray:
    """Fit in the normalized Chebyshev coordinate used by the evaluator."""
    nodes = chebpts1(degree + 1)
    values = func(map_t_to_x(nodes, lo, hi))
    return np.asarray(chebfit(nodes, values, degree), dtype=float)


def extrema_indices(values: np.ndarray) -> np.ndarray:
    if len(values) < 3:
        return np.arange(len(values), dtype=int)
    d = np.diff(values)
    s = np.sign(d)
    # Fill exact zero slopes to avoid losing flat extrema.
    for i in range(1, len(s)):
        if s[i] == 0:
            s[i] = s[i - 1]
    for i in range(len(s) - 2, -1, -1):
        if s[i] == 0:
            s[i] = s[i + 1]
    inner = np.where(s[:-1] * s[1:] <= 0)[0] + 1
    return np.unique(np.r_[0, inner, len(values) - 1])


def solve_minimax_grid(func: Callable[[np.ndarray], np.ndarray], degree: int,
                        lo: float, hi: float, grid_t: np.ndarray) -> tuple[np.ndarray, float]:
    vand = np.polynomial.chebyshev.chebvander(grid_t, degree)
    target = func(map_t_to_x(grid_t, lo, hi))
    # Variables are c_0..c_degree,E.  Enforce |Vc-f| <= E.
    a_ub = np.vstack([
        np.c_[vand, -np.ones(len(grid_t))],
        np.c_[-vand, -np.ones(len(grid_t))],
    ])
    b_ub = np.r_[target, -target]
    objective = np.r_[np.zeros(degree + 1), 1.0]
    bounds = [(None, None)] * (degree + 1) + [(0.0, None)]
    result = linprog(objective, A_ub=a_ub, b_ub=b_ub,
                     bounds=bounds, method="highs")
    if not result.success:
        raise RuntimeError(f"minimax LP failed: {result.message}")
    return np.asarray(result.x[:-1], dtype=float), float(result.x[-1])


def adaptive_minimax(func: Callable[[np.ndarray], np.ndarray], degree: int,
                     lo: float, hi: float, base: int = 4501,
                     validation: int = 350001, iterations: int = 7) -> np.ndarray:
    uniform = np.linspace(-1.0, 1.0, base)
    lobatto = np.cos(np.pi * np.arange(base) / (base - 1))
    grid = np.unique(np.r_[uniform, lobatto])
    dense = np.linspace(-1.0, 1.0, validation)
    target = func(map_t_to_x(dense, lo, hi))
    coeffs: np.ndarray | None = None
    for _ in range(iterations):
        coeffs, lp_error = solve_minimax_grid(func, degree, lo, hi, grid)
        error = chebval(dense, coeffs) - target
        absolute = np.abs(error)
        maximum = float(absolute.max())
        extrema = extrema_indices(error)
        strong = extrema[absolute[extrema] >= 0.75 * maximum]
        additions = dense[np.unique(np.r_[strong, int(absolute.argmax())])]
        old_size = len(grid)
        grid = np.unique(np.r_[grid, additions])
        if len(grid) == old_size or maximum <= lp_error * (1.0 + 2e-7):
            break
    if coeffs is None:
        raise RuntimeError("minimax fit did not run")
    return coeffs


def evaluate_profile(coeffs: np.ndarray, lo: float, hi: float,
                     func: Callable[[np.ndarray], np.ndarray],
                     n: int = 1000001) -> dict[str, float]:
    t = np.linspace(-1.0, 1.0, n)
    x = map_t_to_x(t, lo, hi)
    error = chebval(t, coeffs) - func(x)
    return {
        "dense_max_abs_error": float(np.max(np.abs(error))),
        "dense_mean_abs_error": float(np.mean(np.abs(error))),
        "dense_rmse": float(np.sqrt(np.mean(error * error))),
    }


def composite_coefficients(radius: float, degree1: int = 31,
                           degree2: int = 27) -> tuple[float, np.ndarray, np.ndarray]:
    """Build a stable THOR/Cachemir-inspired 31->27 composition.

    The papers disclose the composite architecture/depth but not SiLU
    coefficients.  We therefore use a reproducible coordinate-compression
    construction: stage 1 approximates an asinh map from x/R to u in [-1,1],
    while stage 2 approximates SiLU after the inverse map.  This is deliberately
    labelled reconstructed, not an official THOR/Cachemir coefficient set.
    """
    dense_t = np.linspace(-1.0, 1.0, 250001)
    target = silu(radius * dense_t)

    def build(alpha: float) -> tuple[np.ndarray, np.ndarray]:
        sh = math.sinh(alpha)
        n1 = chebpts1(degree1 + 1)
        p1 = chebfit(n1, np.arcsinh(sh * n1) / alpha, degree1)
        n2 = chebpts1(degree2 + 1)
        p2 = chebfit(n2, silu(radius * np.sinh(alpha * n2) / sh), degree2)
        return np.asarray(p1, dtype=float), np.asarray(p2, dtype=float)

    def objective(alpha: float) -> float:
        p1, p2 = build(alpha)
        u = chebval(dense_t, p1)
        return float(np.max(np.abs(chebval(u, p2) - target)))

    optimum = minimize_scalar(objective, bounds=(0.25, 4.0), method="bounded",
                              options={"xatol": 1e-11})
    p1, p2 = build(float(optimum.x))
    return float(optimum.x), p1, p2


def evaluate_composite(radius: float, p1: np.ndarray, p2: np.ndarray,
                       n: int = 1000001) -> dict[str, float]:
    t = np.linspace(-1.0, 1.0, n)
    x = radius * t
    u = chebval(t, p1)
    error = chebval(u, p2) - silu(x)
    return {
        "dense_max_abs_error": float(np.max(np.abs(error))),
        "dense_mean_abs_error": float(np.mean(np.abs(error))),
        "dense_rmse": float(np.sqrt(np.mean(error * error))),
        "stage1_output_min": float(np.min(u)),
        "stage1_output_max": float(np.max(u)),
    }


def cxx_array(values: list[float] | np.ndarray, indent: str = "        ") -> list[str]:
    result: list[str] = []
    row: list[str] = []
    for value in values:
        row.append(f"{float(value):.17e}")
        if len(row) == 3:
            result.append(indent + ", ".join(row) + ",")
            row = []
    if row:
        result.append(indent + ", ".join(row) + ",")
    return result


def emit_header(catalog: dict, path: Path) -> None:
    lines = [
        "#pragma once", "", "#include <stdexcept>", "#include <string>",
        "#include <vector>", "", "namespace silu_baselines {", "",
        "struct ChebProfile {", "    std::string name;", "    std::string family;",
        "    std::string provenance;", "    double domain_lo;", "    double domain_hi;",
        "    int ps_split;", "    double offline_max_error;", "    double offline_rmse;",
        "    std::vector<double> coefficients;", "};", "",
        "struct CompositeProfile {", "    std::string name;", "    std::string family;",
        "    std::string provenance;", "    double radius;", "    int stage1_split;",
        "    int stage2_split;", "    double warp_alpha;", "    double offline_max_error;",
        "    double offline_rmse;", "    std::vector<double> stage1_coefficients;",
        "    std::vector<double> stage2_coefficients;", "};", "",
    ]
    for item in catalog["chebyshev_profiles"]:
        lines += [
            f"inline const ChebProfile {item['cpp_id']} = {{",
            f"    \"{item['name']}\",", f"    \"{item['family']}\",",
            f"    \"{item['provenance']}\",",
            f"    {item['domain_lo']:.17g}, {item['domain_hi']:.17g},",
            f"    {item['ps_split']},", f"    {item['dense_max_abs_error']:.17e},",
            f"    {item['dense_rmse']:.17e},", "    {",
        ]
        lines += cxx_array(item["coefficients_chebyshev_low_to_high"])
        lines += ["    },", "};", ""]
    for item in catalog["composite_profiles"]:
        lines += [
            f"inline const CompositeProfile {item['cpp_id']} = {{",
            f"    \"{item['name']}\",", f"    \"{item['family']}\",",
            f"    \"{item['provenance']}\",", f"    {item['radius']:.17g},",
            f"    {item['stage1_split']}, {item['stage2_split']},",
            f"    {item['warp_alpha']:.17g},", f"    {item['dense_max_abs_error']:.17e},",
            f"    {item['dense_rmse']:.17e},", "    {",
        ]
        lines += cxx_array(item["stage1_coefficients_chebyshev_low_to_high"])
        lines += ["    },", "    {"]
        lines += cxx_array(item["stage2_coefficients_chebyshev_low_to_high"])
        lines += ["    },", "};", ""]
    lines += [
        "inline const ChebProfile &find_cheb_profile(const std::string &name) {",
        "    static const std::vector<const ChebProfile *> profiles = {",
    ]
    lines += [f"        &{item['cpp_id']}," for item in catalog["chebyshev_profiles"]]
    lines += [
        "    };", "    for (const auto *profile : profiles) if (profile->name == name) return *profile;",
        "    throw std::invalid_argument(\"unknown SiLU Chebyshev baseline: \" + name);",
        "}", "", "inline const CompositeProfile &find_composite_profile(const std::string &name) {",
        "    static const std::vector<const CompositeProfile *> profiles = {",
    ]
    lines += [f"        &{item['cpp_id']}," for item in catalog["composite_profiles"]]
    lines += [
        "    };", "    for (const auto *profile : profiles) if (profile->name == name) return *profile;",
        "    throw std::invalid_argument(\"unknown SiLU composite baseline: \" + name);",
        "}", "", "} // namespace silu_baselines", "",
    ]
    path.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out-json", type=Path,
                        default=Path("configs/silu_baseline_profiles.json"))
    parser.add_argument("--out-header", type=Path,
                        default=Path("src/silu_baseline_profiles.hpp"))
    args = parser.parse_args()

    profiles: list[dict] = []

    # Orion uses degree 127 and expands the observed interval by margin 2.
    # Store coefficients in the normalized t-domain used by the evaluator.
    for observed_radius, ident in [(8.0, "R8"), (20.0, "R20")]:
        fit_radius = 2.0 * observed_radius
        coeff = orion_code_fit(silu, 127, -fit_radius, fit_radius)
        profiles.append({
            "cpp_id": f"ORION_{ident}",
            "name": f"orion-r{int(observed_radius)}",
            "family": "Orion",
            "provenance": f"Orion source parameters; degree=127, observed [-{int(observed_radius)},{int(observed_radius)}], margin=2; normalized-domain coefficients",
            "domain_lo": -fit_radius, "domain_hi": fit_radius, "ps_split": 16,
            "coefficients_chebyshev_low_to_high": coeff.tolist(),
            **evaluate_profile(coeff, -fit_radius, fit_radius, silu),
        })

    # Uploaded ENSI parameters: EvalLogistic(-10,11,16), followed by x*sigmoid.
    coeff = cheb_interpolant(logistic, 16, -10.0, 11.0)
    component_metrics = evaluate_profile(coeff, -10.0, 11.0, logistic)
    ensi_t = np.linspace(-1.0, 1.0, 1000001)
    ensi_x = map_t_to_x(ensi_t, -10.0, 11.0)
    ensi_error = ensi_x * chebval(ensi_t, coeff) - silu(ensi_x)
    profiles.append({
        "cpp_id": "ENSI_D16",
        "name": "ensi-d16",
        "family": "ENSI",
        "provenance": "ENSI source bounds/degree and OpenFHE-style Chebyshev interpolation; final x multiplication evaluated separately",
        "domain_lo": -10.0, "domain_hi": 11.0, "ps_split": 4,
        "coefficients_chebyshev_low_to_high": coeff.tolist(),
        "component_sigmoid_max_abs_error": component_metrics["dense_max_abs_error"],
        "component_sigmoid_rmse": component_metrics["dense_rmse"],
        "dense_max_abs_error": float(np.max(np.abs(ensi_error))),
        "dense_mean_abs_error": float(np.mean(np.abs(ensi_error))),
        "dense_rmse": float(np.sqrt(np.mean(ensi_error * ensi_error))),
    })

    # Sylph discloses R=10.82 and degree 31, but not coefficients/fitting code.
    coeff = adaptive_minimax(silu, 31, -10.82, 10.82)
    profiles.append({
        "cpp_id": "SYLPH_D31",
        "name": "sylph-d31",
        "family": "Sylph",
        "provenance": "paper-disclosed SiLU radius=10.82 and degree=31; coefficients unavailable, reconstructed with uniform minimax",
        "domain_lo": -10.82, "domain_hi": 10.82, "ps_split": 8,
        "coefficients_chebyshev_low_to_high": coeff.tolist(),
        **evaluate_profile(coeff, -10.82, 10.82, silu),
    })

    composites: list[dict] = []
    for radius in (8.0, 20.0):
        alpha, stage1, stage2 = composite_coefficients(radius)
        composites.append({
            "cpp_id": f"THOR_R{int(radius)}",
            "name": f"thor-r{int(radius)}",
            "family": "THOR-style",
            "provenance": "paper-disclosed two-stage low-degree composite architecture; SiLU coefficients unavailable, reconstructed via stable asinh coordinate compression",
            "radius": radius, "stage1_split": 8, "stage2_split": 4,
            "warp_alpha": alpha,
            "stage1_coefficients_chebyshev_low_to_high": stage1.tolist(),
            "stage2_coefficients_chebyshev_low_to_high": stage2.tolist(),
            **evaluate_composite(radius, stage1, stage2),
        })

    catalog = {
        "format": 1,
        "notes": [
            "Profiles with unavailable public coefficients are labelled as reconstructions.",
            "Orion and ENSI parameters are derived from source code; Orion coefficients use the evaluator's normalized domain.",
            "Sylph and Cachemir/THOR coefficients are paper-only reconstructions with explicit provenance.",
        ],
        "chebyshev_profiles": profiles,
        "composite_profiles": composites,
    }
    args.out_json.parent.mkdir(parents=True, exist_ok=True)
    args.out_header.parent.mkdir(parents=True, exist_ok=True)
    args.out_json.write_text(json.dumps(catalog, indent=2), encoding="utf-8")
    emit_header(catalog, args.out_header)
    for item in profiles:
        print(item["name"], "degree", len(item["coefficients_chebyshev_low_to_high"]) - 1,
              "max", f"{item['dense_max_abs_error']:.6e}",
              "rmse", f"{item['dense_rmse']:.6e}")
    for item in composites:
        print(item["name"], "degrees", 31, 27, "alpha", f"{item['warp_alpha']:.9f}",
              "max", f"{item['dense_max_abs_error']:.6e}",
              "rmse", f"{item['dense_rmse']:.6e}")


if __name__ == "__main__":
    main()
