#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="${BUILD_DIR:-${ROOT}/build}"
BIN="${BUILD_DIR}/bin/silu_bench"
MODE="${1:-all}"
RESULT_DIR="${RESULT_DIR:-${ROOT}/results/silu}"
REPEATS="${REPEATS:-10}"
WARMUPS="${WARMUPS:-2}"
SLOTS="${SLOTS:-32768}"
LEVELS_R5="${LEVELS_R5:-${LEVELS:-16}}"
LEVELS_R20="${LEVELS_R20:-${LEVELS:-16}}"
PRECISION_BITS="${PRECISION_BITS:-46}"
ORDER_SEED="${ORDER_SEED:-20260831}"
CPUSET="${CPUSET:-}"

# SPA is fitted independently for the only two ciphertext benchmark ranges.
# The stable IDs align with the three plaintext model-wide variants:
#   spa-k39: R5 k3 / R20 k15
#   spa-k63: R5 k7 / R20 k23
#   spa-k87: R5 k11 / R20 k31
R5_METHODS="spa-k39,spa-k63,spa-k87,orion,ensi,sylph,thor"
R20_METHODS="spa-k39,spa-k63,spa-k87,orion-wide,thor-wide"
# Experiment B: balanced tier, coefficients rounded to 1..5 decimals, plus full.
ROUNDING_METHODS="${ROUNDING_METHODS:-spa-k63,spa-k63-d1,spa-k63-d2,spa-k63-d3,spa-k63-d4,spa-k63-d5}"
# Experiment C: unrounded balanced coefficients at several CKKS precisions.
PRECISION_POINTS="${PRECISION_POINTS:-46 42 38}"
PRECISION_METHODS="${PRECISION_METHODS:-spa-k63}"

cleanup_obsolete_r56_results() {
  rm -f     "${RESULT_DIR}/r56_summary.csv"     "${RESULT_DIR}/r56_samples.csv"     "${RESULT_DIR}/r56_pooled.csv"     "${RESULT_DIR}/r56.log"
}

build() {
  local args=(-S "${ROOT}" -B "${BUILD_DIR}" -DCMAKE_BUILD_TYPE=Release -DSPA_NATIVE_OPT=ON)
  if [[ -n "${SEAL_DIR:-}" ]]; then
    args+=("-DSEAL_DIR=${SEAL_DIR}")
  elif [[ -n "${CMAKE_PREFIX_PATH:-}" ]]; then
    args+=("-DCMAKE_PREFIX_PATH=${CMAKE_PREFIX_PATH}")
  fi
  cmake "${args[@]}"
  cmake --build "${BUILD_DIR}" --target silu_bench -j"${BUILD_JOBS:-$(nproc)}"
  ctest --test-dir "${BUILD_DIR}" --output-on-failure
}

contains_method() {
  local methods=",$1,"
  local method="$2"
  [[ "${methods}" == *",${method},"* ]]
}

run_matrix() {
  local name="$1" lo="$2" hi="$3" methods="$4" levels="$5" bits="${6:-${PRECISION_BITS}}"
  mkdir -p "${RESULT_DIR}"
  local summary="${RESULT_DIR}/${name}_summary.csv"
  local samples="${RESULT_DIR}/${name}_samples.csv"
  local pooled="${RESULT_DIR}/${name}_pooled.csv"
  rm -f "${summary}" "${samples}" "${pooled}"

  local cmd=(
    "${BIN}" --methods "${methods}" --range "${lo}" "${hi}" --input grid
    --slots "${SLOTS}" --warmup "${WARMUPS}" --repeat "${REPEATS}"
    --levels "${levels}" --scale-bits "${bits}"
    --prime-bits "${bits}" --order-seed "${ORDER_SEED}"
    --run-label "${name}" --csv-out "${summary}" --samples-csv "${samples}"
  )
  if [[ -n "${CPUSET}" ]]; then
    taskset -c "${CPUSET}" "${cmd[@]}" | tee "${RESULT_DIR}/${name}.log"
  else
    "${cmd[@]}" | tee "${RESULT_DIR}/${name}.log"
  fi

  local summarize=(
    python3 "${ROOT}/scripts/summarize.py"
    --samples "${samples}" --summary "${summary}" --out "${pooled}"
    --seed "${ORDER_SEED}"
  )
  if contains_method "${methods}" "spa-k87"; then
    summarize+=(--baseline spak87=spa-k87)
  fi
  if contains_method "${methods}" "spa-k63"; then
    summarize+=(--baseline spak63=spa-k63)
  fi
  if contains_method "${methods}" "orion"; then
    summarize+=(--baseline orion=orion)
  elif contains_method "${methods}" "orion-wide"; then
    summarize+=(--baseline orion=orion-wide)
  fi
  if contains_method "${methods}" "ensi"; then
    summarize+=(--baseline ensi=ensi)
  fi
  if contains_method "${methods}" "sylph"; then
    summarize+=(--baseline sylph=sylph)
  fi
  if contains_method "${methods}" "thor"; then
    summarize+=(--baseline thor=thor)
  elif contains_method "${methods}" "thor-wide"; then
    summarize+=(--baseline thor=thor-wide)
  fi
  "${summarize[@]}"
}

run_rounding() {
  run_matrix roundB_r5 -5 5 "${ROUNDING_METHODS}" "${LEVELS_R5}"
  run_matrix roundB_r20 -20 20 "${ROUNDING_METHODS}" "${LEVELS_R20}"
}

run_precision() {
  local bits
  for bits in ${PRECISION_POINTS}; do
    run_matrix "precC_p${bits}_r5" -5 5 "${PRECISION_METHODS}" "${LEVELS_R5}" "${bits}" ||
      echo "precC: ${bits}-bit run failed (configuration may be invalid for this chain); continuing" >&2
    run_matrix "precC_p${bits}_r20" -20 20 "${PRECISION_METHODS}" "${LEVELS_R20}" "${bits}" ||
      echo "precC: ${bits}-bit run failed (configuration may be invalid for this chain); continuing" >&2
  done
}

[[ -x "${BIN}" ]] || build
case "${MODE}" in
  build) build ;;
  r5) run_matrix r5 -5 5 "${METHODS:-${R5_METHODS}}" "${LEVELS_R5}" ;;
  r20) run_matrix r20 -20 20 "${METHODS:-${R20_METHODS}}" "${LEVELS_R20}" ;;
  roundB) run_rounding ;;
  precC) run_precision ;;
  all)
    cleanup_obsolete_r56_results
    run_matrix r5 -5 5 "${R5_METHODS}" "${LEVELS_R5}"
    run_matrix r20 -20 20 "${R20_METHODS}" "${LEVELS_R20}"
    ;;
  full)
    cleanup_obsolete_r56_results
    run_matrix r5 -5 5 "${R5_METHODS}" "${LEVELS_R5}"
    run_matrix r20 -20 20 "${R20_METHODS}" "${LEVELS_R20}"
    run_rounding
    run_precision
    ;;
  *) echo "usage: $0 [build|r5|r20|roundB|precC|all|full]" >&2; exit 2 ;;
esac
