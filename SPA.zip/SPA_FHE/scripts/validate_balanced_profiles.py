#!/usr/bin/env python3
"""Validate the balanced SPA profiles: evaluator consistency and error bound.

    python3 scripts/validate_balanced_profiles.py \\
        --host-check-binary build/bin/profile_ps_host_check \\
        --out validation/balanced_profile_validation

Two independent checks, reported in separate columns and never merged:

Check A - same-coefficient evaluator consistency.
    P_c(x) = x/2 + sum_j c_j T_j(t), t = 2x^2/R^2 - 1, is evaluated on one
    fixed grid (100,001 points including both endpoints and zero) by
    (i) Clenshaw in Python (numpy.polynomial.chebyshev.chebval), (ii) the C++
    host-side mirror of the ciphertext Paterson-Stockmeyer circuit
    (tests/profile_ps_host_check.cpp: decompose_chebyshev blocks, ChebDAG
    product rules, evaluate_baby_block accumulation order, evaluate_ps
    pairwise recombination with y, y^2, ...), and (iii) the C++ Clenshaw of
    profile_plain_eval. The grid is written once and echoed back by the C++
    program; the echo is compared bitwise so both evaluators are known to
    have seen the same inputs. Reported: clenshaw_ps_gap, clenshaw_py_cpp_gap,
    and separately the function error E_poly_grid = max |P_Clenshaw - A|.
    The FP32 and BF16 columns are the plaintext-harness precision diagnostics
    (Clenshaw in float32; float32 output rounded to bfloat16). None of this
    simulates CKKS encoding, rescaling or noise.

Check B - a verified upper bound on sup_{[-R,R]} |P_c(x) - A(x)| (Route 2).
    With e = P_c - A and midpoints m_0 < ... < m_{n-1} at which e is
    enclosed, sup |e| <= max_j |e(m_j)| + h_cover M, where h_cover =
    max(m_0 + R, R - m_{n-1}, max_j (m_{j+1} - m_j)/2) is computed from the
    midpoints actually evaluated (they are float64 and not exactly equally
    spaced; scripts/reference_helpers.CoverageRadius accumulates it with
    upward enclosure, including gaps across chunks) and M >= sup |e'|.
    |e(m_j)| is enclosed by interval arithmetic in numpy long double
    (np.finfo(np.longdouble).nmant is recorded; 63 on x86-64) with outward
    rounding after every operation (np.nextafter) and coefficients taken as
    exact doubles. exp is not taken from libm: it is evaluated as
    2^k exp(r) with r = x - k ln 2 (ln 2 enclosed between two decimal
    strings), an interval Taylor series to order 24 and the remainder
    |r|^25/25! e^{|r|} <= 2 |r|^25/25! added outward, so the enclosure rests
    only on IEEE-754 correctly rounded +,-,*,/ and sqrt. M = M_P + M_A with
    M_P = 1/2 + (4/R) sum_j |c'_j| (|T_j| <= 1; c' from the Chebyshev
    derivative recurrence, also in interval arithmetic) and M_A an analytic
    constant: SiLU' = s + x s(1-s) with |x s(1-s)| = |x|/(2+2cosh x)
    <= |x|/(4+x^2) <= 1/4, so M_A = 1.25; for tanh-GELU, A' = (1+tanh u)/2
    + x sech^2(u) u'/2 with u = a(x+bx^3), |u| >= a|x|, sech^2(u) <=
    4e^{-2a|x|}, and 2a s(1+3bs^2)e^{-2as} <= 0.39 < 0.5 for s >= 0, so
    M_A = 1.5. The nominal grid width is chosen so that the Lipschitz term
    is a fraction (--bound-tightness) of the sampled error, or 1% of the
    error budget if that is larger (--bound-budget-fraction).
    bound_status = verified_upper_bound means: a bound over the whole
    declared interval, conditional only on IEEE-754 correct rounding of the
    basic operations (the exp backend is recorded in exp_backend); the value
    is also stored in the neutral column upper_bound. Any non-finite
    interval aborts with a failure; nothing falls back to libm silently.
    meets_error_budget compares the bound with the tier target: proven,
    not_proven (the bound exceeds the target, which does not show the
    polynomial fails it), or not_evaluated.

Optionally, --compare-catalog <plaintext catalog> reports ||c_pt - c_ct||_1
for each configuration, which transfers the bound to the other side:
U_other <= U_this + ||c_other - c_this||_1 (Route 1).
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np
from numpy.polynomial.chebyshev import chebval

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from reference_helpers import CoverageRadius  # noqa: E402

LD = np.longdouble
LONGDOUBLE_NMANT = int(np.finfo(np.longdouble).nmant)
EXP_BACKEND = "interval_taylor_argument_reduction_longdouble"
DEFAULT_CONFIGS = [
    ("configs/spa_silu_profiles.json", "spa-r5-k7", "silu", 1e-3),
    ("configs/spa_silu_profiles.json", "spa-r20-k23", "silu", 1e-3),
    ("configs/spa_profiles.json", "spa-gelu-r5-k11", "erf-gelu", 1e-3),
    ("configs/spa_profiles.json", "spa-gelu-r20-k31", "erf-gelu", 1e-3),
    ("configs/spa_quickgelu_profiles.json", "spa-quickgelu-r5-k11", "quickgelu", 1e-3),
    ("configs/spa_quickgelu_profiles.json", "spa-quickgelu-r20-k39", "quickgelu", 1e-3),
]
FIELDS = [
    "target", "catalog", "profile", "radius", "degree_square", "ps_split", "coefficients_hash",
    "grid_points", "sampled_max_error", "sampled_argmax_x",
    "clenshaw_ps_gap", "clenshaw_py_cpp_gap", "grid_echo_bitwise_identical", "outputs_finite",
    "float32_evaluation_gap", "bf16_output_gap",
    "upper_bound", "verified_upper_bound", "bound_method", "bound_status", "exp_backend", "longdouble_nmant",
    "bound_midpoint_count", "bound_coverage_radius", "midpoint_max_enclosure", "bound_lipschitz",
    "error_budget", "meets_error_budget",
    "compare_catalog", "compare_profile", "coefficient_l1_distance", "transferred_upper_bound",
]


# --------------------------------------------------------------------------
# catalogs (ciphertext and plaintext formats)
# --------------------------------------------------------------------------


def load_profile(catalog_path: Path, name: str) -> dict:
    data = json.loads(catalog_path.read_text())
    if isinstance(data.get("profiles"), list):  # ciphertext generator format
        for p in data["profiles"]:
            if p["name"] == name:
                return {
                    "radius": float(p["R"]), "ps_split": int(p["ps_split"]), "degree_square": int(p["degree_square"]),
                    "coefficients": [float(c) for c in p["coefficients_chebyshev_low_to_high"]],
                    "catalog_max_error": float(p["dense_max_abs_error"]), "target_id": data.get("native_activation", {}).get("id"),
                }
        raise KeyError(f"{name} not in {catalog_path}")
    p = data["profiles"][name]  # plaintext harness format
    if p.get("kind") != "spa":
        raise ValueError(f"{name} is not a SPA profile")
    target = str(data.get("target", "")).lower()
    return {
        "radius": float(p["operating_radius"]), "ps_split": int(p["ps_split"]), "degree_square": int(p["degree_square"]),
        "coefficients": [float(c) for c in p["coefficients"]], "catalog_max_error": float(p["max_abs_error"]),
        "target_id": ("erf-gelu" if "erf" in target else "tanh-gelu") if "gelu" in target else ("silu" if "silu" in target else None),
    }


def coefficients_hash(coefficients: list[float]) -> str:
    return hashlib.sha256(",".join(f"{c:.17g}" for c in coefficients).encode()).hexdigest()[:16]


# --------------------------------------------------------------------------
# activations in double (for the grid checks)
# --------------------------------------------------------------------------


def activation_double(target: str):
    if target == "silu":
        return lambda x: x / (1.0 + np.exp(-x))
    if target == "quickgelu":
        return lambda x: x / (1.0 + np.exp(-1.702 * x))
    if target == "tanh-gelu":
        a = math.sqrt(2.0 / math.pi)
        return lambda x: 0.5 * x * (1.0 + np.tanh(a * (x + 0.044715 * x**3)))
    if target == "erf-gelu":
        from scipy.special import erf

        return lambda x: 0.5 * x * (1.0 + erf(x / math.sqrt(2.0)))
    raise ValueError(f"unknown target {target}")


def spa_double(x: np.ndarray, radius: float, coefficients: list[float]) -> np.ndarray:
    t = 2.0 * x * x / (radius * radius) - 1.0
    return 0.5 * x + chebval(t, np.asarray(coefficients, dtype=np.float64))


def spa_float32(x64: np.ndarray, radius: float, coefficients: list[float]) -> np.ndarray:
    """Clenshaw entirely in float32 (the plaintext harness's activation dtype)."""
    x = x64.astype(np.float32)
    r = np.float32(radius)
    t = np.float32(2.0) * x * x / (r * r) - np.float32(1.0)
    c = [np.float32(v) for v in coefficients]
    b1 = np.zeros_like(t)
    b2 = np.zeros_like(t)
    for k in range(len(c) - 1, 0, -1):
        b0 = np.float32(2.0) * t * b1 - b2 + c[k]
        b2, b1 = b1, b0
    return np.float32(0.5) * x + (t * b1 - b2 + c[0])


def to_bfloat16(values32: np.ndarray) -> np.ndarray:
    """Round float32 to bfloat16 (round to nearest even), returned as float32."""
    u = values32.astype(np.float32).view(np.uint32)
    rounding_bias = np.uint32(0x7FFF) + ((u >> np.uint32(16)) & np.uint32(1))
    u16 = ((u + rounding_bias) >> np.uint32(16)) << np.uint32(16)
    return u16.astype(np.uint32).view(np.float32)


# --------------------------------------------------------------------------
# rigorous long-double interval arithmetic (outward rounding via nextafter)
# --------------------------------------------------------------------------

NEG_INF = LD(-np.inf)
POS_INF = LD(np.inf)
EXP_TAYLOR_ORDER = 24


class IV:
    """Closed intervals [lo, hi] of long doubles, every operation widened
    outward by one ulp after IEEE correct rounding; exp widened by a
    relative margin as well."""

    __slots__ = ("lo", "hi")

    def __init__(self, lo, hi=None):
        self.lo = np.asarray(lo, dtype=LD)
        self.hi = self.lo if hi is None else np.asarray(hi, dtype=LD)

    @staticmethod
    def point(values):
        v = np.asarray(values, dtype=LD)
        return IV(v, v.copy())

    @staticmethod
    def decimal(text: str):
        v = LD(text)
        return IV(np.nextafter(v, NEG_INF), np.nextafter(v, POS_INF))

    def _out(self, lo, hi):
        return IV(np.nextafter(lo, NEG_INF), np.nextafter(hi, POS_INF))

    def __add__(self, o):
        return self._out(self.lo + o.lo, self.hi + o.hi)

    def __sub__(self, o):
        return self._out(self.lo - o.hi, self.hi - o.lo)

    def __neg__(self):
        return IV(-self.hi, -self.lo)

    def __mul__(self, o):
        p1, p2, p3, p4 = self.lo * o.lo, self.lo * o.hi, self.hi * o.lo, self.hi * o.hi
        return self._out(np.minimum(np.minimum(p1, p2), np.minimum(p3, p4)), np.maximum(np.maximum(p1, p2), np.maximum(p3, p4)))

    def reciprocal(self):
        if not bool(np.all(self.lo > 0)):
            raise ValueError("reciprocal of an interval not strictly positive")
        return self._out(LD(1.0) / self.hi, LD(1.0) / self.lo)

    def __truediv__(self, o):
        return self * o.reciprocal()

    def exp(self):
        """Rigorous enclosure of exp without libm: exp(x) = 2^k exp(r),
        r = x - k ln 2, |r| <= ~0.35, exp(r) by an interval Taylor series
        with the remainder |r|^{N+1}/(N+1)! e^{|r|} <= 2 |r|^{N+1}/(N+1)!
        (valid for |r| < ln 2) added outward; 2^k is exact (ldexp)."""
        if not (bool(np.isfinite(self.lo).all()) and bool(np.isfinite(self.hi).all())):
            raise FloatingPointError("non-finite input to exp")
        # ln 2 = 0.69314718055994530941723... enclosed by two decimals.
        ln2 = IV(LD("0.6931471805599453094"), LD("0.6931471805599453095"))
        k = np.rint(np.asarray(self.lo / ln2.lo, dtype=np.float64))  # any integer works
        k_iv = IV.point(k.astype(LD))
        r = self - k_iv * ln2
        r_abs = r.abs_upper()
        if bool(np.any(r_abs >= LD("0.69"))):
            raise FloatingPointError("exp argument reduction left |r| too large")
        # Horner form of the Taylor polynomial in interval arithmetic.
        one = IV.point(np.ones_like(self.lo))
        series = one
        for i in range(EXP_TAYLOR_ORDER, 0, -1):
            inv_i = IV.point(LD(1.0)) / IV.point(LD(i))
            series = one + r * inv_i * series
        # remainder: 2 |r|^{N+1} / (N+1)!  (upward)
        n1 = EXP_TAYLOR_ORDER + 1
        power = IV.point(np.ones_like(self.lo))
        r_abs_iv = IV(r_abs, r_abs)
        for _ in range(n1):
            power = power * r_abs_iv
        factorial = LD(1.0)
        for i in range(2, n1 + 1):
            factorial = np.nextafter(factorial * LD(i), NEG_INF)  # rounded down: divides
        remainder = np.nextafter(np.nextafter(LD(2.0) * power.hi, POS_INF) / factorial, POS_INF)
        lo = np.nextafter(series.lo - remainder, NEG_INF)
        hi = np.nextafter(series.hi + remainder, POS_INF)
        k_int = k.astype(np.int64)
        lo = np.ldexp(lo, k_int)
        hi = np.ldexp(hi, k_int)
        if not (bool(np.isfinite(lo).all()) and bool(np.isfinite(hi).all())):
            raise FloatingPointError("exp enclosure overflowed")
        return IV(lo, hi)

    def sqrt(self):
        return self._out(np.sqrt(self.lo), np.sqrt(self.hi))

    def abs_upper(self):
        return np.maximum(np.abs(self.lo), np.abs(self.hi))


def iv_clenshaw(t: IV, coefficients: list[float]) -> IV:
    b1 = IV.point(np.zeros_like(t.lo))
    b2 = IV.point(np.zeros_like(t.lo))
    two = IV.point(LD(2.0))
    for k in range(len(coefficients) - 1, 0, -1):
        c = IV.point(np.full_like(t.lo, LD(coefficients[k])))
        b0 = (two * t) * b1 - b2 + c
        b2, b1 = b1, b0
    return t * b1 - b2 + IV.point(np.full_like(t.lo, LD(coefficients[0])))


def iv_spa(x: IV, radius: float, coefficients: list[float]) -> IV:
    r2 = IV.point(LD(radius)) * IV.point(LD(radius))
    t = (IV.point(LD(2.0)) * x * x) / r2 - IV.point(LD(1.0))
    return IV.point(LD(0.5)) * x + iv_clenshaw(t, coefficients)


def iv_activation(x: IV, target: str) -> IV:
    one = IV.point(LD(1.0))
    if target == "silu":
        return x / (one + (-x).exp())
    if target == "quickgelu":
        beta = IV.decimal("1.702")
        return x / (one + (-(beta * x)).exp())
    if target == "tanh-gelu":
        pi = IV(LD("3.14159265358979323"), LD("3.14159265358979324"))
        a = (IV.point(LD(2.0)) / pi).sqrt()
        b = IV.decimal("0.044715")
        u = a * (x + b * x * x * x)
        # tanh(u) = 1 - 2 / (exp(2u) + 1)
        tanh_u = one - IV.point(LD(2.0)) / ((IV.point(LD(2.0)) * u).exp() + one)
        return IV.point(LD(0.5)) * x * (one + tanh_u)
    raise ValueError(f"no rigorous enclosure implemented for {target}")


def iv_chebder_l1(coefficients: list[float]) -> LD:
    """Upper bound on sum_j |c'_j| for the Chebyshev derivative series
    (numpy.polynomial.chebyshev.chebder recurrence, in interval arithmetic)."""
    n = len(coefficients) - 1
    c = [IV.point(LD(v)) for v in coefficients]
    if n < 1:
        return LD(0.0)
    der = [IV.point(LD(0.0)) for _ in range(n)]
    for j in range(n, 2, -1):
        der[j - 1] = IV.point(LD(2 * j)) * c[j]
        c[j - 2] = c[j - 2] + (IV.point(LD(j)) * c[j]) / IV.point(LD(j - 2))
    if n > 1:
        der[1] = IV.point(LD(4.0)) * c[2]
    der[0] = c[1]
    total = LD(0.0)
    for d in der:
        total = np.nextafter(total + d.abs_upper(), POS_INF)
    return total


# QuickGELU: A' = s + beta x s(1-s) with u = beta x, |u s(1-s)| = |u|/(2+2cosh u)
# <= |u|/(4+u^2) <= 1/4, the SiLU argument with u in place of x, so 1.25.
LIPSCHITZ_ACTIVATION = {"silu": LD(1.25), "tanh-gelu": LD(1.5), "quickgelu": LD(1.25)}


def verified_bound(radius: float, coefficients: list[float], target: str, sampled_error: float,
                   tightness: float, chunk: int, max_points: int, slack_floor: float = 0.0) -> dict:
    # M = M_P + M_A, every step an interval operation.
    m_p_iv = IV.point(LD("0.5")) + (IV.point(LD(4.0)) / IV.point(LD(radius))) * IV.point(iv_chebder_l1(coefficients))
    lipschitz = LD((m_p_iv + IV.point(LIPSCHITZ_ACTIVATION[target])).hi)
    # Nominal width: the Lipschitz term is tightness * E_grid, or slack_floor
    # if larger (1% of the budget by default). The actual coverage radius is
    # measured from the evaluated midpoints, not assumed from this width.
    slack = max(LD(tightness) * LD(sampled_error), LD(slack_floor))
    width = LD(2.0) * slack / lipschitz
    count = int(math.ceil(float(LD(2.0) * LD(radius) / width)))
    if count > max_points:
        return {"status": "inconclusive", "reason": f"needs {count} subintervals, cap {max_points}",
                "midpoint_count": count, "lipschitz": float(lipschitz)}
    cover = CoverageRadius(radius)
    worst = LD(0.0)
    for start in range(0, count, chunk):
        j = np.arange(start, min(count, start + chunk), dtype=np.float64)
        mid = (-radius + (2.0 * j + 1.0) * (radius / count)).astype(np.float64)
        cover.add(mid)  # exactly the midpoints evaluated below
        x = IV.point(mid)
        e = iv_spa(x, radius, coefficients) - iv_activation(x, target)
        if not (bool(np.isfinite(e.lo).all()) and bool(np.isfinite(e.hi).all())):
            raise FloatingPointError("non-finite interval in the error enclosure")
        worst = max(worst, LD(np.max(e.abs_upper())))
    h_cover = cover.finish()
    bound = np.nextafter(worst + np.nextafter(h_cover * lipschitz, POS_INF), POS_INF)
    return {
        "status": "verified_upper_bound",
        "bound": float(np.nextafter(np.float64(bound), np.inf)),  # long double -> float64, rounded up
        "midpoint_count": cover.count,
        "coverage_radius": float(np.nextafter(np.float64(h_cover), np.inf)),
        "midpoint_max": float(np.nextafter(np.float64(worst), np.inf)),
        "lipschitz": float(np.nextafter(np.float64(lipschitz), np.inf)),
    }


# --------------------------------------------------------------------------
# Check A driver
# --------------------------------------------------------------------------


def run_host_check(binary: Path, radius: float, split: int, scale_bits: int, coefficients: list[float], grid: np.ndarray):
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "input.txt"
        lines = [f"{radius:.17g} {split} {scale_bits}", f"{len(coefficients)} " + " ".join(f"{c:.17g}" for c in coefficients), str(grid.size)]
        lines += [f"{v:.17g}" for v in grid]
        path.write_text("\n".join(lines) + "\n")
        result = subprocess.run([str(binary), str(path)], capture_output=True, text=True, check=True)
    echo = np.empty(grid.size)
    ps = np.empty(grid.size)
    cl = np.empty(grid.size)
    for i, line in enumerate(result.stdout.strip().split("\n")):
        a, b, c = line.split()
        echo[i], ps[i], cl[i] = float(a), float(b), float(c)
    return echo, ps, cl


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument("--config", action="append", nargs=4, metavar=("CATALOG", "PROFILE", "TARGET", "BUDGET"),
                        help="Override the default four configurations; may be repeated.")
    parser.add_argument("--host-check-binary", type=Path, default=ROOT / "build/bin/profile_ps_host_check")
    parser.add_argument("--grid-points", type=int, default=100001)
    parser.add_argument("--scale-bits", type=int, default=46, help="Encoding scale used to mirror sub-resolution skips.")
    parser.add_argument("--skip-bound", action="store_true", help="Check A only (fast).")
    parser.add_argument("--bound-tightness", type=float, default=0.1,
                        help="Lipschitz slack (w/2)M as a fraction of the sampled error.")
    parser.add_argument("--bound-budget-fraction", type=float, default=0.01,
                        help="Floor for the slack as a fraction of the error budget (0 disables).")
    parser.add_argument("--bound-chunk", type=int, default=1_000_000)
    parser.add_argument("--bound-max-points", type=int, default=200_000_000)
    parser.add_argument("--compare-catalog", action="append", nargs=2, metavar=("CATALOG", "PROFILE"),
                        help="Other-side catalog/profile for each config, in order; reports ||c_other - c||_1.")
    parser.add_argument("--out", type=Path, default=ROOT / "validation/balanced_profile_validation")
    args = parser.parse_args()

    configs = [(Path(c), p, t, float(b)) for c, p, t, b in (args.config or [])] or [
        (ROOT / c, p, t, b) for c, p, t, b in DEFAULT_CONFIGS
    ]
    compares = args.compare_catalog or []
    rows: list[dict] = []
    for index, (catalog, name, target, budget) in enumerate(configs):
        profile = load_profile(catalog, name)
        if profile["target_id"] and profile["target_id"] != target:
            raise ValueError(f"{name}: catalog target {profile['target_id']} != {target}")
        R, split, coeffs = profile["radius"], profile["ps_split"], profile["coefficients"]
        grid = np.linspace(-R, R, args.grid_points)
        assert grid[0] == -R and grid[-1] == R and 0.0 in grid
        exact = activation_double(target)(grid)
        p_py = spa_double(grid, R, coeffs)
        err = np.abs(p_py - exact)
        row = {
            "target": target, "catalog": str(catalog.relative_to(ROOT) if catalog.is_relative_to(ROOT) else catalog),
            "profile": name, "radius": R, "degree_square": profile["degree_square"], "ps_split": split,
            "coefficients_hash": coefficients_hash(coeffs), "grid_points": grid.size,
            "sampled_max_error": float(err.max()), "sampled_argmax_x": float(grid[int(err.argmax())]),
            "error_budget": budget,
        }
        # Check A
        if args.host_check_binary.exists():
            echo, ps, cl = run_host_check(args.host_check_binary, R, split, args.scale_bits, coeffs, grid)
            row["grid_echo_bitwise_identical"] = bool(np.array_equal(echo, grid))
            row["outputs_finite"] = bool(np.isfinite(ps).all() and np.isfinite(cl).all() and np.isfinite(p_py).all())
            row["clenshaw_ps_gap"] = float(np.max(np.abs(p_py - ps)))
            row["clenshaw_py_cpp_gap"] = float(np.max(np.abs(p_py - cl)))
        else:
            row.update(grid_echo_bitwise_identical="", outputs_finite=bool(np.isfinite(p_py).all()),
                       clenshaw_ps_gap="not run (build profile_ps_host_check)", clenshaw_py_cpp_gap="not run")
        p32 = spa_float32(grid, R, coeffs)
        row["float32_evaluation_gap"] = float(np.max(np.abs(p32.astype(np.float64) - p_py)))
        row["bf16_output_gap"] = float(np.max(np.abs(to_bfloat16(p32).astype(np.float64) - p_py)))
        # Check B
        row["exp_backend"] = EXP_BACKEND
        row["longdouble_nmant"] = LONGDOUBLE_NMANT
        if args.skip_bound or target not in LIPSCHITZ_ACTIVATION:
            # No rigorous enclosure is implemented for this target (erf-GELU:
            # erf has no interval implementation here), so only the grid
            # check is available and the status says so.
            row.update(upper_bound="", verified_upper_bound="", bound_status="sampled_only",
                       bound_method="" if args.skip_bound else "no rigorous enclosure implemented for this target; grid check only",
                       bound_midpoint_count="", bound_coverage_radius="", midpoint_max_enclosure="",
                       bound_lipschitz="", meets_error_budget="not_evaluated")
        else:
            result = verified_bound(R, coeffs, target, row["sampled_max_error"], args.bound_tightness, args.bound_chunk,
                                    args.bound_max_points, slack_floor=args.bound_budget_fraction * budget)
            status = result["status"]
            has_bound = status in {"conditional_upper_bound", "verified_upper_bound"}
            row["bound_status"] = status
            row["bound_method"] = (
                "route 2: U = max_j |e(m_j)| (long double interval enclosure, outward rounding, "
                "exp by interval Taylor with argument reduction) + h_cover * (M_P + M_A), "
                "h_cover from the evaluated midpoints, M_P = 1/2 + 4/R sum|c'_j| (interval), M_A analytic"
            ) + ("" if has_bound else f"; {result.get('reason', '')}")
            row["bound_midpoint_count"] = result.get("midpoint_count", "")
            row["bound_coverage_radius"] = result.get("coverage_radius", "")
            row["midpoint_max_enclosure"] = result.get("midpoint_max", "")
            row["bound_lipschitz"] = result.get("lipschitz", "")
            row["upper_bound"] = result["bound"] if has_bound else ""
            row["verified_upper_bound"] = result["bound"] if status == "verified_upper_bound" else ""
            if not has_bound:
                row["meets_error_budget"] = "not_evaluated"
            elif result["bound"] > budget:
                row["meets_error_budget"] = "not_proven"
            elif status == "verified_upper_bound":
                row["meets_error_budget"] = "proven"
            else:
                row["meets_error_budget"] = "under_stated_assumptions"
        # cross-catalog transfer
        if index < len(compares):
            other_catalog, other_name = compares[index]
            other = load_profile(Path(other_catalog), other_name)
            l1 = float(np.abs(np.asarray(other["coefficients"]) - np.asarray(coeffs)).sum()) if len(other["coefficients"]) == len(coeffs) else float("nan")
            row.update(compare_catalog=other_catalog, compare_profile=other_name, coefficient_l1_distance=l1,
                       transferred_upper_bound=(row["upper_bound"] + l1) if isinstance(row.get("upper_bound"), float) else "")
        rows.append(row)
        print(f"{name}: E_grid={row['sampled_max_error']:.3e} ps_gap={row['clenshaw_ps_gap']} "
              f"upper_bound={row.get('upper_bound', '')} h_cover={row.get('bound_coverage_radius', '')} "
              f"status={row['bound_status']} budget={row['meets_error_budget']}")

    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.with_suffix(".csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows({f: row.get(f, "") for f in FIELDS} for row in rows)
    args.out.with_suffix(".json").write_text(json.dumps(rows, indent=2, default=str) + "\n")
    print(f"saved: {args.out.with_suffix('.csv')}")
    failures = [r["profile"] for r in rows if r.get("grid_echo_bitwise_identical") is False or r.get("outputs_finite") is False]
    if failures:
        print("FAILED:", failures)
        sys.exit(1)


if __name__ == "__main__":
    main()
