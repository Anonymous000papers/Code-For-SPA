#!/usr/bin/env bash
# Every activation: erf-GELU (SPA x3, NEXUS, MOAI), QuickGELU (SPA x3, Euston) and SiLU. MODE=all runs the main
# matrices; MODE=full also runs Experiment B (coefficient rounding) and
# Experiment C (CKKS precision points) for each.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MODE="${MODE:-all}"
export REPEATS="${REPEATS:-10}" WARMUPS="${WARMUPS:-2}"
TARGET=erf bash "${ROOT}/scripts/run_gelu.sh" "${MODE}"
TARGET=quickgelu bash "${ROOT}/scripts/run_gelu.sh" "${MODE}"
bash "${ROOT}/scripts/run_silu.sh" "${MODE}"
if [[ "${MODE}" == full ]]; then
  python3 "${ROOT}/scripts/plot_tradeoff.py" \
    --summary "${ROOT}/results/gelu_erf/r5_summary.csv" "${ROOT}/results/gelu_erf/r20_summary.csv" \
    --summary "${ROOT}/results/gelu_quickgelu/r5_summary.csv" "${ROOT}/results/gelu_quickgelu/r20_summary.csv" \
    --summary "${ROOT}/results/silu/r5_summary.csv" "${ROOT}/results/silu/r20_summary.csv" \
    --out "${ROOT}/results/tradeoff"
fi
