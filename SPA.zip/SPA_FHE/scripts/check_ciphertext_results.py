#!/usr/bin/env python3
"""Read actual SEAL output CSVs; never generates/replaces measurements."""
import argparse,csv,json,math
from pathlib import Path

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--summary',type=Path,required=True)
    p.add_argument('--require-methods',default='moai,euston')
    p.add_argument('--allow-diagnostic',action='store_true',help='Accept explicit --no-sec data; never labels it secure')
    p.add_argument('--max-ckks-extra',type=float,default=None,
                   help='Optional user-selected max absolute CKKS residual sanity threshold')
    a=p.parse_args();rows=list(csv.DictReader(a.summary.open(newline='')))
    required=set(a.require_methods.split(','));found={r['method'] for r in rows}
    if not required<=found:raise ValueError(f'missing methods: {required-found}')
    report=[]
    for r in rows:
        if r['method'] not in required:continue
        if r.get('implementation_revision')!='spa-1':raise ValueError('unexpected summary schema tag')
        if any(int(r[k]) for k in ('encrypt','decrypt','decode','dynamic_plain_encode','bootstraps')):
            raise ValueError('evaluation invoked a forbidden client operation')
        if int(r['context_count'])!=1:raise ValueError('not a single-context evaluator')
        secure=r['security_validation']=='tc128-linked-SEAL'
        if not secure and not a.allow_diagnostic:raise ValueError('diagnostic-only security configuration')
        for k in ('total_max_abs','total_rmse','method_bias_max','ckks_extra_max','median_ms',
                  'e_target','e_poly','e_coeff','e_he','e_total','decomposition_bound'):
            if not math.isfinite(float(r[k])):raise ValueError(f'nonfinite field {k}')
        if r['decomposition_bound_holds']!='1':raise ValueError('E_total exceeds E_target+E_poly+E_coeff+E_HE')
        if abs(float(r['e_total'])-float(r['total_max_abs']))>1e-12*max(1.0,float(r['total_max_abs'])):
            raise ValueError('e_total is not total_max_abs')
        if abs(float(r['e_he'])-float(r['ckks_extra_max']))>1e-12*max(1.0,float(r['ckks_extra_max'])):
            raise ValueError('e_he is not ckks_extra_max')
        if int(r['output_chain'])<int(r['reserve_levels']):raise ValueError('reserve exhausted')
        if r['method']=='euston':
            if r['reference_gap_is_ckks_only']!='1':raise ValueError('wrong error decomposition')
            if int(r['consumed_levels'])!=int(r['expected_consumed_levels']):raise ValueError('depth mismatch')
        if a.max_ckks_extra is not None and float(r['ckks_extra_max'])>a.max_ckks_extra:
            raise ValueError(f'{r["method"]}: CKKS residual exceeds configured threshold')
        report.append({k:r[k] for k in ('method','range_lo','range_hi','context_count','consumed_levels',
            'evaluation_scale_bits','main_modulus_bits','security_validation','total_max_abs','method_bias_max','ckks_extra_max',
            'native_target_id','fit_target_id','e_target','e_poly','e_coeff','e_he','e_total')})
    print(json.dumps({'status':'PASS_RECORDED_FIELDS','continuous_error_certified':False,
                      'independent_security_estimate_performed':False,'rows':report},indent=2))
if __name__=='__main__':main()
