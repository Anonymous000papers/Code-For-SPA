#!/usr/bin/env python3
"""Error-latency trade-off figure from benchmark summary CSVs.

    python3 scripts/plot_tradeoff.py \\
        --summary results/gelu_erf/r5_summary.csv results/gelu_erf/r20_summary.csv \\
        --summary results/gelu_quickgelu/r5_summary.csv results/gelu_quickgelu/r20_summary.csv \\
        --summary results/silu/r5_summary.csv results/silu/r20_summary.csv \\
        --out results/tradeoff

x: median latency of the activation module (ms, log scale);
y: E_total, the maximum absolute error of the decrypted output against the
   common native target of that run (log scale).
One panel per (native target, interval). Every point carries the method id,
tier (SPA) and the parameter differences that matter for a fair read:
Euston's own 35-bit chain, NEXUS sign depth and its range-conditioning status,
MOAI's source/refit polynomial, and for Experiment B points the rounding
decimals. Methods are not forced to a common error; the configurations that
were actually run are shown as distinct trade-off points.

Always writes ``<out>_points.csv`` (the plotted values plus annotations). The
figure (``<out>.png`` and ``<out>.pdf``) needs matplotlib; without it the CSV
is still produced and a note is printed.
"""

from __future__ import annotations

import argparse
import csv
import math
from collections import defaultdict
from pathlib import Path

POINT_FIELDS = [
    "native_target_id", "range_lo", "range_hi", "method", "family", "spa_tier",
    "active_profile", "spa_rounding_decimals", "median_ms", "e_total", "e_target",
    "e_poly", "e_coeff", "e_he", "evaluation_scale_bits", "evaluation_prime_bits",
    "consumed_levels", "annotation", "source_file", "run_label",
]


def annotate(row: dict) -> str:
    """Short label with the parameter differences a reader must know."""
    method = row["method"]
    parts = [method]
    tier = row.get("spa_tier", "")
    if tier:
        parts.append(tier)
    decimals = row.get("spa_rounding_decimals", "")
    if decimals not in ("", "-1"):
        parts.append(f"d={decimals}")
    family = row.get("family", "")
    if family == "Euston":
        parts.append(f"own {row.get('evaluation_scale_bits', '?')}-bit chain")
        parts.append(f"dg={row.get('euston_g_rounds', '?')},df={row.get('euston_f_rounds', '?')},tau={row.get('euston_tau', '?')}")
    elif family == "NEXUS":
        policy = row.get("parameter_policy", "")
        for token in policy.split(","):
            token = token.strip()
            if token.startswith("dg=") or token.startswith("df=") or token.startswith("conditioning="):
                parts.append(token)
    elif family == "MOAI":
        parts.append(row.get("active_profile", ""))
    fit = row.get("fit_target_id", "")
    native = row.get("native_target_id", "")
    if fit and native and fit != native:
        parts.append(f"fit={fit}")
    return "; ".join(p for p in parts if p)


def load_rows(paths: list[Path]) -> list[dict]:
    rows: list[dict] = []
    for path in paths:
        with path.open(newline="") as handle:
            for row in csv.DictReader(handle):
                if "e_total" not in row:
                    raise ValueError(f"{path}: not a benchmark summary (no e_total column)")
                row["source_file"] = str(path)
                rows.append(row)
    return rows


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument("--summary", type=Path, nargs="+", action="append", required=True,
                        help="Summary CSVs; may be repeated.")
    parser.add_argument("--out", type=Path, required=True, help="Output prefix.")
    parser.add_argument("--title", default="Activation error-latency trade-off under CKKS")
    parser.add_argument("--no-figure", action="store_true", help="Write the points CSV only.")
    parser.add_argument("--formats", default="png", help="Comma-separated figure formats, e.g. png,pdf (default png).")
    args = parser.parse_args()

    paths = [p for group in args.summary for p in group]
    rows = load_rows(paths)
    if not rows:
        raise SystemExit("no rows")

    points: list[dict] = []
    for row in rows:
        try:
            median = float(row["median_ms"])
            e_total = float(row["e_total"])
        except (KeyError, ValueError):
            continue
        if not (math.isfinite(median) and math.isfinite(e_total)):
            continue
        point = {field: row.get(field, "") for field in POINT_FIELDS}
        point["median_ms"] = median
        point["e_total"] = e_total
        point["annotation"] = annotate(row)
        points.append(point)

    args.out.parent.mkdir(parents=True, exist_ok=True)
    points_path = args.out.with_name(args.out.name + "_points.csv")
    with points_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=POINT_FIELDS)
        writer.writeheader()
        writer.writerows(points)
    print(f"points: {points_path} ({len(points)} rows)")

    if args.no_figure:
        return
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        from matplotlib.lines import Line2D
        from matplotlib.ticker import NullLocator
    except ImportError:
        print("matplotlib is not installed; the figure was not drawn (points CSV is complete)")
        return

    # Log axes are drawn by hand (log10 values on linear axes) with explicit
    # tick positions and plain-text labels, so the figure does not depend on
    # matplotlib's log transform, locator, formatter or minor-tick machinery.
    def log10_ticks(axis_obj, which: str, values: list[float]) -> None:
        low = math.floor(min(values))
        high = math.ceil(max(values))
        ticks = list(range(low, high + 1))
        labels = [f"1e{k}" for k in ticks]
        target_axis = axis_obj.xaxis if which == "x" else axis_obj.yaxis
        target_axis.set_minor_locator(NullLocator())
        if which == "x":
            axis_obj.set_xticks(ticks, labels)
            axis_obj.set_xlim(low - 0.1, high + 0.1)
        else:
            axis_obj.set_yticks(ticks, labels)
            axis_obj.set_ylim(low - 0.1, high + 0.1)

    target_order = {"erf-gelu": 0, "quickgelu": 1, "silu": 2}
    panels: dict[tuple[str, str, str], list[dict]] = defaultdict(list)
    for point in points:
        panels[(point["native_target_id"], point["range_lo"], point["range_hi"])].append(point)
    keys = sorted(panels, key=lambda k: (target_order.get(k[0], 9), -float(k[1])))
    columns = 2 if len(keys) > 1 else 1
    rows_n = math.ceil(len(keys) / columns)
    figure, axes = plt.subplots(rows_n, columns, figsize=(7.2 * columns, 4.8 * rows_n), squeeze=False)
    markers = {"SPA-GELU": "o", "SPA-SiLU": "o", "MOAI": "s", "NEXUS": "^", "Euston": "D",
               "Orion": "v", "ENSI": "<", "Sylph": ">", "THOR-style": "P"}
    colors = {"SPA-GELU": "C0", "SPA-SiLU": "C0", "MOAI": "C3", "NEXUS": "C4", "Euston": "C5",
              "Orion": "C6", "ENSI": "C7", "Sylph": "C8", "THOR-style": "C9"}
    for axis, key in zip(axes.flat, keys):
        native, lo, hi = key
        legend: dict[str, Line2D] = {}
        xs = [math.log10(p["median_ms"]) for p in panels[key]]
        ys = [math.log10(max(p["e_total"], 1e-12)) for p in panels[key]]
        for point in sorted(panels[key], key=lambda p: p["median_ms"]):
            family = point["family"]
            rounded = point["spa_rounding_decimals"] not in ("", "-1")
            label = "SPA (Experiment B)" if rounded else family
            marker = "x" if rounded else markers.get(family, "o" if family.startswith("SPA") else "v")
            color = "C1" if rounded else colors.get(family, "C2")
            lx = math.log10(point["median_ms"])
            ly = math.log10(max(point["e_total"], 1e-12))
            axis.plot([lx], [ly], linestyle="none", marker=marker, markersize=7, color=color)
            axis.annotate(point["annotation"], (lx, ly), fontsize=6, xytext=(4, 3), textcoords="offset points")
            legend.setdefault(label, Line2D([], [], linestyle="none", marker=marker, color=color))
        log10_ticks(axis, "x", xs)
        log10_ticks(axis, "y", ys)
        axis.set_xlabel("median latency of the activation module (ms)")
        axis.set_ylabel(f"E_total = max |Y_HE - A_native| ({native})")
        axis.set_title(f"native target {native}, interval [{lo}, {hi}]")
        axis.grid(True, alpha=0.3)
        axis.legend(legend.values(), legend.keys(), fontsize=7, loc="best")
        print(f"panel: {native} [{lo}, {hi}] ({len(panels[key])} points)")
    for axis in list(axes.flat)[len(keys):]:
        axis.set_visible(False)
    figure.suptitle(args.title)
    figure.tight_layout()
    for fmt in args.formats.split(","):
        fmt = fmt.strip().lstrip(".")
        if not fmt:
            continue
        figure.savefig(args.out.with_suffix("." + fmt), dpi=200)
        print(f"figure: {args.out.with_suffix('.' + fmt)}", flush=True)


if __name__ == "__main__":
    main()
