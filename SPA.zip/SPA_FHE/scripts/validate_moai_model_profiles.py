#!/usr/bin/env python3
"""Host-side consistency check for the imported MOAI model profiles.

    python3 scripts/validate_moai_model_profiles.py \\
        --host-check-binary build/bin/moai_host_check \\
        --plaintext-dir ../SPA_GELU \\
        --out validation/moai_model_profile_check

For each imported profile (r5 on [-5, 5], r20 on [-20, 20]) one grid of
100,001 points including both endpoints and zero is written once and
echoed back bitwise by the C++ host program, so every evaluator sees the
same inputs. Three host-side (double) evaluations are compared:

* P_model-host: the plaintext harness's own evaluator,
  ``activation_approximations.evaluate_moai`` imported from --plaintext-dir,
  applied to the profile as stored in the imported JSON (a local
  re-implementation is used, and flagged, if the plaintext tree is absent);
* P_cipher-host: ``moai_model::circuit_host`` — the ciphertext circuit's
  operation order (stage products, y/B, product-tree Chebyshev basis,
  (x/2)(1+P));
* P_clenshaw-host: ``moai_model::plain_host`` — the benchmark's host
  reference for E_HE.

Reported per profile: ``model_cipher_gap`` = max |P_model-host -
P_cipher-host|, ``model_clenshaw_gap``, ``sampled_max_error`` = max
|P_model-host - A_fit| (the function-approximation error, kept separate
from the evaluator gaps), the catalog's stored error for comparison, and
the grid echo check. Double arithmetic throughout; FP32/BF16 rounding of the
model's execution path is a separate question (see the plaintext harness),
and CKKS output is not expected to match bit for bit.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np
from numpy.polynomial.chebyshev import chebval

ROOT = Path(__file__).resolve().parents[1]
FIELDS = [
    "profile", "radius", "base_radius", "extension_stages", "degree", "target", "source_catalog_sha256",
    "grid_points", "grid_echo_bitwise_identical", "model_evaluator",
    "model_cipher_gap", "model_clenshaw_gap", "cipher_clenshaw_gap",
    "sampled_max_error", "sampled_argmax_x", "catalog_max_abs_error", "outputs_finite", "status",
]


def local_evaluate_moai(spec: dict, x: np.ndarray) -> np.ndarray:
    """Re-implementation of activation_approximations.evaluate_moai (used only
    when the plaintext tree is not available; flagged in the output)."""
    base = float(spec["base_radius"])
    factor = float(spec.get("extension_factor", 1.5))
    y = np.asarray(x, dtype=np.float64)
    for r in range(int(spec["extension_stages"]) - 1, -1, -1):
        scale = base * (factor**r)
        y = y - (4.0 / (27.0 * scale * scale)) * (y * y * y)
    return 0.5 * x * (1.0 + chebval(y * (1.0 / base), spec["coefficients"]))


def activation(target: str):
    if target == "erf-gelu":
        from scipy.special import erf

        return lambda x: 0.5 * x * (1.0 + erf(x / math.sqrt(2.0)))
    if target == "tanh-gelu":
        return lambda x: 0.5 * x * (1.0 + np.tanh(math.sqrt(2.0 / math.pi) * (x + 0.044715 * x**3)))
    raise ValueError(target)


def run_host(binary: Path, label: str, grid: np.ndarray):
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "input.txt"
        path.write_text(f"{label}\n{grid.size}\n" + "\n".join(f"{v:.17g}" for v in grid) + "\n")
        result = subprocess.run([str(binary), str(path)], capture_output=True, text=True, check=True)
    echo = np.empty(grid.size); circuit = np.empty(grid.size); clenshaw = np.empty(grid.size)
    i = 0
    header = ""
    for line in result.stdout.strip().split("\n"):
        if line.startswith("#"):
            header = line
            continue
        a, b, c = line.split()
        echo[i], circuit[i], clenshaw[i] = float(a), float(b), float(c)
        i += 1
    return header, echo, circuit, clenshaw


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument("--profiles-json", type=Path, default=ROOT / "configs/moai_model_profiles.json")
    parser.add_argument("--host-check-binary", type=Path, default=ROOT / "build/bin/moai_host_check")
    parser.add_argument("--plaintext-dir", type=Path, default=None,
                        help="Plaintext GELU tree (imports activation_approximations.evaluate_moai). "
                             "Default: ../SPA_GELU or ./SPA_GELU if present.")
    parser.add_argument("--grid-points", type=int, default=100001)
    parser.add_argument("--out", type=Path, default=ROOT / "validation/moai_model_profile_check")
    args = parser.parse_args()

    record = json.loads(args.profiles_json.read_text())
    target = record["native_target_id"]
    plaintext_dir = args.plaintext_dir
    if plaintext_dir is None:
        for candidate in (ROOT / "SPA_GELU", ROOT.parent / "SPA_GELU"):
            if (candidate / "activation_approximations.py").exists():
                plaintext_dir = candidate
                break
    evaluator_name = "local re-implementation (plaintext tree not found)"
    evaluate_moai = local_evaluate_moai
    if plaintext_dir is not None and (plaintext_dir / "activation_approximations.py").exists():
        sys.path.insert(0, str(plaintext_dir))
        import activation_approximations as aa  # type: ignore

        evaluate_moai = aa.evaluate_moai
        evaluator_name = f"activation_approximations.evaluate_moai from {plaintext_dir}"

    rows: list[dict] = []
    failures: list[str] = []
    for label in ("r5", "r20"):
        spec = record["profiles"][label]
        radius = float(spec["operating_radius"])
        grid = np.linspace(-radius, radius, args.grid_points)
        assert grid[0] == -radius and grid[-1] == radius and 0.0 in grid
        p_model = np.asarray(evaluate_moai(spec, grid), dtype=np.float64)
        header, echo, p_cipher, p_clenshaw = run_host(args.host_check_binary, label, grid)
        if record["source_catalog_sha256"] not in header:
            failures.append(f"{label}: the host binary was built from a different import (header: {header})")
        exact = activation(target)(grid)
        err = np.abs(p_model - exact)
        echo_ok = bool(np.array_equal(echo, grid))
        finite = bool(np.isfinite(p_model).all() and np.isfinite(p_cipher).all() and np.isfinite(p_clenshaw).all())
        row = {
            "profile": spec["id"], "radius": radius, "base_radius": spec["base_radius"],
            "extension_stages": spec["extension_stages"], "degree": spec["degree"], "target": target,
            "source_catalog_sha256": record["source_catalog_sha256"], "grid_points": grid.size,
            "grid_echo_bitwise_identical": echo_ok, "model_evaluator": evaluator_name,
            "model_cipher_gap": float(np.max(np.abs(p_model - p_cipher))),
            "model_clenshaw_gap": float(np.max(np.abs(p_model - p_clenshaw))),
            "cipher_clenshaw_gap": float(np.max(np.abs(p_cipher - p_clenshaw))),
            "sampled_max_error": float(err.max()), "sampled_argmax_x": float(grid[int(err.argmax())]),
            "catalog_max_abs_error": float(spec["max_abs_error"]), "outputs_finite": finite,
        }
        # Same function: the evaluator gap must be host rounding, far below the
        # function error; the sampled error must agree with the catalog's.
        ok = (echo_ok and finite and row["model_cipher_gap"] < 1e-12 * max(1.0, radius)
              and abs(row["sampled_max_error"] - row["catalog_max_abs_error"]) < 1e-9 + 1e-3 * row["catalog_max_abs_error"])
        row["status"] = "pass" if ok else "FAIL"
        if not ok:
            failures.append(f"{label}: {row}")
        rows.append(row)
        print(f"{spec['id']}: model-cipher gap {row['model_cipher_gap']:.2e}, model-clenshaw gap {row['model_clenshaw_gap']:.2e}, "
              f"E_poly {row['sampled_max_error']:.3e} (catalog {row['catalog_max_abs_error']:.3e}), echo {echo_ok}, {row['status']}")

    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.with_suffix(".csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)
    args.out.with_suffix(".json").write_text(json.dumps(rows, indent=2, default=str) + "\n")
    print(f"model evaluator: {evaluator_name}")
    print(f"saved: {args.out.with_suffix('.csv')}")
    if failures:
        print("FAILED:\n  " + "\n  ".join(failures))
        sys.exit(1)


if __name__ == "__main__":
    main()
