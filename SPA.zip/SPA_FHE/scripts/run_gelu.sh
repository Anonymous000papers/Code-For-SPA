#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="${BUILD_DIR:-${ROOT}/build}"
# TARGET=erf (default): exact erf-GELU with gelu_bench; methods are the three
# SPA tiers, NEXUS and MOAI (the plaintext model's imported profile), the
# methods whose polynomials approximate the erf-GELU. TARGET=quickgelu:
# QuickGELU x*sigmoid(1.702x) with gelu_quickgelu_bench, Euston's own fitting
# target, so SPA refitted to it and Euston are compared on equal terms
# (E_target = 0 for both). Each binary's SPA profiles are refitted to its
# target; baselines keep theirs.
TARGET="${TARGET:-erf}"
case "${TARGET}" in
  erf)       BIN_NAME=gelu_bench; DEFAULT_RESULT_DIR="${ROOT}/results/gelu_erf" ;;
  quickgelu) BIN_NAME=gelu_quickgelu_bench; DEFAULT_RESULT_DIR="${ROOT}/results/gelu_quickgelu" ;;
  *) echo "TARGET must be erf or quickgelu" >&2; exit 2 ;;
esac
BIN="${BUILD_DIR}/bin/${BIN_NAME}"
MODE="${1:-all}"
RESULT_DIR="${RESULT_DIR:-${DEFAULT_RESULT_DIR}}"
REPEATS="${REPEATS:-10}"
WARMUPS="${WARMUPS:-2}"
SLOTS="${SLOTS:-32768}"
LEVELS_R5="${LEVELS_R5:-${LEVELS:-22}}"
LEVELS_R20="${LEVELS_R20:-${LEVELS:-30}}"
RESERVE_LEVELS="${RESERVE_LEVELS:-4}"
PRECISION_BITS="${PRECISION_BITS:-46}"
ORDER_SEED="${ORDER_SEED:-20260831}"
CPUSET="${CPUSET:-}"
EUSTON_BREAKDOWN="${EUSTON_BREAKDOWN:-1}"
EUSTON_PRECISION_BITS="${EUSTON_PRECISION_BITS:-35}"
EUSTON_PRIME_BITS="${EUSTON_PRIME_BITS:-${EUSTON_PRECISION_BITS}}"
EUSTON_LEVELS="${EUSTON_LEVELS:-0}"
POLY_DEGREE="${POLY_DEGREE:-65536}"

# erf-GELU: the three SPA tiers, NEXUS (released graph, range-adapted at R20,
# with its range-conditioning diagnostic) and MOAI (the plaintext
# model's imported profile, moai-r5 / moai-r20). Euston is fitted to
# QuickGELU and is compared under that target instead.
R5_METHODS="${ERF_METHODS:-spa-k39,spa-k63,spa-k87,nexus,moai}"
R20_METHODS="${ERF_METHODS:-spa-k39,spa-k63,spa-k87,nexus,moai}"
# QuickGELU: the three SPA tiers against Euston, the method fitted to it.
if [[ "${TARGET}" == quickgelu ]]; then
  R5_METHODS="${QUICKGELU_METHODS:-spa-k39,spa-k63,spa-k87,euston}"
  R20_METHODS="${QUICKGELU_METHODS:-spa-k39,spa-k63,spa-k87,euston}"
fi
# Experiment B: the balanced tier with coefficients rounded to 1..5 decimals
# next to the unrounded ("full") coefficients; same profiles, same split.
ROUNDING_METHODS="${ROUNDING_METHODS:-spa-k63,spa-k63-d1,spa-k63-d2,spa-k63-d3,spa-k63-d4,spa-k63-d5}"
# Experiment C: unrounded balanced coefficients, CKKS scale/prime bits varied.
# 46 is the baseline; 42 and 38 are lower candidates. Whether a lower setting
# is valid depends on the chain (the binary refuses infeasible parameters).
PRECISION_POINTS="${PRECISION_POINTS:-46 42 38}"
PRECISION_METHODS="${PRECISION_METHODS:-spa-k63}"

build() {
  local args=(-S "${ROOT}" -B "${BUILD_DIR}" -DCMAKE_BUILD_TYPE=Release -DSPA_NATIVE_OPT=ON)
  if [[ -n "${SEAL_DIR:-}" ]]; then
    args+=("-DSEAL_DIR=${SEAL_DIR}")
  elif [[ -n "${CMAKE_PREFIX_PATH:-}" ]]; then
    args+=("-DCMAKE_PREFIX_PATH=${CMAKE_PREFIX_PATH}")
  fi
  cmake "${args[@]}"
  cmake --build "${BUILD_DIR}" --target "${BIN_NAME}" -j"${BUILD_JOBS:-$(nproc)}"
  ctest --test-dir "${BUILD_DIR}" --output-on-failure
}

run_matrix() {
  local name="$1"
  local methods="$2"
  local lo="$3"
  local hi="$4"
  local levels="$5"
  local bits="${6:-${PRECISION_BITS}}"

  mkdir -p "${RESULT_DIR}"
  local summary="${RESULT_DIR}/${name}_summary.csv"
  local samples="${RESULT_DIR}/${name}_samples.csv"
  local pooled="${RESULT_DIR}/${name}_pooled.csv"
  if [[ -e "${summary}" || -e "${samples}" || -e "${pooled}" ]]; then
    echo "Refusing to overwrite prior results; choose a new RESULT_DIR: ${RESULT_DIR}" >&2
    exit 2
  fi

  local cmd=(
    "${BIN}" --methods "${methods}" --range "${lo}" "${hi}" --input grid
    --poly-degree "${POLY_DEGREE}" --slots "${SLOTS}" --warmup "${WARMUPS}" --repeat "${REPEATS}"
    --levels "${levels}" --reserve-levels "${RESERVE_LEVELS}"
    --scale-bits "${bits}" --prime-bits "${bits}"
    --euston-scale-bits "${EUSTON_PRECISION_BITS}" --euston-prime-bits "${EUSTON_PRIME_BITS}"
    --euston-levels "${EUSTON_LEVELS}"
    --order-seed "${ORDER_SEED}" --euston-breakdown "${EUSTON_BREAKDOWN}"
    --run-label "${name}" --csv-out "${summary}" --samples-csv "${samples}"
  )

  if [[ -n "${CPUSET}" ]]; then
    taskset -c "${CPUSET}" "${cmd[@]}" | tee "${RESULT_DIR}/${name}.log"
  else
    "${cmd[@]}" | tee "${RESULT_DIR}/${name}.log"
  fi

  local summarize=(
    python3 "${ROOT}/scripts/summarize.py"
    --samples "${samples}" --summary "${summary}" --out "${pooled}"
    --seed "${ORDER_SEED}"
  )
  if [[ "${methods}" == *spa-k87* ]]; then
    summarize+=(--baseline spa_k87=spa-k87)
  fi
  if [[ "${methods}" == *spa-k63* ]]; then
    summarize+=(--baseline spa_k63=spa-k63)
  fi
  if [[ "${methods}" == *nexus* ]]; then
    summarize+=(--baseline nexus=nexus)
  fi
  if [[ "${methods}" == *moai* ]]; then
    summarize+=(--baseline moai=moai)
  fi
  if [[ "${methods}" == *euston* ]]; then
    summarize+=(--baseline euston=euston)
  fi
  "${summarize[@]}"
}

# Experiment B on both public intervals.
run_rounding() {
  run_matrix "roundB_r5" "${ROUNDING_METHODS}" -5 5 "${LEVELS_R5}"
  run_matrix "roundB_r20" "${ROUNDING_METHODS}" -20 20 "${LEVELS_R20}"
}

# Experiment C: one run per precision point, separate from Experiment B.
run_precision() {
  local bits
  for bits in ${PRECISION_POINTS}; do
    if ! "${BIN}" --describe-plan --methods "${PRECISION_METHODS}" --range -5 5 \
         --poly-degree "${POLY_DEGREE}" --levels "${LEVELS_R5}" --reserve-levels "${RESERVE_LEVELS}" \
         --scale-bits "${bits}" --prime-bits "${bits}" > /dev/null 2>&1; then
      echo "precC: ${bits}-bit scale/prime is not a valid configuration for this chain; skipped" >&2
      continue
    fi
    run_matrix "precC_p${bits}_r5" "${PRECISION_METHODS}" -5 5 "${LEVELS_R5}" "${bits}"
    run_matrix "precC_p${bits}_r20" "${PRECISION_METHODS}" -20 20 "${LEVELS_R20}" "${bits}"
  done
}

if [[ "${MODE}" != build ]]; then
  if [[ ! -x "${BIN}" || "${ROOT}/CMakeLists.txt" -nt "${BIN}" ]] ||
     [[ -n "$(find "${ROOT}/src" -type f -newer "${BIN}" -print -quit 2>/dev/null || true)" ]]; then
    build
  fi
fi
case "${MODE}" in
  build) build ;;
  r5) run_matrix r5 "${METHODS:-${R5_METHODS}}" -5 5 "${LEVELS_R5}" ;;
  r20) run_matrix r20 "${METHODS:-${R20_METHODS}}" -20 20 "${LEVELS_R20}" ;;
  roundB) run_rounding ;;
  precC) run_precision ;;
  all)
    run_matrix r5 "${R5_METHODS}" -5 5 "${LEVELS_R5}"
    run_matrix r20 "${R20_METHODS}" -20 20 "${LEVELS_R20}"
    ;;
  full)
    run_matrix r5 "${R5_METHODS}" -5 5 "${LEVELS_R5}"
    run_matrix r20 "${R20_METHODS}" -20 20 "${LEVELS_R20}"
    run_rounding
    run_precision
    ;;
  *)
    echo "usage: TARGET=erf|quickgelu $0 [build|r5|r20|roundB|precC|all|full]" >&2
    exit 2
    ;;
esac
