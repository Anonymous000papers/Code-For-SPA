# SPA_FHE — CKKS activation microbenchmarks

Single-context CKKS (Microsoft SEAL 4.1) evaluation of polynomial activation
approximations, timed on one packed ciphertext with no intermediate
decryption, refresh or bootstrapping. Three native activations are covered,
each by its own binary and profile catalog:

| native target | binary | SPA catalog | comparison methods |
|---|---|---|---|
| exact erf-GELU | `gelu_bench` | `configs/spa_profiles.json` → `src/spa_profiles.hpp` | SPA×3, NEXUS, MOAI (plaintext model profile) |
| SiLU | `silu_bench` | `configs/spa_silu_profiles.json` → `src/spa_silu_profiles.hpp` | Orion, ENSI, Sylph, THOR |

SPA tiers are selected by the same rule as the plaintext harness — the
smallest degree on the Paterson–Stockmeyer ladder (k = m·split − 1, split 4
at R5, 8 at R20) whose dense-grid maximum error meets the tier target
(fast 2.1e-2, balanced 1e-3, accurate 1e-4). The method ids `spa-k39`,
`spa-k63`, `spa-k87` are stable tier labels (fast / balanced / accurate);
the numbers are historical and do not denote a degree. Active degrees:

| target | fast (R5/R20) | balanced | accurate |
|---|---|---|---|
| SiLU | 3 / 15 | 7 / 23 | 11 / 31 |
| erf-GELU | 7 / 23 | 11 / 31 | 11 / 39 |

These are the plaintext harness's r5/r20 degrees for the same tiers, so a
tier label denotes the same polynomial in both experiments.

`gelu_bench` and `gelu_quickgelu_bench` are the same source
(`src/gelu_bench.cpp`) built with `SPA_GELU_TARGET_QUICKGELU` and
`SPA_PROFILE_HEADER` set by CMake; the QuickGELU catalog is the erf
generator run with `--target quickgelu`. Each target compares the methods
whose polynomials approximate it: erf-GELU — the three SPA tiers, NEXUS
(released erf graph) and MOAI (the plaintext model's own erf profile);
QuickGELU — the three SPA tiers and Euston (fitted to QuickGELU); SiLU —
the three SPA tiers, Orion, ENSI, Sylph and THOR. The tanh-GELU form is
evaluated in the plaintext harness only.

## Build and run

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DSEAL_DIR=<seal>/lib/cmake/SEAL-4.1
cmake --build build -j
ctest --test-dir build --output-on-failure        # numerical/source tests, no CKKS

TARGET=erf bash scripts/run_gelu.sh all           # results/gelu_erf: SPA x3, NEXUS, MOAI
bash scripts/run_silu.sh all                      # results/silu
MODE=full bash scripts/run_all.sh                 # all three + Experiments B and C + figure
```

`run_gelu.sh`/`run_silu.sh` modes: `r5`, `r20`, `all` (both), `roundB`
(Experiment B), `precC` (Experiment C), `full` (everything). `REPEATS`,
`WARMUPS`, `SLOTS`, `LEVELS_R5`, `LEVELS_R20`, `PRECISION_BITS`, `CPUSET` and
`RESULT_DIR` are environment variables. A run refuses to overwrite an
existing result file; choose a new `RESULT_DIR`.

## Error decomposition

With `c` the fitted coefficients, `c_d` the coefficients actually evaluated
(rounded in Experiment B, otherwise `c`), `Y_HE` the decrypted output,
`A_fit` the function the method was fitted to and `A_native` the benchmark's
native target, every summary row records, as maxima over the metric slots:

| column | definition |
|---|---|
| `e_target` | max \|A_fit − A_native\| — 0 when the method is fitted to the run's target (SPA, NEXUS/MOAI under erf, Euston under QuickGELU) |
| `e_poly` | max \|P_c − A_fit\| — host double evaluation of the unrounded circuit |
| `e_coeff` | max \|P_{c_d} − P_c\| — Experiment B only, 0 otherwise |
| `e_he` | max \|Y_HE − P_{c_d}\| — decrypted output minus the host reference of the identical circuit |
| `e_total` | max \|Y_HE − A_native\| |
| `decomposition_bound` | `e_target + e_poly + e_coeff + e_he`; the run aborts if `e_total` exceeds it |

`method_bias_max` (host reference minus native target) is kept for continuity
and already contains `E_target` and `E_coeff`; it must not be added to them.
`e_he` is the difference from the host-side double-precision evaluation of the
same polynomial or composite circuit; it includes host floating-point error
and is not independently verified pure CKKS noise (`host_reference_semantics`
says so in every row). `catalog_e_poly` / `catalog_e_coeff` are the dense-grid
values from the profile catalog for cross-checking the on-grid numbers.
`scripts/check_ciphertext_results.py` verifies the bound, `e_total ==
total_max_abs` and `e_he == ckks_extra_max` on recorded CSVs.

## Experiment B — coefficient precision (`roundB`)

Each catalog carries the balanced tier (`spa-k63`) with its normalised
Chebyshev coefficients rounded half-to-even to d ∈ {1,…,5} decimals as
`spa-k63-d1` … `spa-k63-d5`; the unrounded fit is the `full` point. Degree,
PS split, range and coefficient source are untouched; nothing is refitted.
Each rounded profile records ‖c_d − c‖₁ and E_coeff = ‖P_{c_d} − P_c‖_∞ on
the interval; E_coeff ≤ ‖c_d − c‖₁ holds because |T_j(t)| ≤ 1 and is
verified per profile. The bound describes the ideal real-arithmetic
perturbation; it excludes CKKS encoding and rescale error, which appear in
`e_he`. Coarse rounding zeroes whole Paterson–Stockmeyer blocks; those are
skipped rather than multiplied by an encoded zero (a transparent ciphertext,
which SEAL rejects), so `ct_plain_multiply` and possibly `consumed_levels`
are lower for d = 1–2. That is a genuine consequence of the rounding and is
recorded as such.

## Experiment C — CKKS precision points (`precC`)

Separate from Experiment B: the unrounded balanced coefficients, with only
the scale and prime bits varied. `PRECISION_POINTS="46 42 38"` by default —
46 is the baseline; 42 and 38 are candidates, not guarantees. The GELU
script checks each point with `--describe-plan` and skips an infeasible one;
the SiLU script reports a failed point and continues. Results go to
`precC_p<bits>_r5` / `precC_p<bits>_r20`.

## Main figure — error–latency trade-off

`scripts/plot_tradeoff.py` plots median latency of the activation module
(x, log) against `e_total` relative to the common native target (y, log),
one panel per (native target, interval), each point annotated with method,
tier, and the parameter differences a fair read needs (Euston's own 35-bit
chain and sign/exp settings, NEXUS sign depth and conditioning status, MOAI
source vs. refit polynomial, Experiment B decimals, and `fit=` when the fit
target differs from the native one). Methods are not forced to a common
error; the configurations actually run are shown as distinct points. The
plotted values are also written to `<out>_points.csv`; the figure itself
needs matplotlib.

## MOAI: the plaintext model's own profiles

The ciphertext MOAI is no longer reconstructed from the released source. It
is the profile the plaintext harness actually ran, imported verbatim:
`scripts/import_model_moai_profiles.py` reads `moai-r5` and `moai-r20` from
a plaintext `profile_catalog.json` (degree-23 Chebyshev factor polynomial on
[−B, B], Cheon–Kim–Park extension stages, base radius, factor), verifies
that every other task's catalog carries identical profiles, and writes
`configs/moai_model_profiles.json` plus `src/moai_model_profiles.hpp` with
every coefficient at 17 significant digits and the source catalog path, its
SHA-256 and the task recorded. Nothing is refitted, truncated or reselected;
the R5 run uses `moai-r5` and the R20 run `moai-r20`, selected by the public
interval only, never by ciphertext values.

```bash
python3 scripts/import_model_moai_profiles.py \
    --catalog SPA_GELU/results/zeroshot_erf/hellaswag/profile_catalog.json \
    --cross-check SPA_GELU/results/zeroshot_erf/*/profile_catalog.json
cmake --build build -j                     # the header is compiled in
python3 scripts/validate_moai_model_profiles.py --host-check-binary build/bin/moai_host_check \
    --plaintext-dir SPA_GELU
```

`MoaiModelMethod` evaluates exactly that function under encryption:
extension stages outermost first (2 levels each), y/B, the factor
polynomial in the Chebyshev basis (product tree; every stored coefficient
applied), and the reconstruction (x/2)(1+P), all inside the timed region
and with no scale relabelling (an exact-arithmetic model of the circuit
leaves a 1e-15 residual). Cost: R5 8 levels, 23 ct×ct, 36 pt×ct; R20 14
levels, 29 ct×ct, 42 pt×ct. The importer accepts erf-GELU catalogs only.

`validate_moai_model_profiles.py` (with `tests/moai_host_check.cpp`)
compares, on one bitwise-shared grid of 100,001 points including both
endpoints and zero, P_model-host — the plaintext harness's own
`evaluate_moai` on the imported profile — with P_cipher-host, a mirror of
the circuit's operation order, and with the benchmark's Clenshaw host
reference. The reference reproduces the plaintext evaluator bit for bit,
the circuit mirror differs by ≤ 1.1e-14, and the grid error equals the
catalog's stored `max_abs_error` (3.81e-6 at R5, 4.54e-3 at R20). All in
double; FP32/BF16 rounding of the model's path is the plaintext harness's
subject, and CKKS output is not expected to match bit for bit. Artifacts:
`validation/moai_model_profile_check.{csv,json}`; `ctest` runs the check.
`gelu_baseline_profiles.hpp` and its generator no longer define MOAI.

## Balanced-profile validation (Checks A and B)

`scripts/validate_balanced_profiles.py` validates the balanced
configurations actually used — SiLU 7/4 and 23/8, erf-GELU 11/4 and 31/8,
QuickGELU 11/4 and 39/8 (degree/split) — with the complete coefficients
from the catalogs, without models, keys or CKKS. Two independent checks,
reported in separate columns:

* **Check A, evaluator consistency.** One fixed grid (100,001 points,
  endpoints and zero included) is written once and echoed bitwise by
  `tests/profile_ps_host_check.cpp`, which evaluates the polynomial the way
  the ciphertext circuit does — `decompose_chebyshev` blocks, ChebDAG product
  rules, `evaluate_baby_block` accumulation order, `evaluate_ps` pairwise
  recombination with y, y², … — and by `profile_plain_eval` (Clenshaw).
  `clenshaw_ps_gap` (Python Clenshaw vs C++ PS mirror) is ≤ 1.1e-14 on all
  four; `clenshaw_py_cpp_gap` ≤ 4.4e-15. Separately, `sampled_max_error` is
  the function error on the grid. `float32_evaluation_gap` and
  `bf16_output_gap` are the plaintext-harness precision diagnostics. This
  check does not simulate CKKS.
* **Check B, verified bound.** sup over the whole interval of |P_c − A| is
  bounded (Route 2) as U = max_j |e(m_j)| + h_cover·(M_P + M_A), where the
  midpoint enclosures use long-double interval arithmetic
  (`longdouble_nmant` is recorded; 63 on x86-64) with outward rounding after
  every operation, coefficients as exact doubles, and an exp that does not
  come from libm: 2^k·exp(r) with r = x − k·ln 2 (ln 2 enclosed between two
  decimals), an interval Taylor series to order 24 and its remainder added
  outward (`exp_backend`). h_cover = max(m₀ + R, R − m_{n−1}, max gap/2) is
  measured from the midpoints actually evaluated, across chunks
  (`scripts/reference_helpers.CoverageRadius`), not assumed from the nominal
  spacing (the float64 midpoints are not exactly equally spaced, and a fixed
  relative margin would not cover them). M_P = ½ + (4/R)Σ|c′_j| is computed with interval operations
  at every step; M_A is an analytic constant (1.25 for SiLU and QuickGELU;
  derivations in the script). A non-finite interval anywhere aborts; nothing
  falls back to libm. `bound_status = verified_upper_bound` therefore rests
  only on IEEE-754 correctly rounded basic operations; the value is also in
  the neutral `upper_bound` column, and `bound_midpoint_count`,
  `bound_coverage_radius`, `midpoint_max_enclosure`, `bound_lipschitz` let a
  reader recompute U. `meets_error_budget` is `proven`, `not_proven` (the
  bound exceeds the target — which does not show the polynomial fails it) or
  `not_evaluated`. Results in `validation/balanced_profile_validation.csv`:

| profile | E_grid | verified bound | subintervals | budget 1e-3 |
|---|---|---|---|---|
| SiLU R5 k7 | 1.78e-4 | 1.96e-4 | 1.2e6 | proven |
| SiLU R20 k23 | 7.31e-4 | 8.05e-4 | 3.2e6 | proven |
| erf-GELU R5 k11 | 6.60e-6 | — | — | sampled_only |
| erf-GELU R20 k31 | 4.33e-4 | — | — | sampled_only |
| QuickGELU R5 k11 | 1.83e-4 | 2.01e-4 | 1.6e6 | proven |
| QuickGELU R20 k39 | 4.40e-4 | 4.84e-4 | 8.4e6 | proven |

No rigorous erf enclosure is implemented, so the erf-GELU rows carry
Check A and the sampled error only (`bound_status = sampled_only`); the
rigorous bounds are for SiLU and QuickGELU. `--compare-catalog` reports
‖c_pt − c_ct‖₁ against the plaintext catalogs (≤ 1.9e-7), so a bound
transfers to the plaintext
coefficients as U_pt ≤ U_ct + ‖Δc‖₁ (Route 1); `transferred_upper_bound`
holds that value. `ctest` runs Check A (`balanced_profile_check_a`); Check
B takes a few minutes and is run with

```bash
python3 scripts/validate_balanced_profiles.py --host-check-binary build/bin/profile_ps_host_check \
    --compare-catalog <plaintext SiLU catalog> spa-r5-k7 --compare-catalog <same> spa-r20-k23 \
    --compare-catalog <plaintext erf GELU catalog> spa-r5-k11 --compare-catalog <same> spa-r20-k31
```

## Tests

`python3 tests/run_source_checks.py` runs the numerical and source-policy
tests (no SEAL needed): catalog reproducibility for all three targets,
profile invariants including the Experiment B variants, the Euston
reference, the error-decomposition tooling, and the arithmetic-model checks.
`ctest` registers the same tests. The arithmetic model is not encryption,
noise, security or timing evidence.

## Provenance notes

Every generated header embeds the SHA-256 of its JSON catalog and the
native target id; a binary refuses a header fitted for another target, and
the summary CSV records the catalog hash, the active profile, the CKKS
parameters and the security validation status of every row. NEXUS at R20
is a range extension of the released graph: its encrypted gate residual is
amplified by the centre polynomial outside the centre interval
(`conditioning=ill-conditioned-range-extension` in the log), and the figure
labels that point accordingly rather than tuning the graph.
