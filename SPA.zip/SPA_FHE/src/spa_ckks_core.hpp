#pragma once

#include <seal/seal.h>

// The SPA profile header is selected at build time so one benchmark source
// serves several fitting targets: the erf-GELU catalog by default,
// spa_quickgelu_profiles.hpp for the gelu_quickgelu_bench target (see CMake).
#if defined(SPA_PROFILE_HEADER)
#include SPA_PROFILE_HEADER
#else
#include "spa_profiles.hpp"
#endif

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <limits>
#include <map>
#include <memory>
#include <optional>
#include <random>
#include <sstream>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>

namespace spa {

using seal::CKKSEncoder;
using seal::Ciphertext;
using seal::CoeffModulus;
using seal::Decryptor;
using seal::EncryptionParameters;
using seal::Encryptor;
using seal::Evaluator;
using seal::KeyGenerator;
using seal::Plaintext;
using seal::PublicKey;
using seal::RelinKeys;
using seal::SEALContext;
using seal::SecretKey;
using seal::parms_id_type;
using seal::scheme_type;
using seal::sec_level_type;

inline int chain_index(const SEALContext &context, const Ciphertext &ct) {
    auto data = context.get_context_data(ct.parms_id());
    return data ? data->chain_index() : -1;
}

inline parms_id_type parms_id_at_chain_index(const SEALContext &context, int target) {
    auto data = context.first_context_data();
    while (data) {
        if (data->chain_index() == target) return data->parms_id();
        data = data->next_context_data();
    }
    throw std::invalid_argument("requested CKKS chain index is unavailable: " + std::to_string(target));
}

inline int ceil_log2_int(int n) {
    if (n <= 1) return 0;
    int value = 1;
    int result = 0;
    while (value < n) {
        value <<= 1;
        ++result;
    }
    return result;
}

template <typename Eval>
inline std::unique_ptr<Evaluator> make_evaluator_impl(
    SEALContext &context, CKKSEncoder &encoder) {
    // Support upstream SEAL and the local SEAL fork.
    if constexpr (std::is_constructible_v<Eval, SEALContext &, CKKSEncoder &>) {
        return std::make_unique<Eval>(context, encoder);
    } else if constexpr (std::is_constructible_v<Eval, const SEALContext &, CKKSEncoder &>) {
        return std::make_unique<Eval>(static_cast<const SEALContext &>(context), encoder);
    } else if constexpr (std::is_constructible_v<Eval, SEALContext &>) {
        return std::make_unique<Eval>(context);
    } else if constexpr (std::is_constructible_v<Eval, const SEALContext &>) {
        return std::make_unique<Eval>(static_cast<const SEALContext &>(context));
    } else {
        static_assert(std::is_constructible_v<Eval, const SEALContext &>,
                      "Unsupported SEAL Evaluator constructor");
    }
}

inline std::unique_ptr<Evaluator> make_evaluator(
    SEALContext &context, CKKSEncoder &encoder) {
    return make_evaluator_impl<Evaluator>(context, encoder);
}

struct OperationCounts {
    std::uint64_t ct_ct_multiply = 0;
    std::uint64_t ct_square = 0;
    std::uint64_t ct_plain_multiply = 0;
    std::uint64_t relinearize = 0;
    std::uint64_t rescale = 0;
    std::uint64_t mod_switch = 0;
    std::uint64_t ct_add = 0;
    std::uint64_t ct_sub = 0;
    std::uint64_t add_plain = 0;

    std::uint64_t total_ct_ct() const { return ct_ct_multiply + ct_square; }

    bool operator==(const OperationCounts &other) const {
        return ct_ct_multiply == other.ct_ct_multiply &&
               ct_square == other.ct_square &&
               ct_plain_multiply == other.ct_plain_multiply &&
               relinearize == other.relinearize &&
               rescale == other.rescale &&
               mod_switch == other.mod_switch &&
               ct_add == other.ct_add &&
               ct_sub == other.ct_sub &&
               add_plain == other.add_plain;
    }
};

struct HEEnv {
    double scale;
    std::vector<int> modulus_bits;
    std::shared_ptr<SEALContext> context;
    std::unique_ptr<CKKSEncoder> encoder;
    std::unique_ptr<KeyGenerator> keygen;
    SecretKey secret_key;
    PublicKey public_key;
    RelinKeys relin_keys;
    std::unique_ptr<Encryptor> encryptor;
    std::unique_ptr<Evaluator> evaluator;
    std::unique_ptr<Decryptor> decryptor;

    HEEnv(std::size_t poly_modulus_degree, const std::vector<int> &bits,
          double scale_, bool secure128)
        : scale(scale_), modulus_bits(bits) {
        EncryptionParameters parms(scheme_type::ckks);
        parms.set_poly_modulus_degree(poly_modulus_degree);
        parms.set_coeff_modulus(CoeffModulus::Create(poly_modulus_degree, bits));
        context = std::make_shared<SEALContext>(
            parms, true, secure128 ? sec_level_type::tc128 : sec_level_type::none);
        if (!context->parameters_set()) {
            throw std::runtime_error(
                "invalid SEAL parameters; use --no-sec only for a smoke test or adjust the modulus chain");
        }
        encoder = std::make_unique<CKKSEncoder>(*context);
        keygen = std::make_unique<KeyGenerator>(*context);
        secret_key = keygen->secret_key();
        keygen->create_public_key(public_key);
        keygen->create_relin_keys(relin_keys);
        encryptor = std::make_unique<Encryptor>(*context, public_key);
        evaluator = make_evaluator(*context, *encoder);
        decryptor = std::make_unique<Decryptor>(*context, secret_key);
    }
};

inline Ciphertext encrypt_vector(HEEnv &env, const std::vector<double> &values) {
    Plaintext plain;
    env.encoder->encode(values, env.scale, plain);
    Ciphertext encrypted;
    env.encryptor->encrypt(plain, encrypted);
    return encrypted;
}

inline std::vector<double> decrypt_vector(HEEnv &env, const Ciphertext &ct) {
    Plaintext plain;
    std::vector<double> decoded;
    env.decryptor->decrypt(ct, plain);
    env.encoder->decode(plain, decoded);
    return decoded;
}

inline void mod_switch_to_inplace(HEEnv &env, Ciphertext &ct,
                                  parms_id_type target_id,
                                  OperationCounts &counts) {
    if (ct.parms_id() != target_id) {
        env.evaluator->mod_switch_to_inplace(ct, target_id);
        ++counts.mod_switch;
    }
}

inline void align_scale_inplace(Ciphertext &ct, double target_scale) {
    ct.scale() = target_scale;
}

inline Ciphertext multiply_and_rescale(
    HEEnv &env, const Ciphertext &lhs, const Ciphertext &rhs,
    OperationCounts &counts, double target_scale) {
    const Ciphertext *a = &lhs;
    const Ciphertext *b = &rhs;
    std::optional<Ciphertext> a_copy;
    std::optional<Ciphertext> b_copy;
    const int ia = chain_index(*env.context, lhs);
    const int ib = chain_index(*env.context, rhs);
    if (ia < 0 || ib < 0) throw std::runtime_error("invalid parms_id in ciphertext multiplication");
    if (ia > ib) {
        a_copy = lhs;
        mod_switch_to_inplace(env, *a_copy, rhs.parms_id(), counts);
        align_scale_inplace(*a_copy, target_scale);
        a = &*a_copy;
    } else if (ib > ia) {
        b_copy = rhs;
        mod_switch_to_inplace(env, *b_copy, lhs.parms_id(), counts);
        align_scale_inplace(*b_copy, target_scale);
        b = &*b_copy;
    }

    Ciphertext out;
    env.evaluator->multiply(*a, *b, out);
    ++counts.ct_ct_multiply;
    env.evaluator->relinearize_inplace(out, env.relin_keys);
    ++counts.relinearize;
    env.evaluator->rescale_to_next_inplace(out);
    ++counts.rescale;
    out.scale() = target_scale;
    return out;
}

inline Ciphertext square_and_rescale(
    HEEnv &env, const Ciphertext &input, OperationCounts &counts,
    double target_scale) {
    Ciphertext out;
    env.evaluator->square(input, out);
    ++counts.ct_square;
    env.evaluator->relinearize_inplace(out, env.relin_keys);
    ++counts.relinearize;
    env.evaluator->rescale_to_next_inplace(out);
    ++counts.rescale;
    out.scale() = target_scale;
    return out;
}

inline void add_cipher_inplace(HEEnv &env, Ciphertext &dst,
                               const Ciphertext &src,
                               OperationCounts &counts,
                               double target_scale) {
    const int idst = chain_index(*env.context, dst);
    const int isrc = chain_index(*env.context, src);
    if (idst < 0 || isrc < 0) throw std::runtime_error("invalid parms_id in ciphertext addition");
    if (idst > isrc) {
        // dst is at a higher chain index and can be switched down in place;
        // no copy of src is required.
        mod_switch_to_inplace(env, dst, src.parms_id(), counts);
        dst.scale() = target_scale;
        env.evaluator->add_inplace(dst, src);
    } else if (isrc > idst) {
        // src is const, so only this branch needs a temporary copy.
        Ciphertext aligned = src;
        mod_switch_to_inplace(env, aligned, dst.parms_id(), counts);
        aligned.scale() = target_scale;
        dst.scale() = target_scale;
        env.evaluator->add_inplace(dst, aligned);
    } else {
        dst.scale() = target_scale;
        env.evaluator->add_inplace(dst, src);
    }
    ++counts.ct_add;
}

inline void sub_cipher_inplace(HEEnv &env, Ciphertext &dst,
                               const Ciphertext &src,
                               OperationCounts &counts,
                               double target_scale) {
    const int idst = chain_index(*env.context, dst);
    const int isrc = chain_index(*env.context, src);
    if (idst < 0 || isrc < 0) throw std::runtime_error("invalid parms_id in ciphertext subtraction");
    if (idst > isrc) {
        mod_switch_to_inplace(env, dst, src.parms_id(), counts);
        dst.scale() = target_scale;
        env.evaluator->sub_inplace(dst, src);
    } else if (isrc > idst) {
        Ciphertext aligned = src;
        mod_switch_to_inplace(env, aligned, dst.parms_id(), counts);
        aligned.scale() = target_scale;
        dst.scale() = target_scale;
        env.evaluator->sub_inplace(dst, aligned);
    } else {
        dst.scale() = target_scale;
        env.evaluator->sub_inplace(dst, src);
    }
    ++counts.ct_sub;
}

inline void double_inplace(HEEnv &env, Ciphertext &ct,
                           OperationCounts &counts) {
    env.evaluator->add_inplace(ct, ct);
    ++counts.ct_add;
}

inline void multiply_plain_no_rescale(HEEnv &env, Ciphertext &ct,
                                      const Plaintext &plain,
                                      OperationCounts &counts,
                                      double output_scale) {
    env.evaluator->multiply_plain_inplace(ct, plain);
    ++counts.ct_plain_multiply;
    ct.scale() = output_scale;
}

inline void rescale_to_next_inplace(HEEnv &env, Ciphertext &ct,
                                    OperationCounts &counts,
                                    double output_scale) {
    env.evaluator->rescale_to_next_inplace(ct);
    ++counts.rescale;
    ct.scale() = output_scale;
}

class LevelConstants {
public:
    explicit LevelConstants(HEEnv &env) : env_(env) {
        auto data = env_.context->first_context_data();
        while (data) {
            const int idx = data->chain_index();
            Plaintext one;
            Plaintext minus_one;
            env_.encoder->encode(1.0, data->parms_id(), env_.scale, one);
            env_.encoder->encode(-1.0, data->parms_id(), env_.scale, minus_one);
            one_[idx] = std::move(one);
            minus_one_[idx] = std::move(minus_one);
            data = data->next_context_data();
        }
    }

    const Plaintext &one(int chain) const { return one_.at(chain); }
    const Plaintext &minus_one(int chain) const { return minus_one_.at(chain); }
    std::size_t size() const { return one_.size() + minus_one_.size(); }

    void add_one_inplace(Ciphertext &ct, OperationCounts &counts) const {
        env_.evaluator->add_plain_inplace(ct, one(chain_index(*env_.context, ct)));
        ++counts.add_plain;
    }

    void add_minus_one_inplace(Ciphertext &ct, OperationCounts &counts) const {
        env_.evaluator->add_plain_inplace(ct, minus_one(chain_index(*env_.context, ct)));
        ++counts.add_plain;
    }

private:
    HEEnv &env_;
    std::unordered_map<int, Plaintext> one_;
    std::unordered_map<int, Plaintext> minus_one_;
};

using ChebPolynomial = std::vector<double>;

struct ChebDecomposition {
    int generator_degree = 0;
    std::vector<ChebPolynomial> blocks;
};

inline std::pair<ChebPolynomial, ChebPolynomial>
divide_by_chebyshev_generator(ChebPolynomial p, int k) {
    if (k <= 0) throw std::invalid_argument("Chebyshev decomposition degree must be positive");
    if (static_cast<std::size_t>(k) >= p.size()) return {{}, p};
    ChebPolynomial quotient(p.size() - static_cast<std::size_t>(k), 0.0);
    for (int i = static_cast<int>(p.size()) - 1; i >= k; --i) {
        if (p[static_cast<std::size_t>(i)] == 0.0) continue;
        if (i == k) {
            quotient[0] = p[static_cast<std::size_t>(i)];
        } else {
            quotient[static_cast<std::size_t>(i - k)] =
                2.0 * p[static_cast<std::size_t>(i)];
            p[static_cast<std::size_t>(std::abs(i - 2 * k))] -=
                p[static_cast<std::size_t>(i)];
            p[static_cast<std::size_t>(i)] = 0.0;
        }
    }
    ChebPolynomial remainder(p.begin(), p.begin() + k);
    return {quotient, remainder};
}

inline ChebDecomposition decompose_chebyshev(const ChebPolynomial &coeffs,
                                             int split) {
    ChebPolynomial p = coeffs;
    ChebDecomposition result;
    result.generator_degree = split;
    while (!p.empty()) {
        auto qr = divide_by_chebyshev_generator(std::move(p), split);
        result.blocks.push_back(std::move(qr.second));
        p = std::move(qr.first);
    }
    return result;
}

inline int auto_ps_split(int degree) {
    if (degree <= 1) return 1;
    const int log_degree = ceil_log2_int(degree + 1);
    int log_split = log_degree / 2;
    auto cost_a = [&](int ls) -> long long {
        const int other = log_degree - ls;
        return (1LL << ls) + (1LL << other) + log_degree - ls - 3;
    };
    if (log_split + 1 < log_degree && cost_a(log_split + 1) < cost_a(log_split)) {
        ++log_split;
    }
    int split = 1 << std::max(0, log_split);
    split = std::min(split, degree);
    return std::max(1, split);
}

inline int predict_ps_output_chain(int basis_target_chain, int block_count) {
    if (block_count <= 0) throw std::invalid_argument("PS block count must be positive");
    // Each baby block is first accumulated at Delta^2 and rescaled once.
    std::vector<int> nodes(static_cast<std::size_t>(block_count), basis_target_chain - 1);
    int generator_power_chain = basis_target_chain;
    while (nodes.size() > 1) {
        std::vector<int> next;
        next.reserve((nodes.size() + 1) / 2);
        for (std::size_t i = 0; i < nodes.size(); i += 2) {
            int combined = nodes[i];
            if (i + 1 < nodes.size()) {
                const int scaled = std::min(nodes[i + 1], generator_power_chain) - 1;
                combined = std::min(combined, scaled);
            }
            next.push_back(combined);
        }
        nodes = std::move(next);
        if (nodes.size() > 1) --generator_power_chain;
    }
    return nodes.front();
}

struct SlotAssignment {
    std::vector<const ProfileDef *> profiles;
    int max_degree = 0;
    bool any_warp = false;

    std::size_t size() const { return profiles.size(); }
};

inline SlotAssignment make_slot_assignment(
    std::size_t slot_count, const std::vector<std::string> &profile_names) {
    if (profile_names.empty()) throw std::invalid_argument("profile assignment is empty");
    SlotAssignment assignment;
    assignment.profiles.reserve(slot_count);
    for (std::size_t i = 0; i < slot_count; ++i) {
        const ProfileDef &profile = find_profile(profile_names[i % profile_names.size()]);
        assignment.profiles.push_back(&profile);
        assignment.max_degree = std::max(
            assignment.max_degree,
            static_cast<int>(profile.coefficients.size()) - 1);
        assignment.any_warp = assignment.any_warp || std::abs(profile.warp_a) > 0.0;
    }
    return assignment;
}

inline std::vector<std::string> preset_profiles(const std::string &preset) {
    if (preset == "gelu-r5-fast") return {"spa-gelu-r5-k3"};
    if (preset == "gelu-r5-balanced") return {"spa-gelu-r5-k7"};
    if (preset == "gelu-r5-accurate") return {"spa-gelu-r5-k11"};
    if (preset == "gelu-r20-fast") return {"spa-gelu-r20-k15"};
    if (preset == "gelu-r20-balanced") return {"spa-gelu-r20-k23"};
    if (preset == "gelu-r20-accurate") return {"spa-gelu-r20-k31"};
    if (preset == "gelu-tier-fast") {
        return {"spa-gelu-r5-k3", "spa-gelu-r20-k15"};
    }
    if (preset == "gelu-tier-balanced") {
        return {"spa-gelu-r5-k7", "spa-gelu-r20-k23"};
    }
    if (preset == "gelu-tier-accurate") {
        return {"spa-gelu-r5-k11", "spa-gelu-r20-k31"};
    }
    throw std::invalid_argument("unknown preset: " + preset);
}

inline std::vector<std::string> read_profile_map(const std::string &path) {
    std::ifstream input(path);
    if (!input) throw std::runtime_error("cannot open profile map: " + path);
    std::vector<std::string> result;
    std::string line;
    while (std::getline(input, line)) {
        const auto comment = line.find('#');
        if (comment != std::string::npos) line.erase(comment);
        std::replace(line.begin(), line.end(), ',', ' ');
        std::istringstream stream(line);
        std::string name;
        std::size_t repeat = 1;
        if (!(stream >> name)) continue;
        if (stream >> repeat) {
            if (repeat == 0) throw std::invalid_argument("profile repeat count must be positive");
        }
        (void)find_profile(name);
        for (std::size_t i = 0; i < repeat; ++i) result.push_back(name);
    }
    if (result.empty()) throw std::invalid_argument("profile map contains no assignments: " + path);
    return result;
}

// A coefficient below half a unit of the encoding scale encodes to the
// zero polynomial; multiplying by it would yield a transparent ciphertext
// (rejected by SEAL) and contributes nothing, so such terms are skipped.
inline bool encodes_to_nonzero(double value, double scale) {
    return std::abs(value) * scale >= 0.5;
}

inline bool vector_has_nonzero(const std::vector<double> &values,
                               double threshold = 1e-18) {
    return std::any_of(values.begin(), values.end(), [threshold](double x) {
        return std::abs(x) > threshold;
    });
}

inline bool vector_encodes_nonzero(const std::vector<double> &values, double scale) {
    return std::any_of(values.begin(), values.end(), [scale](double x) {
        return encodes_to_nonzero(x, scale);
    });
}

inline Plaintext encode_vector(HEEnv &env, const std::vector<double> &values,
                               parms_id_type id, double scale) {
    Plaintext plain;
    env.encoder->encode(values, id, scale, plain);
    return plain;
}

inline Plaintext encode_scalar(HEEnv &env, double value,
                               parms_id_type id, double scale) {
    Plaintext plain;
    env.encoder->encode(value, id, scale, plain);
    return plain;
}

enum class Engine { Direct, PatersonStockmeyer };
enum class InputSemantics { Normalized, Raw };

inline std::string engine_name(Engine engine) {
    return engine == Engine::Direct ? "direct" : "cheb-ps";
}

struct PreparedPlan {
    Engine engine = Engine::Direct;
    InputSemantics input_semantics = InputSemantics::Normalized;
    SlotAssignment assignment;
    int fresh_chain = -1;
    int coordinate_chain = -1;
    int basis_target_chain = -1;
    int predicted_output_chain = -1;
    int ps_split = 0;
    int ps_blocks = 0;
    int ps_rounds = 0;
    parms_id_type raw_map_id{};
    parms_id_type warp_mix_id{};
    parms_id_type basis_target_id{};

    std::optional<Plaintext> raw_map_plain;
    std::optional<Plaintext> warp_half_a_plain;
    std::optional<Plaintext> warp_lift_one_plain;
    std::vector<std::optional<Plaintext>> direct_coeff_plain;
    std::optional<Plaintext> direct_c0_plain;
    std::optional<Plaintext> linear_plain;
    std::vector<std::vector<std::optional<Plaintext>>> ps_coeff_plain;
    std::vector<std::optional<Plaintext>> ps_c0_plain;
    // Blocks whose only surviving coefficient is the constant term (possible
    // after Experiment B rounding). Such a block has no ciphertext to hold
    // the constant; it enters as y_power * c0 in the giant-step combination,
    // with c0 pre-encoded at every chain index so nothing is encoded during
    // evaluation. Indexed [block][chain_index].
    std::vector<std::map<int, Plaintext>> ps_constant_plain;
    std::optional<Plaintext> zero_plain;
};

inline PreparedPlan prepare_plan(HEEnv &env, const SlotAssignment &assignment,
                                 int fresh_chain, Engine engine,
                                 InputSemantics input_semantics,
                                 int requested_ps_split = 0) {
    PreparedPlan plan;
    plan.engine = engine;
    plan.input_semantics = input_semantics;
    plan.assignment = assignment;
    plan.fresh_chain = fresh_chain;

    const std::size_t slots = assignment.size();
    const int raw_levels = input_semantics == InputSemantics::Raw ? 2 : 1;
    const int warp_levels = assignment.any_warp ? 2 : 0;
    plan.coordinate_chain = fresh_chain - raw_levels - warp_levels;
    if (plan.coordinate_chain < 0) throw std::runtime_error("modulus chain is too short for SPA coordinate construction");

    if (input_semantics == InputSemantics::Raw) {
        const int map_input_chain = fresh_chain - 1;
        plan.raw_map_id = parms_id_at_chain_index(*env.context, map_input_chain);
        std::vector<double> map_values(slots);
        for (std::size_t i = 0; i < slots; ++i) {
            const double r = assignment.profiles[i]->radius;
            map_values[i] = 2.0 / (r * r);
        }
        plan.raw_map_plain = encode_vector(env, map_values, plan.raw_map_id, env.scale);
    }

    if (assignment.any_warp) {
        const int warp_input_chain = plan.coordinate_chain + 1;
        plan.warp_mix_id = parms_id_at_chain_index(*env.context, warp_input_chain);
        std::vector<double> half_a(slots);
        for (std::size_t i = 0; i < slots; ++i) {
            half_a[i] = 0.5 * assignment.profiles[i]->warp_a;
        }
        plan.warp_half_a_plain = encode_vector(env, half_a, plan.warp_mix_id, env.scale);
        plan.warp_lift_one_plain = encode_scalar(env, 1.0, plan.warp_mix_id, env.scale);
    }

    int basis_depth = 0;
    if (engine == Engine::Direct) {
        basis_depth = ceil_log2_int(assignment.max_degree);
    } else {
        plan.ps_split = requested_ps_split > 0
                            ? requested_ps_split
                            : auto_ps_split(assignment.max_degree);
        // A split of degree+1 is useful for a single baby block, e.g. the
        // plaintext-aligned k=3/PS4 profile. In that case no giant-step
        // generator is evaluated.
        if (plan.ps_split < 1 || plan.ps_split > assignment.max_degree + 1) {
            throw std::invalid_argument("invalid Paterson-Stockmeyer split");
        }
        basis_depth = ceil_log2_int(plan.ps_split);
    }
    plan.basis_target_chain = plan.coordinate_chain - basis_depth;
    if (plan.basis_target_chain < 1) {
        throw std::runtime_error("modulus chain is too short for the requested SPA basis depth");
    }
    plan.basis_target_id = parms_id_at_chain_index(*env.context, plan.basis_target_chain);

    std::vector<double> linear_values(slots);
    for (std::size_t i = 0; i < slots; ++i) {
        linear_values[i] = input_semantics == InputSemantics::Normalized
                               ? 0.5 * assignment.profiles[i]->radius
                               : 0.5;
    }
    plan.linear_plain = encode_vector(env, linear_values, plan.basis_target_id, env.scale);
    plan.zero_plain = encode_scalar(env, 0.0, plan.basis_target_id, env.scale);

    if (engine == Engine::Direct) {
        const int degree = assignment.max_degree;
        plan.direct_coeff_plain.resize(static_cast<std::size_t>(degree + 1));
        for (int j = 1; j <= degree; ++j) {
            std::vector<double> packed(slots, 0.0);
            for (std::size_t s = 0; s < slots; ++s) {
                const auto &coeffs = assignment.profiles[s]->coefficients;
                if (j < static_cast<int>(coeffs.size())) packed[s] = coeffs[static_cast<std::size_t>(j)];
            }
            if (vector_encodes_nonzero(packed, env.scale)) {
                plan.direct_coeff_plain[static_cast<std::size_t>(j)] =
                    encode_vector(env, packed, plan.basis_target_id, env.scale);
            }
        }
        std::vector<double> c0(slots, 0.0);
        for (std::size_t s = 0; s < slots; ++s) {
            c0[s] = assignment.profiles[s]->coefficients[0];
        }
        plan.direct_c0_plain = encode_vector(
            env, c0, plan.basis_target_id, env.scale * env.scale);
        plan.predicted_output_chain = plan.basis_target_chain - 1;
    } else {
        std::map<const ProfileDef *, ChebDecomposition> unique_decompositions;
        int max_blocks = 0;
        for (const auto *profile : assignment.profiles) {
            if (unique_decompositions.find(profile) == unique_decompositions.end()) {
                auto decomposition = decompose_chebyshev(profile->coefficients, plan.ps_split);
                max_blocks = std::max(max_blocks, static_cast<int>(decomposition.blocks.size()));
                unique_decompositions.emplace(profile, std::move(decomposition));
            }
        }
        plan.ps_blocks = max_blocks;
        plan.ps_rounds = ceil_log2_int(std::max(1, max_blocks));
        plan.ps_coeff_plain.resize(static_cast<std::size_t>(max_blocks));
        plan.ps_c0_plain.resize(static_cast<std::size_t>(max_blocks));
        plan.ps_constant_plain.resize(static_cast<std::size_t>(max_blocks));

        for (int block = 0; block < max_blocks; ++block) {
            bool block_has_terms = block == 0;  // block 0 always carries the linear term
            plan.ps_coeff_plain[static_cast<std::size_t>(block)].resize(
                static_cast<std::size_t>(plan.ps_split));
            for (int j = 1; j < plan.ps_split; ++j) {
                std::vector<double> packed(slots, 0.0);
                for (std::size_t s = 0; s < slots; ++s) {
                    const auto &decomp = unique_decompositions.at(assignment.profiles[s]);
                    if (block < static_cast<int>(decomp.blocks.size()) &&
                        j < static_cast<int>(decomp.blocks[static_cast<std::size_t>(block)].size())) {
                        packed[s] = decomp.blocks[static_cast<std::size_t>(block)][static_cast<std::size_t>(j)];
                    }
                }
                if (vector_encodes_nonzero(packed, env.scale)) {
                    plan.ps_coeff_plain[static_cast<std::size_t>(block)][static_cast<std::size_t>(j)] =
                        encode_vector(env, packed, plan.basis_target_id, env.scale);
                    block_has_terms = true;
                }
            }
            std::vector<double> c0(slots, 0.0);
            for (std::size_t s = 0; s < slots; ++s) {
                const auto &decomp = unique_decompositions.at(assignment.profiles[s]);
                if (block < static_cast<int>(decomp.blocks.size()) &&
                    !decomp.blocks[static_cast<std::size_t>(block)].empty()) {
                    c0[s] = decomp.blocks[static_cast<std::size_t>(block)][0];
                }
            }
            if (block_has_terms) {
                if (vector_encodes_nonzero(c0, env.scale * env.scale)) {
                    plan.ps_c0_plain[static_cast<std::size_t>(block)] = encode_vector(
                        env, c0, plan.basis_target_id, env.scale * env.scale);
                }
            } else if (vector_encodes_nonzero(c0, env.scale)) {
                auto &table = plan.ps_constant_plain[static_cast<std::size_t>(block)];
                auto data = env.context->first_context_data();
                while (data) {
                    table[data->chain_index()] = encode_vector(env, c0, data->parms_id(), env.scale);
                    data = data->next_context_data();
                }
            }
        }
        plan.predicted_output_chain = predict_ps_output_chain(
            plan.basis_target_chain, plan.ps_blocks);
    }

    if (plan.predicted_output_chain < 0) {
        throw std::runtime_error("modulus chain is too short for the requested SPA evaluator");
    }
    return plan;
}

class ChebDAG {
public:
    ChebDAG(HEEnv &env, const Ciphertext &base, LevelConstants &constants,
            OperationCounts &counts)
        : env_(env), constants_(constants), counts_(counts) {
        cache_.resize(2);
        cache_[1] = std::make_unique<Ciphertext>(base);
    }

    const Ciphertext &T(int n) {
        if (n <= 0) throw std::invalid_argument("T(0) is represented as a plaintext constant");
        if (static_cast<std::size_t>(n) >= cache_.size()) cache_.resize(static_cast<std::size_t>(n + 1));
        if (cache_[static_cast<std::size_t>(n)]) return *cache_[static_cast<std::size_t>(n)];

        Ciphertext out;
        if ((n & 1) == 0) {
            const Ciphertext &half = T(n / 2);
            out = square_and_rescale(env_, half, counts_, env_.scale);
            double_inplace(env_, out, counts_);
            constants_.add_minus_one_inplace(out, counts_);
        } else {
            const Ciphertext &left = T((n - 1) / 2);
            const Ciphertext &right = T((n + 1) / 2);
            out = multiply_and_rescale(env_, left, right, counts_, env_.scale);
            double_inplace(env_, out, counts_);
            sub_cipher_inplace(env_, out, T(1), counts_, env_.scale);
        }
        cache_[static_cast<std::size_t>(n)] = std::make_unique<Ciphertext>(std::move(out));
        return *cache_[static_cast<std::size_t>(n)];
    }

private:
    HEEnv &env_;
    LevelConstants &constants_;
    OperationCounts &counts_;
    std::vector<std::unique_ptr<Ciphertext>> cache_;
};

inline Ciphertext construct_coordinate(HEEnv &env, const Ciphertext &input,
                                       const PreparedPlan &plan,
                                       LevelConstants &constants,
                                       OperationCounts &counts) {
    Ciphertext t;
    if (plan.input_semantics == InputSemantics::Normalized) {
        Ciphertext z2 = square_and_rescale(env, input, counts, env.scale);
        t = std::move(z2);
        double_inplace(env, t, counts);
        constants.add_minus_one_inplace(t, counts);
    } else {
        Ciphertext x2 = square_and_rescale(env, input, counts, env.scale);
        if (!plan.raw_map_plain) throw std::logic_error("raw SPA plan lacks the x^2 mapping plaintext");
        multiply_plain_no_rescale(env, x2, *plan.raw_map_plain, counts,
                                  env.scale * env.scale);
        rescale_to_next_inplace(env, x2, counts, env.scale);
        t = std::move(x2);
        constants.add_minus_one_inplace(t, counts);
    }

    if (!plan.assignment.any_warp) return t;

    Ciphertext t2 = square_and_rescale(env, t, counts, env.scale);
    Ciphertext t_aligned = t;
    mod_switch_to_inplace(env, t_aligned, t2.parms_id(), counts);
    t_aligned.scale() = env.scale;

    Ciphertext one_minus_t2 = t2;
    env.evaluator->negate_inplace(one_minus_t2);
    constants.add_one_inplace(one_minus_t2, counts);

    if (!plan.warp_half_a_plain || !plan.warp_lift_one_plain) {
        throw std::logic_error("warped SPA plan lacks packed warp plaintexts");
    }
    Ciphertext warp_term = one_minus_t2;
    multiply_plain_no_rescale(env, warp_term, *plan.warp_half_a_plain,
                              counts, env.scale * env.scale);
    Ciphertext t_term = t_aligned;
    multiply_plain_no_rescale(env, t_term, *plan.warp_lift_one_plain,
                              counts, env.scale * env.scale);
    env.evaluator->add_inplace(t_term, warp_term);
    ++counts.ct_add;
    rescale_to_next_inplace(env, t_term, counts, env.scale);
    return t_term;
}

inline void add_weighted_term(HEEnv &env, Ciphertext &acc, bool &started,
                              const Ciphertext &source,
                              const Plaintext &coefficient,
                              parms_id_type target_id,
                              OperationCounts &counts) {
    Ciphertext term;
    if (source.parms_id() == target_id) {
        // Use the out-of-place API directly instead of deep-copying source and
        // then multiplying in place.
        env.evaluator->multiply_plain(source, coefficient, term);
        ++counts.ct_plain_multiply;
    } else {
        Ciphertext aligned = source;
        mod_switch_to_inplace(env, aligned, target_id, counts);
        aligned.scale() = env.scale;
        env.evaluator->multiply_plain(aligned, coefficient, term);
        ++counts.ct_plain_multiply;
    }
    term.scale() = env.scale * env.scale;
    if (!started) {
        acc = std::move(term);
        started = true;
    } else {
        env.evaluator->add_inplace(acc, term);
        ++counts.ct_add;
    }
}

inline Ciphertext evaluate_direct(HEEnv &env, const Ciphertext &input,
                                  const PreparedPlan &plan,
                                  LevelConstants &constants,
                                  OperationCounts &counts) {
    Ciphertext coordinate = construct_coordinate(env, input, plan, constants, counts);
    ChebDAG dag(env, coordinate, constants, counts);
    // Force the deepest basis node first; the remaining T_i reuse its dependencies.
    (void)dag.T(plan.assignment.max_degree);

    Ciphertext acc;
    bool started = false;
    for (int i = 1; i <= plan.assignment.max_degree; ++i) {
        const auto &plain = plan.direct_coeff_plain.at(static_cast<std::size_t>(i));
        if (!plain) continue;
        add_weighted_term(env, acc, started, dag.T(i), *plain,
                          plan.basis_target_id, counts);
    }
    if (!plan.linear_plain) throw std::logic_error("SPA plan lacks the linear plaintext");
    add_weighted_term(env, acc, started, input, *plan.linear_plain,
                      plan.basis_target_id, counts);
    if (!started) throw std::runtime_error("empty SPA direct accumulator");
    if (plan.direct_c0_plain) {
        env.evaluator->add_plain_inplace(acc, *plan.direct_c0_plain);
        ++counts.add_plain;
    }
    rescale_to_next_inplace(env, acc, counts, env.scale);
    return acc;
}

inline std::optional<Ciphertext> evaluate_baby_block(
    HEEnv &env, const Ciphertext &input, ChebDAG &dag,
    const PreparedPlan &plan, int block, OperationCounts &counts) {
    Ciphertext acc;
    bool started = false;
    if (block == 0) {
        if (!plan.linear_plain) throw std::logic_error("SPA plan lacks the linear plaintext");
        add_weighted_term(env, acc, started, input, *plan.linear_plain,
                          plan.basis_target_id, counts);
    }
    const auto &block_coeffs = plan.ps_coeff_plain.at(static_cast<std::size_t>(block));
    for (int j = 1; j < plan.ps_split; ++j) {
        const auto &plain = block_coeffs.at(static_cast<std::size_t>(j));
        if (!plain) continue;
        add_weighted_term(env, acc, started, dag.T(j), *plain,
                          plan.basis_target_id, counts);
    }
    const auto &c0 = plan.ps_c0_plain.at(static_cast<std::size_t>(block));
    if (!started) {
        // No ciphertext term survives in this block (Experiment B's coarsely
        // rounded profiles, or coefficients below the encoding resolution).
        // A product with an encoded zero would be a transparent ciphertext,
        // which SEAL rejects by design, and an implementation would not
        // compute it anyway. The block is reported absent; a surviving
        // constant term is applied by evaluate_ps as y_power * c0. Skipped
        // terms lower the ct-plain multiplication count, and a vanished
        // trailing block can save the last giant-step product, so the
        // recorded consumed_levels may be lower than for the unrounded fit.
        return std::nullopt;
    }
    if (c0) {
        env.evaluator->add_plain_inplace(acc, *c0);
        ++counts.add_plain;
    }
    rescale_to_next_inplace(env, acc, counts, env.scale);
    return acc;
}

inline Ciphertext evaluate_ps(HEEnv &env, const Ciphertext &input,
                              const PreparedPlan &plan,
                              LevelConstants &constants,
                              OperationCounts &counts) {
    Ciphertext coordinate = construct_coordinate(env, input, plan, constants, counts);
    ChebDAG dag(env, coordinate, constants, counts);

    std::vector<std::optional<Ciphertext>> nodes;
    // Block index of a pending constant-only block at each node position, or -1.
    std::vector<int> pending;
    nodes.reserve(static_cast<std::size_t>(plan.ps_blocks));
    for (int block = 0; block < plan.ps_blocks; ++block) {
        nodes.push_back(evaluate_baby_block(env, input, dag, plan, block, counts));
        const bool constant_only = !nodes.back() &&
            block < static_cast<int>(plan.ps_constant_plain.size()) &&
            !plan.ps_constant_plain[static_cast<std::size_t>(block)].empty();
        pending.push_back(constant_only ? block : -1);
    }

    if (nodes.empty() || !nodes[0]) throw std::runtime_error("empty SPA PS result");
    if (nodes.size() == 1) return std::move(*nodes[0]);

    const Ciphertext &generator = dag.T(plan.ps_split);
    Ciphertext y_power = generator;
    while (nodes.size() > 1) {
        std::vector<std::optional<Ciphertext>> next;
        std::vector<int> next_pending;
        next.reserve((nodes.size() + 1) / 2);
        for (std::size_t i = 0; i < nodes.size(); i += 2) {
            std::optional<Ciphertext> combined;
            int carried = -1;
            if (nodes[i]) combined = std::move(*nodes[i]);
            else carried = pending[i];
            if (i + 1 < nodes.size()) {
                std::optional<Ciphertext> scaled;
                if (nodes[i + 1]) {
                    scaled = multiply_and_rescale(env, *nodes[i + 1], y_power, counts, env.scale);
                } else if (pending[i + 1] >= 0) {
                    // y_power * c0 with c0 pre-encoded at y_power's level.
                    const auto &table = plan.ps_constant_plain[static_cast<std::size_t>(pending[i + 1])];
                    Ciphertext product;
                    bool started = false;
                    add_weighted_term(env, product, started, y_power,
                                      table.at(chain_index(*env.context, y_power)),
                                      y_power.parms_id(), counts);
                    rescale_to_next_inplace(env, product, counts, env.scale);
                    scaled = std::move(product);
                }
                if (scaled) {
                    if (combined) {
                        add_cipher_inplace(env, *combined, *scaled, counts, env.scale);
                    } else if (carried >= 0) {
                        throw std::runtime_error("SPA PS: constant block below a live block is unsupported");
                    } else {
                        combined = std::move(*scaled);
                    }
                }
            }
            next.push_back(std::move(combined));
            next_pending.push_back(next.back() ? -1 : carried);
        }
        nodes = std::move(next);
        pending = std::move(next_pending);
        if (nodes.size() > 1) {
            y_power = square_and_rescale(env, y_power, counts, env.scale);
        }
    }
    if (nodes.empty() || !nodes[0]) throw std::runtime_error("empty SPA PS result");
    return std::move(*nodes[0]);
}

inline Ciphertext evaluate(HEEnv &env, const Ciphertext &input,
                           const PreparedPlan &plan,
                           LevelConstants &constants,
                           OperationCounts &counts) {
    if (plan.engine == Engine::Direct) {
        return evaluate_direct(env, input, plan, constants, counts);
    }
    return evaluate_ps(env, input, plan, constants, counts);
}

inline double gelu_exact(double x) {
    return 0.5 * x * (1.0 + std::erf(x / std::sqrt(2.0)));
}

inline double cheb_eval(double variable, const std::vector<double> &coeffs) {
    const int degree = static_cast<int>(coeffs.size()) - 1;
    double b1 = 0.0;
    double b2 = 0.0;
    for (int k = degree; k >= 1; --k) {
        const double b0 = 2.0 * variable * b1 - b2 + coeffs[static_cast<std::size_t>(k)];
        b2 = b1;
        b1 = b0;
    }
    return variable * b1 - b2 + coeffs[0];
}

inline double profile_plain_eval(double x, const ProfileDef &profile) {
    const double t = 2.0 * x * x / (profile.radius * profile.radius) - 1.0;
    const double u = t + 0.5 * profile.warp_a * (1.0 - t * t);
    return 0.5 * x + cheb_eval(u, profile.coefficients);
}

struct Metrics {
    double max_abs = 0.0;
    double mean_abs = 0.0;
    double rmse = 0.0;
    std::size_t max_index = 0;
};

inline Metrics compute_metrics(const std::vector<double> &lhs,
                               const std::vector<double> &rhs,
                               std::size_t count) {
    if (count == 0 || lhs.size() < count || rhs.size() < count) {
        throw std::invalid_argument("invalid metric vector length");
    }
    Metrics metrics;
    long double sum_abs = 0.0L;
    long double sum_sq = 0.0L;
    for (std::size_t i = 0; i < count; ++i) {
        const double error = lhs[i] - rhs[i];
        const double abs_error = std::abs(error);
        if (abs_error > metrics.max_abs) {
            metrics.max_abs = abs_error;
            metrics.max_index = i;
        }
        sum_abs += abs_error;
        sum_sq += static_cast<long double>(error) * error;
    }
    metrics.mean_abs = static_cast<double>(sum_abs / count);
    metrics.rmse = std::sqrt(static_cast<double>(sum_sq / count));
    return metrics;
}

inline std::map<std::string, std::size_t> profile_histogram(
    const SlotAssignment &assignment, std::size_t count) {
    std::map<std::string, std::size_t> histogram;
    for (std::size_t i = 0; i < std::min(count, assignment.size()); ++i) {
        ++histogram[assignment.profiles[i]->name];
    }
    return histogram;
}

} // namespace spa
