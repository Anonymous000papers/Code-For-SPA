// Host-side evaluation of the imported MOAI model profiles (moai_model::Profile).
//
// plain_host()   evaluates the profile as the plaintext model defines it
//                (activation_approximations.evaluate_moai): Cheon-Kim-Park
//                stages outermost first, t = y / B, Clenshaw for the factor
//                polynomial, then 0.5 * x * (1 + P). This is P_model-host and
//                the benchmark's host reference for E_HE.
// circuit_host() evaluates the same function in the operation order of the
//                ciphertext circuit (MoaiModelMethod): per stage y2 = y*y,
//                cy = c*y, y3c = y2*cy, y = y - y3c; t = y * (1/B); the
//                Chebyshev basis by the product tree of chebyshev_balanced
//                (T_n = 2 T_a T_b - T_{b-a}, a = n/2, b = n - a), the linear
//                combination in index order, then (x*0.5) * (1 + P). This is
//                P_cipher-host, used only by the consistency check.
// Both are pure double arithmetic; neither models CKKS.
#pragma once

#include <cmath>
#include <map>
#include <vector>

#ifndef SPA_MOAI_MODEL_HEADER
#define SPA_MOAI_MODEL_HEADER "moai_model_profiles.hpp"
#endif
#include SPA_MOAI_MODEL_HEADER

namespace moai_model {

inline double stage_constant(const Profile &p, int r) {
    const double scale = p.base_radius * std::pow(p.extension_factor, r);
    return 4.0 / (27.0 * scale * scale);
}

// The model's own formula: y - (4/(27 s^2)) * (y*y*y).
inline double extension_model(double x, const Profile &p) {
    double y = x;
    for (int r = p.extension_stages - 1; r >= 0; --r) {
        const double scale = p.base_radius * std::pow(p.extension_factor, r);
        y = y - (4.0 / (27.0 * scale * scale)) * (y * y * y);
    }
    return y;
}

// The circuit's order: y2 = y*y, cy = c*y, y3c = y2*cy, y = y - y3c.
inline double extension_circuit(double x, const Profile &p) {
    double y = x;
    for (int r = p.extension_stages - 1; r >= 0; --r) {
        const double c = stage_constant(p, r);
        const double y2 = y * y;
        const double cy = c * y;
        const double y3c = y2 * cy;
        y = y - y3c;
    }
    return y;
}

inline double clenshaw(double t, const std::vector<double> &c) {
    double b1 = 0.0, b2 = 0.0;
    for (int i = static_cast<int>(c.size()) - 1; i >= 1; --i) {
        const double b = 2.0 * t * b1 - b2 + c[static_cast<std::size_t>(i)];
        b2 = b1;
        b1 = b;
    }
    return t * b1 - b2 + c[0];
}

inline double plain_host(double x, const Profile &p) {
    const double y = extension_model(x, p);
    const double factor = clenshaw(y * (1.0 / p.base_radius), p.coefficients);
    return 0.5 * x * (1.0 + factor);
}

// Product-tree Chebyshev basis as built by chebyshev_balanced.
inline double basis_term(int n, double t, std::map<int, double> &cache) {
    auto found = cache.find(n);
    if (found != cache.end()) return found->second;
    double v;
    if (n == 1) {
        v = t;
    } else {
        const int a = n / 2, b = n - a;
        const double left = basis_term(a, t, cache);
        const double right = basis_term(b, t, cache);
        v = left * right;
        v = v + v;
        v = (a == b) ? v - 1.0 : v - t;  // b - a is 0 or 1
    }
    cache[n] = v;
    return v;
}

inline double circuit_host(double x, const Profile &p) {
    const double y = extension_circuit(x, p);
    const double t = y * (1.0 / p.base_radius);
    std::map<int, double> cache;
    const int degree = static_cast<int>(p.coefficients.size()) - 1;
    double result = 0.0;
    bool started = false;
    for (int i = 1; i <= degree; ++i) {
        const double ci = p.coefficients[static_cast<std::size_t>(i)];
        if (ci == 0.0) continue;
        const double term = basis_term(i, t, cache) * ci;
        result = started ? result + term : term;
        started = true;
    }
    result = result + p.coefficients[0];
    const double half_x = x * 0.5;
    return half_x * (1.0 + result);
}

}  // namespace moai_model
