#pragma once

#include "gelu_baseline_profiles.hpp"
#include <algorithm>
#include <cmath>
#include <stdexcept>
#include <vector>

namespace euston_circuit {

struct Config {
    double radius = 5.0;
    double sign_scale = 6.0;
    double beta = 1.702;
    int g_rounds = 3;
    int f_rounds = 3;
    int exp_squarings = 1;
    int inverse_iterations = 3;
    double inverse_divisor = 2.0;

    int consumed_levels() const {
        // norm + 4*(dg+df) + abs; two exp paths run in parallel.
        // In the Goldschmidt product q is squared on its own branch: the
        // product consumes iterations+1 levels (not 2*iterations).
        return 4 * (g_rounds + f_rounds) + 12 + exp_squarings + inverse_iterations;
    }
};

inline Config make_config(double radius, double sign_scale=0.0, int tau=-1,
                          int dg=3, int df=3, int inverse_iterations=3) {
    if (!std::isfinite(radius) || radius <= 0.0 || radius > 20.0 + 1e-12)
        throw std::invalid_argument("Euston public radius must be in (0,20]");
    Config c;
    c.radius=radius;
    c.sign_scale=sign_scale == 0.0 ? 1.2 * radius : sign_scale;
    c.g_rounds=dg;
    c.f_rounds=df;
    c.inverse_iterations=inverse_iterations;
    const int minimum_tau=std::max(0, static_cast<int>(std::ceil(std::log2(c.beta*radius/5.0))));
    c.exp_squarings=tau < 0 ? minimum_tau : tau;
    if (!std::isfinite(c.sign_scale) || c.sign_scale < radius)
        throw std::invalid_argument("Euston sign normalization must cover the public radius");
    if (dg < 1 || df < 1 || dg > 6 || df > 6 || inverse_iterations < 1 || inverse_iterations > 8)
        throw std::invalid_argument("invalid Euston composition/reciprocal iterations");
    if (c.exp_squarings < minimum_tau || c.exp_squarings > 10)
        throw std::invalid_argument("Euston exp tau does not map the public domain into [-5,0]");
    return c;
}

inline const std::vector<double>& f_coefficients() {
    static const std::vector<double> c={0,315./128,0,-420./128,0,378./128,0,-180./128,0,35./128};
    return c;
}
inline const std::vector<double>& g_coefficients() {
    static const std::vector<double> c={0,5850./1024,0,-34974./1024,0,97015./1024,0,-113492./1024,0,46623./1024};
    return c;
}
inline const std::vector<double>& exp_coefficients() {
    static const std::vector<double> c(gelu_range_profiles::euston_exp.begin(),
                                     gelu_range_profiles::euston_exp.end());
    return c;
}

// Ops must provide arithmetic only. No secret key, decryption, clipping,
// ciphertext comparison or native transcendental call is part of this graph.
template<class Ops>
typename Ops::Value sign(Ops& op, const typename Ops::Value& x, const Config& c) {
    auto s=op.constant_multiply(x, 1.0/c.sign_scale);
    for (int i=0;i<c.g_rounds;++i) s=op.odd9(s,g_coefficients());
    for (int i=0;i<c.f_rounds;++i) s=op.odd9(s,f_coefficients());
    return s;
}

template<class Ops>
typename Ops::Value exp_scaled(Ops& op, const typename Ops::Value& x,
                               double factor, const Config& c) {
    auto u=op.constant_multiply(x,std::ldexp(factor,-c.exp_squarings));
    auto e=op.polynomial(u,exp_coefficients());
    for (int i=0;i<c.exp_squarings;++i) e=op.square(e);
    return e;
}

template<class Ops>
typename Ops::Value inverse(Ops& op, const typename Ops::Value& d, const Config& c) {
    // d = 1 + exp(-beta*a). Dividing by two keeps q=1-d/2 in [0,1/2]
    // on the ideal domain, INCLUDING a=0. The old unnormalised seed had
    // |1-d|=1 at a=0 and was outside the strict convergence region.
    auto u=op.constant_multiply(d,-1.0/c.inverse_divisor);
    auto q=op.add_constant(u,1.0);
    auto r=op.add_constant(q,1.0);
    for (int i=0;i<c.inverse_iterations;++i) {
        q=op.square(q);
        r=op.multiply(r,op.add_constant(q,1.0));
    }
    return op.constant_multiply(r,1.0/c.inverse_divisor);
}

template<class Ops>
typename Ops::Value main_path(Ops& op, const typename Ops::Value& x,
                             const typename Ops::Value& s, const Config& c) {
    auto a=op.multiply(x,s);
    auto e=exp_scaled(op,a,-c.beta,c);
    auto reciprocal=inverse(op,op.add_constant(e,1.0),c);
    auto g=op.multiply(a,reciprocal);
    // Preserve the released sign-uniform recombination, rather than using
    // plaintext abs/sign/where or substituting a direct GELU polynomial.
    auto b=op.multiply(op.add_constant(s,-1.0),a);
    auto rect=op.multiply(s,exp_scaled(op,b,c.beta/2.0,c));
    return op.multiply(g,rect);
}

struct DoubleOps {
    using Value=double;
    double constant_multiply(double x,double c) { return x*c; }
    double multiply(double x,double y) { return x*y; }
    double square(double x) { return x*x; }
    double add_constant(double x,double c) { return x+c; }
    double polynomial(double x,const std::vector<double>& coefficients) {
        double r=0.;
        for (auto it=coefficients.rbegin();it!=coefficients.rend();++it) r=r*x+*it;
        return r;
    }
    double odd9(double x,const std::vector<double>& c) {
        double x2=x*x;
        return x*(c[1]+x2*(c[3]+x2*(c[5]+x2*(c[7]+x2*c[9]))));
    }
};
inline double plain(double x,const Config& c) {
    DoubleOps op;
    auto s=sign(op,x,c);
    return main_path(op,x,s,c);
}

struct Diagnostics {
    double exp_argument_min=0.,exp_argument_max=0.;
    double denominator_min=3.,denominator_max=0.;
    double max_error_gelu=0.,max_error_quickgelu=0.;
};
inline Diagnostics validate_public_grid(const Config &c, int points=32769) {
    if(points<3) throw std::invalid_argument("public grid requires at least 3 points");
    Diagnostics report;
    DoubleOps op;
    for(int i=0;i<points;++i) {
        const double x=-c.radius+2*c.radius*i/(points-1);
        const double s=sign(op,x,c),a=x*s;
        const double u=std::ldexp(-c.beta*a,-c.exp_squarings);
        const double v=std::ldexp(c.beta*(s-1)*a/2,-c.exp_squarings);
        report.exp_argument_min=std::min({report.exp_argument_min,u,v});
        report.exp_argument_max=std::max({report.exp_argument_max,u,v});
        const double d=1.+exp_scaled(op,a,-c.beta,c);
        report.denominator_min=std::min(report.denominator_min,d);
        report.denominator_max=std::max(report.denominator_max,d);
        const double y=main_path(op,x,s,c);
        if(!std::isfinite(y) || !std::isfinite(s) || a < -1e-10)
            throw std::invalid_argument("Euston public arithmetic preflight failed");
        report.max_error_gelu=std::max(report.max_error_gelu,
            std::abs(y-.5*x*(1.+std::erf(x/std::sqrt(2.)))));
        report.max_error_quickgelu=std::max(report.max_error_quickgelu,
            std::abs(y-x/(1.+std::exp(-c.beta*x))));
    }
    if(report.exp_argument_min < -5.-1e-9 || report.exp_argument_max>1e-9 ||
       report.denominator_min < 1.-1e-9 || report.denominator_max>2.+1e-9)
        throw std::invalid_argument("Euston public preflight: exponential or inverse domain not covered");
    return report; // Numerical grid check, not a continuous-domain certificate.
}

} // namespace euston_circuit
