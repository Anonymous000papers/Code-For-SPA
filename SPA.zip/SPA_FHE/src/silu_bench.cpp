#include "spa_ckks_core.hpp"
#include "spa_silu_profiles.hpp"
#include "silu_baseline_profiles.hpp"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <memory>
#include <numeric>
#include <optional>
#include <random>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <unordered_set>
#include <utility>
#include <vector>

namespace fs = std::filesystem;
using namespace std;
using namespace seal;
using namespace spa;

namespace silu_bench {

struct Args {
    string methods = "spa-k39,spa-k63,spa-k87,orion,ensi,sylph,thor";
    string input_mode = "grid";
    size_t slots_to_test = 32768;
    int warmups = 2;
    int repeats = 10;
    int cooldown_ms = 0;
    int middle_primes = 16;
    int prime_bits = 46;
    uint64_t seed = 12345;
    uint64_t order_seed = 20260831;
    double lo = -5.0;
    double hi = 5.0;
    double scale_bits = 46.0;
    bool secure128 = true;
    bool randomize_order = true;
    bool verbose_samples = false;
    bool allow_out_of_domain = false;
    bool list_methods = false;
    string csv_out;
    string samples_csv;
    string run_label = "run0";
};

void print_help() {
    cout
        << "CKKS SiLU microbenchmark\n\n"
        << "Methods:\n"
        << "  --methods CSV                 Comma-separated method IDs\n"
        << "  --method ID                   Single-method alias\n"
        << "  --list-methods                Print supported IDs\n"
        << "  SPA IDs: spa-k39, spa-k63, spa-k87\n"
        << "  The active R5 or R20 profile is selected from --range.\n\n"
        << "Common input and scheduling:\n"
        << "  --range LO HI                 Common raw-x range (default -5 5)\n"
        << "  --input grid|random           Same full-slot input for every method\n"
        << "  --slots N                     Slots used for errors (N<=32768)\n"
        << "  --seed N                      Random-input seed\n"
        << "  --order-seed N                Method-order shuffle seed\n"
        << "  --fixed-order                 Disable per-round randomization\n"
        << "  --verbose-samples             Print each timing sample\n"
        << "  --cooldown-ms N               Pause between timed methods\n\n"
        << "CKKS and benchmark policy:\n"
        << "  --warmup N                    Untimed warm-up rounds\n"
        << "  --repeat N                    Timed randomized rounds\n"
        << "  --levels N                    Number of middle primes (default 16)\n"
        << "  --scale-bits B                CKKS scale exponent (default 46)\n"
        << "  --prime-bits B                Middle-prime size in bits (default 46)\n"
        << "  --allow-out-of-domain         Permit labelled stress tests\n"
        << "  --no-sec                      Disable SEAL security validation (smoke only)\n\n"
        << "Output:\n"
        << "  --csv-out FILE                Append one summary row per method\n"
        << "  --samples-csv FILE            Append every timed sample\n"
        << "  --run-label TEXT              Label written to CSV files\n"
        << "  -h, --help\n\n"
        << "Coefficient generation, fixed plaintext encoding, input encryption, output\n"
        << "decryption, metrics, and CSV output are outside timing. SPA coefficients\n"
        << "are independently refitted for R5 and R20 by scripts/generate_silu_spa_profiles.py.\n";
}

vector<string> split_csv(const string &value) {
    vector<string> result;
    string token;
    istringstream input(value);
    while (getline(input, token, ',')) {
        const auto first = token.find_first_not_of(" \t\r\n");
        if (first == string::npos) continue;
        const auto last = token.find_last_not_of(" \t\r\n");
        result.push_back(token.substr(first, last - first + 1));
    }
    if (result.empty()) throw invalid_argument("method list is empty");
    return result;
}

Args parse_args(int argc, char **argv) {
    Args args;
    for (int i = 1; i < argc; ++i) {
        const string flag(argv[i]);
        auto need = [&](const string &name) -> string {
            if (i + 1 >= argc) throw invalid_argument("missing value for " + name);
            return string(argv[++i]);
        };
        if (flag == "--methods" || flag == "--method") args.methods = need(flag);
        else if (flag == "--range") {
            args.lo = stod(need("--range LO"));
            args.hi = stod(need("--range HI"));
        } else if (flag == "--input") args.input_mode = need(flag);
        else if (flag == "--slots") args.slots_to_test = static_cast<size_t>(stoull(need(flag)));
        else if (flag == "--warmup") args.warmups = stoi(need(flag));
        else if (flag == "--repeat" || flag == "--repeats") args.repeats = stoi(need(flag));
        else if (flag == "--cooldown-ms") args.cooldown_ms = stoi(need(flag));
        else if (flag == "--levels") args.middle_primes = stoi(need(flag));
        else if (flag == "--prime-bits") args.prime_bits = stoi(need(flag));
        else if (flag == "--seed") args.seed = static_cast<uint64_t>(stoull(need(flag)));
        else if (flag == "--order-seed") args.order_seed = static_cast<uint64_t>(stoull(need(flag)));
        else if (flag == "--scale-bits") args.scale_bits = stod(need(flag));
        else if (flag == "--fixed-order") args.randomize_order = false;
        else if (flag == "--verbose-samples") args.verbose_samples = true;
        else if (flag == "--allow-out-of-domain") args.allow_out_of_domain = true;
        else if (flag == "--no-sec") args.secure128 = false;
        else if (flag == "--csv-out") args.csv_out = need(flag);
        else if (flag == "--samples-csv") args.samples_csv = need(flag);
        else if (flag == "--run-label") args.run_label = need(flag);
        else if (flag == "--list-methods") args.list_methods = true;
        else if (flag == "--help" || flag == "-h") {
            print_help();
            exit(0);
        } else {
            throw invalid_argument("unknown argument: " + flag);
        }
    }
    if (!(args.lo < args.hi)) throw invalid_argument("--range requires LO < HI");
    if (args.input_mode != "grid" && args.input_mode != "random") {
        throw invalid_argument("--input must be grid or random");
    }
    if (args.slots_to_test == 0 || args.slots_to_test > 32768) {
        throw invalid_argument("--slots must be in [1,32768]");
    }
    if (args.warmups < 0 || args.repeats < 1 || args.cooldown_ms < 0) {
        throw invalid_argument("warmup/cooldown must be nonnegative and repeat positive");
    }
    if (args.middle_primes < 6) throw invalid_argument("--levels is too short for this benchmark");
    if (args.prime_bits < 35 || args.prime_bits > 55) {
        throw invalid_argument("--prime-bits must be in [35,55]");
    }
    if (abs(args.scale_bits - static_cast<double>(args.prime_bits)) > 1.0) {
        throw invalid_argument("--scale-bits and --prime-bits must differ by at most one bit");
    }
    return args;
}

void print_supported_methods() {
    for (const auto *method : spa_silu::builtin_methods()) {
        cout << method->id << '\n';
    }
    cout
        << "orion\n"
        << "orion-wide\n"
        << "ensi\n"
        << "sylph\n"
        << "thor\n"
        << "thor-wide\n";
}

struct MethodCounts {
    OperationCounts he;
    uint64_t dynamic_plain_encode = 0;
    uint64_t encrypt = 0;
    uint64_t decrypt = 0;
    uint64_t decode = 0;

    uint64_t total_ct_ct() const { return he.total_ct_ct(); }
    bool operator==(const MethodCounts &other) const {
        return he == other.he && dynamic_plain_encode == other.dynamic_plain_encode &&
               encrypt == other.encrypt && decrypt == other.decrypt && decode == other.decode;
    }
};

int total_modulus_bits(const HEEnv &env) {
    return env.context->key_context_data()->total_coeff_modulus_bit_count();
}

struct SampleStats {
    double best = 0.0;
    double median = 0.0;
    double p25 = 0.0;
    double p75 = 0.0;
    double p95 = 0.0;
    double mean = 0.0;
    double stddev = 0.0;
};

double quantile(const vector<double> &sorted, double p) {
    if (sorted.empty()) throw invalid_argument("quantile of empty sample");
    if (sorted.size() == 1) return sorted.front();
    const double position = p * static_cast<double>(sorted.size() - 1);
    const size_t lo = static_cast<size_t>(floor(position));
    const size_t hi = static_cast<size_t>(ceil(position));
    const double fraction = position - static_cast<double>(lo);
    return sorted[lo] * (1.0 - fraction) + sorted[hi] * fraction;
}

SampleStats summarize_samples(const vector<double> &samples) {
    if (samples.empty()) throw invalid_argument("cannot summarize empty samples");
    vector<double> sorted = samples;
    sort(sorted.begin(), sorted.end());
    SampleStats stats;
    stats.best = sorted.front();
    stats.median = quantile(sorted, 0.50);
    stats.p25 = quantile(sorted, 0.25);
    stats.p75 = quantile(sorted, 0.75);
    stats.p95 = quantile(sorted, 0.95);
    stats.mean = accumulate(sorted.begin(), sorted.end(), 0.0) /
                 static_cast<double>(sorted.size());
    long double variance = 0.0L;
    for (double value : sorted) {
        const long double delta = static_cast<long double>(value) - stats.mean;
        variance += delta * delta;
    }
    variance /= static_cast<long double>(sorted.size());
    stats.stddev = sqrt(static_cast<double>(variance));
    return stats;
}

vector<double> make_inputs(size_t slots, const Args &args) {
    vector<double> values(slots);
    if (args.input_mode == "grid") {
        if (slots == 1) values[0] = 0.5 * (args.lo + args.hi);
        else {
            for (size_t i = 0; i < slots; ++i) {
                values[i] = args.lo + (args.hi - args.lo) *
                    static_cast<double>(i) / static_cast<double>(slots - 1);
            }
        }
    } else {
        mt19937_64 rng(args.seed);
        uniform_real_distribution<double> distribution(args.lo, args.hi);
        for (double &value : values) value = distribution(rng);
    }
    return values;
}

Metrics compute_metrics_spread(const vector<double> &lhs,
                               const vector<double> &rhs,
                               size_t count) {
    if (count == 0 || lhs.size() != rhs.size() || lhs.empty() || count > lhs.size()) {
        throw invalid_argument("invalid metric vector length");
    }
    if (count == lhs.size()) return compute_metrics(lhs, rhs, count);
    Metrics metrics;
    long double sum_abs = 0.0L;
    long double sum_sq = 0.0L;
    for (size_t sample = 0; sample < count; ++sample) {
        size_t index = count == 1 ? (lhs.size() - 1) / 2 :
            static_cast<size_t>(llround(static_cast<long double>(sample) *
                static_cast<long double>(lhs.size() - 1) /
                static_cast<long double>(count - 1)));
        const double error = lhs[index] - rhs[index];
        const double absolute = abs(error);
        if (absolute > metrics.max_abs) {
            metrics.max_abs = absolute;
            metrics.max_index = index;
        }
        sum_abs += absolute;
        sum_sq += static_cast<long double>(error) * error;
    }
    metrics.mean_abs = static_cast<double>(sum_abs / count);
    metrics.rmse = sqrt(static_cast<double>(sum_sq / count));
    return metrics;
}

inline double silu_exact(double x) {
    return 0.5 * x * (1.0 + tanh(0.5 * x));
}

// -----------------------------------------------------------------------------
// Generic Chebyshev-PS evaluator for ordinary polynomial baselines.
// -----------------------------------------------------------------------------

struct GenericChebPlan {
    double domain_lo = -1.0;
    double domain_hi = 1.0;
    int degree = 0;
    int split = 1;
    int fresh_chain = -1;
    int coordinate_chain = -1;
    int basis_target_chain = -1;
    int predicted_output_chain = -1;
    int blocks = 0;
    int rounds = 0;
    bool map_raw_input = true;
    parms_id_type basis_target_id{};
    optional<Plaintext> map_scale_plain;
    optional<Plaintext> map_shift_plain;
    vector<vector<optional<Plaintext>>> coeff_plain;
    vector<optional<Plaintext>> c0_plain;
    // Constant-only blocks (no surviving ciphertext term): c0 pre-encoded at
    // every chain index, applied as y_power * c0 in the giant-step combination.
    vector<map<int, Plaintext>> constant_plain;
    optional<Plaintext> zero_plain;
};

bool any_nonzero(const vector<double> &values) {
    for (double value : values) if (value != 0.0) return true;
    return false;
}

GenericChebPlan prepare_generic_plan(
    HEEnv &env, const vector<double> &coefficients, double lo, double hi,
    int fresh_chain, int split, bool map_raw_input) {
    if (coefficients.empty()) throw invalid_argument("empty Chebyshev coefficient vector");
    if (!(lo < hi)) throw invalid_argument("invalid Chebyshev domain");
    const int degree = static_cast<int>(coefficients.size()) - 1;
    if (split < 1 || split > max(1, degree)) throw invalid_argument("invalid PS split");

    GenericChebPlan plan;
    plan.domain_lo = lo;
    plan.domain_hi = hi;
    plan.degree = degree;
    plan.split = split;
    plan.fresh_chain = fresh_chain;
    plan.map_raw_input = map_raw_input;
    plan.coordinate_chain = fresh_chain - (map_raw_input ? 1 : 0);
    if (plan.coordinate_chain < 0) throw runtime_error("chain too short for affine map");

    if (map_raw_input) {
        const parms_id_type input_id = parms_id_at_chain_index(*env.context, fresh_chain);
        const parms_id_type coordinate_id = parms_id_at_chain_index(*env.context, plan.coordinate_chain);
        plan.map_scale_plain = encode_scalar(
            env, 2.0 / (hi - lo), input_id, env.scale);
        plan.map_shift_plain = encode_scalar(
            env, -(hi + lo) / (hi - lo), coordinate_id, env.scale);
    }

    const int basis_depth = ceil_log2_int(split);
    plan.basis_target_chain = plan.coordinate_chain - basis_depth;
    if (plan.basis_target_chain < 1) {
        throw runtime_error("chain too short for generic Chebyshev basis");
    }
    plan.basis_target_id = parms_id_at_chain_index(*env.context, plan.basis_target_chain);

    const ChebDecomposition decomposition = decompose_chebyshev(coefficients, split);
    plan.blocks = static_cast<int>(decomposition.blocks.size());
    plan.rounds = ceil_log2_int(max(1, plan.blocks));
    plan.coeff_plain.resize(static_cast<size_t>(plan.blocks));
    plan.c0_plain.resize(static_cast<size_t>(plan.blocks));
    plan.constant_plain.resize(static_cast<size_t>(plan.blocks));
    for (int block = 0; block < plan.blocks; ++block) {
        bool block_has_terms = false;
        plan.coeff_plain[static_cast<size_t>(block)].resize(static_cast<size_t>(split));
        const auto &source = decomposition.blocks[static_cast<size_t>(block)];
        for (int j = 1; j < split; ++j) {
            if (j < static_cast<int>(source.size()) &&
                encodes_to_nonzero(source[static_cast<size_t>(j)], env.scale)) {
                plan.coeff_plain[static_cast<size_t>(block)][static_cast<size_t>(j)] =
                    encode_scalar(env, source[static_cast<size_t>(j)],
                                  plan.basis_target_id, env.scale);
                block_has_terms = true;
            }
        }
        if (source.empty()) continue;
        if (block_has_terms) {
            if (encodes_to_nonzero(source[0], env.scale * env.scale)) {
                plan.c0_plain[static_cast<size_t>(block)] = encode_scalar(
                    env, source[0], plan.basis_target_id, env.scale * env.scale);
            }
        } else if (encodes_to_nonzero(source[0], env.scale)) {
            auto &table = plan.constant_plain[static_cast<size_t>(block)];
            auto data = env.context->first_context_data();
            while (data) {
                table[data->chain_index()] = encode_scalar(env, source[0], data->parms_id(), env.scale);
                data = data->next_context_data();
            }
        }
    }
    plan.zero_plain = encode_scalar(env, 0.0, plan.basis_target_id, env.scale);
    plan.predicted_output_chain = predict_ps_output_chain(
        plan.basis_target_chain, plan.blocks);
    if (plan.predicted_output_chain < 0) {
        throw runtime_error("chain too short for generic Chebyshev PS evaluation");
    }
    return plan;
}

size_t count_generic_plaintexts(const GenericChebPlan &plan) {
    size_t count = 0;
    if (plan.map_scale_plain) ++count;
    if (plan.map_shift_plain) ++count;
    for (const auto &block : plan.coeff_plain) {
        for (const auto &plain : block) if (plain) ++count;
    }
    for (const auto &plain : plan.c0_plain) if (plain) ++count;
    if (plan.zero_plain) ++count;
    return count;
}

Ciphertext construct_generic_coordinate(
    HEEnv &env, const Ciphertext &input, const GenericChebPlan &plan,
    OperationCounts &counts) {
    if (!plan.map_raw_input) return input;
    if (!plan.map_scale_plain || !plan.map_shift_plain) {
        throw logic_error("generic plan lacks affine-map plaintexts");
    }
    Ciphertext coordinate = input;
    multiply_plain_no_rescale(env, coordinate, *plan.map_scale_plain,
                              counts, env.scale * env.scale);
    rescale_to_next_inplace(env, coordinate, counts, env.scale);
    env.evaluator->add_plain_inplace(coordinate, *plan.map_shift_plain);
    ++counts.add_plain;
    return coordinate;
}

optional<Ciphertext> evaluate_generic_baby_block(
    HEEnv &env, ChebDAG &dag, const GenericChebPlan &plan,
    int block, OperationCounts &counts) {
    Ciphertext accumulator;
    bool started = false;
    const auto &coeffs = plan.coeff_plain.at(static_cast<size_t>(block));
    for (int j = 1; j < plan.split; ++j) {
        const auto &plain = coeffs.at(static_cast<size_t>(j));
        if (!plain) continue;
        add_weighted_term(env, accumulator, started, dag.T(j), *plain,
                          plan.basis_target_id, counts);
    }
    const auto &c0 = plan.c0_plain.at(static_cast<size_t>(block));
    if (!started) {
        // No ciphertext term survives in this block: a product with an
        // encoded zero is a transparent ciphertext, which SEAL rejects. The
        // block is reported absent; a surviving constant term is applied by
        // the giant-step combination as y_power * c0. Seen with the Orion
        // (tiny coefficients) and ENSI (degree 16, split 4) reconstructions
        // under a real SEAL build.
        return nullopt;
    }
    if (c0) {
        env.evaluator->add_plain_inplace(accumulator, *c0);
        ++counts.add_plain;
    }
    rescale_to_next_inplace(env, accumulator, counts, env.scale);
    return accumulator;
}

Ciphertext evaluate_generic_chebyshev(
    HEEnv &env, const Ciphertext &input, const GenericChebPlan &plan,
    LevelConstants &constants, OperationCounts &counts) {
    Ciphertext coordinate = construct_generic_coordinate(env, input, plan, counts);
    ChebDAG dag(env, coordinate, constants, counts);
    const Ciphertext &generator = dag.T(plan.split);

    vector<optional<Ciphertext>> nodes;
    vector<int> pending;  // block index of a pending constant-only block, or -1
    nodes.reserve(static_cast<size_t>(plan.blocks));
    for (int block = 0; block < plan.blocks; ++block) {
        nodes.push_back(evaluate_generic_baby_block(env, dag, plan, block, counts));
        const bool constant_only = !nodes.back() &&
            !plan.constant_plain[static_cast<size_t>(block)].empty();
        pending.push_back(constant_only ? block : -1);
    }

    Ciphertext generator_power = generator;
    while (nodes.size() > 1) {
        vector<optional<Ciphertext>> next;
        vector<int> next_pending;
        next.reserve((nodes.size() + 1) / 2);
        for (size_t i = 0; i < nodes.size(); i += 2) {
            optional<Ciphertext> combined;
            int carried = -1;
            if (nodes[i]) combined = std::move(*nodes[i]);
            else carried = pending[i];
            if (i + 1 < nodes.size()) {
                optional<Ciphertext> scaled;
                if (nodes[i + 1]) {
                    scaled = multiply_and_rescale(
                        env, *nodes[i + 1], generator_power, counts, env.scale);
                } else if (pending[i + 1] >= 0) {
                    const auto &table = plan.constant_plain[static_cast<size_t>(pending[i + 1])];
                    Ciphertext product;
                    bool started = false;
                    add_weighted_term(env, product, started, generator_power,
                                      table.at(chain_index(*env.context, generator_power)),
                                      generator_power.parms_id(), counts);
                    rescale_to_next_inplace(env, product, counts, env.scale);
                    scaled = std::move(product);
                }
                if (scaled) {
                    if (combined) add_cipher_inplace(env, *combined, *scaled, counts, env.scale);
                    else if (carried >= 0) throw runtime_error("generic PS: constant block below a live block is unsupported");
                    else combined = std::move(*scaled);
                }
            }
            next.push_back(std::move(combined));
            next_pending.push_back(next.back() ? -1 : carried);
        }
        nodes = std::move(next);
        pending = std::move(next_pending);
        if (nodes.size() > 1) {
            generator_power = square_and_rescale(
                env, generator_power, counts, env.scale);
        }
    }
    if (nodes.empty() || !nodes[0]) throw runtime_error("empty generic PS result");
    return std::move(*nodes[0]);
}

inline double map_x_to_t(double x, double lo, double hi) {
    return (2.0 * x - (hi + lo)) / (hi - lo);
}

// -----------------------------------------------------------------------------
// Fair-method interface and implementations.
// -----------------------------------------------------------------------------

struct MethodMetadata {
    string family;
    string provenance;
    string reconstruction_status;
    string input_semantics;
    string parameter_policy;
    string native_target;
    string reference_gap_semantics;
    string profile_catalog_sha256;
    string spa_tier;
    string degree_schedule;
    string active_profile;
    int active_degree_square = -1;
    int active_ps_split = -1;
    int active_ps_blocks = -1;
    bool reference_gap_is_ckks_only = true;
    bool reconstructed = false;
    double design_lo = numeric_limits<double>::quiet_NaN();
    double design_hi = numeric_limits<double>::quiet_NaN();
    double offline_max_error = numeric_limits<double>::quiet_NaN();
    int rounding_decimals = -1;
    string derived_from;
    double catalog_e_poly = numeric_limits<double>::quiet_NaN();
    double catalog_e_coeff = 0.0;
    double offline_rmse = numeric_limits<double>::quiet_NaN();
    int paper_reported_depth = -1;
    double paper_reported_precision_bits = numeric_limits<double>::quiet_NaN();
    int context_count = 1;
    int main_modulus_bits = 0;
    int fresh_chain = -1;
    int output_chain = -1;
    double output_scale_log2 = 0.0;
    size_t prepared_plaintexts = 0;
    size_t outside_domain_count = 0;
    double max_abs_normalized = 0.0;
};

class PreparedMethod {
public:
    virtual ~PreparedMethod() = default;
    virtual const string &id() const = 0;
    virtual void evaluate_once() = 0;
    virtual void freeze_preparation() {}
    virtual vector<double> decode_last() = 0;
    virtual const vector<double> &plain_reference() const = 0;
    virtual const MethodCounts &last_counts() const = 0;
    virtual MethodMetadata metadata() const = 0;

    // Error decomposition (see gelu_bench.cpp). Every SiLU method in this
    // benchmark is fitted to SiLU itself, so A_fit = A_native and E_target = 0.
    virtual const char *fit_target_id() const { return "silu"; }
    virtual double fit_activation(double x) const { return silu_exact(x); }
    // Host evaluation of the unrounded P_c when a rounded copy is evaluated.
    virtual const vector<double> *unrounded_reference() const { return nullptr; }
};

static const char *const NATIVE_TARGET_ID = "silu";

size_t count_spa_plaintexts(const PreparedPlan &plan) {
    size_t count = 0;
    auto add = [&](const optional<Plaintext> &plain) { if (plain) ++count; };
    add(plan.raw_map_plain);
    add(plan.warp_half_a_plain);
    add(plan.warp_lift_one_plain);
    for (const auto &plain : plan.direct_coeff_plain) add(plain);
    add(plan.direct_c0_plain);
    add(plan.linear_plain);
    for (const auto &block : plan.ps_coeff_plain) {
        for (const auto &plain : block) add(plain);
    }
    for (const auto &plain : plan.ps_c0_plain) add(plain);
    add(plan.zero_plain);
    return count;
}

class SpaSiluMethod final : public PreparedMethod {
public:
    SpaSiluMethod(HEEnv &env, const Ciphertext &raw_input,
                   const vector<double> &raw_values,
                   const spa_silu::MethodDef &method,
                   const spa_silu::ProfileDef &silu_profile)
        : env_(env), id_(method.id), method_(method), silu_profile_(silu_profile),
          profile_{silu_profile_.name, silu_profile_.radius, 0.0,
                   silu_profile_.offline_max_error, silu_profile_.coefficients},
          constants_(env) {
        assignment_.profiles.assign(raw_values.size(), &profile_);
        assignment_.max_degree = silu_profile_.degree_square;
        assignment_.any_warp = false;

        plain_reference_.resize(raw_values.size());
        for (size_t i = 0; i < raw_values.size(); ++i) {
            plain_reference_[i] = profile_plain_eval(raw_values[i], profile_);
            const double ratio = abs(raw_values[i]) / profile_.radius;
            max_ratio_ = max(max_ratio_, ratio);
            if (ratio > 1.0 + 1e-12) ++outside_;
        }
        if (!silu_profile_.derived_from.empty()) {
            // Experiment B: P_c of the unrounded fit, same structure and range.
            const spa_silu::ProfileDef &base = spa_silu::find_profile(silu_profile_.derived_from);
            if (base.degree_square != silu_profile_.degree_square || base.radius != silu_profile_.radius ||
                base.ps_split != silu_profile_.ps_split) {
                throw runtime_error("rounded profile " + silu_profile_.name + " does not match its source");
            }
            const ProfileDef base_profile{base.name, base.radius, 0.0, base.offline_max_error, base.coefficients};
            unrounded_reference_.resize(raw_values.size());
            for (size_t i = 0; i < raw_values.size(); ++i) {
                unrounded_reference_[i] = profile_plain_eval(raw_values[i], base_profile);
            }
            catalog_e_poly_ = base.offline_max_error;
        } else {
            catalog_e_poly_ = silu_profile_.offline_max_error;
        }
        input_ = raw_input;
        fresh_chain_ = chain_index(*env_.context, input_);
        plan_ = prepare_plan(env_, assignment_, fresh_chain_,
                             Engine::PatersonStockmeyer, InputSemantics::Raw,
                             silu_profile_.ps_split);
    }

    const string &id() const override { return id_; }
    const vector<double> *unrounded_reference() const override {
        return unrounded_reference_.empty() ? nullptr : &unrounded_reference_;
    }

    void evaluate_once() override {
        OperationCounts counts;
        last_output_ = spa::evaluate(env_, input_, plan_, constants_, counts);
        last_counts_ = MethodCounts{};
        last_counts_.he = counts;
    }

    vector<double> decode_last() override { return decrypt_vector(env_, last_output_); }
    const vector<double> &plain_reference() const override { return plain_reference_; }
    const MethodCounts &last_counts() const override { return last_counts_; }

    MethodMetadata metadata() const override {
        MethodMetadata meta;
        meta.family = "SPA-SiLU";
        meta.provenance =
            "independent two-range adaptive minimax refit for the ciphertext benchmark";
        meta.reconstruction_status = "proposed SPA two-range degree variant";
        meta.input_semantics = "standalone raw x; x/R mapping timed";
        meta.parameter_policy = "active profile=" + silu_profile_.name +
            "; degree schedule=" + method_.degree_schedule +
            "; profile catalog sha256=" + spa_silu::profile_catalog_sha256();
        meta.native_target = "exact SiLU via SPA polynomial";
        meta.rounding_decimals = silu_profile_.rounding_decimals;
        meta.derived_from = silu_profile_.derived_from;
        meta.catalog_e_poly = catalog_e_poly_;
        meta.catalog_e_coeff = silu_profile_.coefficient_perturbation_max;
        if (silu_profile_.rounding_decimals >= 0) {
            meta.parameter_policy += "; Experiment B coefficients rounded to " +
                to_string(silu_profile_.rounding_decimals) + " decimals of " + silu_profile_.derived_from;
        }
        meta.reference_gap_semantics =
            "decrypted output minus the identical refitted SPA plaintext polynomial";
        meta.profile_catalog_sha256 = spa_silu::profile_catalog_sha256();
        meta.reference_gap_is_ckks_only = true;
        meta.spa_tier = method_.tier;
        meta.degree_schedule = method_.degree_schedule;
        meta.active_profile = silu_profile_.name;
        meta.active_degree_square = silu_profile_.degree_square;
        meta.active_ps_split = silu_profile_.ps_split;
        meta.active_ps_blocks = silu_profile_.ps_blocks;
        meta.design_lo = -profile_.radius;
        meta.design_hi = profile_.radius;
        meta.offline_max_error = silu_profile_.offline_max_error;
        meta.offline_rmse = silu_profile_.offline_rmse;
        meta.context_count = 1;
        meta.main_modulus_bits = total_modulus_bits(env_);
        meta.fresh_chain = fresh_chain_;
        meta.output_chain = chain_index(*env_.context, last_output_);
        meta.output_scale_log2 = log2(last_output_.scale());
        meta.prepared_plaintexts = count_spa_plaintexts(plan_) + constants_.size();
        meta.outside_domain_count = outside_;
        meta.max_abs_normalized = max_ratio_;
        return meta;
    }

private:
    HEEnv &env_;
    string id_;
    const spa_silu::MethodDef &method_;
    const spa_silu::ProfileDef &silu_profile_;
    ProfileDef profile_;
    vector<double> unrounded_reference_;
    double catalog_e_poly_ = numeric_limits<double>::quiet_NaN();
    SlotAssignment assignment_;
    LevelConstants constants_;
    Ciphertext input_;
    Ciphertext last_output_;
    int fresh_chain_ = -1;
    PreparedPlan plan_;
    vector<double> plain_reference_;
    MethodCounts last_counts_;
    size_t outside_ = 0;
    double max_ratio_ = 0.0;
};

class OrdinaryChebMethod final : public PreparedMethod {
public:
    OrdinaryChebMethod(HEEnv &env, const Ciphertext &raw_input,
                       const vector<double> &raw_values,
                       string id, const silu_baselines::ChebProfile &profile,
                       string status, int paper_depth = -1,
                       double paper_precision = numeric_limits<double>::quiet_NaN())
        : env_(env), input_(raw_input), id_(std::move(id)), profile_(profile),
          status_(std::move(status)), paper_depth_(paper_depth),
          paper_precision_(paper_precision), constants_(env) {
        fresh_chain_ = chain_index(*env_.context, input_);
        plan_ = prepare_generic_plan(env_, profile_.coefficients,
                                     profile_.domain_lo, profile_.domain_hi,
                                     fresh_chain_, profile_.ps_split, true);
        plain_reference_.resize(raw_values.size());
        const double center = 0.5 * (profile_.domain_lo + profile_.domain_hi);
        const double half = 0.5 * (profile_.domain_hi - profile_.domain_lo);
        for (size_t i = 0; i < raw_values.size(); ++i) {
            const double t = map_x_to_t(raw_values[i], profile_.domain_lo, profile_.domain_hi);
            plain_reference_[i] = cheb_eval(t, profile_.coefficients);
            const double ratio = abs(raw_values[i] - center) / half;
            max_ratio_ = max(max_ratio_, ratio);
            if (ratio > 1.0 + 1e-12) ++outside_;
        }
    }

    const string &id() const override { return id_; }
    void evaluate_once() override {
        OperationCounts counts;
        last_output_ = evaluate_generic_chebyshev(env_, input_, plan_, constants_, counts);
        last_counts_ = MethodCounts{};
        last_counts_.he = counts;
    }
    vector<double> decode_last() override { return decrypt_vector(env_, last_output_); }
    const vector<double> &plain_reference() const override { return plain_reference_; }
    const MethodCounts &last_counts() const override { return last_counts_; }

    MethodMetadata metadata() const override {
        MethodMetadata meta;
        meta.family = profile_.family;
        meta.provenance = profile_.provenance;
        meta.reconstruction_status = status_;
        meta.reconstructed = true;
        meta.input_semantics = "standalone raw x; affine Chebyshev mapping timed";
        meta.parameter_policy = "common secure CKKS context and common Chebyshev-PS evaluator";
        meta.native_target = "SiLU polynomial reconstructed from the cited method";
        meta.reference_gap_semantics = "decrypted output minus exact plaintext reconstructed polynomial";
        meta.design_lo = profile_.domain_lo;
        meta.design_hi = profile_.domain_hi;
        meta.offline_max_error = profile_.offline_max_error;
        meta.offline_rmse = profile_.offline_rmse;
        meta.paper_reported_depth = paper_depth_;
        meta.paper_reported_precision_bits = paper_precision_;
        meta.main_modulus_bits = total_modulus_bits(env_);
        meta.fresh_chain = fresh_chain_;
        meta.output_chain = chain_index(*env_.context, last_output_);
        meta.output_scale_log2 = log2(last_output_.scale());
        meta.prepared_plaintexts = count_generic_plaintexts(plan_) + constants_.size();
        meta.outside_domain_count = outside_;
        meta.max_abs_normalized = max_ratio_;
        return meta;
    }

private:
    HEEnv &env_;
    Ciphertext input_;
    Ciphertext last_output_;
    string id_;
    const silu_baselines::ChebProfile &profile_;
    string status_;
    int paper_depth_ = -1;
    double paper_precision_ = numeric_limits<double>::quiet_NaN();
    LevelConstants constants_;
    int fresh_chain_ = -1;
    GenericChebPlan plan_;
    vector<double> plain_reference_;
    MethodCounts last_counts_;
    size_t outside_ = 0;
    double max_ratio_ = 0.0;
};

class EnsiMethod final : public PreparedMethod {
public:
    EnsiMethod(HEEnv &env, const Ciphertext &raw_input,
               const vector<double> &raw_values)
        : env_(env), input_(raw_input),
          profile_(silu_baselines::ENSI_D16), constants_(env) {
        fresh_chain_ = chain_index(*env_.context, input_);
        plan_ = prepare_generic_plan(env_, profile_.coefficients,
                                     profile_.domain_lo, profile_.domain_hi,
                                     fresh_chain_, profile_.ps_split, true);
        plain_reference_.resize(raw_values.size());
        const double center = 0.5 * (profile_.domain_lo + profile_.domain_hi);
        const double half = 0.5 * (profile_.domain_hi - profile_.domain_lo);
        for (size_t i = 0; i < raw_values.size(); ++i) {
            const double t = map_x_to_t(raw_values[i], profile_.domain_lo, profile_.domain_hi);
            plain_reference_[i] = raw_values[i] * cheb_eval(t, profile_.coefficients);
            const double ratio = abs(raw_values[i] - center) / half;
            max_ratio_ = max(max_ratio_, ratio);
            if (ratio > 1.0 + 1e-12) ++outside_;
        }
    }

    const string &id() const override { return id_; }
    void evaluate_once() override {
        OperationCounts counts;
        Ciphertext sigmoid = evaluate_generic_chebyshev(
            env_, input_, plan_, constants_, counts);
        last_output_ = multiply_and_rescale(
            env_, input_, sigmoid, counts, env_.scale);
        last_counts_ = MethodCounts{};
        last_counts_.he = counts;
    }
    vector<double> decode_last() override { return decrypt_vector(env_, last_output_); }
    const vector<double> &plain_reference() const override { return plain_reference_; }
    const MethodCounts &last_counts() const override { return last_counts_; }

    MethodMetadata metadata() const override {
        MethodMetadata meta;
        meta.family = "ENSI";
        meta.provenance = profile_.provenance;
        meta.reconstruction_status = "source-derived reconstruction; attention-specific -log(seq) shift omitted for mathematical SiLU";
        meta.reconstructed = true;
        meta.input_semantics = "standalone raw x; EvalLogistic-style polynomial and final x*sigmoid timed";
        meta.parameter_policy = "common secure CKKS context and common Chebyshev-PS evaluator";
        meta.native_target = "x multiplied by degree-16 reconstructed logistic polynomial";
        meta.reference_gap_semantics = "decrypted output minus exact plaintext ENSI-style SiLU polynomial";
        meta.design_lo = profile_.domain_lo;
        meta.design_hi = profile_.domain_hi;
        meta.offline_max_error = profile_.offline_max_error;
        meta.offline_rmse = profile_.offline_rmse;
        meta.main_modulus_bits = total_modulus_bits(env_);
        meta.fresh_chain = fresh_chain_;
        meta.output_chain = chain_index(*env_.context, last_output_);
        meta.output_scale_log2 = log2(last_output_.scale());
        meta.prepared_plaintexts = count_generic_plaintexts(plan_) + constants_.size();
        meta.outside_domain_count = outside_;
        meta.max_abs_normalized = max_ratio_;
        return meta;
    }

private:
    HEEnv &env_;
    Ciphertext input_;
    Ciphertext last_output_;
    string id_ = "ensi";
    const silu_baselines::ChebProfile &profile_;
    LevelConstants constants_;
    int fresh_chain_ = -1;
    GenericChebPlan plan_;
    vector<double> plain_reference_;
    MethodCounts last_counts_;
    size_t outside_ = 0;
    double max_ratio_ = 0.0;
};

class CompositeMethod final : public PreparedMethod {
public:
    CompositeMethod(HEEnv &env, const Ciphertext &raw_input,
                    const vector<double> &raw_values,
                    string id, const silu_baselines::CompositeProfile &profile)
        : env_(env), input_(raw_input), id_(std::move(id)), profile_(profile),
          constants_(env) {
        fresh_chain_ = chain_index(*env_.context, input_);
        stage1_ = prepare_generic_plan(
            env_, profile_.stage1_coefficients, -profile_.radius, profile_.radius,
            fresh_chain_, profile_.stage1_split, true);
        stage2_ = prepare_generic_plan(
            env_, profile_.stage2_coefficients, -1.0, 1.0,
            stage1_.predicted_output_chain, profile_.stage2_split, false);
        plain_reference_.resize(raw_values.size());
        for (size_t i = 0; i < raw_values.size(); ++i) {
            const double t = raw_values[i] / profile_.radius;
            const double u = cheb_eval(t, profile_.stage1_coefficients);
            plain_reference_[i] = cheb_eval(u, profile_.stage2_coefficients);
            const double ratio = abs(raw_values[i]) / profile_.radius;
            max_ratio_ = max(max_ratio_, ratio);
            if (ratio > 1.0 + 1e-12) ++outside_;
        }
    }

    const string &id() const override { return id_; }
    void evaluate_once() override {
        OperationCounts counts;
        Ciphertext stage1_output = evaluate_generic_chebyshev(
            env_, input_, stage1_, constants_, counts);
        last_output_ = evaluate_generic_chebyshev(
            env_, stage1_output, stage2_, constants_, counts);
        last_counts_ = MethodCounts{};
        last_counts_.he = counts;
    }
    vector<double> decode_last() override { return decrypt_vector(env_, last_output_); }
    const vector<double> &plain_reference() const override { return plain_reference_; }
    const MethodCounts &last_counts() const override { return last_counts_; }

    MethodMetadata metadata() const override {
        MethodMetadata meta;
        meta.family = "THOR-style";
        meta.provenance = profile_.provenance;
        meta.reconstruction_status = "paper-only architecture reconstruction; official SiLU coefficients were not disclosed";
        meta.reconstructed = true;
        meta.input_semantics = "standalone raw x; degree-31 then degree-27 composite polynomial timed";
        meta.parameter_policy = "common secure CKKS context and common Chebyshev-PS evaluator";
        meta.native_target = "reconstructed composite approximation of exact SiLU";
        meta.reference_gap_semantics = "decrypted output minus exact plaintext reconstructed composite";
        meta.design_lo = -profile_.radius;
        meta.design_hi = profile_.radius;
        meta.offline_max_error = profile_.offline_max_error;
        meta.offline_rmse = profile_.offline_rmse;
        if (profile_.radius == 8.0) {
            meta.paper_reported_depth = 10;
            meta.paper_reported_precision_bits = 27.54;
        }
        meta.main_modulus_bits = total_modulus_bits(env_);
        meta.fresh_chain = fresh_chain_;
        meta.output_chain = chain_index(*env_.context, last_output_);
        meta.output_scale_log2 = log2(last_output_.scale());
        meta.prepared_plaintexts = count_generic_plaintexts(stage1_) +
                                   count_generic_plaintexts(stage2_) + constants_.size();
        meta.outside_domain_count = outside_;
        meta.max_abs_normalized = max_ratio_;
        return meta;
    }

private:
    HEEnv &env_;
    Ciphertext input_;
    Ciphertext last_output_;
    string id_;
    const silu_baselines::CompositeProfile &profile_;
    LevelConstants constants_;
    int fresh_chain_ = -1;
    GenericChebPlan stage1_;
    GenericChebPlan stage2_;
    vector<double> plain_reference_;
    MethodCounts last_counts_;
    size_t outside_ = 0;
    double max_ratio_ = 0.0;
};

pair<double, double> nominal_domain(const string &id, double required_radius) {
    if (const auto *method = spa_silu::try_find_method(id)) {
        const auto &profile = spa_silu::select_profile(*method, required_radius);
        return {-profile.radius, profile.radius};
    }
    if (id == "orion" || id == "thor") return {-8.0, 8.0};
    if (id == "orion-wide" || id == "thor-wide") return {-20.0, 20.0};
    if (id == "ensi") return {-10.0, 11.0};
    if (id == "sylph") return {-10.82, 10.82};
    throw invalid_argument("unsupported method ID: " + id);
}

unique_ptr<PreparedMethod> make_method(
    const string &id, double required_radius, HEEnv &env,
    const Ciphertext &raw_input, const vector<double> &raw_values) {
    if (const auto *method = spa_silu::try_find_method(id)) {
        const auto &profile = spa_silu::select_profile(*method, required_radius);
        return make_unique<SpaSiluMethod>(env, raw_input, raw_values, *method, profile);
    }
    if (id == "orion") {
        return make_unique<OrdinaryChebMethod>(
            env, raw_input, raw_values, id,
            silu_baselines::ORION_R8,
            "Orion source parameters with corrected coefficient domain", 7);
    }
    if (id == "orion-wide") {
        return make_unique<OrdinaryChebMethod>(
            env, raw_input, raw_values, id,
            silu_baselines::ORION_R20,
            "Orion source parameters with corrected coefficient domain", 7);
    }
    if (id == "ensi") {
        return make_unique<EnsiMethod>(env, raw_input, raw_values);
    }
    if (id == "sylph") {
        return make_unique<OrdinaryChebMethod>(
            env, raw_input, raw_values, id,
            silu_baselines::SYLPH_D31,
            "paper-parameter reconstruction; coefficients unavailable");
    }
    if (id == "thor") {
        return make_unique<CompositeMethod>(
            env, raw_input, raw_values, id,
            silu_baselines::THOR_R8);
    }
    if (id == "thor-wide") {
        return make_unique<CompositeMethod>(
            env, raw_input, raw_values, id,
            silu_baselines::THOR_R20);
    }
    throw invalid_argument("unsupported method ID: " + id);
}

// -----------------------------------------------------------------------------
// CSV and reporting.
// -----------------------------------------------------------------------------

// Standardised error decomposition, identical to gelu_bench.cpp:
//   E_target = max |A_fit - A_native| (0 here), E_poly = max |P_c - A_fit|,
//   E_coeff = max |P_{c_d} - P_c| (Experiment B), E_HE = max |Y_HE - P_{c_d}|,
//   E_total = max |Y_HE - A_native| <= E_target + E_poly + E_coeff + E_HE.
struct ErrorDecomposition {
    double e_target = 0.0;
    double e_poly = 0.0;
    double e_coeff = 0.0;
    double e_he = 0.0;
    double e_total = 0.0;
    double bound = 0.0;
    bool bound_holds = true;
};

struct MethodResult {
    PreparedMethod *method = nullptr;
    vector<double> samples_ms;
    SampleStats timing;
    Metrics total_error;
    Metrics method_bias;
    Metrics ckks_extra;
    ErrorDecomposition decomposition;
    MethodCounts counts;
    MethodMetadata metadata;
};

string csv_escape(const string &value) {
    if (value.find_first_of(",\"\n") == string::npos) return value;
    string output = "\"";
    for (char c : value) output += c == '\"' ? "\"\"" : string(1, c);
    output += "\"";
    return output;
}

void ensure_parent_directory(const string &path) {
    if (path.empty()) return;
    fs::path file(path);
    if (file.has_parent_path()) fs::create_directories(file.parent_path());
}

struct RawSample {
    string run_label;
    int round = 0;
    int position = 0;
    string method;
    double milliseconds = 0.0;
};

void append_samples_csv(const string &path, const vector<RawSample> &samples) {
    if (path.empty()) return;
    ensure_parent_directory(path);
    const bool header = !fs::exists(path) || fs::file_size(path) == 0;
    ofstream output(path, ios::app);
    if (!output) throw runtime_error("cannot open samples CSV: " + path);
    if (header) output << "run_label,round,position,method,time_ms\n";
    for (const auto &sample : samples) {
        output << csv_escape(sample.run_label) << ',' << sample.round << ','
               << sample.position << ',' << csv_escape(sample.method) << ','
               << setprecision(17) << sample.milliseconds << '\n';
    }
}

string count_prefix(const MethodCounts &counts) {
    ostringstream out;
    out << "ct_ct_multiply=" << counts.he.ct_ct_multiply
        << " ct_square=" << counts.he.ct_square
        << " ct_ct_total=" << counts.total_ct_ct()
        << " ct_plain_multiply=" << counts.he.ct_plain_multiply
        << " relinearize=" << counts.he.relinearize
        << " rescale=" << counts.he.rescale
        << " mod_switch=" << counts.he.mod_switch
        << " ct_add=" << counts.he.ct_add
        << " ct_sub=" << counts.he.ct_sub
        << " add_plain=" << counts.he.add_plain
        << " dynamic_plain_encode=" << counts.dynamic_plain_encode
        << " encrypt=" << counts.encrypt
        << " decrypt=" << counts.decrypt
        << " decode=" << counts.decode;
    return out.str();
}

void append_summary_csv(const string &path, const Args &args,
                        const MethodResult &result,
                        const map<string, double> &speedups) {
    if (path.empty()) return;
    ensure_parent_directory(path);
    const bool header = !fs::exists(path) || fs::file_size(path) == 0;
    if (!header) {
        ifstream previous(path);
        string columns;
        getline(previous, columns);
        if (columns.find(",e_total,") == string::npos)
            throw runtime_error("summary CSV schema mismatch (expected the current column set): " + path);
    }
    ofstream out(path, ios::app);
    if (!out) throw runtime_error("cannot open summary CSV: " + path);
    if (header) {
        out << "run_label,method,family,provenance,reconstruction_status,reconstructed,"
               "input_semantics,parameter_policy,native_target,reference_gap_semantics,"
               "profile_catalog_sha256,spa_tier,degree_schedule,active_profile,"
               "active_degree_square,active_ps_split,active_ps_blocks,"
               "input_mode,range_lo,range_hi,slots,warmups,repeats,levels,order_seed,randomized_order,"
               "scale_bits,prime_bits,"
               "design_lo,design_hi,offline_max_error,offline_rmse,paper_reported_depth,paper_reported_precision_bits,"
               "median_ms,p25_ms,p75_ms,p95_ms,best_ms,mean_ms,stddev_ms,"
               "speedup_vs_spa_k87,speedup_vs_orion,speedup_vs_ensi,speedup_vs_sylph,speedup_vs_thor,"
               "context_count,main_modulus_bits,fresh_chain,output_chain,consumed_levels,output_scale_log2,"
               "prepared_plaintexts,outside_domain_count,max_abs_normalized,"
               "ct_ct_multiply,ct_square,ct_ct_total,ct_plain_multiply,relinearize,rescale,mod_switch,"
               "ct_add,ct_sub,add_plain,dynamic_plain_encode,encrypt,decrypt,decode,"
               "total_max_abs,total_mean_abs,total_rmse,method_bias_max,method_bias_rmse,"
               "ckks_extra_max,ckks_extra_rmse,implementation_revision,"
               "native_target_id,fit_target_id,e_target,e_poly,e_coeff,e_he,e_total,decomposition_bound,decomposition_bound_holds,"
               "catalog_e_poly,catalog_e_coeff,spa_rounding_decimals,spa_derived_from,host_reference_semantics\n";
    }
    const auto &m = result.metadata;
    auto speedup = [&](const string &key) {
        const auto it = speedups.find(key);
        return it == speedups.end() ? numeric_limits<double>::quiet_NaN() : it->second;
    };
    out << csv_escape(args.run_label) << ',' << csv_escape(result.method->id()) << ','
        << csv_escape(m.family) << ',' << csv_escape(m.provenance) << ','
        << csv_escape(m.reconstruction_status) << ',' << (m.reconstructed ? 1 : 0) << ','
        << csv_escape(m.input_semantics) << ',' << csv_escape(m.parameter_policy) << ','
        << csv_escape(m.native_target) << ',' << csv_escape(m.reference_gap_semantics) << ','
        << csv_escape(m.profile_catalog_sha256) << ',' << csv_escape(m.spa_tier) << ','
        << csv_escape(m.degree_schedule) << ',' << csv_escape(m.active_profile) << ','
        << m.active_degree_square << ',' << m.active_ps_split << ',' << m.active_ps_blocks << ','
        << args.input_mode << ',' << setprecision(17) << args.lo << ',' << args.hi << ','
        << args.slots_to_test << ',' << args.warmups << ',' << args.repeats << ','
        << args.middle_primes << ',' << args.order_seed << ','
        << (args.randomize_order ? 1 : 0) << ','
        << args.scale_bits << ',' << args.prime_bits << ','
        << m.design_lo << ',' << m.design_hi << ',' << m.offline_max_error << ','
        << m.offline_rmse << ',' << m.paper_reported_depth << ','
        << m.paper_reported_precision_bits << ','
        << result.timing.median << ',' << result.timing.p25 << ',' << result.timing.p75 << ','
        << result.timing.p95 << ',' << result.timing.best << ',' << result.timing.mean << ','
        << result.timing.stddev << ',' << speedup("spa_k87") << ','
        << speedup("orion") << ',' << speedup("ensi") << ','
        << speedup("sylph") << ',' << speedup("thor") << ','
        << m.context_count << ',' << m.main_modulus_bits << ',' << m.fresh_chain << ','
        << m.output_chain << ',' << (m.fresh_chain - m.output_chain) << ','
        << m.output_scale_log2 << ',' << m.prepared_plaintexts << ','
        << m.outside_domain_count << ',' << m.max_abs_normalized << ','
        << result.counts.he.ct_ct_multiply << ',' << result.counts.he.ct_square << ','
        << result.counts.total_ct_ct() << ',' << result.counts.he.ct_plain_multiply << ','
        << result.counts.he.relinearize << ',' << result.counts.he.rescale << ','
        << result.counts.he.mod_switch << ',' << result.counts.he.ct_add << ','
        << result.counts.he.ct_sub << ',' << result.counts.he.add_plain << ','
        << result.counts.dynamic_plain_encode << ',' << result.counts.encrypt << ','
        << result.counts.decrypt << ',' << result.counts.decode << ','
        << result.total_error.max_abs << ',' << result.total_error.mean_abs << ','
        << result.total_error.rmse << ',' << result.method_bias.max_abs << ','
        << result.method_bias.rmse << ',' << result.ckks_extra.max_abs << ','
        << result.ckks_extra.rmse << ",spa-1,"
        << NATIVE_TARGET_ID << ',' << result.method->fit_target_id() << ','
        << result.decomposition.e_target << ',' << result.decomposition.e_poly << ','
        << result.decomposition.e_coeff << ',' << result.decomposition.e_he << ','
        << result.decomposition.e_total << ',' << result.decomposition.bound << ','
        << (result.decomposition.bound_holds ? 1 : 0) << ','
        << m.catalog_e_poly << ',' << m.catalog_e_coeff << ','
        << m.rounding_decimals << ',' << csv_escape(m.derived_from) << ','
        << csv_escape("E_HE is the decrypted output minus the host double-precision evaluation of the identical circuit; "
                      "it includes host floating-point error and is not independently verified pure CKKS noise")
        << '\n';
}

string choose_reference(const vector<MethodResult> &results,
                        const vector<string> &preferred) {
    for (const string &id : preferred) {
        for (const auto &result : results) if (result.method->id() == id) return id;
    }
    return {};
}

} // namespace silu_bench

int main(int argc, char **argv) {
    using namespace silu_bench;
    try {
        const Args args = parse_args(argc, argv);
        if (args.list_methods) {
            print_supported_methods();
            return 0;
        }
        const vector<string> requested = split_csv(args.methods);
        const double required_radius = max(abs(args.lo), abs(args.hi));
        unordered_set<string> unique;
        for (const string &id : requested) {
            if (!unique.insert(id).second) throw invalid_argument("duplicate method ID: " + id);
            const auto [lo, hi] = nominal_domain(id, required_radius);
            if (!args.allow_out_of_domain && (args.lo < lo - 1e-12 || args.hi > hi + 1e-12)) {
                ostringstream message;
                message << id << " has nominal comparison domain [" << lo << ',' << hi
                        << "]; pass --allow-out-of-domain only for a labelled stress test";
                throw invalid_argument(message.str());
            }
        }

        const size_t poly_modulus_degree = 65536;
        vector<int> bits;
        bits.reserve(static_cast<size_t>(args.middle_primes + 2));
        bits.push_back(60);
        for (int i = 0; i < args.middle_primes; ++i) bits.push_back(args.prime_bits);
        bits.push_back(60);
        HEEnv env(poly_modulus_degree, bits, pow(2.0, args.scale_bits), args.secure128);
        const size_t slot_count = env.encoder->slot_count();
        if (slot_count != 32768) throw runtime_error("expected 32768 CKKS slots for N=65536");

        const vector<double> raw_values = make_inputs(slot_count, args);
        vector<double> exact(slot_count);
        transform(raw_values.begin(), raw_values.end(), exact.begin(), silu_exact);
        const Ciphertext common_raw = encrypt_vector(env, raw_values);

        vector<unique_ptr<PreparedMethod>> methods;
        for (const string &id : requested) {
            methods.push_back(make_method(id, required_radius, env, common_raw, raw_values));
        }

        cout << "scheme: CKKS\n";
        cout << "benchmark: silu_bench\n";
        cout << "run_label: " << args.run_label << "\n";
        cout << "common_raw_input: one identical " << args.input_mode
             << " vector for all methods, range=[" << args.lo << ',' << args.hi << "]\n";
        cout << "slot_count_executed: " << slot_count << "\n";
        cout << "slots_used_for_metrics: " << args.slots_to_test << "\n";
        cout << "common_parameters: N=65536 scale=2^" << args.scale_bits
             << " prime_bits=" << args.prime_bits
             << " middle_primes=" << args.middle_primes
             << " total_modulus_bits=" << total_modulus_bits(env) << "\n";
        cout << "timing_excludes: context,keygen,coefficient-generation,fixed-plaintext-preparation,input-encode,input-encrypt,output-decrypt,metrics,CSV\n";
        cout << "timing_includes: all ciphertext arithmetic,allocation,relinearize,rescale,mod-switch\n";
        cout << "spa_profile_catalog_sha256: " << spa_silu::profile_catalog_sha256() << "\n";
        cout << "spa_profile_selection: R5 for |x|<=5, otherwise R20 for |x|<=20\n";
        cout << "baseline_policy: Orion and ENSI use source parameters; Sylph and THOR use labelled reconstructions\n";
        cout << "warmups: " << args.warmups << " repeats: " << args.repeats
             << " randomized_order: " << (args.randomize_order ? "true" : "false")
             << " order_seed: " << args.order_seed << "\n";
        cout << "methods:";
        for (const auto &method : methods) cout << ' ' << method->id();
        cout << "\n";

        for (auto &method : methods) {
            cout << "prepare_trace: " << method->id() << "\n";
            method->evaluate_once();
            method->freeze_preparation();
        }

        vector<size_t> order(methods.size());
        iota(order.begin(), order.end(), 0);
        mt19937_64 order_rng(args.order_seed);
        for (int warm = 0; warm < args.warmups; ++warm) {
            if (args.randomize_order) shuffle(order.begin(), order.end(), order_rng);
            for (size_t index : order) methods[index]->evaluate_once();
        }

        vector<MethodResult> results(methods.size());
        for (size_t i = 0; i < methods.size(); ++i) results[i].method = methods[i].get();
        vector<optional<MethodCounts>> expected_counts(methods.size());
        vector<RawSample> raw_samples;
        raw_samples.reserve(static_cast<size_t>(args.repeats) * methods.size());

        for (int round = 0; round < args.repeats; ++round) {
            iota(order.begin(), order.end(), 0);
            if (args.randomize_order) shuffle(order.begin(), order.end(), order_rng);
            int position = 0;
            for (size_t index : order) {
                if (args.cooldown_ms > 0) {
                    this_thread::sleep_for(chrono::milliseconds(args.cooldown_ms));
                }
                const auto begin = chrono::steady_clock::now();
                methods[index]->evaluate_once();
                const auto end = chrono::steady_clock::now();
                const double milliseconds = chrono::duration<double, milli>(end - begin).count();
                results[index].samples_ms.push_back(milliseconds);
                raw_samples.push_back({args.run_label, round, position,
                                       methods[index]->id(), milliseconds});
                const MethodCounts &counts = methods[index]->last_counts();
                if (!expected_counts[index]) expected_counts[index] = counts;
                else if (!(counts == *expected_counts[index])) {
                    throw runtime_error("operation counts changed between repeats for " +
                                        methods[index]->id());
                }
                if (args.verbose_samples) {
                    cout << "sample round=" << round << " method=" << methods[index]->id()
                         << " position=" << position << " time_ms=" << fixed
                         << setprecision(3) << milliseconds << "\n";
                }
                ++position;
            }
            cout << "completed_round: " << (round + 1) << '/' << args.repeats << "\n";
        }
        append_samples_csv(args.samples_csv, raw_samples);

        for (size_t i = 0; i < methods.size(); ++i) {
            MethodResult &result = results[i];
            result.timing = summarize_samples(result.samples_ms);
            const vector<double> decoded = methods[i]->decode_last();
            result.total_error = compute_metrics_spread(decoded, exact, args.slots_to_test);
            result.method_bias = compute_metrics_spread(
                methods[i]->plain_reference(), exact, args.slots_to_test);
            result.ckks_extra = compute_metrics_spread(
                decoded, methods[i]->plain_reference(), args.slots_to_test);
            {
                vector<double> fit_values(raw_values.size());
                for (size_t k = 0; k < raw_values.size(); ++k) {
                    fit_values[k] = methods[i]->fit_activation(raw_values[k]);
                }
                const vector<double> *unrounded = methods[i]->unrounded_reference();
                const vector<double> &p_c = unrounded ? *unrounded : methods[i]->plain_reference();
                ErrorDecomposition &d = result.decomposition;
                d.e_target = compute_metrics_spread(fit_values, exact, args.slots_to_test).max_abs;
                d.e_poly = compute_metrics_spread(p_c, fit_values, args.slots_to_test).max_abs;
                d.e_coeff = unrounded
                    ? compute_metrics_spread(methods[i]->plain_reference(), *unrounded, args.slots_to_test).max_abs
                    : 0.0;
                d.e_he = result.ckks_extra.max_abs;
                d.e_total = result.total_error.max_abs;
                d.bound = d.e_target + d.e_poly + d.e_coeff + d.e_he;
                d.bound_holds = d.e_total <= d.bound * (1.0 + 1e-9) + 1e-15;
                if (!d.bound_holds) {
                    throw runtime_error("error decomposition bound violated for " + methods[i]->id());
                }
            }
            result.counts = methods[i]->last_counts();
            result.metadata = methods[i]->metadata();
        }

        const string spa_k87_ref = choose_reference(results, {"spa-k87"});
        const string orion_ref = choose_reference(results, {"orion", "orion-wide"});
        const string ensi_ref = choose_reference(results, {"ensi"});
        const string sylph_ref = choose_reference(results, {"sylph"});
        const string thor_ref = choose_reference(results, {"thor", "thor-wide"});
        map<string, double> medians;
        for (const auto &result : results) medians[result.method->id()] = result.timing.median;

        cout << "\n================ SILU SUMMARY ================\n";
        cout << scientific << setprecision(8);
        for (const MethodResult &result : results) {
            map<string, double> speedups;
            auto set_speedup = [&](const string &key, const string &ref) {
                if (!ref.empty()) speedups[key] = medians[ref] / result.timing.median;
            };
            set_speedup("spa_k87", spa_k87_ref);
            set_speedup("orion", orion_ref);
            set_speedup("ensi", ensi_ref);
            set_speedup("sylph", sylph_ref);
            set_speedup("thor", thor_ref);
            const auto &m = result.metadata;
            cout << "\nmethod: " << result.method->id() << "\n";
            cout << "family: " << m.family << "\n";
            cout << "provenance: " << m.provenance << "\n";
            cout << "reconstruction_status: " << m.reconstruction_status << "\n";
            cout << "reconstructed: " << (m.reconstructed ? "true" : "false") << "\n";
            if (!m.active_profile.empty()) {
                cout << "profile_catalog_sha256: " << m.profile_catalog_sha256 << "\n";
                cout << "spa_tier: " << m.spa_tier << "\n";
                cout << "degree_schedule: " << m.degree_schedule << "\n";
                cout << "active_profile: " << m.active_profile << "\n";
                cout << "active_square_degree: " << m.active_degree_square << "\n";
                cout << "active_ps_split: " << m.active_ps_split << "\n";
                cout << "active_ps_blocks: " << m.active_ps_blocks << "\n";
            }
            cout << "input_semantics: " << m.input_semantics << "\n";
            cout << "design_domain: [" << m.design_lo << ',' << m.design_hi << "]\n";
            cout << "offline_profile_max_error: " << m.offline_max_error << "\n";
            if (isfinite(m.offline_rmse)) cout << "offline_profile_rmse: " << m.offline_rmse << "\n";
            if (m.paper_reported_depth >= 0) cout << "paper_reported_depth: " << m.paper_reported_depth << "\n";
            if (isfinite(m.paper_reported_precision_bits)) {
                cout << "paper_reported_precision_bits: " << m.paper_reported_precision_bits << "\n";
            }
            cout << "timing_ms: median=" << result.timing.median
                 << " p25=" << result.timing.p25 << " p75=" << result.timing.p75
                 << " p95=" << result.timing.p95 << " best=" << result.timing.best
                 << " mean=" << result.timing.mean << " stddev=" << result.timing.stddev << "\n";
            for (const auto &[key, value] : speedups) {
                cout << "speedup_vs_" << key << "_median: " << value << "\n";
            }
            cout << "main_chain: fresh=" << m.fresh_chain << " output=" << m.output_chain
                 << " consumed=" << (m.fresh_chain - m.output_chain)
                 << " remaining=" << m.output_chain << "\n";
            cout << "output_scale_log2: " << m.output_scale_log2 << "\n";
            cout << "prepared_fixed_plaintexts: " << m.prepared_plaintexts << "\n";
            cout << "operation_counts: " << count_prefix(result.counts) << "\n";
            cout << "total_max_abs_error: " << result.total_error.max_abs << "\n";
            cout << "total_mean_abs_error: " << result.total_error.mean_abs << "\n";
            cout << "total_rmse: " << result.total_error.rmse << "\n";
            cout << "native_target_id: " << NATIVE_TARGET_ID << "\n";
            cout << "fit_target_id: " << result.method->fit_target_id() << "\n";
            cout << "e_target: " << result.decomposition.e_target << "\n";
            cout << "e_poly: " << result.decomposition.e_poly << "\n";
            cout << "e_coeff: " << result.decomposition.e_coeff << "\n";
            cout << "e_he: " << result.decomposition.e_he << "\n";
            cout << "e_total: " << result.decomposition.e_total << "\n";
            cout << "decomposition_bound: " << result.decomposition.bound
                 << " (holds: " << (result.decomposition.bound_holds ? "true" : "false") << ")\n";
            if (result.metadata.rounding_decimals >= 0) {
                cout << "spa_rounding_decimals: " << result.metadata.rounding_decimals
                     << " derived_from: " << result.metadata.derived_from << "\n";
            }
            cout << "method_bias_max_abs_error: " << result.method_bias.max_abs << "\n";
            cout << "method_bias_rmse: " << result.method_bias.rmse << "\n";
            cout << "ckks_extra_max_abs_error: " << result.ckks_extra.max_abs << "\n";
            cout << "ckks_extra_rmse: " << result.ckks_extra.rmse << "\n";
            cout << "outside_domain_count: " << m.outside_domain_count << "\n";
            cout << "max_abs_normalized: " << m.max_abs_normalized << "\n";
            append_summary_csv(args.csv_out, args, result, speedups);
        }
        cout << defaultfloat;
        if (!args.csv_out.empty()) cout << "summary_csv_appended: " << args.csv_out << "\n";
        if (!args.samples_csv.empty()) cout << "samples_csv_appended: " << args.samples_csv << "\n";
        return 0;
    } catch (const exception &error) {
        cerr << "ERROR: " << error.what() << "\n";
        return 1;
    }
}
