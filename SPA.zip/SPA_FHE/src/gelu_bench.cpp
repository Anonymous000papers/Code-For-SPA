#include "spa_ckks_core.hpp"
#include "euston_circuit.hpp"
#include "moai_model_eval.hpp"
#include <functional>

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <memory>
#include <numeric>
#include <optional>
#include <random>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

namespace fs = std::filesystem;
using namespace std;
using namespace seal;
using namespace spa;

namespace gelu_bench {

// Summary CSV schema tag written to implementation_revision; consumers
// (scripts/check_ciphertext_results.py) verify it.
static const char *const CSV_SCHEMA = "spa-1";

// Native target. One source builds two benchmarks: gelu_bench (exact erf-GELU,
// profiles from spa_profiles.hpp; methods SPA x3, NEXUS, MOAI) and
// gelu_quickgelu_bench (QuickGELU, profiles from spa_quickgelu_profiles.hpp,
// defined through SPA_GELU_TARGET_QUICKGELU and SPA_PROFILE_HEADER by CMake;
// methods SPA x3, Euston). The comparison baselines keep their own fitting
// targets; the gap to the native target is reported as E_target.
// QuickGELU x*sigmoid(1.702x): Euston's fitting target, also a native
// target of its own (gelu_quickgelu_bench) so SPA refitted to it can be
// compared with Euston on equal terms (E_target = 0 for both).
inline double quickgelu_plain(double x) {
    return x / (1.0 + exp(-1.702 * x));
}

#if defined(SPA_GELU_TARGET_QUICKGELU)
static const char *const NATIVE_TARGET_ID = "quickgelu";
static const char *const NATIVE_TARGET_LABEL = "QuickGELU x*sigmoid(1.702x)";
inline double native_activation(double x) { return quickgelu_plain(x); }
#else
static const char *const NATIVE_TARGET_ID = "erf-gelu";
static const char *const NATIVE_TARGET_LABEL = "exact erf-GELU 0.5*x*(1+erf(x/sqrt(2)))";
inline double native_activation(double x) { return gelu_exact(x); }
#endif

// MOAI: the plaintext model's own profiles (moai_model_profiles*.hpp), imported
// verbatim by scripts/import_model_moai_profiles.py; see MoaiModelMethod.

struct Args {
    string methods = "spa-k39,spa-k63,spa-k87,moai,nexus,euston";
    string input_mode = "grid"; // grid | random
    size_t slots_to_test = 32768;
    int warmups = 2;
    int repeats = 10;
    int euston_breakdown_repeats = 1;
    int cooldown_ms = 0;
    int middle_primes = 22;
    int reserve_levels = 4;
    int prime_bits = 46;
    uint64_t seed = 12345;
    uint64_t order_seed = 20260831;
    double lo = -5.0;
    double hi = 5.0;
    double scale_bits = 46.0;
    double euston_scale_bits = 35.0;
    int euston_prime_bits = 35;
    int euston_levels = 0;
    double euston_sign_scale = 0.0;
    int euston_tau = -1;
    int euston_g_rounds = 3;
    int euston_f_rounds = 3;
    int euston_inverse_iterations = 3;
    size_t poly_degree = 65536;
    bool describe_plan = false;
    bool secure128 = true;
    bool randomize_order = true;
    bool verbose_samples = false;
    int nexus_g_rounds = 2;
    int nexus_f_rounds = 0;
    double nexus_sign_scale = 0.0;
    bool list_methods = false;
    string csv_out;
    string samples_csv;
    string run_label = "run0";
};

void print_help() {
    cout
        << "CKKS GELU microbenchmark\n\n"
        << "Methods:\n"
        << "  --methods CSV                 Comma-separated method IDs\n"
        << "  --method ID                   Single-method alias\n"
        << "  --list-methods                Print supported IDs\n\n"
        << "Common input and scheduling:\n"
        << "  --range LO HI                 Common raw-x range (default -5 5)\n"
        << "  --input grid|random           Same full-slot input for every method\n"
        << "  --slots N                     Slots used for reported errors (N<=32768)\n"
        << "  --seed N                      Random-input seed\n"
        << "  --order-seed N                Method-order shuffle seed\n"
        << "  --fixed-order                 Disable per-round order randomization\n"
        << "  --verbose-samples             Print each sample after it is measured\n"
        << "  --cooldown-ms N               Optional pause between timed methods\n\n"
        << "Benchmark policy:\n"
        << "  --warmup N                    Untimed warm-up rounds after preparation\n"
        << "  --repeat N                    Timed randomized rounds\n"
        << "  --euston-breakdown N          Untimed-after-main diagnostic rounds\n"
        << "  --levels N                    Number of middle primes (default 22)\n"
        << "  --reserve-levels N            Levels kept after the deepest method (default 4)\n"
        << "  --scale-bits B                Common CKKS scale exponent\n"
        << "  --prime-bits B                Middle-prime size in bits (default 46)\n"
        << "  --euston-scale-bits B         Euston single-chain scale exponent (35)\n"
        << "  --euston-prime-bits B         Euston middle prime bits (35)\n"
        << "  --euston-levels N             0=critical path + reserve (default 0)\n"
        << "  --euston-sign-scale S         0=1.2*public radius (default 0)\n"
        << "  --euston-tau N                -1=range-derived exp squarings\n"
        << "  --euston-g-rounds N           Sign g compositions (3)\n"
        << "  --euston-f-rounds N           Sign f compositions (3)\n"
        << "  --euston-inverse-iterations N Goldschmidt product rounds (3)\n"
        << "  --poly-degree N               Ring degree (65536, depends on linked SEAL support)\n"
        << "  --describe-plan               Print public parameters without keys/evaluation\n"
        << "  --nexus-g-rounds N            NEXUS g-composition rounds (default 2)\n"
        << "  --nexus-f-rounds N            NEXUS f-composition rounds (0 selects by range)\n"
        << "  --nexus-sign-scale S          Override NEXUS comparison normalization (0=auto)\n"
        << "  --no-sec                      Disable SEAL security validation (smoke only)\n\n"
        << "Output:\n"
        << "  --csv-out FILE                Append one summary row per method\n"
        << "  --samples-csv FILE            Append every timed sample\n"
        << "  --run-label TEXT              Label written to CSV files\n"
        << "  -h, --help\n\n"
        << "Fixed plaintext preparation, input encryption, output decryption, and metrics\n"
        << "are outside timing. No intermediate decryption, refresh or bootstrapping.\n";
}

vector<string> split_csv(const string &value) {
    vector<string> result;
    string token;
    istringstream input(value);
    while (getline(input, token, ',')) {
        const auto first = token.find_first_not_of(" \t\r\n");
        if (first == string::npos) continue;
        const auto last = token.find_last_not_of(" \t\r\n");
        result.push_back(token.substr(first, last - first + 1));
    }
    if (result.empty()) throw invalid_argument("method list is empty");
    return result;
}

Args parse_args(int argc, char **argv) {
    Args args;
    for (int i = 1; i < argc; ++i) {
        const string flag(argv[i]);
        auto need = [&](const string &name) -> string {
            if (i + 1 >= argc) throw invalid_argument("missing value for " + name);
            return string(argv[++i]);
        };
        if (flag == "--methods") args.methods = need(flag);
        else if (flag == "--method") args.methods = need(flag);
        else if (flag == "--range") {
            args.lo = stod(need("--range LO"));
            args.hi = stod(need("--range HI"));
        } else if (flag == "--input") args.input_mode = need(flag);
        else if (flag == "--slots") args.slots_to_test = static_cast<size_t>(stoull(need(flag)));
        else if (flag == "--warmup") args.warmups = stoi(need(flag));
        else if (flag == "--repeat" || flag == "--repeats") args.repeats = stoi(need(flag));
        else if (flag == "--euston-breakdown") args.euston_breakdown_repeats = stoi(need(flag));
        else if (flag == "--cooldown-ms") args.cooldown_ms = stoi(need(flag));
        else if (flag == "--levels") args.middle_primes = stoi(need(flag));
        else if (flag == "--reserve-levels") args.reserve_levels = stoi(need(flag));
        else if (flag == "--prime-bits") args.prime_bits = stoi(need(flag));
        else if (flag == "--seed") args.seed = static_cast<uint64_t>(stoull(need(flag)));
        else if (flag == "--order-seed") {
            args.order_seed = static_cast<uint64_t>(stoull(need(flag)));
        }
        else if (flag == "--scale-bits") args.scale_bits = stod(need(flag));
        else if (flag == "--euston-scale-bits") args.euston_scale_bits = stod(need(flag));
        else if (flag == "--fixed-order") args.randomize_order = false;
        else if (flag == "--verbose-samples") args.verbose_samples = true;
        else if (flag == "--allow-euston-wide") {
            throw invalid_argument("--allow-euston-wide was removed: Euston now adapts its parameters automatically through R20");
        }
        else if (flag == "--euston-prime-bits") args.euston_prime_bits = stoi(need(flag));
        else if (flag == "--euston-levels") args.euston_levels = stoi(need(flag));
        else if (flag == "--euston-sign-scale") args.euston_sign_scale = stod(need(flag));
        else if (flag == "--euston-tau") args.euston_tau = stoi(need(flag));
        else if (flag == "--euston-g-rounds") args.euston_g_rounds = stoi(need(flag));
        else if (flag == "--euston-f-rounds") args.euston_f_rounds = stoi(need(flag));
        else if (flag == "--euston-inverse-iterations") args.euston_inverse_iterations = stoi(need(flag));
        else if (flag == "--poly-degree") args.poly_degree = stoull(need(flag));
        else if (flag == "--describe-plan") args.describe_plan = true;
        else if (flag == "--nexus-g-rounds") args.nexus_g_rounds = stoi(need(flag));
        else if (flag == "--nexus-f-rounds") args.nexus_f_rounds = stoi(need(flag));
        else if (flag == "--nexus-sign-scale") args.nexus_sign_scale = stod(need(flag));
        else if (flag == "--no-sec") args.secure128 = false;
        else if (flag == "--csv-out") args.csv_out = need(flag);
        else if (flag == "--samples-csv") args.samples_csv = need(flag);
        else if (flag == "--run-label") args.run_label = need(flag);
        else if (flag == "--list-methods") args.list_methods = true;
        else if (flag == "--help" || flag == "-h") {
            print_help();
            exit(0);
        } else {
            throw invalid_argument("unknown argument: " + flag);
        }
    }
    if (!(args.lo < args.hi)) throw invalid_argument("--range requires LO < HI");
    if (args.input_mode != "grid" && args.input_mode != "random") {
        throw invalid_argument("--input must be grid or random");
    }
    if (args.slots_to_test == 0 || args.slots_to_test > 32768) {
        throw invalid_argument("--slots must be in [1,32768]");
    }
    if (args.warmups < 0 || args.repeats < 1 || args.euston_breakdown_repeats < 0) {
        throw invalid_argument("warmup/breakdown must be nonnegative and repeat must be positive");
    }
    if (args.cooldown_ms < 0) throw invalid_argument("--cooldown-ms must be nonnegative");
    if (args.middle_primes < 8) throw invalid_argument("--levels is too short");
    if (args.reserve_levels < 0) throw invalid_argument("--reserve-levels must be nonnegative");
    if (args.prime_bits < 35 || args.prime_bits > 55) {
        throw invalid_argument("--prime-bits must be in [35,55]");
    }
    if (abs(args.scale_bits - static_cast<double>(args.prime_bits)) > 1.0) {
        throw invalid_argument("--scale-bits and --prime-bits must differ by at most one bit");
    }
    if (args.nexus_g_rounds < 1 || args.nexus_f_rounds < 0) {
        throw invalid_argument(
            "NEXUS composition rounds must be positive "
            "(or zero for auto f-rounds)");
    }
    if (args.nexus_sign_scale < 0.0) {
        throw invalid_argument("--nexus-sign-scale must be nonnegative");
    }
    if (!isfinite(args.lo) || !isfinite(args.hi) || !isfinite(args.scale_bits) ||
        !isfinite(args.euston_scale_bits) || !isfinite(args.euston_sign_scale))
        throw invalid_argument("range and scale parameters must be finite");
    if (args.poly_degree < 8192 || (args.poly_degree & (args.poly_degree-1)) != 0)
        throw invalid_argument("--poly-degree must be a power of two >=8192");
    if (args.slots_to_test > args.poly_degree/2)
        throw invalid_argument("--slots exceeds poly-degree/2");
    if (args.euston_levels<0 || args.euston_tau < -1 || args.euston_sign_scale<0.)
        throw invalid_argument("invalid Euston parameter override");
    if (args.euston_prime_bits < 30 || args.euston_prime_bits > 55 ||
        abs(args.euston_scale_bits-args.euston_prime_bits)>1.)
        throw invalid_argument("Euston prime bits must be 30..55 and within one bit of its scale");
    return args;
}

void print_supported_methods() {
    for (const auto *method : spa::builtin_methods()) cout << method->id << "\n";
    cout << "moai\n"
         << "nexus\n"
         << "euston\n";
}

uint64_t double_bits(double value) {
    uint64_t bits = 0;
    static_assert(sizeof(bits) == sizeof(value), "unexpected double size");
    memcpy(&bits, &value, sizeof(bits));
    return bits;
}

void add_operation_counts(OperationCounts &dst, const OperationCounts &src) {
    dst.ct_ct_multiply += src.ct_ct_multiply;
    dst.ct_square += src.ct_square;
    dst.ct_plain_multiply += src.ct_plain_multiply;
    dst.relinearize += src.relinearize;
    dst.rescale += src.rescale;
    dst.mod_switch += src.mod_switch;
    dst.ct_add += src.ct_add;
    dst.ct_sub += src.ct_sub;
    dst.add_plain += src.add_plain;
}

struct MethodCounts {
    OperationCounts he;
    uint64_t ct_negate = 0;
    uint64_t dynamic_plain_encode = 0;
    uint64_t encrypt = 0;
    uint64_t decrypt = 0;
    uint64_t decode = 0;

    uint64_t total_ct_ct() const { return he.total_ct_ct(); }

    bool operator==(const MethodCounts &other) const {
        return he == other.he &&
               ct_negate == other.ct_negate &&
               dynamic_plain_encode == other.dynamic_plain_encode &&
               encrypt == other.encrypt && decrypt == other.decrypt && decode == other.decode;
    }
};

MethodCounts sum_counts(const MethodCounts &a, const MethodCounts &b) {
    MethodCounts out = a;
    add_operation_counts(out.he, b.he);
    out.ct_negate += b.ct_negate;
    out.dynamic_plain_encode += b.dynamic_plain_encode;
    out.encrypt += b.encrypt;
    out.decrypt += b.decrypt;
    out.decode += b.decode;
    return out;
}

struct PlainKey {
    int chain = -1;
    uint64_t value_bits = 0;
    uint64_t scale_bits = 0;

    bool operator==(const PlainKey &other) const {
        return chain == other.chain && value_bits == other.value_bits && scale_bits == other.scale_bits;
    }
};

struct PlainKeyHash {
    size_t operator()(const PlainKey &key) const {
        size_t h = std::hash<int>{}(key.chain);
        h ^= std::hash<uint64_t>{}(key.value_bits) + 0x9e3779b97f4a7c15ULL + (h << 6U) + (h >> 2U);
        h ^= std::hash<uint64_t>{}(key.scale_bits) + 0x9e3779b97f4a7c15ULL + (h << 6U) + (h >> 2U);
        return h;
    }
};

// The first untimed preparation trace fills this cache. Timed evaluation is
// forbidden from encoding a new fixed scalar plaintext.
class ScalarPlainCache {
public:
    explicit ScalarPlainCache(HEEnv &env) : env_(env) {}

    const Plaintext &get(double value, parms_id_type id, double scale) {
        auto data = env_.context->get_context_data(id);
        if (!data) throw runtime_error("plaintext cache received an unknown parms_id");
        PlainKey key{data->chain_index(), double_bits(value), double_bits(scale)};
        auto it = values_.find(key);
        if (it != values_.end()) return it->second;
        if (frozen_) {
            ostringstream message;
            message << "fixed plaintext cache miss after freeze: chain=" << key.chain
                    << " value=" << setprecision(17) << value
                    << " scale_log2=" << log2(scale);
            throw runtime_error(message.str());
        }
        Plaintext plain;
        env_.encoder->encode(value, id, scale, plain);
        auto inserted = values_.emplace(key, std::move(plain));
        return inserted.first->second;
    }

    void freeze() { frozen_ = true; }
    size_t size() const { return values_.size(); }

private:
    HEEnv &env_;
    bool frozen_ = false;
    unordered_map<PlainKey, Plaintext, PlainKeyHash> values_;
};

int total_modulus_bits(const HEEnv &env) {
    return env.context->key_context_data()->total_coeff_modulus_bit_count();
}

uint64_t get_modulus(const HEEnv &env, const Ciphertext &x, int k) {
    const vector<Modulus> &modulus =
        env.context->get_context_data(x.parms_id())->parms().coeff_modulus();
    const int size = static_cast<int>(modulus.size());
    if (k < 1 || k > size) throw runtime_error("not enough modulus primes");
    return modulus[static_cast<size_t>(size - k)].value();
}

void counted_mod_switch_to(HEEnv &env, Ciphertext &ct, parms_id_type target,
                           MethodCounts &counts) {
    if (ct.parms_id() != target) {
        env.evaluator->mod_switch_to_inplace(ct, target);
        ++counts.he.mod_switch;
    }
}

void counted_mod_switch_next(HEEnv &env, Ciphertext &ct, MethodCounts &counts) {
    env.evaluator->mod_switch_to_next_inplace(ct);
    ++counts.he.mod_switch;
}

void counted_relinearize(HEEnv &env, Ciphertext &ct, MethodCounts &counts) {
    env.evaluator->relinearize_inplace(ct, env.relin_keys);
    ++counts.he.relinearize;
}

void counted_rescale(HEEnv &env, Ciphertext &ct, MethodCounts &counts) {
    env.evaluator->rescale_to_next_inplace(ct);
    ++counts.he.rescale;
}

Ciphertext counted_multiply_rescale(HEEnv &env, Ciphertext lhs, Ciphertext rhs,
                                    MethodCounts &counts, optional<double> target_scale) {
    const int left_chain = chain_index(*env.context, lhs);
    const int right_chain = chain_index(*env.context, rhs);
    if (left_chain > right_chain) counted_mod_switch_to(env, lhs, rhs.parms_id(), counts);
    else if (right_chain > left_chain) counted_mod_switch_to(env, rhs, lhs.parms_id(), counts);
    if (target_scale) {
        lhs.scale() = *target_scale;
        rhs.scale() = *target_scale;
    }
    Ciphertext out;
    env.evaluator->multiply(lhs, rhs, out);
    ++counts.he.ct_ct_multiply;
    counted_relinearize(env, out, counts);
    counted_rescale(env, out, counts);
    if (target_scale) out.scale() = *target_scale;
    return out;
}

Ciphertext counted_square_rescale(HEEnv &env, const Ciphertext &input,
                                  MethodCounts &counts, optional<double> target_scale) {
    Ciphertext out;
    env.evaluator->square(input, out);
    ++counts.he.ct_square;
    counted_relinearize(env, out, counts);
    counted_rescale(env, out, counts);
    if (target_scale) out.scale() = *target_scale;
    return out;
}

Ciphertext counted_multiply_plain_rescale(
    HEEnv &env, Ciphertext ct, double value, double plain_scale,
    optional<double> target_scale, ScalarPlainCache &cache, MethodCounts &counts) {
    if (target_scale) ct.scale() = *target_scale;
    const Plaintext &plain = cache.get(value, ct.parms_id(), plain_scale);
    env.evaluator->multiply_plain_inplace(ct, plain);
    ++counts.he.ct_plain_multiply;
    counted_rescale(env, ct, counts);
    if (target_scale) ct.scale() = *target_scale;
    return ct;
}

Ciphertext counted_multiply_const_current(
    HEEnv &env, Ciphertext ct, double value, ScalarPlainCache &cache,
    MethodCounts &counts) {
    const Plaintext &plain = cache.get(value, ct.parms_id(), ct.scale());
    env.evaluator->multiply_plain_inplace(ct, plain);
    ++counts.he.ct_plain_multiply;
    counted_rescale(env, ct, counts);
    return ct;
}

void counted_add_plain_current(HEEnv &env, Ciphertext &ct, double value,
                               ScalarPlainCache &cache, MethodCounts &counts) {
    const Plaintext &plain = cache.get(value, ct.parms_id(), ct.scale());
    env.evaluator->add_plain_inplace(ct, plain);
    ++counts.he.add_plain;
}

void counted_add_cipher(HEEnv &env, Ciphertext &dst, const Ciphertext &src,
                        MethodCounts &counts) {
    env.evaluator->add_inplace(dst, src);
    ++counts.he.ct_add;
}

Ciphertext evaluate_odd9(HEEnv &env, ScalarPlainCache &cache,
                         const vector<double> &coefficients, Ciphertext x,
                         MethodCounts &counts) {
    const double base_scale = x.scale();
    uint64_t p = get_modulus(env, x, 2);
    uint64_t q = get_modulus(env, x, 3);
    uint64_t r = get_modulus(env, x, 4);
    (void)get_modulus(env, x, 5);

    Ciphertext x2 = counted_square_rescale(env, x, counts, nullopt);
    counted_mod_switch_next(env, x, counts);

    Ciphertext x3;
    env.evaluator->multiply(x2, x, x3);
    ++counts.he.ct_ct_multiply;
    counted_relinearize(env, x3, counts);
    counted_rescale(env, x3, counts);
    Ciphertext x6 = counted_square_rescale(env, x3, counts, nullopt);

    Ciphertext t1;
    const double a5_scale = base_scale / x2.scale() * static_cast<double>(p) /
                            x3.scale() * static_cast<double>(q);
    env.evaluator->multiply_plain(
        x2, cache.get(coefficients[5], x2.parms_id(), a5_scale), t1);
    ++counts.he.ct_plain_multiply;
    counted_rescale(env, t1, counts);
    env.evaluator->add_plain_inplace(
        t1, cache.get(coefficients[3], t1.parms_id(), t1.scale()));
    ++counts.he.add_plain;
    env.evaluator->multiply_inplace(t1, x3);
    ++counts.he.ct_ct_multiply;
    counted_relinearize(env, t1, counts);
    counted_rescale(env, t1, counts);

    Ciphertext t2;
    const double a9_scale = base_scale / x3.scale() * static_cast<double>(r) /
                            x6.scale() * static_cast<double>(q);
    env.evaluator->multiply_plain(
        x3, cache.get(coefficients[9], x3.parms_id(), a9_scale), t2);
    ++counts.he.ct_plain_multiply;
    counted_rescale(env, t2, counts);

    const double a7_scale = t2.scale() / x.scale() * static_cast<double>(p);
    Ciphertext a7x;
    env.evaluator->multiply_plain(
        x, cache.get(coefficients[7], x.parms_id(), a7_scale), a7x);
    ++counts.he.ct_plain_multiply;
    counted_rescale(env, a7x, counts);
    counted_mod_switch_to(env, a7x, t2.parms_id(), counts);
    const double t2_scale = 0.5 * (t2.scale() + a7x.scale());
    t2.scale() = t2_scale;
    a7x.scale() = t2_scale;
    counted_add_cipher(env, t2, a7x, counts);
    env.evaluator->multiply_inplace(t2, x6);
    ++counts.he.ct_ct_multiply;
    counted_relinearize(env, t2, counts);
    counted_rescale(env, t2, counts);

    Ciphertext t3;
    env.evaluator->multiply_plain(
        x, cache.get(coefficients[1], x.parms_id(), static_cast<double>(p)), t3);
    ++counts.he.ct_plain_multiply;
    counted_rescale(env, t3, counts);

    const double output_scale = (t1.scale() + t2.scale() + t3.scale()) / 3.0;
    t1.scale() = output_scale;
    t2.scale() = output_scale;
    t3.scale() = output_scale;
    counted_mod_switch_to(env, t1, t2.parms_id(), counts);
    counted_add_cipher(env, t2, t1, counts);
    counted_mod_switch_to(env, t3, t2.parms_id(), counts);
    counted_add_cipher(env, t2, t3, counts);
    return t2;
}

// Scalar rescaling with an explicit target scale. Unlike a bare metadata
// rewrite, the plaintext scale compensates for the ACTUAL prime being dropped.
Ciphertext multiply_constant_exact_scale(HEEnv &env, ScalarPlainCache &cache,
        Ciphertext input, double value, MethodCounts &counts, double output_scale) {
    const double q=static_cast<double>(get_modulus(env,input,1));
    const double plaintext_scale=output_scale*q/input.scale();
    const Plaintext &p=cache.get(value,input.parms_id(),plaintext_scale);
    env.evaluator->multiply_plain_inplace(input,p);
    ++counts.he.ct_plain_multiply;
    counted_rescale(env,input,counts);
    if (abs(input.scale()/output_scale-1.0)>1e-12)
        throw runtime_error("constant multiplication scale mismatch");
    input.scale()=output_scale; // only removes floating-point roundoff
    return input;
}

// Balanced power graph, followed by one coefficient/rescale layer. The
// coefficients include exp input scaling in the caller, never a native exp.
Ciphertext polynomial_balanced(HEEnv &env, ScalarPlainCache &cache,
        const Ciphertext &x,const vector<double> &coeff,MethodCounts &counts) {
    map<int,Ciphertext> powers;
    powers.emplace(1,x);
    function<const Ciphertext&(int)> power=[&](int n)->const Ciphertext& {
        auto found=powers.find(n);
        if(found!=powers.end()) return found->second;
        int a=n/2,b=n-a;
        Ciphertext value;
        if(a==b) value=counted_square_rescale(env,power(a),counts,nullopt);
        else {
            const Ciphertext &left=power(a);
            const Ciphertext &right=power(b);
            value=counted_multiply_rescale(env,left,right,counts,nullopt);
        }
        return powers.emplace(n,std::move(value)).first->second;
    };
    int max_degree=static_cast<int>(coeff.size())-1;
    while(max_degree>0 && coeff[static_cast<size_t>(max_degree)]==0.0) --max_degree;
    if(max_degree==0) throw invalid_argument("constant-only polynomial not supported here");
    for(int i=1;i<=max_degree;++i) if(coeff[static_cast<size_t>(i)]!=0.) power(i);
    auto target=power(max_degree).parms_id();
    Ciphertext result;
    bool started=false;
    for(int i=1;i<=max_degree;++i) {
        if(coeff[static_cast<size_t>(i)]==0.) continue;
        Ciphertext t=power(i);
        counted_mod_switch_to(env,t,target,counts);
        t=multiply_constant_exact_scale(env,cache,std::move(t),coeff[static_cast<size_t>(i)],counts,env.scale);
        if(!started) { result=std::move(t);started=true; }
        else counted_add_cipher(env,result,t,counts);
    }
    counted_add_plain_current(env,result,coeff[0],cache,counts);
    return result;
}

// Direct Chebyshev polynomial in t=x/R, not SPA's square-domain polynomial.
Ciphertext chebyshev_balanced(HEEnv &env,ScalarPlainCache &cache,
        const Ciphertext &x,const vector<double> &coeff,MethodCounts &counts) {
    map<int,Ciphertext> basis;
    basis.emplace(1,x);
    function<const Ciphertext&(int)> term=[&](int n)->const Ciphertext& {
        auto found=basis.find(n);
        if(found!=basis.end()) return found->second;
        int a=n/2,b=n-a;
        Ciphertext v;
        if(a==b) v=counted_square_rescale(env,term(a),counts,nullopt);
        else {
            const Ciphertext &left=term(a);
            const Ciphertext &right=term(b);
            v=counted_multiply_rescale(env,left,right,counts,nullopt);
        }
        env.evaluator->add_inplace(v,v); ++counts.he.ct_add;
        if(a==b) counted_add_plain_current(env,v,-1.,cache,counts);
        else {
            // The low-depth T1 branch is scaled with a real multiply/rescale
            // before alignment. No arbitrary unequal-scale metadata rewrite.
            Ciphertext low=multiply_constant_exact_scale(env,cache,x,1.,counts,v.scale());
            counted_mod_switch_to(env,low,v.parms_id(),counts);
            env.evaluator->sub_inplace(v,low); ++counts.he.ct_sub;
        }
        return basis.emplace(n,std::move(v)).first->second;
    };
    int d=static_cast<int>(coeff.size())-1;
    for(int i=1;i<=d;++i) if(coeff[static_cast<size_t>(i)]!=0.) term(i);
    auto target=term(d).parms_id();
    Ciphertext result;bool started=false;
    for(int i=1;i<=d;++i) {
        if(coeff[static_cast<size_t>(i)]==0.) continue;
        Ciphertext t=term(i);
        counted_mod_switch_to(env,t,target,counts);
        t=multiply_constant_exact_scale(env,cache,std::move(t),coeff[static_cast<size_t>(i)],counts,env.scale);
        if(!started) {result=std::move(t);started=true;}
        else counted_add_cipher(env,result,t,counts);
    }
    counted_add_plain_current(env,result,coeff[0],cache,counts);
    return result;
}

struct SealEustonOps {
    using Value=Ciphertext;
    HEEnv &env;
    ScalarPlainCache &cache;
    MethodCounts &counts;
    Value constant_multiply(const Value &x,double c) {
        return multiply_constant_exact_scale(env,cache,x,c,counts,env.scale);
    }
    Value multiply(const Value &a,const Value &b) {
        return counted_multiply_rescale(env,a,b,counts,nullopt);
    }
    Value square(const Value &x) { return counted_square_rescale(env,x,counts,nullopt); }
    Value add_constant(Value x,double c) {
        counted_add_plain_current(env,x,c,cache,counts); return x;
    }
    Value polynomial(const Value &x,const vector<double>& c) {
        return polynomial_balanced(env,cache,x,c,counts);
    }
    Value odd9(const Value &x,const vector<double>& c) {
        return evaluate_odd9(env,cache,c,x,counts);
    }
};

double nexus_middle_plain(double x) {
    static const array<double, 8> coefficients = {
        2.25775755e-04, 5.00000000e-01, 3.96880960e-01,
        -6.37042698e-02, 8.38841647e-03, -7.17830961e-04,
        3.49617829e-05, -7.26059653e-07};
    const double x2 = x * x;
    double power = x2;
    double value = coefficients[0] + coefficients[1] * x;
    for (size_t i = 2; i < coefficients.size(); ++i) {
        value += coefficients[i] * power;
        power *= x2;
    }
    return value;
}

struct NexusConfig {
    double gate = 3.5;
    double sign_scale = 0.0;
    double required_sign_scale = 0.0;
    int g_rounds = 2;
    int f_rounds = 2;
    double center_abs_max = 0.0;
    double gate_condition_max = 0.0;
    double gate_error_budget = 0.0;
    double ulp_margin = 0.0;
    string conditioning_status;
};

double nexus_required_sign_scale(double lo, double hi, double gate) {
    return max({abs(lo + gate), abs(hi + gate),
                abs(lo - gate), abs(hi - gate)});
}

int nexus_default_f_rounds(double lo, double hi) {
    const double radius = max(abs(lo), abs(hi));
    // The supplied NEXUS GELU source uses Delta=8.5, d_g=2, d_f=2
    // for its [-5,5] input file. Wider public domains require additional
    // final f-compositions to suppress plaintext gate leakage.
    if (radius <= 5.0 + 1e-12) return 2;
    if (radius <= 8.0 + 1e-12) return 3;
    if (radius <= 20.0 + 1e-12) return 4;
    throw invalid_argument(
        "NEXUS automatic range adaptation is defined through |x|<=20; "
        "set --nexus-f-rounds and --nexus-sign-scale for a custom profile");
}

NexusConfig make_nexus_config(const Args &args) {
    NexusConfig config;
    config.required_sign_scale =
        nexus_required_sign_scale(args.lo, args.hi, config.gate);
    config.sign_scale = args.nexus_sign_scale > 0.0
                            ? args.nexus_sign_scale
                            : config.required_sign_scale;
    if (config.sign_scale + 1e-12 < config.required_sign_scale) {
        ostringstream message;
        message << "NEXUS sign scale " << config.sign_scale
                << " is too small for [" << args.lo << ',' << args.hi
                << "]; use at least " << config.required_sign_scale;
        throw invalid_argument(message.str());
    }
    config.g_rounds = args.nexus_g_rounds;
    config.f_rounds = args.nexus_f_rounds > 0
                          ? args.nexus_f_rounds
                          : nexus_default_f_rounds(args.lo, args.hi);

    constexpr int conditioning_samples = 20001;
    for (int i = 0; i < conditioning_samples; ++i) {
        const double x = args.lo + (args.hi - args.lo) *
            static_cast<double>(i) / static_cast<double>(conditioning_samples - 1);
        const double middle = nexus_middle_plain(x);
        config.center_abs_max = max(config.center_abs_max, abs(middle));
        const double condition = abs(middle) + abs(x - middle);
        config.gate_condition_max = max(config.gate_condition_max, condition);
    }
    config.gate_error_budget = 1e-3 / config.gate_condition_max;
    const double one_ulp = exp2(-args.scale_bits);
    config.ulp_margin = config.gate_error_budget / one_ulp;
    const double radius = max(abs(args.lo), abs(args.hi));
    if (radius <= 5.0 + 1e-12 && config.g_rounds == 2 &&
        config.f_rounds == 2 &&
        abs(config.sign_scale - 8.5) <= 1e-12) {
        config.conditioning_status = "source-domain";
    } else if (radius <= 8.0 + 1e-12) {
        config.conditioning_status = "validated-range-adaptation";
    } else if (config.ulp_margin < 64.0) {
        config.conditioning_status = "ill-conditioned-range-extension";
    } else {
        config.conditioning_status = "experimental-range-extension";
    }
    return config;
}

int nexus_required_levels(const NexusConfig &config) {
    // The supplied dg=2, df=2 graph consumes 18 levels. Each additional
    // degree-9 composition adds four levels on the critical path.
    return 18 + 4 * (config.g_rounds + config.f_rounds - 4);
}

const vector<double> &nexus_f_coeffs() {
    static const vector<double> coeffs = {
        0.0, 315.0 / 128.0, 0.0, -420.0 / 128.0, 0.0,
        378.0 / 128.0, 0.0, -180.0 / 128.0, 0.0, 35.0 / 128.0};
    return coeffs;
}

const vector<double> &nexus_g_coeffs() {
    static const vector<double> coeffs = {
        0.0, 5850.0 / 1024.0, 0.0, -34974.0 / 1024.0, 0.0,
        97015.0 / 1024.0, 0.0, -113492.0 / 1024.0, 0.0,
        46623.0 / 1024.0};
    return coeffs;
}

vector<double> scaled_coefficients(const vector<double> &coefficients,
                                   double factor) {
    vector<double> result = coefficients;
    for (double &value : result) value *= factor;
    return result;
}

Ciphertext evaluate_nexus_sign(HEEnv &env, ScalarPlainCache &cache,
                               Ciphertext input, const NexusConfig &config,
                               MethodCounts &counts) {
    // The NEXUS source applies the 0.5 output factor once, folded into the
    // final composition (the last f round, or the last g round if df = 0).
    // Applying it earlier would feed the f stage +-0.5 instead of +-1 and
    // leave a gate residual that the centre polynomial amplifies outside
    // the centre interval.
    const vector<double> g_last = scaled_coefficients(nexus_g_coeffs(), 0.5);
    const vector<double> f_last = scaled_coefficients(nexus_f_coeffs(), 0.5);
    const bool factor_on_g = config.f_rounds == 0;
    Ciphertext value = std::move(input);
    for (int round = 0; round < config.g_rounds; ++round) {
        const vector<double> &coefficients =
            (factor_on_g && round + 1 == config.g_rounds) ? g_last : nexus_g_coeffs();
        value = evaluate_odd9(env, cache, coefficients, std::move(value), counts);
    }
    for (int round = 0; round < config.f_rounds; ++round) {
        const vector<double> &coefficients =
            round + 1 == config.f_rounds ? f_last : nexus_f_coeffs();
        value = evaluate_odd9(env, cache, coefficients, std::move(value), counts);
    }
    return value;
}

inline double eval_odd9_plain(double x, const vector<double> &coefficients) {
    const double x2 = x * x;
    return x * (coefficients[1] + x2 * (coefficients[3] +
           x2 * (coefficients[5] + x2 * (coefficients[7] +
           x2 * coefficients[9]))));
}

inline double nexus_sign_plain(double x, const NexusConfig &config) {
    const vector<double> g_last = scaled_coefficients(nexus_g_coeffs(), 0.5);
    const vector<double> f_last = scaled_coefficients(nexus_f_coeffs(), 0.5);
    const bool factor_on_g = config.f_rounds == 0;
    double value = x;
    for (int round = 0; round < config.g_rounds; ++round) {
        value = eval_odd9_plain(
            value, (factor_on_g && round + 1 == config.g_rounds) ? g_last : nexus_g_coeffs());
    }
    for (int round = 0; round < config.f_rounds; ++round) {
        value = eval_odd9_plain(
            value, round + 1 == config.f_rounds ? f_last : nexus_f_coeffs());
    }
    return value;
}

inline double nexus_gelu_plain(double x, const NexusConfig &config) {
    const double middle = nexus_middle_plain(x);
    const double left = nexus_sign_plain(
        (x + config.gate) / config.sign_scale, config);
    const double right = nexus_sign_plain(
        (x - config.gate) / config.sign_scale, config);
    return middle * (left - right) + x * (right + 0.5);
}

struct SampleStats {
    double best = 0.0;
    double median = 0.0;
    double p25 = 0.0;
    double p75 = 0.0;
    double p95 = 0.0;
    double mean = 0.0;
    double stddev = 0.0;
};

double quantile(const vector<double> &sorted, double p) {
    if (sorted.empty()) throw invalid_argument("quantile of empty sample");
    if (sorted.size() == 1) return sorted.front();
    const double position = p * static_cast<double>(sorted.size() - 1);
    const size_t lo = static_cast<size_t>(floor(position));
    const size_t hi = static_cast<size_t>(ceil(position));
    const double fraction = position - static_cast<double>(lo);
    return sorted[lo] * (1.0 - fraction) + sorted[hi] * fraction;
}

SampleStats summarize_samples(const vector<double> &samples) {
    if (samples.empty()) throw invalid_argument("cannot summarize empty samples");
    vector<double> sorted = samples;
    sort(sorted.begin(), sorted.end());
    SampleStats stats;
    stats.best = sorted.front();
    stats.median = quantile(sorted, 0.5);
    stats.p25 = quantile(sorted, 0.25);
    stats.p75 = quantile(sorted, 0.75);
    stats.p95 = quantile(sorted, 0.95);
    stats.mean = accumulate(sorted.begin(), sorted.end(), 0.0) /
                 static_cast<double>(sorted.size());
    long double variance = 0.0L;
    for (double value : sorted) {
        const long double delta = static_cast<long double>(value) - stats.mean;
        variance += delta * delta;
    }
    variance /= static_cast<long double>(sorted.size());
    stats.stddev = sqrt(static_cast<double>(variance));
    return stats;
}

vector<double> make_inputs(size_t slots, const Args &args) {
    vector<double> values(slots);
    if (args.input_mode == "grid") {
        if (slots == 1) {
            values[0] = 0.5 * (args.lo + args.hi);
        } else {
            for (size_t i = 0; i < slots; ++i) {
                values[i] = args.lo + (args.hi - args.lo) *
                    static_cast<double>(i) / static_cast<double>(slots - 1);
            }
        }
    } else {
        mt19937_64 rng(args.seed);
        uniform_real_distribution<double> distribution(args.lo, args.hi);
        for (double &value : values) value = distribution(rng);
    }
    return values;
}

// When fewer than all slots are used for accuracy reporting, sample indices
// uniformly across the full packed vector instead of taking only its prefix.
// This preserves coverage of both endpoints for deterministic grid inputs.
Metrics compute_metrics_spread(const vector<double> &lhs,
                               const vector<double> &rhs,
                               size_t count) {
    if (count == 0 || lhs.size() != rhs.size() || lhs.empty() || count > lhs.size()) {
        throw invalid_argument("invalid metric vector length");
    }
    if (count == lhs.size()) return compute_metrics(lhs, rhs, count);

    Metrics metrics;
    long double sum_abs = 0.0L;
    long double sum_sq = 0.0L;
    for (size_t sample = 0; sample < count; ++sample) {
        size_t index = 0;
        if (count == 1) {
            index = (lhs.size() - 1) / 2;
        } else {
            const long double position = static_cast<long double>(sample) *
                static_cast<long double>(lhs.size() - 1) /
                static_cast<long double>(count - 1);
            index = static_cast<size_t>(llround(position));
        }
        const double error = lhs[index] - rhs[index];
        const double abs_error = abs(error);
        if (abs_error > metrics.max_abs) {
            metrics.max_abs = abs_error;
            metrics.max_index = index;
        }
        sum_abs += abs_error;
        sum_sq += static_cast<long double>(error) * error;
    }
    metrics.mean_abs = static_cast<double>(sum_abs / count);
    metrics.rmse = sqrt(static_cast<double>(sum_sq / count));
    return metrics;
}

struct MethodMetadata {
    string family;
    string input_semantics;
    string parameter_policy;
    string native_target;
    string reference_gap_semantics;
    string profile_catalog_sha256;
    string spa_tier;
    string degree_schedule;
    string active_profile;
    int active_degree_square = -1;
    int active_ps_split = -1;
    int active_ps_blocks = -1;
    double design_lo = numeric_limits<double>::quiet_NaN();
    double design_hi = numeric_limits<double>::quiet_NaN();
    double offline_max_error = numeric_limits<double>::quiet_NaN();
    double offline_rmse = numeric_limits<double>::quiet_NaN();
    bool reference_gap_is_ckks_only = false;
    int context_count = 1;
    int polynomial_degree = -1;
    double euston_sign_scale = 0.;
    int euston_g_rounds = 0, euston_f_rounds = 0, euston_tau = 0, euston_inverse_iterations = 0;
    double evaluation_scale_bits = 0.;
    int evaluation_prime_bits = 0, expected_consumed_levels = -1;
    int main_modulus_bits = 0;
    int auxiliary_modulus_bits = 0;
    int fresh_chain = -1;
    int output_chain = -1;
    int auxiliary_fresh_chain = -1;
    int auxiliary_output_chain = -1;
    double output_scale_log2 = 0.0;
    size_t prepared_plaintexts = 0;
    size_t outside_profile_count = 0;
    double max_abs_x_over_R = 0.0;
    int rounding_decimals = -1;
    string derived_from;
    double catalog_e_poly = numeric_limits<double>::quiet_NaN();
    double catalog_e_coeff = 0.0;
};

class PreparedMethod {
public:
    virtual ~PreparedMethod() = default;
    virtual const string &id() const = 0;
    virtual void evaluate_once() = 0;
    virtual void freeze_preparation() = 0;
    virtual vector<double> decode_last() = 0;
    virtual const vector<double> &plain_reference() const = 0;
    virtual const MethodCounts &last_counts() const = 0;
    virtual MethodMetadata metadata() const = 0;
    virtual bool is_euston() const { return false; }

    // Error decomposition. A_fit is the function the method's polynomial or
    // circuit was fitted to; it coincides with the native target for SPA and
    // differs for baselines fitted to another GELU form (E_target > 0).
    virtual const char *fit_target_id() const { return NATIVE_TARGET_ID; }
    virtual double fit_activation(double x) const { return native_activation(x); }
    // Host-side evaluation of the unrounded polynomial P_c, when the method
    // evaluates a rounded copy P_{c_d} (Experiment B); null otherwise.
    virtual const vector<double> *unrounded_reference() const { return nullptr; }

    virtual map<string, SampleStats> euston_breakdown(int) { return {}; }
    virtual map<string, MethodCounts> stage_counts() const { return {}; }
};

struct SpaSpec {
    const spa::MethodDef *method = nullptr;
    const ProfileDef *profile = nullptr;
};

optional<SpaSpec> find_spa_spec(const string &id, double required_radius) {
    const spa::MethodDef *method = spa::try_find_method(id);
    if (!method) return nullopt;
    return SpaSpec{method, &spa::select_profile(*method, required_radius)};
}

size_t count_plan_plaintexts(const PreparedPlan &plan) {
    size_t count = 0;
    auto add_optional = [&](const optional<Plaintext> &plain) {
        if (plain) ++count;
    };
    add_optional(plan.raw_map_plain);
    add_optional(plan.warp_half_a_plain);
    add_optional(plan.warp_lift_one_plain);
    for (const auto &plain : plan.direct_coeff_plain) add_optional(plain);
    add_optional(plan.direct_c0_plain);
    add_optional(plan.linear_plain);
    for (const auto &block : plan.ps_coeff_plain) {
        for (const auto &plain : block) add_optional(plain);
    }
    for (const auto &plain : plan.ps_c0_plain) add_optional(plain);
    add_optional(plan.zero_plain);
    return count;
}

class SpaMethod final : public PreparedMethod {
public:
    SpaMethod(HEEnv &env, const Ciphertext &raw_input,
               const vector<double> &raw_values, const SpaSpec &spec)
        : env_(env), id_(spec.method->id), method_(*spec.method),
          profile_(*spec.profile),
          assignment_(make_slot_assignment(raw_values.size(), {profile_.name})),
          constants_(env) {
        const ProfileDef &profile = profile_;
        plain_reference_.resize(raw_values.size());
        for (size_t i = 0; i < raw_values.size(); ++i) {
            plain_reference_[i] = profile_plain_eval(raw_values[i], profile);
            const double ratio = abs(raw_values[i]) / profile.radius;
            max_ratio_ = max(max_ratio_, ratio);
            if (ratio > 1.0 + 1e-12) ++outside_;
        }
        if (!profile.derived_from.empty()) {
            // Experiment B: P_c of the unrounded fit, same structure and range.
            const ProfileDef &base = spa::find_profile(profile.derived_from);
            if (base.degree_square != profile.degree_square || base.radius != profile.radius ||
                base.ps_split != profile.ps_split) {
                throw runtime_error("rounded profile " + profile.name + " does not match its source");
            }
            unrounded_reference_.resize(raw_values.size());
            for (size_t i = 0; i < raw_values.size(); ++i) {
                unrounded_reference_[i] = profile_plain_eval(raw_values[i], base);
            }
        }
        input_ = raw_input;
        fresh_chain_ = chain_index(*env_.context, input_);
        plan_ = prepare_plan(env_, assignment_, fresh_chain_,
                             Engine::PatersonStockmeyer,
                             InputSemantics::Raw, profile_.ps_split);
    }

    const string &id() const override { return id_; }

    void evaluate_once() override {
        OperationCounts counts;
        last_output_ = spa::evaluate(env_, input_, plan_, constants_, counts);
        last_counts_ = MethodCounts{};
        last_counts_.he = counts;
    }

    void freeze_preparation() override {}

    vector<double> decode_last() override {
        return decrypt_vector(env_, last_output_);
    }

    const vector<double> &plain_reference() const override { return plain_reference_; }
    const MethodCounts &last_counts() const override { return last_counts_; }
    const vector<double> *unrounded_reference() const override {
        return unrounded_reference_.empty() ? nullptr : &unrounded_reference_;
    }

    MethodMetadata metadata() const override {
        MethodMetadata meta;
        meta.family = "SPA-GELU";
        meta.input_semantics = "standalone raw x; x/R mapping timed";
        meta.parameter_policy = "active profile=" + profile_.name +
            "; degree schedule=" + method_.degree_schedule +
            "; profile catalog sha256=" + spa::profile_catalog_sha256() +
            (profile_.rounding_decimals >= 0
                 ? "; Experiment B coefficients rounded to " + to_string(profile_.rounding_decimals) +
                       " decimals of " + profile_.derived_from
                 : string());
        meta.native_target = string(NATIVE_TARGET_LABEL) + " via SPA polynomial";
        meta.reference_gap_semantics =
            "decrypted output minus the host double-precision evaluation of the identical SPA polynomial";
        meta.rounding_decimals = profile_.rounding_decimals;
        meta.derived_from = profile_.derived_from;
        meta.catalog_e_poly = profile_.rounding_decimals >= 0
            ? spa::find_profile(profile_.derived_from).offline_max_error
            : profile_.offline_max_error;
        meta.catalog_e_coeff = profile_.coefficient_perturbation_max;
        meta.profile_catalog_sha256 = spa::profile_catalog_sha256();
        meta.spa_tier = method_.tier;
        meta.degree_schedule = method_.degree_schedule;
        meta.active_profile = profile_.name;
        meta.active_degree_square = profile_.degree_square;
        meta.active_ps_split = profile_.ps_split;
        meta.active_ps_blocks = profile_.ps_blocks;
        meta.design_lo = -profile_.radius;
        meta.design_hi = profile_.radius;
        meta.offline_max_error = profile_.offline_max_error;
        meta.offline_rmse = profile_.offline_rmse;
        meta.reference_gap_is_ckks_only = true;
        meta.context_count = 1;
        meta.main_modulus_bits = total_modulus_bits(env_);
        meta.fresh_chain = fresh_chain_;
        meta.output_chain = chain_index(*env_.context, last_output_);
        meta.output_scale_log2 = log2(last_output_.scale());
        meta.prepared_plaintexts = count_plan_plaintexts(plan_) + constants_.size();
        meta.outside_profile_count = outside_;
        meta.max_abs_x_over_R = max_ratio_;
        return meta;
    }

private:
    HEEnv &env_;
    string id_;
    const spa::MethodDef &method_;
    const ProfileDef &profile_;
    SlotAssignment assignment_;
    LevelConstants constants_;
    Ciphertext input_;
    Ciphertext last_output_;
    int fresh_chain_ = -1;
    PreparedPlan plan_;
    vector<double> plain_reference_;
    vector<double> unrounded_reference_;
    MethodCounts last_counts_;
    size_t outside_ = 0;
    double max_ratio_ = 0.0;
};

class MoaiModelMethod final : public PreparedMethod {
    // The plaintext model's MOAI profile for the public interval, evaluated
    // as 0.5*x*(1 + P(y/B)) with y the Cheon-Kim-Park extension of x. The
    // whole activation is timed: input transformation (the extension
    // stages, 2 levels each), y/B, the degree-23 factor polynomial in the
    // Chebyshev basis (product tree of chebyshev_balanced; every stored
    // coefficient is applied, none is refitted, truncated or dropped) and
    // the reconstruction (x*0.5)*(1 + P). Profile selection is by the
    // public radius only.
public:
    MoaiModelMethod(HEEnv &env, const Ciphertext &raw_input,
                    const vector<double> &raw_values, double public_radius)
        : env_(env), input_(raw_input), cache_(env),
          profile_(moai_model::profile_for_radius(public_radius)) {
        if (public_radius > 20.0 + 1e-12)
            throw invalid_argument("MOAI model profiles cover public intervals through R20");
        if (string(moai_model::native_target_id()) != "erf-gelu")
            throw runtime_error("the imported MOAI profiles must be fitted to erf-GELU");
        for (double c : profile_.coefficients) {
            if (!encodes_to_nonzero(c, env_.scale)) {
                throw runtime_error("MOAI model profile " + profile_.id +
                                    " has a coefficient below the encoding resolution; "
                                    "it would be dropped, which changes the function");
            }
        }
        plain_reference_.resize(raw_values.size());
        transform(raw_values.begin(), raw_values.end(), plain_reference_.begin(),
                  [&](double x) { return moai_model::plain_host(x, profile_); });
        fresh_chain_ = chain_index(*env_.context, input_);
    }

    const string &id() const override { return id_; }
    // The imported profile was fitted to the plaintext catalog's target, erf-GELU.
    const char *fit_target_id() const override { return moai_model::native_target_id(); }
    double fit_activation(double x) const override { return gelu_exact(x); }

    void evaluate_once() override {
        MethodCounts counts;
        // Extension stages, outermost first: y <- y - c_r y^3 with
        // y3c = (y*y) * (c_r*y). Scales are never relabelled: every product
        // keeps its natural scale after rescaling, the plaintext factor c_r
        // is encoded so that (c_r*y) lands exactly on y2's scale, and y is
        // brought to y3c's level and scale by an exact-scale multiply by 1
        // (as chebyshev_balanced aligns its T1 branch). Two levels per stage.
        Ciphertext y = input_;
        for (int r = profile_.extension_stages - 1; r >= 0; --r) {
            const double c = moai_model::stage_constant(profile_, r);
            Ciphertext y2 = counted_square_rescale(env_, y, counts, nullopt);
            Ciphertext cy = multiply_constant_exact_scale(env_, cache_, y, c, counts, y2.scale());
            Ciphertext y3c = counted_multiply_rescale(env_, y2, cy, counts, nullopt);
            Ciphertext aligned = multiply_constant_exact_scale(env_, cache_, y, 1.0, counts, y3c.scale());
            counted_mod_switch_to(env_, aligned, y3c.parms_id(), counts);
            env_.evaluator->sub_inplace(aligned, y3c);
            ++counts.he.ct_sub;
            y = std::move(aligned);
        }
        // t = y / B (exact scale), then the factor polynomial P(t).
        Ciphertext t = multiply_constant_exact_scale(env_, cache_, y, 1.0 / profile_.base_radius, counts, env_.scale);
        Ciphertext factor = chebyshev_balanced(env_, cache_, t, profile_.coefficients, counts);
        // Reconstruction: (x * 0.5) * (1 + P), the last product at its natural scale.
        counted_add_plain_current(env_, factor, 1.0, cache_, counts);
        Ciphertext half_x = multiply_constant_exact_scale(env_, cache_, input_, 0.5, counts, factor.scale());
        last_output_ = counted_multiply_rescale(env_, half_x, factor, counts, nullopt);
        last_counts_ = counts;
    }

    void freeze_preparation() override { cache_.freeze(); }

    vector<double> decode_last() override { return decrypt_vector(env_, last_output_); }
    const vector<double> &plain_reference() const override { return plain_reference_; }
    const MethodCounts &last_counts() const override { return last_counts_; }

    MethodMetadata metadata() const override {
        MethodMetadata meta;
        meta.family = "MOAI";
        meta.input_semantics = "standalone raw x; extension stages, y/B, factor polynomial and reconstruction all timed";
        meta.parameter_policy = "plaintext model profile " + profile_.id + " imported verbatim (B=" +
            to_string(profile_.base_radius) + ", " + to_string(profile_.extension_stages) +
            " extension stages, degree " + to_string(profile_.degree) + " factor polynomial); source catalog " +
            moai_model::source_catalog() + " sha256 " + moai_model::source_catalog_sha256() +
            " (task " + moai_model::source_task() + "); no refit";
        meta.native_target = string("MOAI model profile fitted to ") + moai_model::native_target_id() +
            "; benchmark native target " + NATIVE_TARGET_LABEL;
        meta.catalog_e_poly = profile_.catalog_max_abs_error;
        meta.polynomial_degree = profile_.degree;
        meta.active_profile = profile_.id;
        meta.design_lo = -profile_.radius;
        meta.design_hi = profile_.radius;
        meta.profile_catalog_sha256 = moai_model::source_catalog_sha256();
        meta.offline_max_error = profile_.catalog_max_abs_error;
        meta.reference_gap_semantics =
            "decrypted output minus the host double-precision evaluation of the identical model profile "
            "(extension stages, factor polynomial, reconstruction)";
        meta.reference_gap_is_ckks_only = true;
        meta.context_count = 1;
        meta.main_modulus_bits = total_modulus_bits(env_);
        meta.fresh_chain = fresh_chain_;
        meta.output_chain = chain_index(*env_.context, last_output_);
        meta.output_scale_log2 = log2(last_output_.scale());
        meta.prepared_plaintexts = cache_.size();
        return meta;
    }

private:
    HEEnv &env_;
    const string id_ = "moai";
    Ciphertext input_;
    ScalarPlainCache cache_;
    const moai_model::Profile &profile_;
    Ciphertext last_output_;
    vector<double> plain_reference_;
    MethodCounts last_counts_;
    int fresh_chain_ = -1;
};

class NexusMethod final : public PreparedMethod {
public:
    NexusMethod(HEEnv &env, const Ciphertext &input,
                const vector<double> &raw_values, NexusConfig config)
        : env_(env), config_(std::move(config)), input_(input), cache_(env) {
        fresh_chain_ = chain_index(*env_.context, input_);
        plain_reference_.resize(raw_values.size());
        transform(raw_values.begin(), raw_values.end(), plain_reference_.begin(),
                  [&](double x) { return nexus_gelu_plain(x, config_); });
    }

    const string &id() const override { return id_; }
    // NEXUS's supplied centre polynomial approximates the standard erf-GELU
    // (its deviation from erf- and tanh-GELU on [-3.5,3.5] is 6.9e-4 and
    // 6.5e-4, both above the 4.7e-4 gap between the two forms, so the
    // attribution follows the paper's definition).
    const char *fit_target_id() const override { return "erf-gelu"; }
    double fit_activation(double x) const override { return gelu_exact(x); }

    void evaluate_once() override {
        MethodCounts counts;

        Ciphertext left = input_;
        counted_add_plain_current(env_, left, config_.gate, cache_, counts);
        left = counted_multiply_const_current(
            env_, std::move(left), 1.0 / config_.sign_scale, cache_, counts);

        Ciphertext right = input_;
        counted_add_plain_current(env_, right, -config_.gate, cache_, counts);
        right = counted_multiply_const_current(
            env_, std::move(right), 1.0 / config_.sign_scale, cache_, counts);

        left = evaluate_nexus_sign(
            env_, cache_, std::move(left), config_, counts);
        right = evaluate_nexus_sign(
            env_, cache_, std::move(right), config_, counts);

        Ciphertext middle_gate;
        env_.evaluator->sub(left, right, middle_gate);
        ++counts.he.ct_sub;
        Ciphertext right_gate = right;
        counted_add_plain_current(env_, right_gate, 0.5, cache_, counts);

        Ciphertext x2 = counted_square_rescale(env_, input_, counts, env_.scale);
        Ciphertext x4 = counted_square_rescale(env_, x2, counts, env_.scale);
        Ciphertext x6 = counted_multiply_rescale(env_, x2, x4, counts, env_.scale);
        Ciphertext x8 = counted_square_rescale(env_, x4, counts, env_.scale);
        Ciphertext x10 = counted_multiply_rescale(env_, x2, x8, counts, env_.scale);
        Ciphertext x12 = counted_square_rescale(env_, x6, counts, env_.scale);

        static const array<double, 8> coefficients = {
            2.25775755e-04, 5.00000000e-01, 3.96880960e-01,
            -6.37042698e-02, 8.38841647e-03, -7.17830961e-04,
            3.49617829e-05, -7.26059653e-07};

        vector<Ciphertext> terms;
        terms.reserve(7);
        terms.push_back(counted_multiply_const_current(
            env_, input_, coefficients[1], cache_, counts));
        terms.push_back(counted_multiply_const_current(
            env_, x2, coefficients[2], cache_, counts));
        terms.push_back(counted_multiply_const_current(
            env_, x4, coefficients[3], cache_, counts));
        terms.push_back(counted_multiply_const_current(
            env_, x6, coefficients[4], cache_, counts));
        terms.push_back(counted_multiply_const_current(
            env_, x8, coefficients[5], cache_, counts));
        terms.push_back(counted_multiply_const_current(
            env_, x10, coefficients[6], cache_, counts));
        terms.push_back(counted_multiply_const_current(
            env_, x12, coefficients[7], cache_, counts));

        Ciphertext middle = std::move(terms.back());
        terms.pop_back();
        for (Ciphertext &term : terms) {
            counted_mod_switch_to(env_, term, middle.parms_id(), counts);
            term.scale() = middle.scale();
            counted_add_cipher(env_, middle, term, counts);
        }
        env_.evaluator->add_plain_inplace(
            middle, cache_.get(coefficients[0], middle.parms_id(), middle.scale()));
        ++counts.he.add_plain;

        Ciphertext middle_part = counted_multiply_rescale(
            env_, std::move(middle), std::move(middle_gate), counts, env_.scale);
        Ciphertext right_part = counted_multiply_rescale(
            env_, input_, std::move(right_gate), counts, env_.scale);
        counted_mod_switch_to(env_, right_part, middle_part.parms_id(), counts);
        right_part.scale() = middle_part.scale();
        counted_add_cipher(env_, middle_part, right_part, counts);

        last_output_ = std::move(middle_part);
        last_counts_ = counts;
    }

    void freeze_preparation() override { cache_.freeze(); }
    vector<double> decode_last() override { return decrypt_vector(env_, last_output_); }
    const vector<double> &plain_reference() const override { return plain_reference_; }
    const MethodCounts &last_counts() const override { return last_counts_; }

    MethodMetadata metadata() const override {
        MethodMetadata meta;
        meta.family = "NEXUS";
        meta.input_semantics = "standalone raw x";
        ostringstream policy;
        const bool source_domain = config_.conditioning_status == "source-domain";
        policy << (source_domain ? "supplied source graph" : "range-adapted source graph")
               << ": gate=" << config_.gate
               << ", sign_scale=" << config_.sign_scale
               << ", dg=" << config_.g_rounds
               << ", df=" << config_.f_rounds
               << ", conditioning=" << config_.conditioning_status
               << ", gate_budget=" << config_.gate_error_budget;
        meta.parameter_policy = policy.str();
        meta.native_target = string(source_domain
                                 ? "NEXUS supplied-source GELU approximation"
                                 : "range-adapted NEXUS source GELU approximation") +
                             "; benchmark native target " + NATIVE_TARGET_LABEL;
        meta.reference_gap_semantics = "decrypted output minus plaintext NEXUS approximation";
        meta.reference_gap_is_ckks_only = true;
        meta.context_count = 1;
        meta.main_modulus_bits = total_modulus_bits(env_);
        meta.fresh_chain = fresh_chain_;
        meta.output_chain = chain_index(*env_.context, last_output_);
        meta.output_scale_log2 = log2(last_output_.scale());
        meta.prepared_plaintexts = cache_.size();
        return meta;
    }

private:
    HEEnv &env_;
    NexusConfig config_;
    const string id_ = "nexus";
    Ciphertext input_;
    Ciphertext last_output_;
    ScalarPlainCache cache_;
    vector<double> plain_reference_;
    MethodCounts last_counts_;
    int fresh_chain_ = -1;
};

vector<int> euston_modulus_bits(const Args &args,const euston_circuit::Config &config) {
    const int required=config.consumed_levels()+args.reserve_levels;
    const int levels=args.euston_levels==0 ? required : args.euston_levels;
    if(levels<required)
        throw invalid_argument("Euston requires at least "+to_string(required)+" middle primes including reserve");
    vector<int> bits{60};
    bits.insert(bits.end(),static_cast<size_t>(levels),args.euston_prime_bits);
    bits.push_back(60);
    return bits;
}

class EustonMethod final : public PreparedMethod {
public:
    EustonMethod(const vector<double>& raw_values,const Args &args,
                 const euston_circuit::Config &config)
        : config_(config), env_(args.poly_degree,euston_modulus_bits(args,config),
                  pow(2.,args.euston_scale_bits),args.secure128), cache_(env_) {
        diagnostics_=euston_circuit::validate_public_grid(config_);
        // Client input encryption is outside server timing, exactly once.
        raw_=encrypt_vector(env_,raw_values);
        fresh_chain_=chain_index(*env_.context,raw_);
        for(double x:raw_values) plain_reference_.push_back(euston_circuit::plain(x,config_));
    }
    const string& id() const override { return id_; }
    bool is_euston() const override {return true;}
    const char *fit_target_id() const override { return "quickgelu"; }
    double fit_activation(double x) const override { return quickgelu_plain(x); }
    void evaluate_once() override { evaluate_impl(false); }
    void freeze_preparation() override {cache_.freeze();}
    // Only final benchmark/client verification decrypts; never evaluate_impl.
    vector<double> decode_last() override {return decrypt_vector(env_,last_output_);}
    const vector<double>& plain_reference() const override {return plain_reference_;}
    const MethodCounts& last_counts() const override {return last_counts_;}
    MethodMetadata metadata() const override {
        MethodMetadata m;
        m.family="Euston";
        m.input_semantics="standalone raw x; one uninterrupted CKKS chain";
        ostringstream p;
        p<<"range-adapted parameters; beta="<<config_.beta<<"; sign_scale="<<config_.sign_scale
         <<"; dg="<<config_.g_rounds<<"; df="<<config_.f_rounds
         <<"; exp_degree=7; tau="<<config_.exp_squarings
         <<"; exp_refit=[-5,0], P(0)=1; inverse_divisor=2; inverse_iterations="<<config_.inverse_iterations;
        m.parameter_policy=p.str();
        m.native_target=string("QuickGELU x*sigmoid(1.702x); total error reference is the benchmark native target ")+NATIVE_TARGET_LABEL;
        m.reference_gap_semantics="decrypted output minus identical sign/exp/reciprocal/recombination plaintext circuit";
        m.reference_gap_is_ckks_only=true;
        m.profile_catalog_sha256=gelu_range_profiles::catalog_sha256;
        m.active_profile="euston-r"+to_string(static_cast<int>(config_.radius));
        m.design_lo=-config_.radius;m.design_hi=config_.radius;
        m.offline_max_error=diagnostics_.max_error_gelu;
        m.catalog_e_poly=diagnostics_.max_error_quickgelu;
        m.context_count=1;m.main_modulus_bits=total_modulus_bits(env_);
        m.fresh_chain=fresh_chain_;m.output_chain=chain_index(*env_.context,last_output_);
        m.output_scale_log2=log2(last_output_.scale());m.prepared_plaintexts=cache_.size();
        m.max_abs_x_over_R=1.0;
        m.euston_sign_scale=config_.sign_scale;
        m.euston_g_rounds=config_.g_rounds;m.euston_f_rounds=config_.f_rounds;
        m.euston_tau=config_.exp_squarings;m.euston_inverse_iterations=config_.inverse_iterations;
        m.evaluation_scale_bits=log2(env_.scale);m.evaluation_prime_bits=env_.modulus_bits[1];
        m.expected_consumed_levels=config_.consumed_levels();
        return m;
    }
    map<string,MethodCounts> stage_counts() const override {
        return {{"sign",sign_counts_},{"main",main_counts_}};
    }
    map<string,SampleStats> euston_breakdown(int repeats) override {
        if(repeats<=0) return {};
        vector<double> sign,main,total;
        for(int i=0;i<repeats;++i) {
            evaluate_impl(true);
            sign.push_back(sign_ms_);main.push_back(main_ms_);total.push_back(sign_ms_+main_ms_);
        }
        return {{"sign",summarize_samples(sign)},{"main",summarize_samples(main)},
                {"total",summarize_samples(total)}};
    }
private:
    void evaluate_impl(bool timing) {
        MethodCounts sc,mc;
        SealEustonOps sign_op{env_,cache_,sc};
        auto begin=chrono::steady_clock::time_point{};
        if(timing) begin=chrono::steady_clock::now();
        Ciphertext s=euston_circuit::sign(sign_op,raw_,config_);
        if(timing) {
            auto now=chrono::steady_clock::now();
            sign_ms_=chrono::duration<double,milli>(now-begin).count(); begin=now;
        }
        // s remains a ciphertext in the SAME context/key/modulus chain.
        SealEustonOps main_op{env_,cache_,mc};
        last_output_=euston_circuit::main_path(main_op,raw_,s,config_);
        if(timing) main_ms_=chrono::duration<double,milli>(chrono::steady_clock::now()-begin).count();
        sign_counts_=sc;main_counts_=mc;last_counts_=sum_counts(sc,mc);
        const int consumed=fresh_chain_-chain_index(*env_.context,last_output_);
        if(consumed!=config_.consumed_levels())
            throw runtime_error("Euston critical-path level accounting disagrees with ciphertext output");
        if(last_counts_.decrypt || last_counts_.decode || last_counts_.encrypt || last_counts_.dynamic_plain_encode)
            throw runtime_error("Euston server evaluation accessed a forbidden client operation");
    }
    const string id_="euston";
    euston_circuit::Config config_;
    euston_circuit::Diagnostics diagnostics_;
    HEEnv env_;
    ScalarPlainCache cache_;
    Ciphertext raw_,last_output_;
    vector<double> plain_reference_;
    int fresh_chain_=-1;
    MethodCounts sign_counts_,main_counts_,last_counts_;
    double sign_ms_=0.,main_ms_=0.;
};

// Standardised error decomposition (all maxima over the metric slots):
//   E_target = max |A_fit - A_native|        (0 when the method fits the native target)
//   E_poly   = max |P_c - A_fit|             (host double evaluation of the unrounded circuit)
//   E_coeff  = max |P_{c_d} - P_c|           (Experiment B only; 0 otherwise)
//   E_HE     = max |Y_HE - P_{c_d}|          (decrypted output minus the host reference)
//   E_total  = max |Y_HE - A_native|
// E_total <= E_target + E_poly + E_coeff + E_HE by the triangle inequality;
// the bound is recorded and checked. method_bias_max = max |P_{c_d} - A_native|
// already contains E_target and E_coeff and must not be added to them.
struct ErrorDecomposition {
    double e_target = 0.0;
    double e_poly = 0.0;
    double e_coeff = 0.0;
    double e_he = 0.0;
    double e_total = 0.0;
    double bound = 0.0;
    bool bound_holds = true;
};

struct MethodResult {
    PreparedMethod *method = nullptr;
    vector<double> samples_ms;
    SampleStats timing;
    Metrics total_error;
    Metrics method_bias;
    Metrics ckks_extra;
    ErrorDecomposition decomposition;
    MethodCounts counts;
    MethodMetadata metadata;
    map<string, SampleStats> stage_timing;
    map<string, MethodCounts> stage_counts;
};

string csv_escape(const string &value) {
    if (value.find_first_of(",\"\n") == string::npos) return value;
    string output = "\"";
    for (char c : value) output += c == '\"' ? "\"\"" : string(1, c);
    output += "\"";
    return output;
}

void ensure_parent_directory(const string &path) {
    if (path.empty()) return;
    fs::path file(path);
    if (file.has_parent_path()) fs::create_directories(file.parent_path());
}

struct RawSample {
    string run_label;
    int round = 0;
    int position = 0;
    string method;
    double milliseconds = 0.0;
};

void append_samples_csv(const string &path, const vector<RawSample> &samples) {
    if (path.empty()) return;
    ensure_parent_directory(path);
    const bool header = !fs::exists(path) || fs::file_size(path) == 0;
    ofstream output(path, ios::app);
    if (!output) throw runtime_error("cannot open samples CSV: " + path);
    if (header) output << "run_label,round,position,method,time_ms\n";
    for (const auto &sample : samples) {
        output << csv_escape(sample.run_label) << ',' << sample.round << ','
               << sample.position << ',' << csv_escape(sample.method) << ','
               << setprecision(17) << sample.milliseconds << '\n';
    }
}

string count_prefix(const MethodCounts &counts) {
    ostringstream out;
    out << "ct_ct_multiply=" << counts.he.ct_ct_multiply
        << " ct_square=" << counts.he.ct_square
        << " ct_ct_total=" << counts.total_ct_ct()
        << " ct_plain_multiply=" << counts.he.ct_plain_multiply
        << " relinearize=" << counts.he.relinearize
        << " rescale=" << counts.he.rescale
        << " mod_switch=" << counts.he.mod_switch
        << " ct_add=" << counts.he.ct_add
        << " ct_sub=" << counts.he.ct_sub
        << " add_plain=" << counts.he.add_plain
        << " ct_negate=" << counts.ct_negate
        << " dynamic_plain_encode=" << counts.dynamic_plain_encode
        << " encrypt=" << counts.encrypt
        << " decrypt=" << counts.decrypt
        << " decode=" << counts.decode;
    return out.str();
}

void append_summary_csv(const string &path, const Args &args,
                        const MethodResult &result,
                        double speedup_vs_spa_k87, double speedup_vs_moai,
                        double speedup_vs_nexus, double speedup_vs_euston) {
    if (path.empty()) return;
    ensure_parent_directory(path);
    const bool header = !fs::exists(path) || fs::file_size(path) == 0;
    if (!header) {
        ifstream previous(path);
        string columns;
        getline(previous,columns);
        if (columns.find(",implementation_revision,")==string::npos || columns.find(",e_total,")==string::npos)
            throw runtime_error("summary CSV schema mismatch (expected the current column set): "+path);
    }
    ofstream out(path, ios::app);
    if (!out) throw runtime_error("cannot open summary CSV: " + path);
    out << setprecision(17);
    if (header) {
        out << "run_label,method,family,input_semantics,parameter_policy,native_target,reference_gap_semantics,reference_gap_is_ckks_only,"
               "profile_catalog_sha256,spa_tier,degree_schedule,active_profile,"
               "active_degree_square,active_ps_split,active_ps_blocks,design_lo,design_hi,offline_max_error,offline_rmse,"
               "input_mode,range_lo,range_hi,slots,warmups,repeats,order_seed,randomized_order,"
               "scale_bits,prime_bits,middle_primes,reserve_levels,"
               "median_ms,p25_ms,p75_ms,p95_ms,best_ms,mean_ms,stddev_ms,"
               "speedup_vs_spa_k87,speedup_vs_moai,speedup_vs_nexus,speedup_vs_euston,context_count,main_modulus_bits,aux_modulus_bits,"
               "fresh_chain,output_chain,consumed_levels,aux_fresh_chain,aux_output_chain,aux_consumed_levels,"
               "output_scale_log2,prepared_plaintexts,outside_profile_count,max_abs_x_over_R,"
               "ct_ct_multiply,ct_square,ct_ct_total,ct_plain_multiply,relinearize,rescale,mod_switch,"
               "ct_add,ct_sub,add_plain,ct_negate,dynamic_plain_encode,encrypt,decrypt,decode,"
               "total_max_abs,total_mean_abs,total_rmse,method_bias_max,method_bias_rmse,"
               "ckks_extra_max,ckks_extra_rmse,euston_sign_median_ms,"
               "euston_main_median_ms,euston_breakdown_total_median_ms,implementation_revision,poly_modulus_degree,security_validation,evaluation_scale_bits,evaluation_prime_bits,polynomial_degree,euston_sign_scale,euston_g_rounds,euston_f_rounds,euston_tau,euston_inverse_iterations,expected_consumed_levels,bootstraps,"
               "native_target_id,fit_target_id,e_target,e_poly,e_coeff,e_he,e_total,decomposition_bound,decomposition_bound_holds,"
               "catalog_e_poly,catalog_e_coeff,spa_rounding_decimals,spa_derived_from,host_reference_semantics\n";
    }
    const auto &m = result.metadata;
    auto stage_median = [&](const string &name) {
        auto it = result.stage_timing.find(name);
        return it == result.stage_timing.end() ? numeric_limits<double>::quiet_NaN()
                                               : it->second.median;
    };
    out << csv_escape(args.run_label) << ',' << csv_escape(result.method->id()) << ','
        << csv_escape(m.family) << ',' << csv_escape(m.input_semantics) << ','
        << csv_escape(m.parameter_policy) << ',' << csv_escape(m.native_target) << ','
        << csv_escape(m.reference_gap_semantics) << ',' << (m.reference_gap_is_ckks_only ? 1 : 0) << ','
        << csv_escape(m.profile_catalog_sha256) << ',' << csv_escape(m.spa_tier) << ','
        << csv_escape(m.degree_schedule) << ',' << csv_escape(m.active_profile) << ','
        << m.active_degree_square << ',' << m.active_ps_split << ',' << m.active_ps_blocks << ','
        << m.design_lo << ',' << m.design_hi << ',' << m.offline_max_error << ',' << m.offline_rmse << ','
        << args.input_mode << ',' << setprecision(17) << args.lo << ',' << args.hi << ','
        << args.slots_to_test << ',' << args.warmups << ',' << args.repeats << ','
        << args.order_seed << ',' << (args.randomize_order ? 1 : 0) << ','
        << args.scale_bits << ',' << args.prime_bits << ','
        << args.middle_primes << ',' << args.reserve_levels << ','
        << result.timing.median << ',' << result.timing.p25 << ',' << result.timing.p75 << ','
        << result.timing.p95 << ',' << result.timing.best << ',' << result.timing.mean << ','
        << result.timing.stddev << ',' << speedup_vs_spa_k87 << ','
        << speedup_vs_moai << ',' << speedup_vs_nexus << ','
        << speedup_vs_euston << ',' << m.context_count << ',' << m.main_modulus_bits << ',' << m.auxiliary_modulus_bits << ','
        << m.fresh_chain << ',' << m.output_chain << ',' << (m.fresh_chain - m.output_chain) << ','
        << m.auxiliary_fresh_chain << ',' << m.auxiliary_output_chain << ','
        << (m.auxiliary_fresh_chain >= 0 && m.auxiliary_output_chain >= 0
              ? m.auxiliary_fresh_chain - m.auxiliary_output_chain : -1) << ','
        << m.output_scale_log2 << ',' << m.prepared_plaintexts << ','
        << m.outside_profile_count << ',' << m.max_abs_x_over_R << ','
        << result.counts.he.ct_ct_multiply << ',' << result.counts.he.ct_square << ','
        << result.counts.total_ct_ct() << ',' << result.counts.he.ct_plain_multiply << ','
        << result.counts.he.relinearize << ',' << result.counts.he.rescale << ','
        << result.counts.he.mod_switch << ',' << result.counts.he.ct_add << ','
        << result.counts.he.ct_sub << ',' << result.counts.he.add_plain << ','
        << result.counts.ct_negate << ',' << result.counts.dynamic_plain_encode << ','
        << result.counts.encrypt << ',' << result.counts.decrypt << ',' << result.counts.decode << ','
        << result.total_error.max_abs << ',' << result.total_error.mean_abs << ','
        << result.total_error.rmse << ',' << result.method_bias.max_abs << ','
        << result.method_bias.rmse << ',' << result.ckks_extra.max_abs << ','
        << result.ckks_extra.rmse << ',' << stage_median("sign") << ','
        << stage_median("main") << ',' << stage_median("total") << ','
        << CSV_SCHEMA << ',' << args.poly_degree << ',' << (args.secure128 ? "tc128-linked-SEAL" : "disabled-diagnostic-only") << ','
        << (m.evaluation_scale_bits>0.?m.evaluation_scale_bits:args.scale_bits) << ','
        << (m.evaluation_prime_bits>0?m.evaluation_prime_bits:args.prime_bits) << ','
        << m.polynomial_degree << ',' << m.euston_sign_scale << ',' << m.euston_g_rounds << ','
        << m.euston_f_rounds << ',' << m.euston_tau << ',' << m.euston_inverse_iterations << ','
        << m.expected_consumed_levels << ",0,"
        << NATIVE_TARGET_ID << ',' << result.method->fit_target_id() << ','
        << result.decomposition.e_target << ',' << result.decomposition.e_poly << ','
        << result.decomposition.e_coeff << ',' << result.decomposition.e_he << ','
        << result.decomposition.e_total << ',' << result.decomposition.bound << ','
        << (result.decomposition.bound_holds ? 1 : 0) << ','
        << m.catalog_e_poly << ',' << m.catalog_e_coeff << ','
        << m.rounding_decimals << ',' << csv_escape(m.derived_from) << ','
        << csv_escape("E_HE is the decrypted output minus the host double-precision evaluation of the identical circuit; "
                      "it includes host floating-point error and is not independently verified pure CKKS noise")
        << "\n";
}

} // namespace gelu_bench

int main(int argc, char **argv) {
    using namespace gelu_bench;
    try {
        const Args args = parse_args(argc, argv);
        if (args.list_methods) {
            print_supported_methods();
            return 0;
        }
        const vector<string> requested = split_csv(args.methods);
        unordered_set<string> unique_methods;
        for (const string &id : requested) {
            if (!unique_methods.insert(id).second) {
                throw invalid_argument("duplicate method ID: " + id);
            }
        }
        const bool requests_euston =
            find(requested.begin(), requested.end(), "euston") != requested.end();
        const bool requests_nexus =
            find(requested.begin(), requested.end(), "nexus") != requested.end();
        const bool requests_moai =
            find(requested.begin(), requested.end(), "moai") != requested.end();
        const double public_radius=max(abs(args.lo),abs(args.hi));
        if ((requests_moai || requests_euston) && public_radius>20.+1e-12)
            throw invalid_argument("MOAI/Euston public-domain profiles are defined through R20");
        optional<euston_circuit::Config> euston_config;
        if(requests_euston) {
            euston_config=euston_circuit::make_config(public_radius,args.euston_sign_scale,
                args.euston_tau,args.euston_g_rounds,args.euston_f_rounds,args.euston_inverse_iterations);
            const auto d=euston_circuit::validate_public_grid(*euston_config);
            cout<<"euston_public_grid_check: points=32769 exp_min="<<d.exp_argument_min
                <<" exp_max="<<d.exp_argument_max<<" denominator_min="<<d.denominator_min
                <<" denominator_max="<<d.denominator_max<<" gelu_error="<<d.max_error_gelu
                <<" quickgelu_error="<<d.max_error_quickgelu<<"\n";
        }
        optional<NexusConfig> nexus_config;
        if (requests_nexus) {
            nexus_config = make_nexus_config(args);
            const int required_levels = nexus_required_levels(*nexus_config);
            const int minimum_levels = required_levels + args.reserve_levels;
            if (args.middle_primes < minimum_levels) {
                ostringstream message;
                message << "nexus requires --levels " << minimum_levels
                        << " or more (" << required_levels
                        << " consumed + " << args.reserve_levels
                        << " reserved) for dg=" << nexus_config->g_rounds
                        << ", df=" << nexus_config->f_rounds;
                throw invalid_argument(message.str());
            }
        }
        const size_t poly_modulus_degree = args.poly_degree;
        vector<int> common_bits;
        common_bits.reserve(static_cast<size_t>(args.middle_primes + 2));
        common_bits.push_back(60);
        common_bits.insert(common_bits.end(), static_cast<size_t>(args.middle_primes), args.prime_bits);
        common_bits.push_back(60);
        const int secure_limit=CoeffModulus::MaxBitCount(poly_modulus_degree,sec_level_type::tc128);
        auto requested_bits=[](const vector<int>& bits) {
            return accumulate(bits.begin(),bits.end(),0);
        };
        optional<vector<int>> euston_bits;
        if(euston_config) euston_bits=euston_modulus_bits(args,*euston_config);
        cout << "security_validation_requested: " << (args.secure128 ? "tc128-linked-SEAL" : "disabled-diagnostic-only") << "\n";
        cout << "poly_modulus_degree: " << poly_modulus_degree << "\n";
        cout << "linked_SEAL_tc128_max_modulus_bits: " << secure_limit << "\n";
        if(euston_config) {
            const auto &c=*euston_config;
            cout << "euston_parameters: sign_scale="<<c.sign_scale<<" dg="<<c.g_rounds<<" df="<<c.f_rounds
                 <<" exp_degree=7 tau="<<c.exp_squarings<<" inverse_divisor=2 inverse_iterations="<<c.inverse_iterations
                 <<" required_levels="<<c.consumed_levels()<<" reserved="<<args.reserve_levels
                 <<" middle_primes="<<euston_bits->size()-2<<" total_modulus_bits="<<requested_bits(*euston_bits)
                 <<" scale_bits="<<args.euston_scale_bits<<" contexts=1 bootstraps=0\n";
        }
        const bool supported=secure_limit>0 && requested_bits(common_bits)<=secure_limit &&
            (!euston_bits || requested_bits(*euston_bits)<=secure_limit);
        cout<<"security_parameters_supported_by_linked_table: "<<(supported?"true":"false")<<"\n";
        if(args.describe_plan) {cout<<"plan_only: true; no CKKS evaluation performed\n";return 0;}
        if(args.secure128 && (secure_limit==0 || requested_bits(common_bits)>secure_limit ||
                (euston_bits && requested_bits(*euston_bits)>secure_limit))) {
            throw invalid_argument("linked SEAL tc128 security table does not support the requested ring/chain. "
                "Upstream SEAL 4.1.2 has no tc128 table entry at N=65536. "
                "Use an independently reviewed library/parameter configuration; --no-sec is diagnostic only.");
        }
        HEEnv common_env(poly_modulus_degree, common_bits,
                         pow(2.0, args.scale_bits), args.secure128);
        const size_t slot_count = common_env.encoder->slot_count();
        if(slot_count!=args.poly_degree/2) throw runtime_error("unexpected CKKS slot count");

        const vector<double> raw_values = make_inputs(slot_count, args);
        vector<double> exact(slot_count);
        transform(raw_values.begin(), raw_values.end(), exact.begin(), native_activation);
        if (string(spa::native_target_id()) != NATIVE_TARGET_ID) {
            throw runtime_error(string("SPA profile header was fitted for ") + spa::native_target_id() +
                                " but this benchmark's native target is " + NATIVE_TARGET_ID);
        }
        const Ciphertext common_raw = encrypt_vector(common_env, raw_values);

        const double required_radius = max(abs(args.lo), abs(args.hi));
        vector<unique_ptr<PreparedMethod>> methods;
        for (const string &id : requested) {
            if (auto spec = find_spa_spec(id, required_radius)) {
                methods.push_back(make_unique<SpaMethod>(
                    common_env, common_raw, raw_values, *spec));
            } else if (id == "moai") {
                methods.push_back(make_unique<MoaiModelMethod>(
                    common_env, common_raw, raw_values, public_radius));
            } else if (id == "nexus") {
                methods.push_back(make_unique<NexusMethod>(
                    common_env, common_raw, raw_values, *nexus_config));
            } else if (id == "euston") {
                methods.push_back(make_unique<EustonMethod>(
                    raw_values, args, *euston_config));
            } else {
                throw invalid_argument("unsupported method ID: " + id);
            }
        }

        cout << "scheme: CKKS\n";
        cout << "benchmark: " << (string(NATIVE_TARGET_ID) == "quickgelu" ? "gelu_quickgelu_bench" : "gelu_bench") << "\n";
        cout << "native_target: " << NATIVE_TARGET_ID << " (" << NATIVE_TARGET_LABEL << ")\n";
        cout << "spa_profile_catalog_sha256: " << spa::profile_catalog_sha256() << "\n";
        cout << "run_label: " << args.run_label << "\n";
        cout << "common_raw_input: one identical " << args.input_mode
             << " vector for all methods, range=[" << args.lo << "," << args.hi << "]\n";
        cout << "slot_count_executed: " << slot_count << "\n";
        cout << "slots_used_for_metrics: " << args.slots_to_test << "\n";
        cout << "common_parameters: N=" << poly_modulus_degree << " scale=2^" << args.scale_bits
             << " prime_bits=" << args.prime_bits
             << " middle_primes=" << args.middle_primes
             << " reserve_levels=" << args.reserve_levels
             << " total_modulus_bits=" << total_modulus_bits(common_env) << "\n";
        cout << "timing_excludes: context,keygen,fixed-plaintext-preparation,input-encode,input-encrypt,output-decrypt,metrics,CSV\n";
        cout << "timing_includes: all ciphertext arithmetic,allocation,relinearize,rescale,mod-switch; no intermediate decrypt/re-encrypt or bootstrapping\n";
        cout << "preparation_policy: one untimed trace per method fills fixed plaintext caches, then caches are frozen\n";
        cout << "warmups: " << args.warmups << " repeats: " << args.repeats
             << " randomized_order: " << (args.randomize_order ? "true" : "false")
             << " order_seed: " << args.order_seed << "\n";
        cout << "methods:";
        for (const auto &method : methods) cout << ' ' << method->id();
        cout << "\n";
        if (requests_euston) {
            cout << "euston_domain_policy: public-radius parameter selection and exponential refit\n";
        }
        if (requests_nexus) {
            cout << "nexus_range_adaptation: gate=" << nexus_config->gate
                 << " sign_scale=" << nexus_config->sign_scale
                 << " required_scale=" << nexus_config->required_sign_scale
                 << " dg=" << nexus_config->g_rounds
                 << " df=" << nexus_config->f_rounds
                 << " required_levels=" << nexus_required_levels(*nexus_config)
                 << " reserved_levels=" << args.reserve_levels
                 << " max_normalized_argument="
                 << nexus_config->required_sign_scale / nexus_config->sign_scale
                 << " conditioning=" << nexus_config->conditioning_status
                 << " center_abs_max=" << nexus_config->center_abs_max
                 << " gate_condition_max=" << nexus_config->gate_condition_max
                 << " gate_error_budget_1e-3=" << nexus_config->gate_error_budget
                 << " ulp_margin=" << nexus_config->ulp_margin
                 << "\n";
            if (nexus_config->conditioning_status == "ill-conditioned-range-extension") {
                cout << "nexus_warning: the supplied center polynomial grows far outside "
                        "its fitted central interval; encrypted gate error is amplified by "
                     << nexus_config->gate_condition_max
                     << ". This run is an experimental range-extension stress test.\n";
                if (args.scale_bits < 46.0) {
                    cout << "nexus_warning: reduced CKKS precision increases the gate-error "
                            "floor and is not recommended for the R20 extension.\n";
                }
            }
        }

        // Equal preparation trace: every method executes once outside timing.
        for (auto &method : methods) {
            cout << "prepare_trace: " << method->id() << "\n";
            method->evaluate_once();
            const auto &c=method->last_counts();
            if(c.decrypt || c.encrypt || c.decode || c.dynamic_plain_encode)
                throw runtime_error("forbidden client operation in evaluation of "+method->id());
            if(method->metadata().output_chain<args.reserve_levels)
                throw runtime_error("insufficient post-evaluation reserve for "+method->id());
            method->freeze_preparation();
        }

        vector<size_t> order(methods.size());
        iota(order.begin(), order.end(), 0);
        mt19937_64 order_rng(args.order_seed);
        for (int warm = 0; warm < args.warmups; ++warm) {
            if (args.randomize_order) shuffle(order.begin(), order.end(), order_rng);
            for (size_t index : order) methods[index]->evaluate_once();
        }

        vector<MethodResult> results(methods.size());
        for (size_t i = 0; i < methods.size(); ++i) results[i].method = methods[i].get();
        vector<optional<MethodCounts>> expected_counts(methods.size());
        vector<RawSample> raw_samples;
        raw_samples.reserve(static_cast<size_t>(args.repeats) * methods.size());

        for (int round = 0; round < args.repeats; ++round) {
            iota(order.begin(), order.end(), 0);
            if (args.randomize_order) shuffle(order.begin(), order.end(), order_rng);
            if (args.verbose_samples) {
                cout << "round " << round << " order:";
                for (size_t index : order) cout << ' ' << methods[index]->id();
                cout << "\n";
            }
            int position = 0;
            for (size_t index : order) {
                if (args.cooldown_ms > 0) {
                    this_thread::sleep_for(chrono::milliseconds(args.cooldown_ms));
                }
                const auto begin = chrono::steady_clock::now();
                methods[index]->evaluate_once();
                const auto end = chrono::steady_clock::now();
                const double milliseconds =
                    chrono::duration<double, milli>(end - begin).count();
                results[index].samples_ms.push_back(milliseconds);
                raw_samples.push_back(
                    {args.run_label, round, position, methods[index]->id(), milliseconds});
                const MethodCounts &counts = methods[index]->last_counts();
                if (!expected_counts[index]) expected_counts[index] = counts;
                else if (!(counts == *expected_counts[index])) {
                    throw runtime_error("operation counts changed between repeats for " +
                                        methods[index]->id());
                }
                if (args.verbose_samples) {
                    cout << "  sample method=" << methods[index]->id()
                         << " position=" << position
                         << " time_ms=" << fixed << setprecision(3) << milliseconds << "\n";
                }
                ++position;
            }
            cout << "completed_round: " << (round + 1) << "/" << args.repeats << "\n";
        }
        append_samples_csv(args.samples_csv, raw_samples);

        for (size_t i = 0; i < methods.size(); ++i) {
            MethodResult &result = results[i];
            result.timing = summarize_samples(result.samples_ms);
            const vector<double> decoded = methods[i]->decode_last();
            for(double v:decoded) if(!isfinite(v))
                throw runtime_error("nonfinite decoded output for "+methods[i]->id());
            for(double v:methods[i]->plain_reference()) if(!isfinite(v))
                throw runtime_error("nonfinite plaintext reference for "+methods[i]->id());
            result.total_error = compute_metrics_spread(decoded, exact, args.slots_to_test);
            result.method_bias = compute_metrics_spread(
                methods[i]->plain_reference(), exact, args.slots_to_test);
            result.ckks_extra = compute_metrics_spread(
                decoded, methods[i]->plain_reference(), args.slots_to_test);
            {
                vector<double> fit_values(raw_values.size());
                for (size_t k = 0; k < raw_values.size(); ++k) {
                    fit_values[k] = methods[i]->fit_activation(raw_values[k]);
                }
                const vector<double> *unrounded = methods[i]->unrounded_reference();
                const vector<double> &p_c = unrounded ? *unrounded : methods[i]->plain_reference();
                ErrorDecomposition &d = result.decomposition;
                d.e_target = compute_metrics_spread(fit_values, exact, args.slots_to_test).max_abs;
                d.e_poly = compute_metrics_spread(p_c, fit_values, args.slots_to_test).max_abs;
                d.e_coeff = unrounded
                    ? compute_metrics_spread(methods[i]->plain_reference(), *unrounded, args.slots_to_test).max_abs
                    : 0.0;
                d.e_he = result.ckks_extra.max_abs;
                d.e_total = result.total_error.max_abs;
                d.bound = d.e_target + d.e_poly + d.e_coeff + d.e_he;
                d.bound_holds = d.e_total <= d.bound * (1.0 + 1e-9) + 1e-15;
                if (!d.bound_holds) {
                    throw runtime_error("error decomposition bound violated for " + methods[i]->id());
                }
            }
            result.counts = methods[i]->last_counts();
            result.metadata = methods[i]->metadata();
            result.stage_counts = methods[i]->stage_counts();
            if (methods[i]->is_euston() && args.euston_breakdown_repeats > 0) {
                result.stage_timing = methods[i]->euston_breakdown(
                    args.euston_breakdown_repeats);
            }
        }

        double spa_k87_median = numeric_limits<double>::quiet_NaN();
        double moai_median = numeric_limits<double>::quiet_NaN();
        double nexus_median = numeric_limits<double>::quiet_NaN();
        double euston_median = numeric_limits<double>::quiet_NaN();
        for (const auto &result : results) {
            if (result.method->id() == "spa-k87") spa_k87_median = result.timing.median;
            if (result.method->id() == "moai") moai_median = result.timing.median;
            if (result.method->id() == "nexus") nexus_median = result.timing.median;
            if (result.method->id() == "euston") euston_median = result.timing.median;
        }

        cout << "\n================ GELU SUMMARY ================\n";
        cout << scientific << setprecision(8);
        for (const MethodResult &result : results) {
            const MethodMetadata &meta = result.metadata;
            const double speedup_spa_k87 = isfinite(spa_k87_median)
                                                 ? spa_k87_median / result.timing.median
                                                 : numeric_limits<double>::quiet_NaN();
            const double speedup_moai = isfinite(moai_median)
                                          ? moai_median / result.timing.median
                                          : numeric_limits<double>::quiet_NaN();
            const double speedup_nexus = isfinite(nexus_median)
                                           ? nexus_median / result.timing.median
                                           : numeric_limits<double>::quiet_NaN();
            const double speedup_euston = isfinite(euston_median)
                                            ? euston_median / result.timing.median
                                            : numeric_limits<double>::quiet_NaN();
            cout << "\nmethod: " << result.method->id() << "\n";
            cout << "family: " << meta.family << "\n";
            cout << "input_semantics: " << meta.input_semantics << "\n";
            cout << "parameter_policy: " << meta.parameter_policy << "\n";
            cout << "native_target: " << meta.native_target << "\n";
            cout << "reference_gap_semantics: " << meta.reference_gap_semantics << "\n";
            cout << "reference_gap_is_ckks_only: "
                 << (meta.reference_gap_is_ckks_only ? "true" : "false") << "\n";
            cout << "timing_ms: median=" << result.timing.median
                 << " p25=" << result.timing.p25
                 << " p75=" << result.timing.p75
                 << " p95=" << result.timing.p95
                 << " best=" << result.timing.best
                 << " mean=" << result.timing.mean
                 << " stddev=" << result.timing.stddev << "\n";
            cout << "speedup_vs_spa_k87_median: " << speedup_spa_k87 << "\n";
            cout << "speedup_vs_moai_median: " << speedup_moai << "\n";
            cout << "speedup_vs_nexus_median: " << speedup_nexus << "\n";
            cout << "speedup_vs_euston_median: " << speedup_euston << "\n";
            if (meta.family == "SPA-GELU") {
                cout << "profile_catalog_sha256: " << meta.profile_catalog_sha256 << "\n";
                cout << "spa_tier: " << meta.spa_tier << "\n";
                cout << "degree_schedule: " << meta.degree_schedule << "\n";
                cout << "active_profile: " << meta.active_profile << "\n";
                cout << "active_square_degree: " << meta.active_degree_square << "\n";
                cout << "active_ps_split: " << meta.active_ps_split << "\n";
                cout << "active_ps_blocks: " << meta.active_ps_blocks << "\n";
                cout << "offline_max_abs_error: " << meta.offline_max_error << "\n";
                cout << "offline_rmse: " << meta.offline_rmse << "\n";
            }
            cout << "implementation_revision: " << CSV_SCHEMA << "\n";
            cout << "bootstraps: 0\n";
            cout << "actual_scale_bits: " << (meta.evaluation_scale_bits>0.?meta.evaluation_scale_bits:args.scale_bits) << "\n";
            cout << "contexts: " << meta.context_count
                 << " main_modulus_bits=" << meta.main_modulus_bits
                 << " auxiliary_modulus_bits=" << meta.auxiliary_modulus_bits << "\n";
            cout << "main_chain: fresh=" << meta.fresh_chain
                 << " output=" << meta.output_chain
                 << " consumed=" << (meta.fresh_chain - meta.output_chain)
                 << " remaining=" << meta.output_chain << "\n";
            if (meta.auxiliary_fresh_chain >= 0) {
                cout << "auxiliary_chain: fresh=" << meta.auxiliary_fresh_chain
                     << " output=" << meta.auxiliary_output_chain
                     << " consumed=" << (meta.auxiliary_fresh_chain - meta.auxiliary_output_chain)
                     << "\n";
            }
            cout << "output_scale_log2: " << meta.output_scale_log2 << "\n";
            cout << "prepared_fixed_plaintexts: " << meta.prepared_plaintexts << "\n";
            cout << "operation_counts: " << count_prefix(result.counts) << "\n";
            cout << "total_max_abs_error: " << result.total_error.max_abs << "\n";
            cout << "total_mean_abs_error: " << result.total_error.mean_abs << "\n";
            cout << "total_rmse: " << result.total_error.rmse << "\n";
            cout << "native_target_id: " << NATIVE_TARGET_ID << "\n";
            cout << "fit_target_id: " << result.method->fit_target_id() << "\n";
            cout << "e_target: " << result.decomposition.e_target << "\n";
            cout << "e_poly: " << result.decomposition.e_poly << "\n";
            cout << "e_coeff: " << result.decomposition.e_coeff << "\n";
            cout << "e_he: " << result.decomposition.e_he << "\n";
            cout << "e_total: " << result.decomposition.e_total << "\n";
            cout << "decomposition_bound: " << result.decomposition.bound
                 << " (holds: " << (result.decomposition.bound_holds ? "true" : "false") << ")\n";
            if (meta.rounding_decimals >= 0) {
                cout << "spa_rounding_decimals: " << meta.rounding_decimals
                     << " derived_from: " << meta.derived_from << "\n";
            }
            cout << "method_bias_max_abs_error: " << result.method_bias.max_abs << "\n";
            cout << "method_bias_rmse: " << result.method_bias.rmse << "\n";
            cout << "reference_gap_max_abs_error: " << result.ckks_extra.max_abs << "\n";
            cout << "reference_gap_rmse: " << result.ckks_extra.rmse << "\n";
            if (meta.reference_gap_is_ckks_only) {
                cout << "ckks_extra_max_abs_error: " << result.ckks_extra.max_abs << "\n";
                cout << "ckks_extra_rmse: " << result.ckks_extra.rmse << "\n";
            }
            if (meta.family == "SPA-GELU") {
                cout << "outside_profile_count: " << meta.outside_profile_count << "\n";
                cout << "max_abs_x_over_R: " << meta.max_abs_x_over_R << "\n";
            }
            for (const auto &[stage, counts] : result.stage_counts) {
                cout << "euston_stage_counts_" << stage << ": " << count_prefix(counts) << "\n";
            }
            for (const auto &[stage, timing] : result.stage_timing) {
                cout << "euston_stage_" << stage << "_ms: median=" << timing.median
                     << " p25=" << timing.p25 << " p75=" << timing.p75
                     << " best=" << timing.best << "\n";
            }
            append_summary_csv(args.csv_out, args, result, speedup_spa_k87,
                               speedup_moai, speedup_nexus, speedup_euston);
        }
        cout << defaultfloat;
        if (!args.csv_out.empty()) cout << "summary_csv_appended: " << args.csv_out << "\n";
        if (!args.samples_csv.empty()) cout << "samples_csv_appended: " << args.samples_csv << "\n";
        return 0;
    } catch (const exception &error) {
        cerr << "ERROR: " << error.what() << "\n";
        return 1;
    }
}
